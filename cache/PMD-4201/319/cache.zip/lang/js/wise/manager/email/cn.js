$.extend(true, Lang, {
	"js/wise/manager/email/rule/object.js": {
		"email": "电子邮件",
		"send": "传送"
	}
});