$.extend(true, Lang, {
	"pmGlobal": {
		"none": "无设置任何模块。",
		"V": "电压",
		"I": "电流",
		"KW": "实功率",
		"kvar": "无效功率",
		"kVA": "视在功率",
		"PF": "功率因数",
		"kWh": "kWh",
		"kvarh": "kvarh",
		"kVah": "kVAh",
		"kWh_day": "本日累计用电度数",
		"kWh_month": "本月累计用电度数",
		"kWh_year": "本年累计用电度数",
		"co2_day": "本日累计排碳量",
		"co2_month": "本月累计排碳量",
		"co2_year": "本年累计排碳量",
		"maxKw_hour": "本小时最高需求量",
		"maxKw_day": "本日最高需求量",
		"maxKw_month": "本月最高需求量",
		"kW_now": "实际需求量",
		"kW_predict": "预测需求量",
		"aphase": "A相",
		"bphase": "B相",
		"cphase": "C相",
		"sum_average": "总和/平均",
		"loop": "回路",
		"channel": "通道",
		"sum": "总和",
		"average": "平均",
		"internalRegister": "内部缓存器",
		"enterValue": "请输入数值：",
		"submeter":"子电测模块"
	},
	"pmmsg": {
		"loadingError": "数据读取错误，请再试一次。",
		"getValueError": "数据读取错误!",
		"noSup": "此项目不支持!",
		"noFile": "无记录档案。"
	},
	"html/mobile/home/main.htm": {
		"Home": "首页",
		"PMCName": "名称",
		"Firmware": "韧体版本",
		"SDSpace": "microSD卡剩余空间",
		"approxXDays": "约剩$day天",
		"Date": "日期",
		"Time": "时间",
		"ContractCapacity":"契约容量",
		"pmNumber": "电测模块数量",
		"ioNumber": "I/O模块数量",
		"XB": "XW-Board",
		"pm": "电测模块",
		"io": "I/O模块",
		"PMCInfo": "PMC资讯",
		"ModuleList": "电测模块列表",
		"Module": "模块",
		"Interface": "介面",
		"Address": "地址"
	},
	"html/mobile/home/menu.htm": {
		"Menu": "主选单",
		"Home": "首页",
		"meterInfo": "电测模块信息",
		"ElectricityInfo": "电力信息",
		"ioinfo": "I/O信息",
		"eventRecord": "事件记录",
		"realTimeInfo": "电测模块实时信息",
		"historyTimeInfo": "电测模块历史信息",
		"custom": "其他信息",
		"groupInfo": "群组资讯"
	},
	"html/mobile/home/default.htm": {
		//copy WISE default
		"internalRegister": "内部缓存器",
		"no": "编号",
		"channel": "通道",
		"address": "地址",
		"counter": "计数器:",
		"enterValue": "请输入数值：",
		"valueOfChannel": "$channel数值：",
		"none": "无",
		"diCounterX": "DI计数器$channel",
		"internalRegisterX": "内部缓存器$no",
		"popup": {
			"module": "模块：",
			"channel": "通道：",
			"value": "数值："
		}
	},
	"html/mobile/home/event.htm": {
		"eventRecord": "事件记录",
		"logNone": "无任何事件记录。",  
		"time": "时间",
		"type": "类型",
		"content": "内容",
		"result": "结果"
	},
	"html/mobile/home/pm_overview/pm_overview.htm": {
		"prinfo": "电力信息",
		"Filters": "过滤器",
		"Apply": "确定"
	},
	"html/mobile/home/pm_view/pm_view.htm": {
		"MeterParameterInformation": "电测模块参数信息",
		"realTimeInfo": "电测模块实时信息",
		"Nickname": "名称",
		"index": "电测模块地址",
		"tcpIndex": "编号",
		"ip": "IP地址",
		"portTcp": "端口",
		"netId": "NetID",
		"type": "型号",
		"pt": "PT比值",
		"ct": "CT比值",
		"portRtu": "通讯端口",
		"ActualDemand": "分钟实际需求量",
		"ForecastDemand": "分钟预测需求量",
		"ContractCapacity": "契约容量",
		"doInfo": "电测模块DO信息"
	},
	"html/mobile/home/pm_view/custom.htm": {
		"ptRatio": "PT比值",
		"ctRatio": "CT比值",
		"wiringMode": "接线模式",
		"voltageMode": "电压模式",
		"status": "状态",
		"setting": "设置",
		"phaseSequence": "相序",
		"refresh": "更新数据",
		"popup":{
			"thisFieldRangeIsBetweenAToB": "此字段输入范围为 $minimum ~ $maximum。",
			"thisFieldRangeIsGreaterEqualX": "此字段输入范围为大于或等于 $minimum。",
			"thisFieldRangeIsLessEqualX": "此字段输入范围为小于或等于 $maximum。",
			"thisFieldOnlyAllowInputInteger": "此字段限输入整数。",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "此字段限输入整数或浮点数。"
		}
	},
	"html/mobile/home/pm_view/hy_chart.htm": {
		"Inquiry": "查询",
		"dateRange": "日期范围",
		"historyTimeInfo": "电测模块历史资讯",
		"item": "项目",
		"date": "日期",
		"time": "时间"
	},
	"html/mobile/home/group_view/group_view.htm":{
		"MainGroup": "主群组",
		"CiGroup": "次群组",
		"GroupInformation": "群組参数信息",
		"realTimeInfo": "群組实时信息"
	}
});