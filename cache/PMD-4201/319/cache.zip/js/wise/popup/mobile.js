function showAlert(message){
	popupWindow(4, message);
}

function showPrompt(message, value, callback){
	popupWindow(5, message, {"callback": callback, "value": value});
}

function popupWindow(mode, message, settings){
	settings = $.extend(true, {
		"okButtonText": "<#Lang.global.ok>",
		"cancelButtonText": "<#Lang.global.cancel>",
		"callback": function(){},
		"value": ""
	}, settings);

	$('#popupWindowCancelButton, #popupWindowTitleLeft, #popupWindowTitleCenter, #popupWindowInput').hide();

	if(mode == 0){//Confirm
		$("#popupWindowTitleLeft").show();
		$('#popupWindowBlockIcon').attr("class", "icons2 warning");
		$("#popupWindowCancelButton").show();
	}
	else if(mode == 1){//Error
		$("#popupWindowTitleLeft").show();
		$('#popupWindowBlockIcon').attr("class", "icons2 error");
	}
	else if(mode == 2){//Done
		$("#popupWindowTitleLeft").show();
		$('#popupWindowBlockIcon').attr("class", "icons2 ok");
	}
	else if(mode == 3){//Alarm
		$("#popupWindowTitleLeft").show();
		$('#popupWindowBlockIcon').attr("class", "icons2 warning");
	}
	else if(mode == 4){//replace window.alarm
		$("#popupWindowTitleCenter").show();
	}
	else{//replace window.prompt
		$("#popupWindowTitleCenter, #popupWindowInput, #popupWindowCancelButton").show();
	}

	$("#popupWindowOKButton").html(settings.okButtonText);
	$("#popupWindowCancelButton").html(settings.cancelButtonText);

	popupCallback = function(result){//assign callback function
		$("html, body").css({"overflow": "auto"});

		if(mode != 5){
			settings.callback(result);
		}
		else{
			settings.callback(result == true ? $("#popupWindowInput").val() : null);
		}
	};

	$('#popupWindowContent').empty().append(message || "");
	$('#popupWindow').show();

	if(mode != 5){
		$('#popupWindowOKButton').focus();
	}
	else{
		$('#popupWindowInput').val(settings.value).select().focus();
	}

	$("html, body").css({"overflow": "hidden"});
}

function popupButtonClick(result){
	$('#popupWindow').hide();
	popupCallback(result);
}
