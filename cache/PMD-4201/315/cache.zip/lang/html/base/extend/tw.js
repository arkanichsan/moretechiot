﻿$.extend(true, Lang, {
	"global": {
		"ctX": "CT$no",
		"submeterX": "子電錶$no",
		"phaseX": "相位$no",
		"totalOrAverage": "總和 / 平均",
		"basicValue": "基本數值",
		"statisticsValue": "統計數值",
		"ioInformation": "I/O資訊",
		"otherInformation": "其他資訊"
	}
});