﻿$.extend(true, Lang, {
	"js/wise/manager/bluemix/rule/object.js": {
		"connectionStatus": "Connection Status",
		"offline": "Offline",
		"online": "Online",
		"bluemixConnectionStatus": "IBM Bluemix Connection Status",
		"subscribeMessage": "Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"functionStatus": "Function Status",
		"bluemixFunctionStatus": "IBM Bluemix Function Status",
		"publishMessage": "Publish Message",
		"publish": "Publish",
		"bluemixPublishMessage": "IBM Bluemix Publish Message"
	}
});