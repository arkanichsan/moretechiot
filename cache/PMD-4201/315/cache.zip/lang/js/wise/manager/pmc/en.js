﻿$.extend(true, Lang, {
	"js/wise/manager/pmc/base.js": {
		"someoneGroupsAreError": "One or more power meter(s) set in the power meter setting section has been removed. Please check your settings."
	}
});