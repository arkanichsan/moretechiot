﻿$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"register": "内部缓存器"
	}
});