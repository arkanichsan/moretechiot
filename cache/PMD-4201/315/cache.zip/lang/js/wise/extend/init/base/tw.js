$.extend(true, Lang, {
	"js/wise/extend/init/base.js": {
		"V": "電壓",
		"I": "電流",
		"kW": "實功率",
		"kvar": "無效功率",
		"kVA": "視在功率",
		"PF": "功率因數",
		"actualDemand": "實際需量",
		"forecastDemand": "預測需量",
		"hourlyMaximumDemand": "本小時最高需量",
		"dailyMaximumDemand": "本日最高需量",
		"monthlyMaximumDemand": "本月最高需量",
		"dailyAccumElectricity": "本日累計用電度數",
		"monthlyAccumElectricity": "本月累計用電度數",
		"yearlyAccumElectricity": "本年累計用電度數",
		"wiringType": {
			"0": "無",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT",
			"6": "3P3W2CT(HW)",
			"7": "3P3W3CT(HW)",
			"8": "3P4W3CT(HW)"
		},
		"wiringMode": {
			"0": "自動",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT"
		},
		"voltageMode": {
			"0": "自動",
			"1": "相電壓",
			"2": "線電壓"
		},
		"phaseSequence": {
			"0": "逆相序",
			"1": "正相序"
		}
	}
});