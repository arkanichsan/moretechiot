var title = "PMMS - ICP DAS";

var copyRight = "&copy; ICP DAS Co., Ltd. All Rights Reserved";