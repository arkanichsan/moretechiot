function filterOutInuseExtendedModuleFromCommand(xmlFiles, key){
	var deferred = $.Deferred();

	$.ajax({ 
		url: "./dll/wise.dll",
		type: "POST",
		data: "<?xml version='1.0' encoding='utf-8'?><USED_METER_LIST key='" + key + "'/>",
		contentType: "text/xml",
		processData: false,
		cache: false,
		dataType: "xml",
		success: function(xmlDoc){
			var $xmlUSED_METER_LIST = $(xmlDoc).find("USED_METER_LIST");
			if($xmlUSED_METER_LIST.attr("reply") == "kick"){
				deferred.reject();
				return;
			}

			var $xmlPMs = $xmlUSED_METER_LIST.children("PM");
			for(var i = 0; i < $xmlPMs.length; i++){
				var $xmlPM = $($xmlPMs[i]);

				xmlFiles.push("<PM_FILE name='" + $xmlPM.attr("name") + "' group='" + $xmlPM.attr("group") + "' module_type='" + $xmlPM.attr("module_type") + "' key='" + key + "'/>");
			}

			deferred.resolve();
		}
	});

	return deferred.promise();
}

function filterOutInuseExtendedModuleFromRule(xmlDoc){
	var xmlFiles = [];
	
	var $xmlMETERs = $(xmlDoc).find("MODULE > METER");
	for(var i = 0; i < $xmlMETERs.length; i++){
		var $xmlMODULE = $($xmlMETERs[i]).parent();
		var manufacturer = $xmlMODULE.attr("meter_group");
		var modelName = $xmlMODULE.attr("meter_name");

		if(!(manufacturer && modelName)){continue;}//not extended module

		var protocol = $xmlMODULE.attr("ip") ? "modbusTCP" : "modbusRTU";

		try{
			if(typeof(WISE.managers.moduleManager.modbusModule.powerMeterInformation[protocol][manufacturer][modelName]) == "undefined"){
				throw "not found";
			}
		}
		catch(error){
			xmlFiles.push("<PM_FILE name='" + modelName + "' group='" + manufacturer + "' module_type='" + {"modbusRTU": "RTU", "modbusTCP": "TCP"}[protocol] + "' key='" + WISE.getUser().key + "'/>");
		}
	}

	return xmlFiles;
}