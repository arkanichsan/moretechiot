function popupConfirmWindow(message, callback){
	popupWindow(0, message, (typeof(callback) != "function" ? callback : {"callback": callback}));
}

function popupAlarmWindow(message, callback){
	popupWindow(3, message, (typeof(callback) != "function" ? callback : {"callback": callback}));
}

function popupErrorWindow(message, callback){
	popupWindow(1, message, (typeof(callback) != "function" ? callback : {"callback": callback}));
}

function popupDoneWindow(message, callback){
	popupWindow(2, message, (typeof(callback) != "function" ? callback : {"callback": callback}));
}

function popupCallback(result){}//default popup window callback function. If click OK button, then the result is true, otherwise is false.
