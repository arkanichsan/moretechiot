WISE.managers.systemManager.pool.conditions = {
	"sdCard": {
		"name": "<#Lang['?'].sdCardStatus>",
		"fileName": "csdcard",
		"rule":{
			"value": 0
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			var valueString = ["<#Lang['?'].abnormal>"];

			return this.name + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	}
};

WISE.managers.systemManager.pool.actions = {
	"reboot": {
		"name": "<#Lang['?'].rebootSystem>",
		"fileName": "areboot",
		"rule":{
			"frequency": -1
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			return this.name;
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	},
	"delay": {
		"name": "<#Lang['?'].delayProcess>",
		"fileName": "adelay",
		"rule":{
			"delay": 5,
			"frequency": 0
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			return this.name + " " + ruleColor(this.rule.delay + " <#Lang.global.secondOrSeconds>", 2);
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	}
};

WISE.managers.systemManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['sdCard']['key'] = [];
	this.pool.actions['reboot']['key'] = [];
	this.pool.actions['delay']['key'] = [];

	this.pool.conditions['sdCard']['key'].push(true);

	this.pool.actions['reboot']['key'].push(true);
	this.pool.actions['delay']['key'].push(true);
};