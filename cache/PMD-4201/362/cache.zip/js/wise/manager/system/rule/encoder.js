WISE.managers.systemManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "sdCard"){
			xmlDoc.setAttribute("l_obj", "MICROSD");
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "reboot"){
			xmlDoc.setAttribute("l_obj", "REBOOT");
			xmlDoc.setAttribute("op", "1");
		}
		else if(ruleObject.ruleObjectKey == "delay"){
			xmlDoc.setAttribute("l_obj", "DELAY");
			xmlDoc.setAttribute("op", ruleObject.rule.frequency);
			xmlDoc.setAttribute("interval", ruleObject.rule.delay);
		}
	}
};