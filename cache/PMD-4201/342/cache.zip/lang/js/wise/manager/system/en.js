$.extend(true, Lang, {
	"js/wise/manager/system/rule/object.js": {
		"sdCardStatus": "SD Card Status",
		"abnormal": "Abnormal",
		"signalStrength": "Mobile Network Signal Strength",
		"rebootSystem": "Reboot System",
		"resetModem": "Reset Modem",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message"
	}
});