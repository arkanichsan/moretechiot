var WISE = (function(){
	return new function(){
		var user = {
			"character": null,
			"key": null
		};

		this.timerKey = {"content": -1, "menu": -1};
		this.$ = null;
		this.managers = {};

		this.hashPool = {};
		this.hashChange = function(){
			/*restore manager.originalPool to manager.pool*/
			var currentHash = currentLevel.join("/");
			//var keys = Object.keys(this.hashPool);//IE8 not support
			var keys = [];
			for(var key in this.hashPool){
				keys.push(key);
			}
			keys.sort();
			keys.reverse();

			for(i = 0; i < keys.length; i++){
			    var hash = keys[i];

				if(hash.length > currentHash.length || hash != currentHash.substr(0, hash.length)){
					for(var managerKey in this.hashPool[hash]){
						if(this.managers[managerKey].originalPool.length > 0){
							this.managers[managerKey].pool = this.managers[managerKey].originalPool[this.managers[managerKey].originalPool.length - 1];
							this.managers[managerKey].originalPool.pop();
						}
					}

					delete this.hashPool[hash];
				}
			}
		};

		this.ajaxPool = {"content": [], "menu": []};
		this.timerPool = {"content": [], "menu": [], "global": []};
		this.ajaxAbortPool = this.ajaxPool;//legendary code, discard

		this.bindFunctions = {
			"beforeLoad": {},
			"beforeSave": {},
			"beforeParse": {},
			"beforeLogout": {},
			"afterLoad": {},
			"afterSave": {},
			"afterParse": {}
		};
/*
		this.addCondition = function(managerKey, ruleObjectKey, ruleObject){
			this.managers[managerKey].pool.conditions[ruleObjectKey] = ruleObject;
			this.managers[managerKey].pool.conditions[ruleObjectKey].managerKey = managerKey;
			this.managers[managerKey].pool.conditions[ruleObjectKey].ruleObjectKey = ruleObjectKey;
			this.managers[managerKey].pool.conditions[ruleObjectKey].ruleObjectType = "conditions";
		};

		this.addAction = function(managerKey, ruleObjectKey, ruleObject){
			this.managers[managerKey].pool.actions[ruleObjectKey] = ruleObject;
			this.managers[managerKey].pool.actions[ruleObjectKey].managerKey = managerKey;
			this.managers[managerKey].pool.actions[ruleObjectKey].ruleObjectKey = ruleObjectKey;
			this.managers[managerKey].pool.actions[ruleObjectKey].ruleObjectType = "actions";
		};
*/
		this.initialWISE = function(){
			for(var managerKey in WISE.managers){//copy default pool to wise.pool
				this.managers[managerKey].key = managerKey;

				//insert something information
				for(var i = 0, typeArray = ["conditions", "actions"]; i < typeArray.length; i++){
					for(var ruleObjectKey in this.managers[managerKey].pool[typeArray[i]]){
						this.managers[managerKey].pool[typeArray[i]][ruleObjectKey].managerKey = managerKey;
						this.managers[managerKey].pool[typeArray[i]][ruleObjectKey].ruleObjectKey = ruleObjectKey;
						this.managers[managerKey].pool[typeArray[i]][ruleObjectKey].ruleObjectType = typeArray[i];
					}
				}

				this.managers[managerKey].originalPool = [];
				this.managers[managerKey].cleanPool = $.extend(true, {}, this.managers[managerKey].pool);
				this.managers[managerKey].clearPool = function(){
					this.pool = $.extend(true, {}, this.cleanPool);
				};

				this.managers[managerKey].createTempPool = function(defaultRootHash){
					var currentHash = typeof(defaultRootHash) != "undefined" ? defaultRootHash.substr(1) : currentLevel.join("/");
					var previousHash = previousLevel.join("/");

					if(currentHash != previousHash.substr(0, currentHash.length)){//parent doesn't create temp pool(into children path)
						this.originalPool.push($.extend(true, {}, this.pool));

						if(typeof(WISE.hashPool[currentHash]) == "undefined"){
							WISE.hashPool[currentHash] = {};
						}

						WISE.hashPool[currentHash][this.key] = true;
					}
				};

				this.managers[managerKey].saveTempPool = function(){
					this.updateRuleObject();
					this.originalPool[this.originalPool.length - 1] = $.extend(true, {}, this.pool);
				};

				this.managers[managerKey].hasTempPool = function(rootHash){
					rootHash = rootHash.substr(1);

					try{
						if(WISE.hashPool[rootHash][this.key] == true){
							return true;
						}
						else{
							throw "noTempPoolExist";
						}
					}
					catch(error){
						return false;
					}
				};
			}
		};

		this.createWISE = function(modelName){
			var wise = {
				"pool": {//keep all manager pool, when change WISE profile
					"managers": {}
				},
				"cleanPool": null,
				"rulePool": null,//the pool is consistent with rule file, if rule not load, the content is clean pool
				"ruleXMLString": null,//compare rule change when user logout, assign this value when invoke setWISE.
				"name": modelName,
				"modelName": modelName
			};

			for(var managerKey in this.managers){//create pool
				wise.pool.managers[managerKey] = $.extend(true, {}, this.managers[managerKey].cleanPool);
			}

			if(modelName == "PMD-2201"){
				wise.pool.managers.moduleManager.interfaces.comport[1] = WISE.managers.moduleManager.createInterface("comport485", "COM1", 1000, 16);
				wise.pool.managers.moduleManager.interfaces.comport[2] = WISE.managers.moduleManager.createInterface("comport485", "COM2", 21000, 16);
				wise.pool.managers.moduleManager.interfaces.network[0] = WISE.managers.moduleManager.createInterface("network", "LAN", 41000, 16);

				wise.pool.managers.moduleManager.interfaces.comport[1].dcon.enable = false;
				wise.pool.managers.moduleManager.interfaces.comport[1].protocol = "modbusRTU";
				wise.pool.managers.moduleManager.interfaces.comport[1].baudrate = 19200;
				wise.pool.managers.moduleManager.interfaces.comport[1].modbusRTU.silentInterval = 100;

				wise.pool.managers.moduleManager.interfaces.comport[2].dcon.enable = false;
				wise.pool.managers.moduleManager.interfaces.comport[2].protocol = "modbusRTU";
				wise.pool.managers.moduleManager.interfaces.comport[2].baudrate = 19200;
				wise.pool.managers.moduleManager.interfaces.comport[2].modbusRTU.silentInterval = 100;

				wise.pool.managers.moduleManager.interfaces.network[0].protocol = "modbusTCP";
			}
			else if(modelName == "PMD-4201"){
				wise.pool.managers.moduleManager.interfaces.comport[1] = WISE.managers.moduleManager.createInterface("comport485", "COM1", 1000, 16);
				wise.pool.managers.moduleManager.interfaces.comport[2] = WISE.managers.moduleManager.createInterface("comport485", "COM2", 21000, 16);
				wise.pool.managers.moduleManager.interfaces.comport[3] = WISE.managers.moduleManager.createInterface("comport485", "COM3");//only allow hmi, so no specific the address and module amount
				wise.pool.managers.moduleManager.interfaces.network[0] = WISE.managers.moduleManager.createInterface("network", "LAN", 41000, 16);

				wise.pool.managers.moduleManager.interfaces.comport[1].dcon.enable = false;
				wise.pool.managers.moduleManager.interfaces.comport[1].protocol = "modbusRTU";
				wise.pool.managers.moduleManager.interfaces.comport[1].baudrate = 19200;
				wise.pool.managers.moduleManager.interfaces.comport[1].modbusRTU.silentInterval = 100;

				wise.pool.managers.moduleManager.interfaces.comport[2].dcon.enable = false;
				wise.pool.managers.moduleManager.interfaces.comport[2].protocol = "modbusRTU";
				wise.pool.managers.moduleManager.interfaces.comport[2].baudrate = 19200;
				wise.pool.managers.moduleManager.interfaces.comport[2].modbusRTU.silentInterval = 100;

				wise.pool.managers.moduleManager.interfaces.comport[3].dcon.enable = false;
				wise.pool.managers.moduleManager.interfaces.comport[3].modbusRTU.enable = false;

				wise.pool.managers.moduleManager.interfaces.network[0].protocol = "modbusTCP";
			}
			else{
				throw "modelNameNotFound";
			}

			wise.cleanName = wise.name;
			wise.cleanPool = $.extend(true, {}, wise.pool);//create cleanPool
			wise.rulePool = $.extend(true, {}, wise.pool);

			return wise;
		};

		this.setWISE = function(wise, delCurrentWISE){
			this.abortAllManagersTempPool();

			if(this.$ != null && delCurrentWISE != true){//not first wise
				for(var managerKey in this.managers){//save managers pool to wise
					this.$.pool.managers[managerKey] = this.managers[managerKey].pool;
				}
			}

			this.$ = wise;//change current wise

			for(var managerKey in this.managers){//load wise pool to manager
				this.managers[managerKey].pool = this.$.pool.managers[managerKey];
			}

			this.$.ruleXMLString = xmlToString(this.generateRuleFile(true).documentElement);
		};

		this.resetWISE = function(wise){
			wise = wise || this.$;

			if(wise != null){
				this.abortAllManagersTempPool();

				this.$.name = this.$.cleanName;
				delete this.$.originalPool;

				for(var managerKey in this.managers){//load wise clean pool to manager
					this.managers[managerKey].pool = $.extend(true, {}, this.$.cleanPool.managers[managerKey]);
				}
				
				is_editing = false;
			}
		};

		this.bind = function(type, func, key){
			if(typeof(key) == "undefined"){
				key = randomKey(8);
			}
			this.bindFunctions[type][key] = {
				"executable": true,
				"execute": function(){
					if(this.executable == true){
						this.func();
					}
				},
				"func": func
			};
		};

		this.unbind = function(type, key){
			if(typeof(key) != "undefined"){
				delete this.bindFunctions[type][key];
			}
			else{
				this.bindFunctions[type] = {};
			}
		};

		this.bindTurnON = function(type, key){
			this.bindFunctions[type][key].executable = true;
		};

		this.bindTurnOFF = function(type, key){
			this.bindFunctions[type][key].executable = false;
		};

		this.bindFunctionExecute = function(type){
			for(var key in this.bindFunctions[type]){
				this.bindFunctions[type][key].execute();
			}
		};

		this.getUser = function(){
			return user;
		};

		this.setUser = function(character, key, idleTime){
			user.character = character;
			user.key = key;
			user.idleTime = {"0": 600, "1": 1200, "2": 1800, "3": 3600, "99": 0}[idleTime];
			if(typeof(user.idleTime) == "undefined"){
				user.idleTime = 600;
			}
		};

		this.abortAllManagersTempPool = function(){
			this.hashPool = {};
		};

		this.moduleInfo = function(sourceType, sourceIndex, moduleIndex){
			var moduleInfo = "";
			var module = WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

			if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "onboard"){
				moduleInfo += module.displayModelName;
				if(module.name != ""){
					moduleInfo += "(" + module.name + ")";
				}
			}
			else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "comport485"){
				if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "dcon"){
					moduleInfo += module.displayModelName;
					moduleInfo += "(" + module.address;
					if(module.name != ""){
						moduleInfo += ":" + module.name;
					}
					moduleInfo += ")"
				}
				else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusRTU"){
					if(module.type == "icpdas"){//M7K
						moduleInfo += module.displayModelName;
						moduleInfo += "(" + module.address;
						if(module.name != ""){
							moduleInfo += ":" + module.name;
						}
						moduleInfo += ")"
					}
					else{
						moduleInfo += module.name;
						moduleInfo += "(" + module.modbusRTU.address + ")";
					}
				}
			}
			else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "network"){
				if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusTCP"){
					moduleInfo += module.name;
					moduleInfo += "(" + integerToIP(module.modbusTCP.ip) + ":" + module.modbusTCP.port + "/" + module.modbusTCP.netID + ")";
				}
			}

			return moduleInfo;
		};

		this.channelInfo = function(sourceType, sourceIndex, moduleIndex, channelType, channel/*index or address*/){
			var module = WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
			var channelName = "";
			var name = "";

			if(module.type == "icpdas" || module.type == "onboard"){
				var counterType = null;

				if(channelType == "DIC"){
					counterType = channelType; channelType = "DI";
				}
				else if(channelType == "DOC"){
					counterType = channelType; channelType = "DO";
				}

				if(module[channelType].setting[channel].disable == true){
					throw "channelNotExist";
				}

				channelName = module[channelType].setting[channel].channelName;

				if(counterType != null){
					name = module[channelType].setting[channel].counterName;
				}
				else{
					name = module[channelType].setting[channel].name;
				}

				if(counterType != null){channelType = counterType;}//restore channelType
			}
			else{
				channelName = channel;
				name = module[channelType].remoteAddress[channel].name;
			}

/*
			if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "onboard"){
				channelName = module[channelType].setting[channel].channelName;
				name = module[channelType].setting[channel].name;
			}
			else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "comport485"){
				if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "dcon"){
					channelName = module[channelType].setting[channel].channelName;
					name = module[channelType].setting[channel].name;
				}
				else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusRTU"){
					if(module.type == "icpdas"){//M7K
						channelName = module[channelType].setting[channel].channelName;
						name = module[channelType].setting[channel].name;
					}
					else{
						channelName = channel;
						name = module[channelType].remoteAddress[channel].name;
					}
				}
			}
			else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "network"){
				if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusTCP"){
					if(module.type == "icpdas"){//M7K
						channelName = module[channelType].setting[channel].channelName;
						name = module[channelType].setting[channel].name;
					}
					else{
						channelName = channel;
						name = module[channelType].remoteAddress[channel].name;
					}
				}
			}
*/
			return {
				"channelName": channelName.toString(),
				"name": name,
				"toString": function(format){
					var channelInfo = this.channelName + (this.name != "" ? "(" + this.name + ")" : "");

					if(typeof(format) != "undefined" && this.channelName.match(/^\d+$/)){
						return format.replace("$channel", channelInfo);
					}
					else{//customized channel name, like DL
						return channelInfo;
					}
				}
			};
		};

		this.registerInfo = function(registerIndex){
			var registerInfo = "";
			
			registerInfo += registerIndex + 1;
			if(WISE.managers.registerManager.pool.registers[registerIndex].name != ""){
				registerInfo += "(" + WISE.managers.registerManager.pool.registers[registerIndex].name + ")";
			}

			return registerInfo;
		};

		this.generateRuleFile = function(withoutKey){
			var xmlDoc = $.parseXML("<WISE><NOTE/></WISE>");
			if(withoutKey != true){
				xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
			}
			xmlDoc.documentElement.setAttribute("name", this.$.modelName);
			xmlDoc.documentElement.setAttribute("nickname", this.$.name);

			for(var managerKey in this.managers){
				this.managers[managerKey].beforeEncodeRuleFile();
			}

			for(var managerKey in this.managers){
				this.managers[managerKey].updateIndex();
			}
			
			for(var managerKey in this.managers){
				this.managers[managerKey].encodeXMLObject(xmlDoc);
			}

			for(var managerKey in this.managers){
				this.managers[managerKey].afterEncodeRuleFile();
			}

			return xmlDoc;
		};

		this.loadRuleFile = function(settings){
			settings = $.extend(true, {
				"xmlDoc": null,
				"ignoreDefaultHandler": false,
				"success": function(){},
				"error": function(){},
				"complete": function(){}
			}, settings);

			$.Deferred(function(deferred){//load rules file
				WISE.bindFunctionExecute("beforeLoad");

				if(settings.xmlDoc == null){
					var ajaxSettings = {
						contentType: "text/xml",
						processData: false,
						cache: false,
						dataType: "xml",
						done: function(xmlDoc){
							if(xmlDoc.documentElement.nodeName != "WISE"){
								deferred.reject();
								return;
							}

							deferred.resolve(xmlDoc);
						},
						fail: function(){
							deferred.reject();
						}
					};

					if(settings.ignoreDefaultHandler == true){//overwrite global ajax handler
						ajaxSettings.success = function(xmlDoc){
							this.done(xmlDoc);
						};
					
						ajaxSettings.error = function(){
							this.fail();
						};
					}

					if(WISE.getUser().character == "admin"){
						var xmlDoc = $.parseXML("<RULE/>");
						xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

						$.extend(true, ajaxSettings, {
							url: "./dll/wise.dll",
							type: "POST",
							data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false)
						});
					}
					else if(WISE.getUser().character == "guest"){
						$.extend(true, ajaxSettings, {
							url: "rules.xml",
							type: "GET"
						});
					}

					$.ajax(ajaxSettings);
				}
				else{
					deferred.resolve(settings.xmlDoc);
				}

				return deferred.promise();
			}).then(function(xmlDoc){//load extended module setting file
				var deferred = $.Deferred();

				if(typeof(filterOutInuseExtendedModuleFromRule) == "function"){
					fileLoader(filterOutInuseExtendedModuleFromRule(xmlDoc), true).done(function(fileContents){
						var xmlDocArray = [];
						for(var i = 0; i < fileContents.length; i++){
							xmlDocArray.push(fileContents[i]);
						}

						if(WISE.managers.moduleManager.processExtendedModuleSettingFile(xmlDocArray) == false){
							deferred.reject();//some extended module profile not found
						}
						else{
							deferred.resolve(xmlDoc);
						}
					}).fail(function(){
						deferred.reject();
					});
				}
				else{
					deferred.resolve(xmlDoc);
				}

				return deferred.promise();
			}).done(function(xmlDoc){
				var startDecode = function(managerKey, xmlDoc){
					//load wise clean pool to manager
					//WISE.managers[managerKey].pool = $.extend(true, {}, WISE.$.cleanPool.managers[managerKey]);

					WISE.managers[managerKey].decodeXMLObject(xmlDoc);
					//WISE.managers[managerKey].updateIndex();
					WISE.managers[managerKey].updateRuleObject();
				};

				//WISE.bindFunctionExecute("beforeParse");

				WISE.setWISE(WISE.createWISE($(xmlDoc).children("WISE").attr("name")));
				WISE.$.name = $(xmlDoc).children("WISE").attr("nickname");

				for(var managerKey in WISE.managers){
					WISE.managers[managerKey].beforeDecodeRuleFile();
				}

				startDecode("moduleManager", xmlDoc);//decode moduleManager first

				for(var managerKey in WISE.managers){//decode others manager
					if(managerKey == "moduleManager"){continue;}

					startDecode(managerKey, xmlDoc);
				}

				for(var managerKey in WISE.managers){
					WISE.managers[managerKey].afterDecodeRuleFile();
				}

				//generate rule string for every one ruleObject
				var ruleManager = WISE.managers.ruleManager;
				if(typeof(ruleManager) != "undefined"){
					for(var ruleKey in ruleManager.pool.rules){
						var rule = ruleManager.pool.rules[ruleKey];

						for(var i = 0, ruleTypeArray = ["ifConditions", "thenActions", "elseActions"]; i < ruleTypeArray.length; i++){
							for(var j = 0; j < rule[ruleTypeArray[i]].rules.length; j++){

								var ruleObject = rule[ruleTypeArray[i]].rules[j];

								if(ruleObject.check()){
									ruleObject.ruleString = ruleObject.parseToString();
								}
								else{
									ruleObject.ruleString = "N/A";
								}
							}
						}
					}
				}

				//WISE.bindFunctionExecute("afterParse");

				for(var managerKey in WISE.managers){//save managers pool to rulePool
					WISE.$.rulePool.managers[managerKey] = $.extend(true, {}, WISE.managers[managerKey].pool);
				}
				WISE.$.ruleXMLString = xmlToString(WISE.generateRuleFile(true).documentElement);

				settings.success();
			}).fail(function(){
				settings.error();
			}).always(function(){
				settings.complete();
				WISE.bindFunctionExecute("afterLoad");
			});
		};

		this.startAjax = function(ajaxLocation, url, settings){
			var jqXHR = $.ajax(url, settings);

			this.ajaxPool[ajaxLocation].push(jqXHR);

			return jqXHR;
		};

		this.createTimer = function(timerLocation, manualNext){
			timerLocation = timerLocation != "menu" && timerLocation != "content" && timerLocation != "global" ? "content" : timerLocation;
			manualNext = typeof(manualNext) != "boolean" ? false : manualNext;

			var timer = new function() {
				var run = function(){
					//if(hash != (timerLocation == "content" ? currentLevelwithParameter.join("/") : currentLevelwithParameter[0] + "/" + currentLevelwithParameter[1]) || key != WISE.timerKey[timerLocation]){
					////if(hash != location.hash || key != WISE.timerKey){
					//	that.stop();
					//	return;
					//}

					that.process(that);

					if(manualNext != true){
						that.next();
					}
				};
				var that = this, pid = null, /*hash = null, key = this,*/ ajaxPool = [];

				this.process = function(){};//dummy

				this.refreshTime = 5000;

				this.start = function(delayStart){
					//hash = (timerLocation == "content" ? currentLevelwithParameter.join("/") : currentLevelwithParameter[0] + "/" + currentLevelwithParameter[1]);
					//key = WISE.timerKey[timerLocation];
					//hash = location.hash;
					//key = WISE.timerKey;

					this.stop();

					if(delayStart != true){
						run();
					}
					else{
						this.next();
					}
				};

				this.stop = function(){
					for(var i = 0; i < ajaxPool.length; i++){
						ajaxPool[i].abort();
					}
					ajaxPool = [];

					clearTimeout(pid);
					pid = null;
				};

				this.next = function(){
					pid = setTimeout(run, this.refreshTime);
				};

				this.status = function(){//true: running, false: stop
					return pid == null ? false : true;
				};

				this.addAjax = function(jqXHR){
					ajaxPool.push(jqXHR);
					return jqXHR;
				};
			};

			this.timerPool[timerLocation].push(timer);

			return timer;
		};

		this.stopTimers = function(timerLocation){
			timerLocation = timerLocation != "menu" && timerLocation != "content" && timerLocation != "global" ? "content" : timerLocation;

			for(var i = 0; i < this.timerPool[timerLocation].length; i++){
				this.timerPool[timerLocation][i].stop();
			}

			this.timerPool[timerLocation] = [];
		};

		this.stopAllTimers = function(){
			this.stopTimers("content");
			this.stopTimers("menu");
		};

		this.abortAjaxs = function(ajaxLocation){
			ajaxLocation = ajaxLocation != "menu" && ajaxLocation != "content" ? "content" : ajaxLocation;

			for(var i = 0; i < this.ajaxPool[ajaxLocation].length; i++){
				this.ajaxPool[ajaxLocation][i].abort();
			}

			this.ajaxPool[ajaxLocation] = [];
		};

		this.abortAllAjaxs = function(){
			this.abortAjaxs("content");
			this.abortAjaxs("menu");
		};

		this.createAliveChecker = function(settings){
			settings = $.extend(true, {
				"process": function(){},
				"timeout": function(){}
			}, settings);

			return new function(){
				var aliveTimer = (function(){
					return new function() {
						var run = function(){
							that.process();
							pid = setTimeout(run, that.refreshTime);
						};
						var pid = -1;
						var that = this;
						var jqXHR = null;

						this.process = function(){
							var xmlDoc = $.parseXML("<ALIVE/>");
							xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

							jqXHR = $.ajax({ 
								url: "./dll/wise.dll",
								type: "POST",
								data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
								contentType: "text/xml",
								processData: false,
								cache: false,
								dataType: "xml",
								done: function(xmlDoc){
									var $xmlALIVE = $(xmlDoc).find("ALIVE");
									if($xmlALIVE.length > 0){
										settings.process($xmlALIVE);
									}
								}
							});
						};

						this.refreshTime = 60 * 1000;//unit is ms

						this.start = function(){
							run();
						};

						this.stop = function(){
							clearTimeout(pid);
							pid = -1;

							if(jqXHR != null){
								jqXHR.abort();
								jqXHR = null;
							}
						};
					};
				})();

				var pidIdle = null;
				var idleTimeout = function(){
					aliveTimer.stop();
					$(document).unbind("click.aliveTimer");

					var xmlDoc = $.parseXML("<LOGOUT/>");
					xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

					$.ajax({ 
						url: "./dll/wise.dll",
						type: "POST",
						data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
						contentType: "text/xml",
						processData: false,
						cache: false,
						dataType: "xml"
					});

					settings.timeout();
				};

				this.startIdleTimer = function(){
					$(document).unbind("click.aliveTimer").bind("click.aliveTimer", function(){
						clearTimeout(pidIdle);

						if(!(WISE.getUser().idleTime <= 0 || WISE.getUser().character == "guest")){//keep user always log in
							pidIdle = setTimeout(idleTimeout, WISE.getUser().idleTime * 1000);
						}
					}).triggerHandler("click.aliveTimer");
				};

				this.stopIdleTimer = function(){
					clearTimeout(pidIdle);
					$(document).unbind("click.aliveTimer");
				};

				this.startAliveTimer = function(){
					aliveTimer.start();
				};

				this.stopAliveTimer = function(){
					aliveTimer.stop();
				};

				this.startAliveTimer();
				this.startIdleTimer();
			};
		};
	};
})();
