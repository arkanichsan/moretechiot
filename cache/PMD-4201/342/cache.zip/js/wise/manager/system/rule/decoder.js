WISE.managers.systemManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "MICROSD"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.sdCard);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		}
	}
	else if($(xmlDoc).attr("l_obj") == "REBOOT"){
		if(xmlDoc.tagName == "IF"){
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.reboot);

			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			//ruleObject.rule.frequency = 0;
			ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
		}
	}

	return ruleObject;
};