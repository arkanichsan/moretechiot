WISE.managers.systemManager.pool.conditions = {
	"sdCard": {
		"name": "<#Lang['?'].sdCardStatus>",
		"fileName": "csdcard",
		"rule":{
			"value": 0
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			var valueString = ["<#Lang['?'].abnormal>"];

			return this.name + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	}
};

WISE.managers.systemManager.pool.actions = {
	"reboot": {
		"name": "<#Lang['?'].rebootSystem>",
		"fileName": "areboot",
		"rule":{
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			return this.name;
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.value = 1;
		},
		"key": []
	}
};

WISE.managers.systemManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['sdCard']['key'] = [];
	this.pool.actions['reboot']['key'] = [];

	this.pool.conditions['sdCard']['key'].push(true);

	this.pool.actions['reboot']['key'].push(true);
};