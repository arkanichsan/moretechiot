WISE.managers.smsManager = (function(){
	return new function() {
		this.pool = {
			pinCode: {
				plain: "",
				encoded: "",
				length: 0
			},
			allowAccessPhoneNumbers: [],

			smsCommands: {
				enable: false,
				quickCommands: []//	element must be {"customizeCommand": "", "originalCommand": ""}
			},

			smsAlarms: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxSMSAlarmAmount = 12;
		this.maxSMSQuickCommandAmount = 12;

		this.createSMSAlarm = function(settings){
			var smsAlarm = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"phoneNumbers": [],
				"unicode": false,
				"message": ""
			}, settings);

			return smsAlarm;
		};

		this.addSMSAlarm = function(smsAlarm){
			var retKey = this.pool.key;
			this.pool.smsAlarms[this.pool.key++] = smsAlarm;
			return retKey;
		};

		this.removeSMSAlarm = function(smsAlarmKey){
			delete this.pool.smsAlarms[smsAlarmKey];
		};

		this.getSMSAlarm = function(smsAlarmKey){
			if(typeof(this.pool.smsAlarms[smsAlarmKey]) != "undefined"){
				return this.pool.smsAlarms[smsAlarmKey];
			}
			else{
				return null;
			}
		};

		this.setSMSAlarm = function(smsAlarmKey, smsAlarm){
			this.pool.smsAlarms[smsAlarmKey] = smsAlarm;
		};

		this.getSMSAlarms = function(){
			return this.pool.smsAlarms;
		};
	};
})();
