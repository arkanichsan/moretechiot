$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"register": "内部缓存器",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息"
	}
});