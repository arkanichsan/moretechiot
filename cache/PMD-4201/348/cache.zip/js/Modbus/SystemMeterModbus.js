function InserSystemTable(TableObj){
	AddAddress =0;
	var html_str = '';
	html_str +='<div>';
	html_str += InserTableTitle(TypeTitle["DI"]);
	html_str += '<tr>';
	html_str += '<td>Local FTP Server</td>';
	html_str += '<td>' + padLeft((ModbusAddress["DI"]).toString(), padLeft_num) + '</td>';
	html_str += '<td>' + AddressBit["DI"] + '</td>';
	html_str += '<td>' + ModbusDataType["DI"] + '</td>';
	html_str += '<td>0=Disable<br />1=Enable</td>';
	html_str += '</tr>';
	html_str += '</table>';	
	html_str += '</div>';
	html_str += '<div> <br /></div>';
	html_str +='<div>';
	html_str += InserTableTitle(TypeTitle["AI"]);
	html_str += '<tr><td>Module Name</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 2;
	html_str += '<tr><td>Firmware Version</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>2</td><td>Float</td><td>Floating Point</td></tr>';AddAddress += 2;
	html_str += '<tr><td>Serial Number 1</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 2</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 3</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 4</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 5</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 6</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 7</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Serial Number 8</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Date(Year)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1752~</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Date(Month)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~12</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Date(Day)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~31</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Time(Hour)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~23</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Time(Minute)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~59</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Boot Time(Second)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~59</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Alive Count</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Cycle Time</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535(ms)</td></tr>';AddAddress += 1;
	for(var i in WISE.managers.moduleManager.pool.interfaces.onboard)
		{html_str += '<tr><td>'+WISE.managers.moduleManager.pool.interfaces.onboard[i].name+' Name</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535</td></tr>';AddAddress += 1;}
	for(var i in WISE.managers.moduleManager.pool.interfaces.comport)
		if(WISE.managers.moduleManager.pool.interfaces.comport[i].type!="comport232")
			{html_str += '<tr><td>'+WISE.managers.moduleManager.pool.interfaces.comport[i].name+' Connection Status</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0=Offline, 1=Online <br />Each bit represents a module.</td></tr>';AddAddress += 1;}
	html_str += '<tr><td>LAN Connection Status</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0=Offline, 1=Online <br />Each bit represents a module.</td></tr>';AddAddress += 1;
	for(var i in WISE.managers.moduleManager.pool.interfaces.onboard)
		{html_str += '<tr><td>'+WISE.managers.moduleManager.pool.interfaces.onboard[i].name+' Update Rate</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535(ms)</td></tr>';AddAddress += 1;}
	for(var i in WISE.managers.moduleManager.pool.interfaces.comport)
		if(WISE.managers.moduleManager.pool.interfaces.comport[i].type!="comport232")
			{html_str += '<tr><td>'+WISE.managers.moduleManager.pool.interfaces.comport[i].name+' Update Rate</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535(ms)</td></tr>';AddAddress += 1;}
	AddAddress += 1;
	html_str += '<tr><td>Modbus Slave NetID </td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~247</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Modbus TCP Port</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~65535</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Web Port</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~65535</td></tr>';AddAddress += 1;
	
	
	html_str += '<tr><td>SMS Register Status</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>1~65535</tr>';AddAddress += 1;
	html_str += '<tr><td>3G Signal Strength</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>Int16</td><td>-32768~32767(dbm)</td></tr>';AddAddress += 1;
	html_str += '<tr><td>3G Signal Strength (Percent)</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>Int16</td><td>0, 20, 40, 60, 80, 100</td></tr>';AddAddress += 1;
	
	html_str += '<tr><td>micro SD Free Space</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>0~65535(MB)</td></tr>';AddAddress += 1;
	html_str += '<tr><td>FTP Upload Status</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>Int16</td><td>-1=Initializing<br />0=Failed<br />1=Success</td></tr>';AddAddress += 1;
	html_str += '<tr><td>Contract Capacity</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>2</td><td>Float</td><td>0~99999999(kW)</td></tr>';AddAddress += 2;
	html_str += '<tr><td>Carbon Footprint Factor</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>2</td><td>Float</td><td>0.001~99999999</td></tr>';AddAddress += 2;
	html_str += '<tr><td>Calculation Interval for Demand</td><td>'+padLeft((AddAddress+ModbusAddress["AI"]).toString(), padLeft_num)+'</td><td>1</td><td>UInt16</td><td>15 / 30 / 60(minutes)</td></tr>';AddAddress += 1;
	html_str += '</table>';
	html_str += '</div>';
	TableObj.html(html_str);
}