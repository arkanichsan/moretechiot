var Lang = {};

var languageMapping = {
	"zh": "tw",
	"zh-tw": "tw",
	"zh-hk": "tw",
	"zh-sg": "tw",
	"zh-cn": "cn"
};

var defaultLanguage = currentLanguage = languageMapping[(window.navigator.userLanguage || window.navigator.language).toLowerCase()] || "en";

function login(character, key, idleTime, language){
	currentLanguage = language;

	/*logout when unload*/
	$(window).bind("unload", {"key": key}, function(event) {
		$(window).unbind("unload");

		var key = event.data.key;

		try{
			if(WISE.getUser().key != null){
				key = WISE.getUser().key;
			}
		}
		catch(error){}

		if(navigator.sendBeacon){
			navigator.sendBeacon("./dll/wise.dll", "<?xml version='1.0' encoding='utf-8'?><LOGOUT key='" + key + "'/>");
		}
		else{
			$.ajax({
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?><LOGOUT key='" + key + "'/>",
				contentType: "text/xml",
				processData: false,
				cache: false,
				timeout: 3000,//important
				async: false//important
			});
		}
	});

	var closeCurtain = function(){
		$(".loginCurtain").animate({
			"height": "100%"
		}).promise().done(function(){
			$("#loadingLoader").hide();
			$("#loadingContainer").show();

			var aliveKeeper = new function(){//prevent load file spend too much time, send alive keep the session
				var xhr = null;
				var pid = null;
				var that = this;
				var sender = function(){
					that.stop();

					pid = setTimeout(function(){
						xhr = $.ajax({ 
							url: "./dll/wise.dll",
							type: "POST",
							data: "<?xml version='1.0' encoding='utf-8'?><ALIVE key='" + key + "'/>",
							contentType: "text/xml",
							processData: false,
							cache: false,
							dataType: "xml"
						}).always(function(){
							sender();
						});
					}, 60 * 1000);
				};

				this.start = function(){
					sender();
				};

				this.stop = function(){
					if(xhr != null){
						xhr.abort();
					}

					clearTimeout(pid);
				};
			};
			aliveKeeper.start();

			$.Deferred(function(mainDeferred){
				var fileTotalAmount = 1/*for frame.htm*/, fileLoadedAmount = 0;
				var xmlFiles = [];//for extended module setting files

				fileLoader(["./js/wise/setting/desktop.js", "?./js/wise/extend/setting/desktop.js", "?./js/wise/extend/login/base.js"]).done(function(fileContents){
					for(var i = 0; i < fileContents.length; i++){
						insertScript(fileContents[i]);
					}

					fileTotalAmount += cssFiles.length + jsFiles.length + languageFiles.length;
				}).then(function(){
					if(typeof(filterOutInuseExtendedModuleFromCommand) == "function"){
						return filterOutInuseExtendedModuleFromCommand(xmlFiles, key).done(function(){
							fileTotalAmount += xmlFiles.length;
						});
					}
				}).then(function(){//load language file
					return fileLoader(languageFiles).progress(function(loadedAmount){
						mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
					}).done(function(fileContents){
						for(var i = 0; i < fileContents.length; i++){
							insertScript(fileContents[i]);
						}

						fileLoadedAmount += fileContents.length;
					});
				}).then(function(){//load css, js, html(frame), xml
					return fileLoader(cssFiles).progress(function(loadedAmount){//load css
						mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
					}).done(function(fileContents){
						for(var i = 0; i < fileContents.length; i++){
							insertStyle(fileContents[i]);
						}

						fileLoadedAmount += fileContents.length;
					});
				}).then(function(fileContents){
					return fileLoader(jsFiles).progress(function(loadedAmount){//load js
						mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
					}).done(function(fileContents){
						for(var i = 0; i < fileContents.length; i++){
							fileContents[i] = processLanguage(fileContents[i], jsFiles[i]);
							insertScript(fileContents[i]);
						}

						fileLoadedAmount += fileContents.length;
					});
				}).then(function(fileContents){
					return fileLoader(["html/desktop/frame.htm"]).progress(function(loadedAmount){//load frame
						mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
					}).done(function(fileContents){
						fileContents[0] = processLanguage(fileContents[0], "html/desktop/frame.htm");
						insertHTML(fileContents[0]);

						fileLoadedAmount += fileContents.length;
					});
				}).then(function(fileContents){
					return fileLoader(xmlFiles, true).progress(function(loadedAmount){//load xml
						mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
					}).done(function(fileContents){
						if(typeof(WISE.managers.moduleManager.processExtendedModuleSettingFile) == "function"){
							var xmlDocArray = [];
							for(var i = 0; i < fileContents.length; i++){
								xmlDocArray.push(fileContents[i]);
							}

							WISE.managers.moduleManager.processExtendedModuleSettingFile(xmlDocArray);
						}

						fileLoadedAmount += fileContents.length;
					});
				}).done(function(){
					mainDeferred.resolve();
				}).fail(function(){
					mainDeferred.reject();
				});

				return mainDeferred.promise();
			}).progress(function(fileLoadedAmount, fileTotalAmount){
				var percent = parseInt((fileLoadedAmount) / (fileTotalAmount + 1/*1 for load rule file*/) * 100, 10);
				$("#loadingProgress").css("width", percent + "%");
				$("#loadingPercent").text(percent + "%");
			}).done(function(){
				//$.fx.off = true;
				WISE.initialWISE();
				WISE.setUser(character, key, idleTime);
				WISE.language = language;

				WISE.loadRuleFile({
					ignoreDefaultHandler: true,
					error: function(){
						WISE.setWISE(WISE.createWISE(wiseModelName));
					},
					complete: function(){
						aliveKeeper.stop();
						init();
					}
				});
			}).fail(function(){
				aliveKeeper.stop();

				$("#loadingFile").text(LangLogin.fileCanNotLoad[language]);
				$(window).triggerHandler("unload");
			});
		});
	};

	$("#loginLeftContent, #loginRightContent, .loginCurtain").stop(true, true);//stip animate(when user use "remember me")

	$.when(
		$("#loginLeftContent").animate((function(){
			if($.browser.msie && parseInt($.browser.version, 10) <= 8){
				return {"left": "100%"};
			}
			else{
				return {"left": "100%", "opacity": 0};
			}
		})()),
		$("#loginRightContent").animate((function(){
			if($.browser.msie && parseInt($.browser.version, 10) <= 8){
				return {"right": "100%"};
			}
			else{
				return {"right": "100%", "opacity": 0};
			}
		})())
	).then(function() {
		closeCurtain();
	});
}

function onSubmitLogin(showErrorMessage){
	var password = $("#loginPassword").val();
	var language = $("#loginLanguage").val();
	var remember = $("#loginRememberMe").attr("checked");

	disabledLoginForm(true);
	checkUsernameAndPassword(password, function(xmlDoc){
		var $xmlLOGIN = $(xmlDoc).find("LOGIN");

		if($xmlLOGIN.length > 0){
			var reply = $xmlLOGIN.attr("reply");

			if(reply != null){
				if(reply == "admin" || reply == "guest"){
					setCookie("language", language);

					if(remember){
						setCookie("password", password, 4320);
					}
					else{
						setCookie("password", "", -1);
					}

					location.replace(location.hash.split("/").slice(0, 3).join("/") || "#");//if the hash location exist, keep only 3 level. Show the page directly after loading complete

					login(reply, $xmlLOGIN.attr("key"), $xmlLOGIN.attr("keepalive"), language);

					return false;
				}
				else{
					var originalHeight = $("#loginStatus").height(), newHeight = 0;
					if(reply == "occupied"){//admin
						newHeight = $("#loginStatus").css("height", "auto").html(showErrorMessage == true ? LangLogin.adminAlreadyLogin[language] : "").height();
					}
					else if(reply == "full"){//guest
						newHeight = $("#loginStatus").css("height", "auto").html(showErrorMessage == true ? LangLogin.reachMaximumNumberOfLoginUser[language] : "").height();
					}
					else{
						newHeight = $("#loginStatus").css("height", "auto").html(showErrorMessage == true ? LangLogin.passwordIncorrect[language] : "").height();
						setCookie("password", "", -1);
					}

					$("#loginStatus").css({"opacity": 0, "height": originalHeight + "px"}).animate({"opacity": 1, "height": newHeight + "px"}, "fast");
				}
			}
		}

		disabledLoginForm(false);
		$("#loginPassword").select();
	}, function(){
		location.reload();
	});

	return false;
}

function disabledLoginForm(disabled){
	$("#loginPassword, #loginLanguage, #loginRememberMe, #loginButton").attr("disabled", disabled);
	$("#loginLoader").css("display", disabled == true ? "" : "none");
}

function showLoginPage(){
	disabledLoginForm(false);

	$("#loginPassword").val("");
	$("#loginLanguage").val(getCookie("language") || defaultLanguage);
	$("#loginRememberMe").attr("checked", false);
	$("#loginContainer").show();

	//$("#loginPassword").focus();
	onChangeLanguage();
}

function updateSendPasswordLanguage(){
	var language = $("#loginLanguage").val();

	$("#loginSendPasswordStatus").html($("#loginSendPasswordStatus").attr("lang") ? LangLogin[$("#loginSendPasswordStatus").attr("lang")][language].replace("$email", adminEmail) : "");
	$("#loginSendPassword").html($("#loginSendPassword").attr("lang") ? LangLogin[$("#loginSendPassword").attr("lang")][language] : "");
}

function onChangeLanguage(){
	var language = $("#loginLanguage").val();

	$("#loginStatus").empty().css("height", "auto");
	$("#loginNameText").html(LangLogin.nickname[language]);
	$("#loginPasswordText").html(LangLogin.password[language]);
	$("#loginLanguageText").html(LangLogin.language[language]);
	$("#loginRememberMeText").html(LangLogin.rememberMe[language]);
	$("#loginButton").val(LangLogin.login[language]);

	$("#loadingFile").html(LangLogin.loadingPleaseWait[language]);

	updateSendPasswordLanguage();
}

function main(){
	$.when(
		fileLoader(["css/desktop/login.css"]).done(function(fileContents){
			for(var i = 0; i < fileContents.length; i++){
				insertStyle(fileContents[i]);
			}
		}),
		fileLoader(["html/desktop/login.htm"]).done(function(fileContents){
			for(var i = 0; i < fileContents.length; i++){
				insertHTML(fileContents[i]);
			}
		})
	).done(function(){
		var showServerDown = function(){
			$("#loadingLoader").hide();
			$("#loginRunTimeDown").html(LangLogin.runtimeServerNotStartup[getCookie("language") || defaultLanguage]);
			$("#loginRunTimeDownContainer").show();
		};

		var showAlertMessage = function(){
			$("#loginAlertOKButton").click(function(){
				if($("#loginAlertNeverShow").attr("checked")){
					$.ajax({
						url: "./dll/wise.dll",
						type: "POST",
						data: "<?xml version='1.0' encoding='utf-8'?><VERSION version_2to3='0'/>",
						contentType: "text/xml",
						processData: false,
						cache: false
					});
				}

				$("#loginAlert").hide();
			});

			$("#loginAlertTitle").html(LangLogin.modbusTableChange[getCookie("language") || defaultLanguage]);
			$("#loginAlertContent").html(LangLogin.modbusTableChangeDescription[getCookie("language") || defaultLanguage]);
			$("#loginAlertOKButton").html(LangLogin.ok[getCookie("language") || defaultLanguage]);
			$("#loginAlertNeverShowAgain").html(LangLogin.neverShowAgain[getCookie("language") || defaultLanguage]);
			$("#loginAlert").show();
			$("#loginAlertOKButton").focus();
		};

		if(serverDown == true){//server down, show error message
			showServerDown();
		}
		else{
			$.ajax({
				type: "POST",
				cache: false,
				//url: "dll/xml/name.xml",
				url: "dll/wise.dll",
				data: "<?xml version='1.0' encoding='utf-8'?><NAME/>",
				dataType: "xml",
				success: function(xmlDoc){
					$xmlNAME = $(xmlDoc).find("NAME");
					if($xmlNAME.length <= 0){
						this.error();
						return;
					}

					$("#loadingLoader").hide();
					//wiseModelName = $($xmlNAME[0]).attr("type");//golable variable
					wiseModelName = {//golable variable
						"2201PMD": "PMD-2201",
						"4201PMD": "PMD-4201",
						"2206PMD": "PMD-2206",
						"4206PMD": "PMD-4206",
						"1330PMD": "PPMS-133D"
					}[$($xmlNAME[0]).attr("type") + ($($xmlNAME[0]).attr("subtype") || "") + ($($xmlNAME[0]).attr("series") || "")];

					var name = $($xmlNAME[0]).attr("name");
					if(typeof(name) != "undefined" && name != "null" && name != ""){
						$("#loginNameHandler").show();
						$("#loginName").text(name);
					}

					var email = $($xmlNAME[0]).attr("email");
					if(typeof(email) != "undefined" && email != ""){//enable forgot password
						adminEmail = email;
						$("#loginSendPasswordHandler").show();
						$("#loginSendPassword").bind("click", function(){
							$("#loginSendPassword").hide();
							$("#loginSendPasswordLoader").css("visibility", "visible");
							$("#loginSendPasswordStatus").attr("lang", "sendPasswordToX");
							updateSendPasswordLanguage();

							$.ajax({
								url: "./dll/wise.dll",
								type: "POST",
								data: "<?xml version='1.0' encoding='utf-8'?><EMAIL_PASSWORD/>",
								contentType: "text/xml",
								processData: false,
								cache: false,
								dataType: "xml",
								success: function(xmlDoc){
									var $EMAIL_PASSWORD = $(xmlDoc).find("EMAIL_PASSWORD");
									if($EMAIL_PASSWORD.length > 0){
										var reply = $EMAIL_PASSWORD.attr("reply");
										if(reply == "ok"){
											$("#loginSendPasswordStatus").attr("lang", "sentSuccessfully");
										}
										else if(reply == "error"){
											$("#loginSendPasswordStatus").attr("lang", "sentFailed").attr("title", $EMAIL_PASSWORD.text());
											$("#loginSendPassword").attr("lang", "retry").show();
										}
									}
								},
								error: function(){
									$("#loginSendPasswordStatus").attr("lang", "sentFailed");
									$("#loginSendPassword").attr("lang", "retry").show();
								},
								complete: function(){
									$("#loginSendPasswordLoader").css("visibility", "hidden");
									updateSendPasswordLanguage();
								}
							});
						});
					}

					//version_2to3
					var alertFlag = false;
					if($($xmlNAME[0]).attr("version_2to3") == "1"){
						alertFlag = true;
						showAlertMessage();
					}

					//submeter_quota
					totalExtendedBonusModuleAmount = parseInt($($xmlNAME[0]).attr("submeter_quota") || 32, 10);

					//io_quota
					totalIOModuleAmount = parseInt($($xmlNAME[0]).attr("io_quota") || 8, 10);

					showLoginPage();

					$(".loginCurtain").animate({
						"height": 0
					}).promise().done(function(){
						$("#loginLeftContent").css((function(){
							if($.browser.msie && parseInt($.browser.version, 10) <= 8){
								return {};
							}
							else{
								return {"opacity": "0"};
							}
						})());

						$("#loginRightContent").css({"opacity": "0"});

						$.when(
							$("#loginLeftContent").animate({
								"opacity": 1,
								"left": "0%"
							}),
							$("#loginRightContent").animate({
								"opacity": 1,
								"right": "0%"
							})
						).then(function(){
							// Load language setting from cookie or use default langauge
							$("#loginLanguage").val(getCookie("language") || defaultLanguage);
							onChangeLanguage();

							// Load password setting from cookie
							var password = getCookie("password");

							// If access from cloud
							var serialNumber = location.pathname.match(/([0-9A-Za-z]{16})/);
							if(serialNumber != null){
								password = getCookie("password_" + serialNumber[1]) || password;
								setCookie("password_" + serialNumber[1], "", {expiresTime: -1, path: "/"});// Clear password pass from cloud
							}

							if(password != null){
								$("#loginPassword").val(password);
								$("#loginRememberMe").attr("checked", true);

								if(alertFlag == false){
									onSubmitLogin(false);
								}
							}
							else{
								if(alertFlag == false){
									$("#loginPassword").focus();
								}
							}
						});
					});
				},
				error: function(){
					showServerDown();
				}
			});
		}
	});
}