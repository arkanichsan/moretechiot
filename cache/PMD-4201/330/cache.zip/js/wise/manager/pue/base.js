WISE.managers.pueManager = (function(){
	return new function() {
		this.pool = {
			pues: [],
			isDefaultPage: false
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 10;

		this.createPUE = function(settings){
			var date = new Date();
			var pue = $.extend(true, {
				"name": "",
				"description": "",
				"reference": [],

				"totalEnergys": [],
				"itEnergys": [],
				"range": "meterValue_KWH",//meterValue_KWH, statisticsValue_DTE, statisticsValue_MTE, statisticsValue_YTE

				"chartBoundary": {
					"minimum": 1,
					"maximum": 3
				},

				"chartMarker": [],
				"displayInPercentage": false
			}, settings);

			return pue;
		};

		this.removePUE = function(index){
			delete this.pool.pues[index];
		};

		this.getPUE = function(index){
			if(typeof(this.pool.pues[index]) != "undefined"){
				return this.pool.pues[index];
			}
			else{
				return null;
			}
		};

		this.setPUE = function(index, pue){
			this.pool.pues[index] = pue;
		};

		this.getPUEs = function(){
			return this.pool.pues;
		};
	};
})();
