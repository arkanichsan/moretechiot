WISE.managers.lineBotManager.pool.actions = {
	"message": {
		"name": "LINE Bot",
		"fileName": "alinebot",
		"rule":{
			"messageKey": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.messageKey == null){
				return false;
			}
			
			var lineBotManager = WISE.managers.lineBotManager;

			if(typeof(lineBotManager.pool.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var lineBotManager = WISE.managers.lineBotManager;
			var message = lineBotManager.pool.messages[this.rule.messageKey];
			var valueString = ["<#Lang['?'].send>"];

			return this.name + "(" + message.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.messageKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.lineBotManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['message']['key'] = [];

	for(var key in this.pool.messages){
		this.pool.actions['message']['key'].push(parseInt(key, 10));
	}
};