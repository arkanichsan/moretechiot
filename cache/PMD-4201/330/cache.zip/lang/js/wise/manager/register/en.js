$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"register": "Internal Register",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message"
	}
});