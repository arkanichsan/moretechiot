cssFiles = cssFiles.concat([
	"css/desktop/extend/extend.css"
]);

languageFiles = languageFiles.concat([
	"lang/js/wise/extend/init/base/" + currentLanguage + ".js",
	"lang/js/wise/extend/init/desktop/" + currentLanguage + ".js",
	"lang/html/base/extend/" + currentLanguage + ".js",
	"lang/html/desktop/extend/" + currentLanguage + ".js",

	"lang/js/wise/manager/pue/" + currentLanguage + ".js",

	//--------------pmc----------------------------
	"lang/js/wise/manager/pmc/" + currentLanguage + ".js"
	//---------------------------------------------
]);

jsFiles = jsFiles.concat([
	"js/wise/manager/pmc/base.js",
	"js/wise/manager/pmc/object/encoder.js",
	"js/wise/manager/pmc/object/decoder.js",

	"js/wise/manager/pue/base.js",
	"js/wise/manager/pue/object/encoder.js",
	"js/wise/manager/pue/object/decoder.js",
	"js/wise/manager/pue/rule/object.js",
	"js/wise/manager/pue/rule/encoder.js",
	"js/wise/manager/pue/rule/decoder.js",

	"js/wise/extend/init/base.js",
	"js/wise/extend/init/desktop.js",
	
	//--------------pmc----------------------------
	
	"js/flexigrid/flexigrid.js",
	"js/flot/jquery.flot.js",
	"js/flot/jquery.flot.navigate.js",
	"js/flot/jquery.flot.selection.js",
	"js/flot/jquery.flot.pie.js",
	"js/flot/jquery.flot.time.js",
	
	"js/pmc/base/desktop.js",
	"js/jquery/jquery.spinner.js",
	
	"js/Flotr2/flotr2.ie.min.js",
	"js/Flotr2/flotr2.min.js",
	"js/Modbus/ModbusAddress.js",
	
	"js/Modbus/PowerMeterModbus.js",
	"js/Modbus/IOModbus.js",
	"js/Modbus/RTUMeterModbus.js",
	"js/Modbus/SystemMeterModbus.js",
	"js/Modbus/RegisterMeterModbus.js",
	"js/Modbus/PUEModbus.js",
	
	
	//"js/justgage/raphael.2.1.0.min.js",
	//"js/justgage/justgage.1.0.1.min.js"
	"js/justgage/raphael-2.1.4.min.js",
	"js/justgage/justgage.js"
	
	
	//---------------------------------------------
]);
