$.extend(true, Lang, {
	"js/wise/manager/timer/rule/object.js": {
		"timer": "計時器",
		"notTimeout": "未逾時",
		"timeout": "已逾時",
		"stop": "停止",
		"reset": "重置",
		"start": "啟動",
		"pause": "暫停",
		"resume": "恢復"
	},
	"js/wise/manager/timer/rule/encoder.js": {
		"someoneTimerUseAlreadyRemovedRegister": "計時器使用了已經被移除的內部暫存器數值做為時間長度。"
	}
});