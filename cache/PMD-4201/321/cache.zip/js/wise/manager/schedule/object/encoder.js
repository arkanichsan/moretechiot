WISE.managers.scheduleManager.encodeXMLObject = function(xmlDoc){
	var xmlSCHEDULE = xmlDoc.createElement("SCHEDULE");

	for(var key in this.pool.schedules){
		var schedule = this.pool.schedules[key];
		var xmlS = xmlDoc.createElement("S");

		xmlS.setAttribute("idx", schedule.index);
		xmlS.setAttribute("status", schedule.initialStatus);
		xmlS.setAttribute("type", schedule.mode);
		xmlS.setAttribute("nickname", schedule.name);

		if(schedule.description != ""){
			xmlS.setAttribute("desc", schedule.description);
		}

		for(var i = 0; i < schedule.timeArray.length; i++){
			var xmlTIME = xmlDoc.createElement("TIME");

			xmlTIME.setAttribute("h1", schedule.timeArray[i][0]);
			xmlTIME.setAttribute("m1", schedule.timeArray[i][1]);
			xmlTIME.setAttribute("s1", schedule.timeArray[i][2]);
			xmlTIME.setAttribute("h2", schedule.timeArray[i][3]);
			xmlTIME.setAttribute("m2", schedule.timeArray[i][4]);
			xmlTIME.setAttribute("s2", schedule.timeArray[i][5]);
			xmlTIME.setAttribute("idx", i + 1);

			xmlS.appendChild(xmlTIME);
		}

		if(schedule.mode == 0){
			var xmlDATE = xmlDoc.createElement("DATE");
			xmlDATE.setAttribute("year", schedule.date.startDate.year);
			xmlDATE.setAttribute("month", schedule.date.startDate.month);
			xmlDATE.setAttribute("duration", schedule.date.duration);
			xmlS.appendChild(xmlDATE);

			var xmlSKIP = xmlDoc.createElement("SKIP");
			var skipDateArray = [];
			for(var i = 0; i < schedule.date.skipDateArray.length; i++){
				skipDateArray.push(schedule.date.skipDateArray[i]);
			}
			xmlSKIP.appendChild(xmlDoc.createTextNode(skipDateArray.join(",")));

			xmlS.appendChild(xmlSKIP);
		}
		else if(schedule.mode == 1){
			var week = "";
			var weekArray = schedule.date.repeatDayArray.slice();//clone array
			weekArray.push(weekArray[0]);
			weekArray.splice(0, 1);
			for(var i = 0; i < weekArray.length; i++){
				if(weekArray[i] == true){
					week += (i + 1).toString();
				}
			}
			xmlS.setAttribute("week", week);

			var skipDateArray = [];
			for(var i = 0; i < schedule.date.exceptionDateArray.length; i++){
				skipDateArray.push(schedule.date.exceptionDateArray[i].join("/"));
			}

			if(skipDateArray.length > 0){
				var xmlSKIP = xmlDoc.createElement("SKIP");
				xmlSKIP.appendChild(xmlDoc.createTextNode(skipDateArray.join(",")));
				xmlS.appendChild(xmlSKIP);
			}
		}

		xmlSCHEDULE.appendChild(xmlS);
	}

	if(xmlSCHEDULE.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlSCHEDULE);
				break;
			}
		}
	}
};

WISE.managers.scheduleManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.schedules){
		this.pool.schedules[key].index = ++index;
	}
};