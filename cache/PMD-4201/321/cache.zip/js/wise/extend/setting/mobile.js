cssFiles = cssFiles.concat([
]);

languageFiles = languageFiles.concat([
	"lang/js/wise/extend/init/base/" + currentLanguage + ".js",
	"lang/html/base/extend/" + currentLanguage + ".js",
	"lang/html/mobile/extend/" + currentLanguage + ".js"
]);

jsFiles = jsFiles.concat([
	"js/wise/manager/pmc/base.js",
	"js/wise/manager/pmc/object/decoder.js",

	"js/wise/extend/init/base.js",
	
	//-----------------pmc-------------------------
	"js/pmc/base/mobile.js"
	//---------------------------------------------
]);
