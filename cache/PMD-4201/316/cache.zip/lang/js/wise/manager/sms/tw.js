﻿$.extend(true, Lang, {
	"js/wise/manager/sms/rule/object.js": {
		"smsAlarm": "SMS簡訊警報",
		"send": "傳送"
	}
});