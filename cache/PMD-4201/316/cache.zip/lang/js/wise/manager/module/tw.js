﻿$.extend(true, Lang, {
	"js/wise/manager/module/base.js": {
		"humidity": "相對濕度",
		"celsiusTemperature": "溫度(°C)",
		"fahrenheitTemperature": "溫度(°F)",
		"celsiusDewPointTemperature": "露點溫度(°C)",
		"fahrenheitDewPointTemperature": "露點溫度(°F)"
	},
	"js/wise/manager/module/rule/object.js": {
		"icpdasModule": "泓格模組",
		"modbusModule": "Modbus模組",
		"diCounter": "DI計數器",
		"onToOFF": "ON至OFF",
		"offToON": "OFF至ON",
		"statusChange": "狀態改變",
		"change": "變動",
		"reset": "重置",
		"connectionStatus": "連線狀態",
		"online": "連線",
		"offline": "斷線",
		"pulseOutput": "脈衝輸出"
	}
});