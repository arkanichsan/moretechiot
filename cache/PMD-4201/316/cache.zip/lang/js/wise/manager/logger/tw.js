﻿$.extend(true, Lang, {
	"js/wise/manager/logger/rule/object.js": {
		"ftpUploadStatus": "FTP上傳狀態",
		"uploadFailedContinuingXHours": "上傳失敗持續 $hours 小時",
		"dataLogger": "資料記錄器",
		"stop": "停止",
		"start": "啟動",
		"oneTimeLog": "單次記錄"
	}
});