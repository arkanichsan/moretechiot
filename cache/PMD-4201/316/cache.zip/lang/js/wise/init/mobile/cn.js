﻿$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"popup": {
			"areYouSureYouWantToLogout": "您确定要注销吗？",
			"idleTooLong": "您空闲过久，为了安全起见系统已将您注销，请重新登录即可。"
		}
	}
});