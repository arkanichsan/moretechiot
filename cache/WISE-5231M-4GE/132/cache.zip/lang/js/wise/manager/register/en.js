$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"internalRegister": "Internal Register",
		"local": "Local",
		"remote": "Remote",
		"bit": "Bit",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message"
	}
});