$.extend(true, Lang, {
	"js/wise/manager/schedule/rule/object.js": {
		"schedule": "时间表",
		"outOfRange": "范围外",
		"inRange": "范围内"
	}
});