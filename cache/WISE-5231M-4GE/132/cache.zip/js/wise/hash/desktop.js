var commentCommandPool = {};

var currentLevel = ["home"];
var previousLevel = ["home"];
var currentLevelwithParameter = ["home"];

var parameter = [];

var breadcrumbsTitle = ["<#Lang['?'].home>"];
var hashDisable = false;
var previousHash = "", redirectHash = "";

var redirectToHash = null, redirectToReplace = null;

var hideLeftMenu = hideMenu, showLeftMenu = showMenu;//legendary code, discard

$("#navigation li, #navigation_2nd li").livequery(function() {
	$(this).bind("click", function(event) {
		redirectTo($(this).attr("location"));
	});
});
/*
$(document).on("click", "#navigation li, #navigation_2nd li", function() {
	redirectTo($(this).attr("location"));
});
*/
$("a[href]").livequery(function() {
	if($(this).attr("href").charAt(0) != "#"){return;}

	$(this).bind("click", {"href": $(this).attr("href")}, function(event) {
		redirectTo(event.data.href);
		return false;
	}).attr("href", "#");
});

function hideMenu(force){
	if(wideScreenMode != true || force == true){
		$('#left').hide();
		$('#right').css("width", "100%");
	}
}

function showMenu(){
	$('#left').show();
	$('#right').css("width", ($("#container").width() - $("#left").width() - 25) + "px");
}

function disableHash(disable){
	if(typeof(disable) == "boolean"){
		hashDisable = disable;
	}
}

function updateNavigation(){
	var $navigationItems = $('#navigation li').removeClass("active").filter('[location^="#' + currentLevel[0] + '/' + currentLevel[1] + '"]');
	$navigationItems.length > 1 ? $navigationItems.filter('[location="#' + currentLevel[0] + '/' + currentLevelwithParameter[1] + '"]').first().addClass("active") : $navigationItems.first().addClass("active");

	var $navigationItems = $('#navigation_2nd li').removeClass("active").filter('[location^="#' + currentLevel[0] + '/' + currentLevel[1] + '/' + currentLevel[2] + '"]');
	if($navigationItems.length > 1){
		if(currentLevel[1] == "rules" && currentLevel[2] == "rule"){
			$navigationItems.filter('[location="#' + currentLevel[0] + '/' + currentLevel[1] + '/' + currentLevel[2] + "!" + parameter[0] + '"]').first().addClass("active");
		}
		else{
			$navigationItems.filter('[location="#' + currentLevel[0] + '/' + currentLevel[1] + '/' + currentLevelwithParameter[2] + '"]').first().addClass("active");
		}
	}
	else{
		$navigationItems.first().addClass("active");
	}
}

function processNavigationItem($objects){
/*
	$objects.each(function(){
		if(!WISE.permissionCheck($(this).attr("location"))){
			$(this).remove();
		}
	});
*/

	$objects.each(function(){
		var permission = $(this).attr("permission");
		if(typeof(permission) != "undefined" && WISE.permissionCheck(permission) == false){
			$(this).remove();
		}
	});
}

function updateBreadcrumbsNavigation(){
	$("#bc_navigation_list").empty();

	for(var i = 1, flag = false; i < currentLevelwithParameter.length; i++){
		if(typeof(currentLevelwithParameter[i]) == "undefined"){continue;}

		var url = "#";
		for(var j = 0; j <= i; j++){
			url += currentLevelwithParameter[j] + "/";
		}

		if(i > 1){
			$("<li></li>").attr("class", "joint").appendTo("#bc_navigation_list");
		}

		$("<li></li>").attr("class", "title").append(
			$("<a></a>").attr("href", url.substring(0, url.length - 1)).text(breadcrumbsTitle[i])
		).appendTo("#bc_navigation_list");

		flag = true;
	}

	if(flag == true){
		$("<li></li>").attr("class", "first").prependTo("#bc_navigation_list");
		$("<li></li>").attr("class", "last").appendTo("#bc_navigation_list");
	}
}

function redirectTo(hash, replace){
	hash = hash.charAt(0) == "#" ? hash.substring(1) : hash;

	if(previousHash.replace(/\+.+?\//g, "/") == hash.replace(/\+.+?\//g, "/")){
		replace = true;
	}

	var redirectToArray = [];
	var parameter = "";
	var $breadcrumbsTitle = $("#bc_navigation_list .title a");

	for(var i = 0, tempArray = hash.split("/"); i < tempArray.length; i++){
		var temp2Array = tempArray[i].split("!");

		if(temp2Array[0] == currentLevel[i] && i < tempArray.length - 1){
			redirectToArray[i] = currentLevelwithParameter[i];

			if(i >= 1){//skip home
				redirectToArray[i] += "+" + encodeURIComponent($($breadcrumbsTitle[i - 1]).text().replace(/\//g, "$1").replace(/\+/g, "$2"));//encode title, can't appear / and +
			}
		}
		else{
			redirectToArray[i] = tempArray[i];
		}
	}

	if(replace == true){
		location.replace("#" + redirectToArray.join("/"));
	}
	else{
		location = "#" + redirectToArray.join("/");
	}
}

function _redirectTo(){};

function hashHandler(hash){
	$(".fixedDiv").hide();

	//try{
		$("#opacityCover").css("display", "none");
		//$("#right").css("position", "relative");

		var beforeLoad = function(){
			redirectToHash = redirectToReplace = null;
			_redirectTo = redirectTo;
			redirectTo = function(hash, replace){
				redirectToHash = hash;
				redirectToReplace = replace;
			};
		};

		var afterLoad = function(){
			previousLevel = currentLevel.slice();//clone array

			$('html, body').scrollTop(0);//scroll to top
			$(window).triggerHandler('scroll');
			//$("body").css("cursor", "auto");
			document.title = title;//prevent flash hmi change title(IE8 bug)

			updateNavigation();

			if(currentLevel.length == 2){
				breadcrumbsTitle[1] = $.trim($('#navigation li.active').text());
			}
			else if(currentLevel.length == 3){
				breadcrumbsTitle[2] = $.trim($('#navigation_2nd li.active').text());
			}
			else if(currentLevel.length > 3){
				breadcrumbsTitle[currentLevel.length - 1] = $('#right div[class=title]:first').text();
			}

			if(breadcrumbsTitle[1] == "?"){
				breadcrumbsTitle[1] = $.trim($('#navigation li.active').text());
			}

			if(breadcrumbsTitle[2] == "?"){
				breadcrumbsTitle[2] = $.trim($('#navigation_2nd li.active').text());
			}

			updateBreadcrumbsNavigation();

			redirectTo = _redirectTo;
			if(redirectToHash != null){
				redirectTo(redirectToHash, redirectToReplace);
			}
		};

		/**** process hash ****/
		var _currentLevel = [];
		var _currentLevelwithParameter = [];
		var _parameter = [];

		for(var i = 0, tempArray = hash.split("/"); i < tempArray.length; i++){
			temp1Array = tempArray[i].split("+");
			if(i > 0 && i < tempArray.length - 1){//skip home and last one
				breadcrumbsTitle[i] = decodeURIComponent(temp1Array[1] || "?").replace(/\$1/g, "/").replace(/\$2/g, "+");//firefox encode the uri by itself, so decode to restore it
			}

			var temp2Array = temp1Array[0].split("!");
			_currentLevel[i] = temp2Array[0];

			if(temp2Array.length >= 2){//has !
				_currentLevelwithParameter[i] = _currentLevel[i] + "!" + temp2Array[1];

				if(i == tempArray.length - 1){
					_parameter = temp2Array[1].split("&");
					for(var j = 0; j < _parameter.length; j++){
						_parameter[j] = decodeURIComponent(_parameter[j]).replace(/\$1/g, "/").replace(/\$2/g, "+");
					}
				}
			}
			else{
				_currentLevelwithParameter[i] = _currentLevel[i];
			}
		}
		/**********************/

		//just change parameter, invoke parameterChange function
	    if (_currentLevel.length == currentLevel.length){
			var equalFlag = true;
		    for(var i = 0; i < _currentLevel.length; i++){
		        if (_currentLevel[i] != currentLevel[i]){
					equalFlag = false;
					break;
				}
		    }

			if(equalFlag == true){
				currentLevelwithParameter = _currentLevelwithParameter;
				parameter = _parameter;

				var hasParameterChangeFunc = false;

				if(typeof(parameterChangeMenu) == "function"){
					parameterChangeMenu();
					hasParameterChangeFunc = true;
				}

				if(typeof(parameterChangeContent) == "function"){
					parameterChangeContent();
					hasParameterChangeFunc = true;
				}

				if(hasParameterChangeFunc == true){
					return;
				}
			}
		}

		//execute beforeUnLoad (make sure beforeUnLoad function can read the currentLevel)
		if(_currentLevel.length >= 2){
			if(previousLevel[1] != _currentLevel[1]){//load menu and then content
				if(typeof(beforeUnLoadMenu) == "function"){
					beforeUnLoadMenu();
				}

				if(typeof(beforeUnLoadContent) == "function"){
					beforeUnLoadContent();
				}
			}
			else{//when click menu, just load right content
				if(typeof(beforeUnLoadContent) == "function"){
					beforeUnLoadContent();
				}
			}
		}
		else{
			if(typeof(beforeUnLoadMenu) == "function"){
				beforeUnLoadMenu();
			}

			if(typeof(beforeUnLoadContent) == "function"){
				beforeUnLoadContent();
			}
		}

		currentLevel = _currentLevel;
		currentLevelwithParameter = _currentLevelwithParameter;
		parameter = _parameter;

		WISE.hashChange();

		// load rulePool to Pool or restore, some pages need use current rule in controller
		// reference WISE.$.originalPool to WISE.$.pool and copy WISE.$.rulePool to WISE.$.pool
		// when leave the pages
		// reference WISE.$.pool to WISE.$.originalPool and remove WISE.$.originalPool pointer
		var currentHash = "#" + currentLevel.join("/");
		var findFlag = false;

		for(var i = 0; i < useRuleHash.length; i++){
			if(currentHash.substr(0, useRuleHash[i].length) == useRuleHash[i]){
				if(typeof(WISE.$.originalPool) == "undefined"){
					WISE.$.originalPool = {
						"managers" : {}
					};

					WISE.abortAllManagersTempPool();

					for(var managerKey in WISE.managers){//save managers pool to wise
						WISE.$.originalPool.managers[managerKey] = WISE.managers[managerKey].pool;
					}

					for(var managerKey in WISE.managers){//load wise pool to manager
						WISE.managers[managerKey].pool = WISE.$.rulePool.managers[managerKey];
					}
				}

				findFlag = true;
				break;
			}
		}

		if(findFlag == false && typeof(WISE.$.originalPool) != "undefined"){//restore
			WISE.abortAllManagersTempPool();

			for(var managerKey in WISE.managers){//load wise pool to manager
				WISE.managers[managerKey].pool = WISE.$.originalPool.managers[managerKey];
			}

			delete WISE.$.originalPool;
		}

		//clear tempRule in rules/menu.htm and rules/rule.htm
		if((currentLevel[1] != "rules" || (currentLevel[1] == "rules" && currentLevel.length == 2)) && typeof(tempRule) != "undefined"){
			tempRule = undefined;
		}

		//$("body").css("cursor", "progress");
		if(currentLevel.length >= 2){
			if(previousLevel[1] != currentLevel[1]){//load menu
				WISE.stopAllTimers();
				WISE.abortAllAjaxs();

				$("#leftLoading, #rightLoading, #contentLoader").show();
				//$("#contentInsideLoader").hide();
				$("#leftContent, #rightContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

				loadMenu({
					success: function(menu){
						loadContent({
							success: function(content){
								beforeLoad();

								$("#contentLoader").hide();

								afterLoginMenu = afterLoginContent = null, delayShowFlag = false;
								beforeUnLoadMenu = beforeUnLoadContent = null;
								parameterChangeMenu = parameterChangeContent = null;

								afterLoginFunc = null;
								beforeUnLoadFunc = null;
								parameterChangeFunc = null;

								$("#leftContent").html(menu);
								processNavigationItem($("#navigation_2nd li"));

								if(afterLoginFunc != null){
									afterLoginMenu = afterLoginFunc;
								}
								if(beforeUnLoadFunc != null){
									beforeUnLoadMenu = beforeUnLoadFunc;
								}
								if(parameterChangeFunc != null){
									parameterChangeMenu = parameterChangeFunc;
								}

								afterLoginFunc = null;
								beforeUnLoadFunc = null;
								parameterChangeFunc = null;

								$("#rightContent").html(content);

								if(afterLoginFunc != null){
									afterLoginContent = afterLoginFunc;
								}
								if(beforeUnLoadFunc != null){
									beforeUnLoadContent = beforeUnLoadFunc;
								}
								if(parameterChangeFunc != null){
									parameterChangeContent = parameterChangeFunc;
								}

								if(delayShowFlag == false){
									$("#leftLoading, #rightLoading").hide();
									$("#leftContent, #rightContent").stop().css("opacity", 1);
								}
								else{
									$("#contentLoader").show();
								}

								afterLoad();
							},
							error: function(){
								$("#leftLoading, #rightLoading, #contentLoader").hide();
								$("#leftContent, #rightContent").stop().css("opacity", 1);
							}
						});
					},
					error: function(){
						$("#leftLoading, #rightLoading, #contentLoader").hide();
						$("#leftContent, #rightContent").stop().css("opacity", 1);
					}
				});
			}
			else{//when click menu, just load right content
				WISE.stopTimers("content");
				WISE.abortAjaxs("content");

				$("#rightLoading, #contentLoader").show();
				//$("#contentInsideLoader").hide();
				$("#rightContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

				loadContent({
					success: function(content){
						beforeLoad();

						$("#contentLoader").hide();

						afterLoginContent = null, delayShowFlag = false;
						beforeUnLoadContent = null;
						parameterChangeContent = null;

						afterLoginFunc = null;
						beforeUnLoadFunc = null;
						parameterChangeFunc = null;

						$("#rightContent").html(content);

						if(afterLoginFunc != null){
							afterLoginContent = afterLoginFunc;
						}
						if(beforeUnLoadFunc != null){
							beforeUnLoadContent = beforeUnLoadFunc;
						}
						if(parameterChangeFunc != null){
							parameterChangeContent = parameterChangeFunc;
						}

						if(delayShowFlag == false){
							$("#rightLoading").hide();
							$("#rightContent").stop().css("opacity", 1);
						}
						else{
							$("#contentLoader").show();
						}

						afterLoad();
					},
					error: function(){
						$("#rightLoading, #contentLoader").hide();
						$("#rightContent").stop().css("opacity", 1);
					}
				});
			}
		}
		else{
			WISE.stopAllTimers();
			WISE.abortAllAjaxs();

			$("#leftLoading, #rightLoading, #contentLoader").show();
			//$("#contentInsideLoader").hide();
			$("#leftContent, #rightContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

			loadContent({
				success: function(content){
					$("#leftContent").empty();
					hideMenu(true);
					beforeLoad();

					$("#contentLoader").hide();

					afterLoginContent = null, delayShowFlag = false;
					beforeUnLoadContent = null;
					parameterChangeContent = null;

					afterLoginFunc = null;
					beforeUnLoadFunc = null;
					parameterChangeFunc = null;

					$("#rightContent").html(content);

					if(afterLoginFunc != null){
						afterLoginContent = afterLoginFunc;
					}
					if(beforeUnLoadFunc != null){
						beforeUnLoadContent = beforeUnLoadFunc;
					}
					if(parameterChangeFunc != null){
						parameterChangeContent = parameterChangeFunc;
					}

					if(delayShowFlag == false){
						$("#leftLoading, #rightLoading").hide();
						$("#leftContent, #rightContent").stop().css("opacity", 1);
					}
					else{
						$("#contentLoader").show();
					}

					afterLoad();
				},
				error: function(){
					$("#leftLoading, #rightLoading, #contentLoader").hide();
					$("#leftContent, #rightContent").stop().css("opacity", 1);
				}
			});
		}
	//}
	//catch(error){
	//	window.location.replace("#home");
	//}
}

function loadMenu(settings){
	settings = $.extend(true, {
		"success": function(){},
		"error": function(){},
		"complete": function(){}
	}, settings);

	WISE.startAjax("menu", {
		url: "html/desktop" + "/" + currentLevel[0] + "/" + currentLevel[1] + "/" + "menu.htm" + "?" + cacheString,
		type: "GET",
		dataType: "html",
		done: function(htmlString){
			if(processCommentCommand(htmlString) == false){return;}
			htmlString = processLanguage(htmlString, this.url.split("?")[0]);

			settings.success(htmlString);
		},
		fail: function(jqXHR, textStatus, errorThrown){
			settings.error();
		},
		complete: function(){
			settings.complete();
		}
	});
}

function loadContent(settings){
	settings = $.extend(true, {
		"success": function(){},
		"error": function(){},
		"complete": function(){}
	}, settings);

	var url = "";
	for(var i = 0; i < currentLevel.length; i++){
		url += "/" + currentLevel[i];
	}

	WISE.startAjax("content", {
		url: "html/desktop" + "/" + url.substring(1) + ".htm" + "?" + cacheString,
		type: "GET",
		dataType: "html",
		done: function(htmlString){
			if(processCommentCommand(htmlString) == false){return;}
			htmlString = processLanguage(htmlString, this.url.split("?")[0]);

			settings.success(htmlString);
		},
		fail: function(){
			settings.error();
		},
		complete: function(){
			settings.complete();
		}
	});
}

function reloadMenu(){
	WISE.stopTimers("menu");
	WISE.abortAjaxs("menu");

	$("#leftLoading, #contentLoader").show();
	//$("#contentInsideLoader").hide();
	$("#leftContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

	loadMenu({
		success: function(menu){
			$("#contentLoader").hide();

			afterLoginMenu = null, delayShowFlag = false;
			beforeUnLoadMenu = null;
			parameterChangeMenu = null;

			afterLoginFunc = null;
			beforeUnLoadFunc = null;
			parameterChangeFunc = null;

			$("#leftContent").html(menu);
			processNavigationItem($("#navigation_2nd li"));

			if(afterLoginFunc != null){
				afterLoginMenu = afterLoginFunc;
			}
			if(beforeUnLoadFunc != null){
				beforeUnLoadMenu = beforeUnLoadFunc;
			}
			if(parameterChangeFunc != null){
				parameterChangeMenu = parameterChangeFunc;
			}

			if(delayShowFlag == false){
				$("#leftLoading").hide();
			}
			else{
				$("#contentLoader").show();
			}

			updateNavigation();
		},
		error: function(){
			$("#leftLoading, #contentLoader").hide();
		}
	});
}

function reloadContent(){
	WISE.stopTimers("content");
	WISE.abortAjaxs("content");

	$("#rightLoading, #contentLoader").show();
	//$("#contentInsideLoader").hide();
	$("#rightContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

	loadContent({
		success: function(content){
			$("#contentLoader").hide();

			afterLoginContent = null, delayShowFlag = false;
			beforeUnLoadContent = null;
			parameterChangeContent = null;

			afterLoginFunc = null;
			beforeUnLoadFunc = null;
			parameterChangeFunc = null;

			$("#rightContent").html(content);

			if(afterLoginFunc != null){
				afterLoginContent = afterLoginFunc;
			}
			if(beforeUnLoadFunc != null){
				beforeUnLoadContent = beforeUnLoadFunc;
			}
			if(parameterChangeFunc != null){
				parameterChangeContent = parameterChangeFunc;
			}

			if(delayShowFlag == false){
				$("#rightLoading").hide();
				$("#rightContent").stop().css("opacity", 1);
			}
			else{
				$("#contentLoader").show();
			}
		},
		error: function(){
			$("#rightLoading, #contentLoader").hide();
			$("#rightContent").stop().css("opacity", 1);
		}
	});
}

function reloadAll(){
	WISE.stopAllTimers();
	WISE.abortAllAjaxs();

	$("#leftLoading, #rightLoading, #contentLoader").show();
	//$("#contentInsideLoader").hide();
	$("#leftContent, #rightContent").css("opacity", 1).animate({"opacity": 0.2}, "slow");

	loadMenu({
		success: function(menu){
			loadContent({
				success: function(content){
					$("#contentLoader").hide();

					afterLoginMenu = afterLoginContent = null, delayShowFlag = false;
					beforeUnLoadMenu = beforeUnLoadContent = null;
					parameterChangeMenu = parameterChangeContent = null;

					afterLoginFunc = null;
					beforeUnLoadFunc = null;
					parameterChangeFunc = null;

					$("#leftContent").html(menu);
					processNavigationItem($("#navigation_2nd li"));

					if(afterLoginFunc != null){
						afterLoginMenu = afterLoginFunc;
					}
					if(beforeUnLoadFunc != null){
						beforeUnLoadMenu = beforeUnLoadFunc;
					}
					if(parameterChangeFunc != null){
						parameterChangeMenu = parameterChangeFunc;
					}

					afterLoginFunc = null;
					beforeUnLoadFunc = null;
					parameterChangeFunc = null;

					$("#rightContent").html(content);

					if(afterLoginFunc != null){
						afterLoginContent = afterLoginFunc;
					}
					if(beforeUnLoadFunc != null){
						beforeUnLoadContent = beforeUnLoadFunc;
					}
					if(parameterChangeFunc != null){
						parameterChangeContent = parameterChangeFunc;
					}

					if(delayShowFlag == false){
						$("#leftLoading, #rightLoading").hide();
						$("#leftContent, #rightContent").stop().css("opacity", 1);
					}
					else{
						$("#contentLoader").show();
					}

					updateNavigation();
				},
				error: function(){
					$("#leftLoading, #rightLoading, #contentLoader").hide();
					$("#leftContent, #rightContent").stop().css("opacity", 1);
				}
			});
		},
		error: function(){
			$("#leftLoading, #rightLoading, #contentLoader").hide();
			$("#leftContent, #rightContent").stop().css("opacity", 1);
		}
	});
}

function delayShow(){
	delayShowFlag = true;
}

function startShow(){
	$("#leftLoading, #rightLoading, #contentLoader").hide();
	$("#leftContent, #rightContent").stop().css("opacity", 1);
}

function afterLogin(func){
	afterLoginFunc = func;
}

function beforeUnLoad(func){
	beforeUnLoadFunc = func;
}

function parameterChange(func){
	parameterChangeFunc = func;
}

function addCommentCommand(command, func){
	commentCommandPool[command] = func;
}

function processCommentCommand(htmlString){
	var regex = /<!--WISE(.*?) +(.*?)-->/g;
	var result = regex.exec(htmlString);

	while(result != null) {
		if(typeof(commentCommandPool[RegExp.$1]) == "function"){
			if(commentCommandPool[RegExp.$1](RegExp.$2.split(" ")) == false){return false;}
		}

		result = regex.exec(htmlString);
	}
}

/*
function removeParameter(){
	var hash = window.location.hash;
	if(hash.lastIndexOf("!") >= 0){
		window.location.replace(hash.substring(0, hash.lastIndexOf("!")));
	}
}
*/
