WISE.managers.lineNotifyManager = (function(){
	return new function() {
		this.pool = {
			messages: {},
			chatRooms: {},
			messageKey: 0,
			chatRoomKey: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxMessageAmount = 12;
		this.maxChatRoomAmount = 12;

		this.createMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"chatRooms": [],//key
				"content": ""
			}, settings);

			return message;
		};

		this.addMessage = function(message){
			var retKey = this.pool.messageKey;
			this.pool.messages[this.pool.messageKey++] = message;
			return retKey;
		};

		this.removeMessage = function(key){
			delete this.pool.messages[key];
		};

		this.getMessage = function(key){
			if(typeof(this.pool.messages[key]) != "undefined"){
				return this.pool.messages[key];
			}
			else{
				return null;
			}
		};

		this.setMessage = function(key, message){
			this.pool.messages[key] = message;
		};

		this.getMessages = function(){
			return this.pool.messages;
		};

		this.createChatRoom = function(settings){
			var chatRoom = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"token": "",
				"type": null
			}, settings);

			return chatRoom;
		};

		this.addChatRoom = function(chatRoom){
			var retKey = this.pool.chatRoomKey;
			this.pool.chatRooms[this.pool.chatRoomKey++] = chatRoom;
			return retKey;
		};

		this.removeChatRoom = function(key){
			delete this.pool.chatRooms[key];
		};

		this.getChatRoom = function(key){
			if(typeof(this.pool.chatRooms[key]) != "undefined"){
				return this.pool.chatRooms[key];
			}
			else{
				return null;
			}
		};

		this.setChatRoom = function(key, chatRoom){
			this.pool.chatRooms[key] = chatRoom;
		};

		this.getChatRooms = function(){
			return this.pool.chatRooms;
		};
	};
})();
