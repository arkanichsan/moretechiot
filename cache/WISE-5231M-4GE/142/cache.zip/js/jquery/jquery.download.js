/*
	Content-type: application/vnd.ms-excel\r\nContent-Disposition: attachment; filename="excel.xls"\r\n\r\nCONTENT
	Content-type: application/xml\r\n\r\nCONTENT
	Content-type: text/html\r\n\r\nCONTENT
*/
(function($) {
	$.download = function(settings){
		settings = $.extend(true, {
			"url": "./dll/download.dll",
			"method": "POST",
			"enctype": "application/x-www-form-urlencoded",
			"data": "",
			"response": function(){}
		}, settings);

		var id = "download" + Math.floor(Math.random() * 10000);
		var $iframe = $("<iframe></iframe>").attr({"id": id, "name": id}).css("display", "none").appendTo("body").bind("load", function(){
			if($(this)[0].contentDocument){
				settings.response($(this)[0].contentDocument);
			}
			else{
				settings.response($(this)[0].contentWindow);
			}
		});
/*
		//PMC-5141
		var $iframe = $("<iframe name='" + id + "'></iframe>").css("display", "none").appendTo("body").bind("load", function(){
			settings.response($(this)[0]);

			//if($(this)[0].contentDocument){
			//	settings.response($(this)[0].contentDocument);
			//}
			//else{
			//	settings.response($(this)[0].contentWindow);
			//}
		});
*/
		//$iframe[0].response = function(message){
		//	settings.response(message);
		//};

		if(settings.method == "POST"){
			$("<form></form>").attr({
				"action": settings.url,
				"method": "POST",
				"target": id,
				"enctype": settings.enctype
			}).append(
				$("<textarea/>").attr({"name": "data"}).text(settings.data)
			).css("display", "none").appendTo("body").submit();
		}
		else if(settings.method == "GET"){
			$iframe.attr("src", settings.url + "?" + encodeURIComponent(settings.data));
		}
	};
})(jQuery);
