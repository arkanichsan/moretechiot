﻿$.extend(true, Lang, {
	"js/wise/manager/rule/base.js": {
		"copy": "複製"
	},
	"js/wise/manager/rule/rule/object.js": {
		"ruleStatus": "規則狀態"
	},
	"js/wise/manager/rule/rule/encoder.js": {
		"someoneRulesAreError": "有規則發生錯誤，請修正它們。"
	}
});