﻿$.extend(true, Lang, {
	"js/wise/hash/desktop.js": {
		"home": "首頁"
	}
});