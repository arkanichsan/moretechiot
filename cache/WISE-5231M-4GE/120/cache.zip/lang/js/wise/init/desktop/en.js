﻿$.extend(true, Lang, {
	"js/wise/init/desktop.js": {
		"passwordIncorrect": "The password is incorrect.",
		"reachMaximumNumberOfLoginUser": "The system has exceeded the maximum number of allowed connections.",
		"loginSuccessfully": "Login successfully.",
		"instantMessage": "Instant Message",
		"approxXDays": "Approx.$day Days",
		"noSDCard": "No microSD card detected.",
		"ftpUploadFailed": "Remote FTP upload failed.",
		"initModuleFailed": "Failed to initialize module $moduleName($address).",
		"close": "Close",
		"pollingTime": "Polling Time",
		"internalRegister": "Internal Register",
		"no": "No.",
		"channel": "Ch.",
		"address": "Addr.",
		"counter": "Counter:",
		"none": "None",
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel",
		"loading": "Loading...",
		"tip": {
			"thisFieldRangeIsBetweenAToB": "This field only accepts values between $minimum to $maximum.",
			"thisFieldRangeIsGreaterEqualX": "This field only accepts values greater than or equal to $minimum.",
			"thisFieldRangeIsLessEqualX": "This field only accepts values less than or equal to $maximum.",
			"thisFieldOnlyAllowInputInteger": "This field only accepts integers.",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "This field only accepts integers or floating point numbers.",
			"thisFieldOnlyAllowInputHEX": "This field only accepts hexadecimal values.",
			"thisFieldNotAllowInputThisChar": "This character is not allowed in this field.",
			"thisFieldContainsTooManyChar": "This field exceeds the maximum allowed length of the characters.",
			"clickDownloadAfterCompleteAllSetting": "All the modified settings will not take effect until the 'Save' button is clicked.",
			"settingNotDownloadToController": "The settings have not been saved to the controller yet."
		},
		"popup": {
			"exitEditModeFirst": "Please exit the edit mode first.<br>Tip: [Tool] -> [Project List]",
			"areYouSureYouWantToClearAllSetting": "Are you sure you want to reset all settings?",
			"areYouSureYouWantToLoadSetting": "Are you sure you want to load the setting file? All unsaved settings will be lost after you load the file.",
			"areYouSureYouWantToSaveSetting": "Are you sure you want to save the setting file?",
			"areYouSureYouWantToLogout": "Are you sure you want to logout?"
		}
	}
});