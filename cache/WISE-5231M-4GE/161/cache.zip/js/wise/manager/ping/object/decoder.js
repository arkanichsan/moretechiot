WISE.managers.pingManager.decodeXMLObject = function(xmlDoc){
	var $xmlPING = $(xmlDoc).find("WISE > NOTE > PING");
	if($xmlPING.length > 0){
		var $xmlP = $xmlPING.find("> P");
		var maxKey = 0;
		for(var i = 0; i < $xmlP.length; i++){
			var key = parseInt($($xmlP[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var ping = this.createPing({
				"name": $($xmlP[i]).attr("nickname"),
				"description": $($xmlP[i]).attr("desc"),

				"target": $($xmlP[i]).attr("target"),
				"interval": parseInt($($xmlP[i]).attr("interval"), 10),
				"timeout": parseInt($($xmlP[i]).attr("timeout"), 10),
				"condition": {
					"mode": $($xmlP[i]).attr("mode") == "0" ? "continuous" : "accumulative",
					"continuous": (function(){
						if($($xmlP[i]).attr("mode") == "0"){
							return {
								"fail": parseInt($($xmlP[i]).attr("failed_times"), 10)
							};
						}
					})(),
					"accumulative": (function(){
						if($($xmlP[i]).attr("mode") == "1"){
							var splitArray = $($xmlP[i]).attr("failed_times").split(",");

							return {
								"fail": parseInt(splitArray[0], 10),
								"test": parseInt(splitArray[1], 10)
							};
						}
					})()
				}
			});

			this.setPing(key, ping);
		}

		this.pool.key = ++maxKey;
	}
};