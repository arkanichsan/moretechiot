$.extend(true, Lang, {
	"js/wise/manager/mqtt/rule/object.js": {
		"brokerConnectionStatus": "Borker連線狀態",
		"offline": "斷線",
		"online": "連線",
		"mqttBrokerConnectionStatus": "MQTT Borker連線狀態",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息",
		"brokerFunctionStatus": "Broker功能狀態",
		"mqttBrokerFunctionStatus": "MQTT Broker($broker)功能狀態",
		"publishMessage": "Publish訊息",
		"publish": "發佈",
		"mqttPublishMessage": "MQTT Publish訊息",
		"resetTopic": "重置Topic",
		"reset": "重置"
	}
});