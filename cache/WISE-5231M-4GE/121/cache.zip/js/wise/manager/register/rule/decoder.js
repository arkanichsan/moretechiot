WISE.managers.registerManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "IR"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.register);
			ruleObject.rule.bit = parseInt($(xmlDoc).attr("l_ch") || "0", 10) - 1;
			if(ruleObject.rule.bit >= 0){
				ruleObject.rule.operate = 0;
				ruleObject.rule.type = 0;
				ruleObject.rule.value[0].constant = parseInt($(xmlDoc).attr("op"), 10);
			}
			else{
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.register);

			var code = {"0": 0, "1": 10, "2": 20, "3": 1, "4": 11, "5": 21, "6": 30, "7": 40, "8": 31, "9": 41, "10": 50, "11": 51}[$(xmlDoc).attr("op")];
			ruleObject.rule.operate = Math.floor(code / 10);
			ruleObject.rule.frequency = code % 10;
			processCompareModule(xmlDoc, ruleObject);
		}

		ruleObject.rule.registerIndex = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
	}

	return ruleObject;
};
