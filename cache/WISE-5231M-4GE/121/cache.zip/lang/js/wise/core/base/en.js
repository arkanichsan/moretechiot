$.extend(true, Lang, {
	"js/wise/core/base.js": {
		"camera": "IP Camera"
	}
});