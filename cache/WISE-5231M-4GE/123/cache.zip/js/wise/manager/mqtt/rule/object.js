WISE.managers.mqttManager.pool.conditions = {
	"broker": {
		"name": "<#Lang['?'].brokerConnectionStatus>",
		"fileName": "cbroker",
		"menuPath": "MQTT",
		"rule":{
			"brokerKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.brokerKey == null){
				return false;
			}
			
			var mqttManager = WISE.managers.mqttManager;

			if(typeof(mqttManager.pool.brokers[this.rule.brokerKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var mqttManager = WISE.managers.mqttManager;
			var broker = mqttManager.pool.brokers[this.rule.brokerKey];
			var valueString = ["<#Lang['?'].offline>", "<#Lang['?'].online>"];

			var retString = "<#Lang['?'].mqttBrokerConnectionStatus>" + "(" + broker.name + ") " + " " + ruleColor(valueString[this.rule.value], 2);

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.brokerKey = this.key[0];
		},
		"key": []
	},
	"topic": {
		"name": "Subscribe Topic",
		"fileName": "ctopic",
		"menuPath": "MQTT",
		"rule":{
			"brokerKey": null,
			"topicKey": null,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.brokerKey == null || this.rule.topicKey == null){
				return false;
			}
			
			var mqttManager = WISE.managers.mqttManager;

			if(typeof(mqttManager.pool.brokers[this.rule.brokerKey]) == "undefined" || typeof(mqttManager.pool.brokers[this.rule.brokerKey].subscribe.topics[this.rule.topicKey]) == "undefined"){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var mqttManager = WISE.managers.mqttManager;
			var broker = mqttManager.pool.brokers[this.rule.brokerKey];
			var topic = broker.subscribe.topics[this.rule.topicKey];
			var operateString = ["=", ">", "<", ">=", "<="];

			var retString = "MQTT Subscribe Topic" + "(" + broker.name + ":" + topic.name + ") " + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		//init and key will not be copied
		"init": function(){
			this.rule.brokerKey = this.key[0][0];
			this.rule.topicKey = this.key[0][1];
		},
		"key": []
	}
};

WISE.managers.mqttManager.pool.actions = {
	"broker": {
		"name": "<#Lang['?'].brokerFunctionStatus>",
		"fileName": "abroker",
		"menuPath": "MQTT",
		"rule":{
			"brokerKey": null,
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			if(this.rule.brokerKey == null){
				return false;
			}
			
			var mqttManager = WISE.managers.mqttManager;

			if(typeof(mqttManager.pool.brokers[this.rule.brokerKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var mqttManager = WISE.managers.mqttManager;
			var broker = mqttManager.pool.brokers[this.rule.brokerKey];
			var valueString = ["<#Lang.global.disable>", "<#Lang.global.enable>"];

			return "<#Lang['?'].mqttBrokerFunctionStatus>".replace("$broker", broker.name) + " " + ruleColor(valueString[this.rule.value], 2);
		},

		//init and key will not be copied
		"init": function(){
			this.rule.brokerKey = this.key[0];
		},
		"key": []
	},
	"message": {
		"name": "<#Lang['?'].publishMessage>",
		"fileName": "amessage",
		"menuPath": "MQTT",
		"rule":{
			"brokerKey": null,
			"messageKey": null,
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			if(this.rule.brokerKey == null || this.rule.messageKey == null){
				return false;
			}
			
			var mqttManager = WISE.managers.mqttManager;

			if(typeof(mqttManager.pool.brokers[this.rule.brokerKey]) == "undefined" || typeof(mqttManager.pool.brokers[this.rule.brokerKey].publish.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var mqttManager = WISE.managers.mqttManager;
			var broker = mqttManager.pool.brokers[this.rule.brokerKey];
			var message = broker.publish.messages[this.rule.messageKey];
			var valueString = ["<#Lang['?'].publish>"];

			return "<#Lang['?'].mqttPublishMessage>" + "(" + broker.name + ":" + message.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		//init and key will not be copied
		"init": function(){
			this.rule.brokerKey = this.key[0][0];
			this.rule.messageKey = this.key[0][1];
		},
		"key": []
	}
};

WISE.managers.mqttManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['broker']['key'] = [];
	this.pool.conditions['topic']['key'] = [];
	this.pool.actions['broker']['key'] = [];
	this.pool.actions['message']['key'] = [];

	for(var brokerKey in this.pool.brokers){
		this.pool.conditions['broker']['key'].push(parseInt(brokerKey, 10));
		this.pool.actions['broker']['key'].push(parseInt(brokerKey, 10));
	}

	for(var brokerKey in this.pool.brokers){
		for(var topicKey in this.pool.brokers[brokerKey].subscribe.topics){
			this.pool.conditions['topic']['key'].push([parseInt(brokerKey, 10), parseInt(topicKey, 10)]);
			break;
		}
	}

	for(var brokerKey in this.pool.brokers){
		for(var messageKey in this.pool.brokers[brokerKey].publish.messages){
			this.pool.actions['message']['key'].push([parseInt(brokerKey, 10), parseInt(messageKey, 10)]);
			break;
		}
	}
};
