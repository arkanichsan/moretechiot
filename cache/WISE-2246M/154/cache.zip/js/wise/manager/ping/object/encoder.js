WISE.managers.pingManager.encodeXMLObject = function(xmlDoc){
	var xmlPING = xmlDoc.createElement("PING");

	for(var key in this.pool.pings){
		var ping = this.pool.pings[key];
		var xmlP = xmlDoc.createElement("P");

		xmlP.setAttribute("idx", ping.index);
		xmlP.setAttribute("target", ping.target);
		xmlP.setAttribute("interval", ping.interval);
		xmlP.setAttribute("timeout", ping.timeout);

		if(ping.condition.mode == "continuous"){
			xmlP.setAttribute("mode", "0");
			xmlP.setAttribute("failed_times", ping.condition.continuous.fail);
		}
		else{
			xmlP.setAttribute("mode", "1");
			xmlP.setAttribute("failed_times", ping.condition.accumulative.fail + "," + ping.condition.accumulative.test);
		}

		xmlP.setAttribute("nickname", ping.name);

		if(ping.description != ""){
			xmlP.setAttribute("desc", ping.description);
		}

		xmlPING.appendChild(xmlP);
	}

	if(xmlPING.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlPING);
				break;
			}
		}
	}
};

WISE.managers.pingManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.pings){
		this.pool.pings[key].index = ++index;
	}
};