$.extend(true, Lang, {
	"js/wise/manager/cgi/rule/object.js": {
		"cgiCommand": "CGI命令",
		"fromX": "來自$address",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"send": "傳送",
		"resetVariable": "重置參數",
		"reset": "重置"
	}
});