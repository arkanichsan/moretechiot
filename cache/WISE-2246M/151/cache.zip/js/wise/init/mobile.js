function init(){
	$("#loadingLoader, #loginContainer, #loginRunTimeDownContainer").remove();
	$("#container").show();
	$("#foot").html(copyRight);

	//ajax global setup
	$.ajaxSetup({
		cache: true,
		beforeSend: function(jqXHR, settings){
			if(typeof(debugMode) != "undefined" && debugMode == true){/*check debug mode command*/
				if(/^<\?xml /.test(settings.data) == true){
					settings.data = "!" + (typeof(settings.data) != "undefined" ? settings.data : "");
				}
			}
		},
		success: function(data, textStatus, jqXHR){
			if(this.dataType == "xml"){
				serverNoResponse = false;

				if($(data).children().attr("reply") == "kick" && $(data).children().attr("key") == WISE.getUser().key){
					if(typeof(aliveChecker) != "undefined"){//avoid receive kick when first to load rule file failed, because aliveChecker is not ready to go
						aliveChecker.stopAliveTimer();
						aliveChecker.stopIdleTimer();

						showIdleTooLongMessage();
					}

					this.error(jqXHR, "keyerror", "Key Error");
					return;
				}
			}

			if(typeof(this.done) == "function"){
				this.done(data, textStatus, jqXHR);
			}
		},
		done: function(){},
		error: function(jqXHR, textStatus, errorThrown){
			if(jqXHR.status == 500 || (jqXHR.status == 0 && (textStatus == "timeout" || textStatus == "error"))){
				if(typeof(serverNoResponse) == "undefined" || serverNoResponse == false){
					popupErrorWindow(LangLogin.runtimeServerNoResponse[WISE.language]);
				}

				serverNoResponse = true;
				//return;
			}
			else if(jqXHR.status == 404){
				popupErrorWindow(LangLogin.fileNotFound[WISE.language]);
			}

			if(typeof(this.fail) == "function"){
				this.fail(jqXHR, textStatus, errorThrown);
			}
		},
		fail: function(){}
	});

	$("#menuButton").bind("click", function(){
		if($("#menuWrapper").hasClass("active")){
			hideMenu();
		}
		else{
			showMenu();
		}
	});

	$("#logoutButton").bind("click", function(){
		popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLogout>", function(result){
			if(result == false){return;}

			WISE.bindFunctionExecute("beforeLogout");
			setCookie("password", "", -1);

			$("#loader").show();
			var xmlDoc = $.parseXML("<LOGOUT/>");
			xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

			$.ajax({ 
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				complete: function(xmlDoc){
					$(window).unbind("unload");						
					location.reload();
				}
			});
		});
	});

	$("#contentCover").bind("click", function(){
		hideMenu();
	});

	$("#menuPadding").css("height", $("#footContainer").outerHeight() + "px");

/*
	$("*[location]").livequery(function() { 
		$(this).bind("click", function(){
			redirectTo($(this).attr("location"));
		});
	});
*/
	$(window).bind("resize.updateViewport", function(){
		$("#contentWrapper, #menuWrapper").css("minHeight", $(window).height() + "px");
		updateViewport();
	}).triggerHandler("resize");

	/*browser compatibility process*/
	if($.browser.webkit){//since chrome version 39, chinese line-height not same with english.
		$("body").css("lineHeight", "1.15");
	}

	aliveChecker = WISE.createAliveChecker({
		"process": function($xmlALIVE){},
		"timeout": function(){
			showIdleTooLongMessage();
		}
	});

	//inset back and forward hash to history
	location.assign("#back");
	setTimeout(function(){
		location.assign("#");
		setTimeout(function(){
			location.assign("#forward");
			history.back();

			setTimeout(function(){
				//bind hash change event
				$(window).bind("hashchange", function(){
					var hash = location.hash.replace(/^#/, "");

					if($("#menuWrapper").hasClass("active")){//when open menu and click <back or forward>
						if(hash == "forward"){
							history.back();
						}
						else if(hash == "back"){
							history.forward();
							hideMenu();
						}
					}
					else{
						if(hash == "forward"){
							history.back();
	/*
							if(historyPool.index < historyPool.array.length - 1){
								history.back();
								historyPool.index++;
								historyChange();
							}
							else{
								history.back();
							}
	*/
						}
						else if(hash == "back"){
							history.forward();

							$('html, body').scrollTop(0);//fix for firefox

							setTimeout(function(){
								showMenu();
							}, 0);

	/*
							if(historyPool.index > 0){
								history.forward();
								//historyPool.index--;
								//historyChange();
							}
							else{
								history.back();
							}
	*/
						}
					}
				});

				loadMenu();
				//redirectTo("#home/main");
			}, 1);
		}, 1);
	}, 1);
}

function showIdleTooLongMessage(){
	popupAlarmWindow("<#Lang['?'].popup.idleTooLong>", function(){
		location.reload();
	});
}

/*
parameter[0] == 0 => Internal Register
parameter[0] == 1 => I/O Module, need pass sourceType, sourceIndex, moduleIndex at parameter[1], parameter[2] and parameter[3]
parameter[0] == 2 => Customized Channel Status Page, need pass statusPageKey at parameter[1]
*/
function generateStatus(parameter, timer, callbackFunction){
	var typeNamePool = {
		"DI": "DI$channel",
		"DIC": "<#Lang['?'].diCounterX>",
		"DO": "DO$channel",
		"DOC": "<#Lang['?'].doCounterX>",
		"AI": "AI$channel",
		"AO": "AO$channel",
		"CI": "Discrete Input $channel",
		"CO": "Coil Output $channel",
		"RI": "Input Register $channel",
		"RO": "Holding Register $channel",
		"IR": "<#Lang['?'].internalRegisterX>"
	};

	timer.stop();
	$("#statusBlockContainer").empty();

	if(parameter[0] == "0"){
		var registerManager = WISE.managers.registerManager;
		var registerExist = false;

		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registers.length; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}

			registerExist = true;
			break;
		}

		if(registerExist == false){
			redirectTo("#home/main", true);
		}
		else{
			createRegisterStatus();
			updateStatus = updateMoudleStatus;
		}
	}
	else if(parameter[0] == "1"){
		var moduleManager = WISE.managers.moduleManager;
		var sourceType = parameter[1];
		var sourceIndex = parseInt(parameter[2], 10);
		var moduleIndex = parseInt(parameter[3], 10);

		try{
			var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
		}
		catch(error){
			var module = null;
		}
		finally{
			if(module == null){
				redirectTo("#home/main", true);
			}
			else{
				createModuleStatus();
				updateStatus = updateMoudleStatus;
			}
		}
	}
	else if(parameter[0] == "2"){
		var statusManager = WISE.managers.statusManager;
		var statusPageKey = parseInt(parameter[1], 10);

		try{
			var statusPage = statusManager.pool.statusPages[statusPageKey];
		}
		catch(error){
			var statusPage = null;
		}
		finally{
			if(statusPage == null){
				redirectTo("#home/main", true);
			}
			else{
				var registerManager = WISE.managers.registerManager;
				var moduleManager = WISE.managers.moduleManager;

				createCustomizeStatus();
				updateStatus = updateCustomizeStatus;
			}
		}
	}

	if($("#statusBlockContainer").children().length == 0){
		$("<div></div>").addClass("statusNone").css({
			"padding": "40px 0"
		}).html("<#Lang['?'].none>").appendTo($("#statusBlockContainer"));
	}

	timer.process = function(timer){
		updateStatus(timer);
	};
	timer.start();

	function createRegisterStatus(){
		var $blockIRContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "statusBlockIRContainer");

		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registerManager.maxAmount; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}

			var title, channel = "<#Lang['?'].internalRegisterX>".replace("$channel", registerIndex + 1);
			if(typeof(registers[registerIndex].name) != "undefined" && registers[registerIndex].name != ""){
				title = registers[registerIndex].name;
				channel += "(" + registers[registerIndex].name + ")";
			}
			else{
				title = "<#Lang['?'].no>" + (registerIndex + 1);
			}

			var setting = {
				"title": title,
				"bevel": registerIndex + 1,
				"channel": channel,
				"type": "IR",
				"registerIndex": registerIndex
			};

			$blockIRContainer.append(createBlock(setting).attr("id", "statusBlock_IR_" + registerIndex));
		}

		$("#statusBlockContainer")/*.append(
			$("<span></span>").attr("class", "title").html("<#Lang['?'].internalRegister>")
		)*/.append(
			$("<div></div>").addClass("infoBlock").append($blockIRContainer)
		).append(
			$("<p></p>")
		);
	}

	function createModuleStatus(){
		if(module.type == "icpdas" || module.type == "onboard"){
			for(var i = 0, typeArray = ["DI", "DO", "AI", "AO"]; i < typeArray.length; i++){
				var $blockContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "status" + typeArray[i] + "BlockContainer");

				for(var j = 0; j < module[typeArray[i]].amount; j++){
					if(module[typeArray[i]].setting[j].disable == true){continue;}

					var title, channel;
					if(module.moduleType != "DL"){
						channel = typeNamePool[typeArray[i]].replace("$channel", module[typeArray[i]].setting[j].channelName);

						if(typeof(module[typeArray[i]].setting[j].name) != "undefined" && module[typeArray[i]].setting[j].name != ""){
							channel += "(" + module[typeArray[i]].setting[j].name + ")";
							title = module[typeArray[i]].setting[j].name;
						}
						else{
							title = "<#Lang['?'].channel>" + module[typeArray[i]].setting[j].channelName;
						}
					}
					else{
						channel = module[typeArray[i]].setting[j].channelName;

						if(typeof(module[typeArray[i]].setting[j].name) != "undefined" && module[typeArray[i]].setting[j].name != ""){
							channel += "(" + module[typeArray[i]].setting[j].name + ")";
							title = module[typeArray[i]].setting[j].name;
						}
						else{
							title = module[typeArray[i]].setting[j].channelName;
						}
					}

					var setting = {
						"title": title,
						"bevel": /*module[typeArray[i]].setting[j].channelName*/j,
						"channel": channel,
						"type": typeArray[i],
						"sourceType": sourceType,
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex
					};

					if(typeArray[i] == "AI"){
						setting.unit = moduleManager.icpdasModule.getAIRange(module, j).unit;
					}
					else if(typeArray[i] == "AO"){
						setting.unit = moduleManager.icpdasModule.getAORange(module.AO.setting[j].type).unit;
					}

					var protocol = moduleManager.pool.interfaces[sourceType][sourceIndex].protocol;
					if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
 						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, typeArray[i], j);

						setting.channelType = channelAddressInfo[0];
						setting.channelAddress = channelAddressInfo[1];
						setting.channelIndex = j;//for DI Counter to calculate the address
						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + channelAddressInfo[0] + "_" + channelAddressInfo[1]));
					}
					else{
						setting.channelType = typeArray[i];
						setting.channelIndex = j;
						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + typeArray[i] + "_" + j));
					}
				}

				if($blockContainer.children().length > 0){
					$("#statusBlockContainer").append(
						$("<span></span>").attr("class", "title").html(typeArray[i])
					).append(
						$("<div></div>").addClass("infoBlock").append($blockContainer)
					).append(
						$("<p></p>")
					);
				}
			}

			if(module.moduleType == "WISE"){
				var $blockContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "statusBlockIRContainer");

				for(var i = 0; i < module.IR.amount; i++){
					var setting = {
						"title": module.IR.setting[i].name || ("<#Lang['?'].no>" + (i + 1)),
						"bevel": i + 1,
						"type": "RO",
						"sourceType": sourceType,
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex
					};

					var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, "IR", i);

					setting.channelType = channelAddressInfo[0];
					setting.channelAddress = channelAddressInfo[1];

					var $block = createBlock(setting).attr("id", "statusBlock_" + channelAddressInfo[0] + "_" + channelAddressInfo[1]);
					$blockContainer.append($block);
				}

				$("#statusBlockContainer").append(
					$("<span></span>").attr("class", "title").html("<#Lang['?'].internalRegister>")
				).append(
					$("<div></div>").addClass("infoBlock").append($blockContainer)
				).append(
					$("<p></p>")
				);
			}
		}
		else if(module.type == "rtu" || module.type == "tcp"){
			for(var i = 0, typeArray = ["CI", "CO", "RI", "RO"]; i < typeArray.length; i++){
				if(module[typeArray[i]].blockArray.length > 0){
					var $blockContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "status" + typeArray[i] + "BlockContainer");

					for(var address in module[typeArray[i]].remoteAddress){
						var title, channel = typeNamePool[typeArray[i]].replace("$channel", address);
						if(typeof(module[typeArray[i]].remoteAddress[address].name) != "undefined" && module[typeArray[i]].remoteAddress[address].name != ""){
							title = module[typeArray[i]].remoteAddress[address].name;
							channel += "(" + module[typeArray[i]].remoteAddress[address].name + ")";
						}
						else{
							title = "<#Lang['?'].address>" + address;
						}

						var setting = {
							"title": title,
							"bevel": address,
							"channel": channel,
							"type": typeArray[i],
							"sourceType": sourceType,
							"sourceIndex": sourceIndex,
							"moduleIndex": moduleIndex,
							"channelAddress": address
						};

						if(typeArray[i] == "RI" || typeArray[i] == "RO"){
							setting.unit = module[typeArray[i]].remoteAddress[address].unit;
						}

						if(typeArray[i] == "CO" || typeArray[i] == "RO"){
							if(module[typeArray[i]].blockArray[module[typeArray[i]].remoteAddress[address].blockIndex].writable == false){
								setting.writable = false;
							}
						}

						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + typeArray[i] + "_" + address));
					}

					$("#statusBlockContainer").append(
						$("<span></span>").attr("class", "title").html(typeNamePool[typeArray[i]].replace("$channel", ""))
					).append(
						$("<div></div>").addClass("infoBlock").append($blockContainer)
					).append(
						$("<p></p>")
					);
				}
			}
		}

		//create connection status light
		if(module.type != "onboard"){
			$("#statusBlockContainer .title:first").before(
				$("<div></div>").attr("class", "statusPollingTimeWrapper").append(
					$("<div></div>").attr("class", "statusPollingTimeContainer").append(
						$("<span></span>").css({
							"verticalAlign": "middle"
						}).addClass("statusLight iconsLight unknown").attr("id", "statusLight")
					).append(
						$("<span></span>").attr({
							"class": "statusPollingTime",
							"id": "statusPollingTime"
						}).css({
							"verticalAlign": "middle"
						}).html("&nbsp;")
					)
				)
			);
		}
	}

	function createCustomizeStatus(){
		for(var i = 0; i < statusPage.group.length; i++){
			var group = statusPage.group[i];

			var $blockContainer = $("<div></div>").addClass("infoBlockContent");
			for(var j = 0; j < group.block.length; j++){
				var block = group.block[j];
				var setting = $.extend(true, {}, block);

				if(block.type == "IR"){
					if(block.moduleKey == null){
						var register = registerManager.pool.registers[block.registerIndex];
						setting.name = register.name;
						setting.title = typeNamePool[block.type].replace("$channel", block.registerIndex + 1);
					}
					else{
						var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
						var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

						setting.name = module.IR.setting[block.registerIndex].name;
						setting.title = typeNamePool[block.type].replace("$channel", block.registerIndex + 1);

						setting.sourceType = moduleInfo.sourceType;
						setting.sourceIndex = moduleInfo.sourceIndex;
						setting.moduleIndex = moduleInfo.moduleIndex;

						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, "IR", block.registerIndex);
						setting.channelType = channelAddressInfo[0];
						setting.channelAddress = channelAddressInfo[1];
					}
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
					var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

					if(block.type == "DI" || block.type == "DIC" || block.type == "DO" || block.type == "DOC" || block.type == "AI" || block.type == "AO"){
						var channelInfo = WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, block.type, block.channelIndex);

						var channelName = channelInfo.channelName;
						if(channelName.match(/^\d+$/)){
							setting.title = typeNamePool[block.type].replace("$channel", channelName);
						}
						else{//customized channel name, like DL
							setting.title = channelName;
						}

						setting.name = channelInfo.name;

						if(block.type == "AI"){
							setting.unit = moduleManager.icpdasModule.getAIRange(module, block.channelIndex).unit;
						}
						else if(block.type == "AO"){
							setting.unit = moduleManager.icpdasModule.getAORange(module.AO.setting[block.channelIndex].type).unit;
						}

						var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
						if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
	 						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, block.type, block.channelIndex);

							setting.channelType = channelAddressInfo[0];
							setting.channelAddress = channelAddressInfo[1];
							setting.channelIndex = j;//for DI Counter to calculate the address
						}
					}
					else{
						setting.title = typeNamePool[block.type].replace("$channel", block.channelAddress);
						setting.name = module[block.type].remoteAddress[block.channelAddress].name;

						if(block.type == "RI" || block.type == "RO"){
							setting.unit = module[block.type].remoteAddress[block.channelAddress].unit;
						}

						if(block.type == "CO" || block.type == "RO"){
							if(module[block.type].blockArray[module[block.type].remoteAddress[block.channelAddress].blockIndex].writable == false){
								setting.writable = false;
							}
						}
					}

					setting.sourceType = moduleInfo.sourceType;
					setting.sourceIndex = moduleInfo.sourceIndex;
					setting.moduleIndex = moduleInfo.moduleIndex;
				}

				createBlock(setting, "customize").attr("id", "statusBlock_" + i + "_" + j).appendTo($blockContainer);
			}

			$("#statusBlockContainer").append(
				$("<div></div>").attr("class", "title").html(group.title)
			).append(
				$("<div></div>").addClass("infoBlock").append($blockContainer)
			).append(
				$("<p></p>")
			);
		}
	}

	function createBlock(setting, blockType){
		var $button = $("<button></button>").attr("class", "statusBlockButton")/*.disableSelection()*/;

		if(setting.type == "DI" || setting.type == "DO" || setting.type == "CI" || setting.type == "CO"){
			$button.append(
				(function(){
					if(setting.type == "DO"){
						var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];
/*
						if(module.mainType == "7088"){
							return $("<span></span>").html("PWM&nbsp;");
						}
*/
					}
				})()
			).append(
				$("<span></span>").attr("class", (function(){
					var className = "statusBlockValue";
					if(setting.type == "DI"){
						var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];

						if(moduleManager.icpdasModule.isDICounterModule(module)){
							className += " isDICounterModule";
						}

						if(module.moduleType == "XWBoard"){
							className += " isXWBoard";
						}
					}

					return className;
				})()).text("-")
			).append(
				$("<div></div>").attr("class", (function(){
					var className = "statusBlockLight UNKNOWN";
					if(setting.type == "DI"){
						var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];

						if(moduleManager.icpdasModule.isDICounterModule(module)){
							className += " isDICounterModule";
						}
					}

					return className;
				})()).html("&nbsp;")
			);

			if(setting.type == "DI" || setting.type == "CI" || (setting.type == "CO" && setting.writable == false) || (WISE.getUser().character == "user" && WISE.permissionCheck(6) == false) || WISE.getUser().character == "guest"){
				$button.attr("disabled", true).addClass("hide unEditable");
			}
			else{//DO, CO and user is admin
				$button.bind("click", {"block": setting}, function(event){
					if($(this).hasClass("show")){return;}

					$("#statusBlockContainer .statusBlockButton").not(".unEditable").attr("disabled", true).addClass("show");
					timer.stop();//stop refresh

					var block = event.data.block;
					var moduleType = processModuleType(block);

					var xmlDoc = $.parseXML("<SET/>");
					xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
					xmlDoc.documentElement.setAttribute("type", moduleType);
					xmlDoc.documentElement.setAttribute("ch", block.channelType || block.type);
					xmlDoc.documentElement.setAttribute("chn", typeof(block.channelAddress) != "undefined" ? block.channelAddress : block.channelIndex);
					if(moduleType != "XBOARD"){
						xmlDoc.documentElement.setAttribute("com", block.sourceIndex);
						xmlDoc.documentElement.setAttribute("module", block.moduleIndex + 1);
					}
					xmlDoc.documentElement.appendChild(xmlDoc.createTextNode($button.find(".statusBlockValue").text() == "ON" ? 0 : 1));

					WISE.startAjax("content", {
						url: "./dll/wise.dll",
						type: "POST",
						data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
						contentType: "text/xml",
						processData: false,
						cache: false,
						dataType: "xml",
						complete: function(){
							$("#statusBlockContainer .statusBlockButton").not(".unEditable").attr("disabled", false).removeClass("show");
							timer.start();
						}
					});

					event.stopPropagation();
				});
			}
		}
		else if(setting.type == "DIC" || setting.type == "DOC" || setting.type == "AI" || setting.type == "AO" || setting.type == "RI" || setting.type == "RO" || setting.type == "IR"){
			$button.append(
				$("<span></span>").attr("class", "statusBlockValue").text("-")
			).append(
				$("<span></span>").attr("class", "statusBlockUnit").html("&nbsp;" + (setting.unit ? setting.unit : ""))
			);

			if(setting.type == "DIC" || setting.type == "DOC" || setting.type == "AI" || setting.type == "RI" || (setting.type == "RO" && setting.writable == false) || (WISE.getUser().character == "user" && WISE.permissionCheck(6) == false) || WISE.getUser().character == "guest"){
				$button.attr("disabled", true).addClass("hide unEditable");
			}
			else{//AO, RO and user is admin
				$button.bind("click", {"block": setting}, function(event){
					if($(this).hasClass("show")){return;}

					$("#statusBlockContainer .statusBlockButton").not(".unEditable").attr("disabled", true).addClass("show");
					timer.stop();//stop refresh

					showPrompt("<#Lang['?'].enterValue>", $(this).find(".statusBlockValue").text(), function(value){
						var resumeRefresh = function(){
							$("#statusBlockContainer .statusBlockButton").not(".unEditable").attr("disabled", false).removeClass("show");
							timer.start();
						};

						if(value == null){//click cancel
							resumeRefresh();
							return;
						}

						var block = event.data.block;
						var xmlDoc = $.parseXML("<SET/>");
						xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

						if(setting.type == "IR" && typeof(setting.moduleIndex) == "undefined"){
							xmlDoc.documentElement.setAttribute("type", "IR");
							xmlDoc.documentElement.setAttribute("module", block.registerIndex + 1);
						}
						else{
							xmlDoc.documentElement.setAttribute("type", processModuleType(block));
							xmlDoc.documentElement.setAttribute("com", block.sourceIndex);
							xmlDoc.documentElement.setAttribute("module", block.moduleIndex + 1);
							xmlDoc.documentElement.setAttribute("ch", block.channelType || block.type);
							xmlDoc.documentElement.setAttribute("chn", typeof(block.channelAddress) != "undefined" ? block.channelAddress : block.channelIndex);
						}
						xmlDoc.documentElement.appendChild(xmlDoc.createTextNode(value));

						WISE.startAjax("content", { 
							url: "./dll/wise.dll",
							type: "POST",
							data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
							contentType: "text/xml",
							processData: false,
							cache: false,
							dataType: "xml",
							complete: function(){
								resumeRefresh();
							}
						});
					});

					event.stopPropagation();
				});
			}
		}

		if(typeof(blockType) != "undefined" && blockType == "customize"){
			var $statusBlock = $("<div></div>").attr("class", "statusBlock").bind("click", {"setting": setting}, function(event){
				var $button = $(this).find("button.statusBlockButton");

				if(setting.type == "IR"){
					if(typeof(setting.moduleIndex) == "undefined"){
						var $table = $("<table></table>").append(
							$("<tr></tr>").append(
								$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.channel>")
							).append(
								$("<td></td>").html(setting.title)
							)
						).append(
							$("<tr></tr>").append(
								$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.value>")
							).append(
								$("<td></td>").html($button.find(".statusBlockValue").text() + "&nbsp;" + $button.find(".statusBlockUnit").text())
							)
						);

					}
					else{
						var $table = $("<table></table>").append(
							$("<tr></tr>").append(
								$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.module>")
							).append(
								$("<td></td>").html(moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].name + "&nbsp;" + WISE.moduleInfo(setting.sourceType, setting.sourceIndex, setting.moduleIndex))
							)
						).append(
							$("<tr></tr>").append(
								$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.channel>")
							).append(
								$("<td></td>").html(setting.title)
							)
						).append(
							$("<tr></tr>").append(
								$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.value>")
							).append(
								$("<td></td>").html($button.find(".statusBlockValue").text() + "&nbsp;" + $button.find(".statusBlockUnit").text())
							)
						);
					}
				}
				else{
					var $table = $("<table></table>").append(
						$("<tr></tr>").append(
							$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.module>")
						).append(
							$("<td></td>").html(moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].name + "&nbsp;" + WISE.moduleInfo(setting.sourceType, setting.sourceIndex, setting.moduleIndex))
						)
					).append(
						$("<tr></tr>").append(
							$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.channel>")
						).append(
							$("<td></td>").html(setting.title)
						)
					).append(
						$("<tr></tr>").append(
							$("<td></td>").attr("align", "right").css("fontWeight", "bold").html("<#Lang['?'].popup.value>")
						).append(
							$("<td></td>").html($button.find(".statusBlockValue").text() + "&nbsp;" + $button.find(".statusBlockUnit").text())
						)
					);
				}

				showAlert($table);
			}).append(
				$("<div></div>").attr("class", "statusBlockWrapper").append(
					$("<div></div>").attr("class", "statusBlockBevel").css("visibility", "hidden").html("&nbsp;")
				).append((function(){
					if((setting.type == "DI" || setting.type == "DIC" || setting.type == "DOC" || setting.type == "AI" || setting.type == "RI") || (WISE.getUser().character == "guest" && (setting.type == "AO" || setting.type == "RO" || setting.type == "IR"))){
						return $("<div></div>").addClass("statusBlockButtonWrapper").append(
							$button
						).append(
							$("<div></div>").addClass("statusBlockButtonCover")
						)
					}
					else{
						return $button;
					}
				})()).append(
					$("<div></div>").attr("class", "statusBlockName").append(setting.name || setting.title)
				)
			);

			if(setting.type == "DIC"){
				$statusBlock.addClass("isDICounter");
			}
		}
		else{
			var $statusBlock = $("<div></div>").attr("class", "statusBlock").append(
				$("<div></div>").attr("class", "statusBlockWrapper").append(
					$("<div></div>").attr("class", "statusBlockBevel").html(setting.bevel)
				).append((function(){
					if((setting.type == "AI" || setting.type == "RI") || (WISE.getUser().character == "guest" && (setting.type == "AO" || setting.type == "RO" || setting.type == "IR"))){
						return $("<div></div>").addClass("statusBlockButtonWrapper").append(
							$button
						).append(
							$("<div></div>").addClass("statusBlockButtonCover").bind("click", {"channel": setting.channel}, function(event){
								var $button = $(this).prev(".statusBlockButton");
								showAlert("<#Lang['?'].valueOfChannel>".replace("$channel", event.data.channel) + "<br>" + $button.find(".statusBlockValue").text() + "&nbsp;" + $button.find(".statusBlockUnit").text());
							})
						)
					}
					else{
						return $button;
					}
				})()).append(
					$("<div></div>").attr("class", "statusBlockName").append(setting.title)
				)
			);
		}

		if(blockType != "customize" && ((setting.type == "DI" && !moduleManager.icpdasModule.isNoDICounterModule(module)) || (setting.type == "DO" && moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex].moduleType == "WISE"))){
			$statusBlock.find(".statusBlockWrapper").append(
				$("<div></div>").attr("class", "statusBlockCounter").html("<#Lang['?'].counter>&nbsp;").append(
					$("<span></span>").attr("id", (function(){
						var interfaces = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex];
						var protocol = interfaces.protocol;
						var module = interfaces.modules[setting.moduleIndex];

						if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
							var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, setting.type + "C", setting.channelIndex);
							return "statusCounter_" + channelAddressInfo[0] + "_" + channelAddressInfo[1];
						}
						else{
							return "statusCounter_DI_" + setting.channelIndex;
						}
					})()).text("-")
				)
			)
		}

		return $statusBlock;
	}

	function updateValue($textFiled, value){
		if(!$textFiled.attr("textColor")){
			$textFiled.attr("textColor", $textFiled.css("color"));
		}

		var previousValue = $textFiled.text();
		
		if(previousValue != value && previousValue != "-" && previousValue != ""){
			$textFiled.stop().css("color", "#FF0000").animate({"color": $textFiled.attr("textColor")}, 2000, "easeInExpo");
		}

		$textFiled.text(value);
	}

	function updateMoudleStatus(timer){
		$("#contentLoader").show();

		var xmlDoc = $.parseXML("<STATUS/>");

		xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

		if(parameter[0] == "0"){//IR
			xmlDoc.documentElement.setAttribute("type", "IR");
		}
		else{
			var moduleType = processModuleType({
				"sourceType": sourceType,
				"sourceIndex": sourceIndex,
				"moduleIndex": moduleIndex
			});

			xmlDoc.documentElement.setAttribute("type", moduleType);

			if(moduleType != "XBOARD"){
				xmlDoc.documentElement.setAttribute("com", sourceIndex);
				xmlDoc.documentElement.setAttribute("module", moduleIndex + 1);
			}
		}

		timer.addAjax(
			WISE.startAjax("content", { 
				url: "./dll/wise.dll",
				//url: "./dll/xml/status5.xml",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				done: function(xmlDoc){
					var $xmlSTATUS = $(xmlDoc).find("STATUS");

					if($xmlSTATUS.attr("online") && typeof(callbackFunction) == "function"){
						callbackFunction($xmlSTATUS.attr("online"));
					}

					var pollingTime = parseInt($xmlSTATUS.attr("polling_time"), 10);
					if(!isNaN(pollingTime)){
						$("#statusPollingTime").html(formatPollingTime(pollingTime).join(""));
						//$("#statusPollingTimeWrapper").show();
					}

					var $xmlElement = $xmlSTATUS.children();
					for(var i = 0; i < $xmlElement.length; i++){
						var tagName = $xmlElement[i].tagName;

						if(tagName == "DI" || tagName == "DO" || tagName == "CI" || tagName == "CO"){
							var $statusBlockText = $("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockValue:not(.isDICounterModule)");

							if(tagName == "DI" && $statusBlockText.hasClass("isXWBoard")){
								var statusString = $($xmlElement[i]).text() == "0" ? "ON" : "OFF";
							}
							else{
								var statusString = $($xmlElement[i]).text() == "0" ? "OFF" : "ON";
							}

							updateValue($statusBlockText, statusString);
							$("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockLight:not(.isDICounterModule)").removeClass("ON OFF UNKNOWN").addClass(statusString);

							if(tagName == "DI" && typeof($($xmlElement[i]).attr("cnt")) != "undefined"){
								//$("#statusBlock_DI_" + $($xmlElement[i]).attr("idx") + " .statusBlockCounter > span").html($($xmlElement[i]).attr("cnt"));
								updateValue($("#statusCounter_DI_" + $($xmlElement[i]).attr("idx")), $($xmlElement[i]).attr("cnt"));
							}
						}
						else if(tagName == "AO" || tagName == "RO"){
							updateValue($("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockValue"), $($xmlElement[i]).text());
							$("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockInputField").val($($xmlElement[i]).text());

						}
						else if(tagName == "IR"){
							updateValue($("#statusBlock_" + tagName + "_" + (parseInt($($xmlElement[i]).attr("idx"), 10) - 1) + " .statusBlockValue"), $($xmlElement[i]).text());
							$("#statusBlock_" + tagName + "_" + (parseInt($($xmlElement[i]).attr("idx"), 10) - 1) + " .statusBlockInputField").val($($xmlElement[i]).text());
						}
						else{//AI, RI
							updateValue($("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockValue"), $($xmlElement[i]).text());
						}

						if(tagName == "RI" || tagName == "RO"){//for M7K DI Counter
							updateValue($("#statusCounter_" + tagName + "_" + $($xmlElement[i]).attr("idx")), $($xmlElement[i]).text());
						}
					}
				},
				complete: function(){
					$("#contentLoader").hide();
					timer.next();
				}
			})
		);
	}

	function updateCustomizeStatus(timer, statusType){
		$("#contentLoader").show();

		var xmlDoc = $.parseXML("<STATUS/>");

		xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
		xmlDoc.documentElement.setAttribute("type", "CUSTOM");
		xmlDoc.documentElement.setAttribute("module", statusPageKey + 1);

		timer.addAjax(
			WISE.startAjax("content", { 
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				done: function(xmlDoc){
					var $xmlG = $(xmlDoc).find("STATUS > G");

					for(var i = 0; i < $xmlG.length; i++){
						var groupKey = parseInt($($xmlG[i]).attr("idx"), 10) - 1;
						var $xmlB = $($xmlG[i]).find("> B");

						for(var j = 0; j < $xmlB.length; j++){
							var type = $($xmlB[j]).attr("type");
							var blockIndex = parseInt($($xmlB[j]).attr("idx"), 10) - 1;

							if(type == "DI" || type == "DO" || type == "CI" || type == "CO"){
								var $statusBlock = $("#statusBlock_" + groupKey + "_" + blockIndex);
								var $statusBlockValue = $statusBlock.find(".statusBlockValue");
								var statusString = $($xmlB[j]).text() == "0" ? "OFF" : "ON";

								if(type == "DI"){
									if($statusBlock.hasClass("isDICounter")){
										updateValue($statusBlockValue, $($xmlB[j]).attr("cnt"));
										continue;
									}
									else{
										if($statusBlockValue.hasClass("isXWBoard")){
											statusString = $($xmlB[j]).text() == "0" ? "ON" : "OFF";
										}
									}
								}

								updateValue($statusBlockValue, statusString);
								$statusBlock.find(".statusBlockLight").removeClass("ON OFF UNKNOWN").addClass(statusString);
								continue;
							}
							else if(type == "AO" || type == "RO" || type == "IR"){
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockValue"), $($xmlB[j]).text());
								$("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockInputField").val($($xmlB[j]).text());
								continue;
							}
							else{//AI, RI
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockValue"), $($xmlB[j]).text());
								continue;
							}

							if((type == "CI" || type == "CO") && $($xmlB[j]).attr("cnt")){//for M7K DI Counter
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockCounter"), $($xmlB[j]).attr("cnt"));
								continue;
							}
						}
					}
				},
				complete: function(){
					$("#contentLoader").hide();
					timer.next();
				}
			})
		);
	}

	function processModuleType(moduleInfo){
		var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas"){
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

			if(protocol == "dcon"){//M7K
				return "DCON";
			}
			else if(protocol == "modbusRTU"){
				return "RTU";
			}
			else if(protocol == "modbusTCP"){
				return "TCP";
			}
			else if(protocol == "httpCGI"){
				return "CAMERA";
			}
		}
		else if(module.type == "onboard"){return "XBOARD";}
		else if(module.type == "rtu"){return "RTU";}
		else if(module.type == "tcp"){return "TCP";}
	};

	function formatPollingTime(ms){
		if(isNaN(ms)){
			return null;
		}
		else{
			var retObject = {
				"join": function(string){
					return this.time + string + this.unit;
				}
			};

			//keep only three digi precision
			var msArray = ms.toString().split("");
			for(var i = 3; i < msArray.length; i++){
				msArray[i] = "0";
			}
			ms = parseInt(msArray.join(""), 10);

			if(ms < 1000){
				retObject.time = ms.toString();
				retObject.unit = "<#Lang.global.ms>";
			}
			else{
		        ms /= 1000;

				retObject.time = ms.toString();
				retObject.unit = "<#Lang.global.s>";
			}

			return retObject;
		}
	}
}

/*
need pass sourceType, sourceIndex, moduleIndex at parameter[0], parameter[1] and parameter[2]
*/
function generateIRCommand(parameter, timer, callbackFunction){
	if(typeof(timer) != "undefined"){
		timer.stop();
	}

	$("#statusBlockContainer").empty();

	var moduleManager = WISE.managers.moduleManager;
	var sourceType = parameter[0];
	var sourceIndex = parseInt(parameter[1], 10);
	var moduleIndex = parseInt(parameter[2], 10);

	try{
		var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
	}
	catch(error){
		var module = null;
	}
	finally{
		if(module == null){
			redirectTo("#home/main", true);
		}
		else{
			if(WISE.getUser().character == "guest"){
				$("<div></div>").addClass("statusNone").css({
					"padding": "40px 0"
				}).html("<#Lang['?'].none>").appendTo($("#statusBlockContainer"));
			}
			else{
				createModuleStatus();
			}
		}
	}

	if(typeof(timer) != "undefined"){
		timer.process = function(timer){
			updateStatus(timer);
		};
		timer.start();
	}

	function createModuleStatus(){
		//channel

		var $blockIRChannelContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "statusBlockIRChannelContainer");

		var channelAmount = moduleManager.icpdasModule.getIRChannelAmount(module);
		for(var i = 0; i < channelAmount; i++){
			$blockIRChannelContainer.append(createChannel({
				"title": "<#Lang['?'].ch>" + (i + 1)
			}).attr("id", "statusBlock_IR_Channel_" + i));
		}

		$blockIRChannelContainer.children(":first").addClass("checked");

		$("#statusBlockContainer").append(
			$("<div></div>").attr("class", "title").html("<#Lang['?'].outputChannel>")
		).append(
			$("<div></div>").addClass("infoBlock").append($blockIRChannelContainer)
		).append(
			$("<p></p>")
		);

		//command
		var $blockIRCommandContainer = $("<div></div>").addClass("infoBlockContent").attr("id", "statusBlockIRCommandContainer");

		for(var i = 0; i < module.command.length; i++){
			if(typeof(module.command[i]) == "undefined"){continue;}

			$blockIRCommandContainer.append(createCommand({
				"name": module.command[i] == "" ? "-" : module.command[i],
				"bevel": i + 1,
				"moduleKey": module.key,
				"commandIndex": i
			}).attr("id", "statusBlock_IR_Command_" + i));
		}

		if($blockIRCommandContainer.children().length <= 0){
			$blockIRCommandContainer.append(
				$("<div></div>").addClass("statusNone").css({
					"padding": "40px 0"
				}).html("<#Lang['?'].none>")
			);
		}

		$("#statusBlockContainer").append(
			$("<div></div>").attr("class", "title").html("<#Lang['?'].availableCommand>")
		).append(
			$("<div></div>").addClass("infoBlock").append($blockIRCommandContainer)
		).append(
			$("<p></p>")
		);

		//create connection status light
		if(module.type != "onboard"){
			$("#statusBlockContainer .title:first").before(
				$("<div></div>").attr("class", "statusPollingTimeWrapper").append(
					$("<div></div>").attr("class", "statusPollingTimeContainer").append(
						$("<span></span>").css({
							"verticalAlign": "middle"
						}).addClass("statusLight iconsLight unknown").attr("id", "statusLight")
					).append(
						$("<span></span>").attr({
							"class": "statusPollingTime",
							"id": "statusPollingTime"
						}).css({
							"verticalAlign": "middle"
						}).html("&nbsp;")
					)
				)
			);
		}
	}

	function createChannel(setting){
		var $statusBlock = $("<div></div>").attr("class", "statusBlock").css({
			"overflow": "hidden",
			"cursor": "pointer"
		}).append(
			$("<div></div>").attr("class", "statusBlockInnerDiv").append(
				$("<div></div>").attr("class", "statusBlockChannelCheck")
			).append(
				$("<div></div>").attr("class", "statusBlockChannelContent").append(
					$("<div></div>").attr("class", "statusBlockChannelIRContainer").append(
						$("<div></div>").attr("class", "statusBlockChannelIR")
					).append("&nbsp;")
				).append(
					$("<span></span>").attr("class", "statusBlockChannelName").html((typeof(setting.title) == "undefined" || setting.title == "") ? "-" : setting.title)
				)
			)
		).bind("click", function(){
			if($(this).hasClass("checked")){
				$(this).removeClass("checked");
			}
			else{
				$(this).addClass("checked");
			}
		});

		return $statusBlock;
	}

	function createCommand(setting){
		var $button = $("<button></button>").attr("class", "statusBlockButton")/*.disableSelection()*/;

		$button.append(
			$("<div></div>").attr("class", "statusBlockLightContainer").append(
				$("<span></span>").attr("class", "statusBlockText").text("<#Lang['?'].transmit>")
			)
		);

		$button.bind("click", {"block": setting}, function(event){
			if($(this).hasClass("show")){return;}

			var $outputChannel = $("#statusBlockIRChannelContainer").children(".checked");
			if($outputChannel.length <= 0){
				popupErrorWindow("<#Lang['?'].popup.outputChannelIsEmpty>");
				return;
			}

			var outputChannel = 0;
			$outputChannel.each(function(index) {
				var splitArray = $(this).attr("id").split("_");
				outputChannel += Math.pow(2, parseInt(splitArray[splitArray.length - 1], 10));
			});

			$("#statusBlockContainer .statusBlockButton").attr("disabled", true).addClass("show");

			var xmlDoc = $.parseXML("<SET/>");
			var block = event.data.block;
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
			var module = moduleInfo.module;
			var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, "AO", 0);
			var moduleType = processModuleType(moduleInfo);

			xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
			xmlDoc.documentElement.setAttribute("type", moduleType);
			xmlDoc.documentElement.setAttribute("ch", channelAddressInfo[0]);
			xmlDoc.documentElement.setAttribute("chn", channelAddressInfo[1]);
			if(moduleType != "XBOARD"){
				xmlDoc.documentElement.setAttribute("com", moduleInfo.sourceIndex);
				xmlDoc.documentElement.setAttribute("module", moduleInfo.moduleIndex + 1);
			}

			xmlDoc.documentElement.appendChild(xmlDoc.createTextNode((outputChannel << 16) + (block.commandIndex + 1)));

			WISE.startAjax("content", {
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				complete: function(){
					setTimeout(function(){
						$("#statusBlockContainer .statusBlockButton").attr("disabled", false).removeClass("show");
					}, 5000);
				}
			});

			event.stopPropagation();
		});

		var $statusBlock = $("<div></div>").attr("class", "statusBlock").append(
			$("<div></div>").attr("class", "statusBlockWrapper").append(
				$("<div></div>").attr("class", "statusBlockBevel").html(setting.bevel)
			).append(
				$button
			).append(
				$("<div></div>").attr("class", "statusBlockName").append((typeof(setting.name) == "undefined" || setting.name == "") ? "-" : setting.name)
			)
		);

		return $statusBlock;
	}

	function processModuleType(moduleInfo){
		var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas"){
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

			if(protocol == "dcon"){//M7K
				return "DCON";
			}
			else if(protocol == "modbusRTU"){
				return "RTU";
			}
			else if(protocol == "modbusTCP"){
				return "TCP";
			}
		}
		else if(module.type == "onboard"){return "XBOARD";}
		else if(module.type == "rtu"){return "RTU";}
		else if(module.type == "tcp"){return "TCP";}
	};

	function updateStatus(timer){
		$("#contentLoader").show();

		var xmlDoc = $.parseXML("<CONNECT/>");
		xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

		timer.addAjax(
			WISE.startAjax("content", { 
				url: "./dll/wise.dll",
				//url: "./dll/xml/status5.xml",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				done: function(xmlDoc){
					var $xmlCONNECT = $(xmlDoc).find("CONNECT");

					if($xmlCONNECT.length > 0){
						if(typeof(callbackFunction) == "function"){
							if(sourceType == "comport"){
								callbackFunction($xmlCONNECT.find("COM[idx='" + sourceIndex + "'] > MODULE[idx='" + (moduleIndex + 1) + "']").attr("online"));
							}
							else if(sourceType == "network"){
								callbackFunction($xmlCONNECT.find("TCP > MODULE[idx='" + (moduleIndex + 1) + "']").attr("online"));
							}
						}
					}
				},
				complete: function(){
					$("#contentLoader").hide();
					timer.next();
				}
			})
		);
	}
}