WISE.managers.statusManager = (function(){
	return new function() {
		this.pool = {
			statusPages: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxStatusAmount = 12;
		this.maxGroupAmount = 5;
		this.maxBlockAmount = 30;//for each group, not all

		this.createStatus = function(settings){
			var statusPage = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"group": []
			}, settings);
			
			return statusPage;
		};

		this.addStatus = function(statusPage){
			var retKey = this.pool.key;
			this.pool.statusPages[this.pool.key++] = statusPage;
			return retKey;
		};

		this.removeStatus = function(index){
			delete this.pool.statusPages[index];
		};

		this.setStatus = function(index, statusPage){
			this.pool.statusPages[index] = statusPage;
		};

		this.getStatus = function(index){
			if(typeof(this.pool.statusPages[index]) != "undefined"){
				return this.pool.statusPages[index];
			}
			else{
				return null;
			}
		};

		this.setStatusPages = function(key, statusPage){
			this.pool.statusPages[key] = statusPage;
		};

		this.getStatusPages = function(){
			return this.pool.statusPages;
		};
	};
})();
