WISE.managers.iotstarManager.check = function(){//return null means no error
	if(this.pool.sendback.realtime.enable == true){
		var columns = this.pool.sendback.realtime.columns;

		for(var i = 0; i < columns.length; i++){
			var column = columns[i];

			if(column.channelType == "IR"){
				if(column.moduleKey == null){
					var registerManager = WISE.managers.registerManager;
					if(typeof(registerManager.pool.registers[column.registerIndex]) == "undefined"){
						columns.splice(i, 1);
						i--;
					}
				}
				else{
					var moduleManager = WISE.managers.moduleManager;
					var module = moduleManager.getModuleByKey(column.moduleKey);
					if(module == null){
						columns.splice(i, 1);
						i--;
					}
				}
			}
			else{
				var moduleManager = WISE.managers.moduleManager;
				var module = moduleManager.getModuleByKey(column.moduleKey);

				if(module == null){
					columns.splice(i, 1);
					i--;
				}
				else{
					if(typeof(module.extendedModule) != "undefined"){
						if(this.check.processExtendedModuleObject(column) == false){
							columns.splice(i, 1);
							i--;
						}
					}
					else{
						var channelType = column.channelType;
						if(channelType == "DIC"){
							channelType = "DI";
						}
						else if(channelType == "DOC"){
							channelType = "DO";
						}

						if(
							(
								(module.type == "icpdas" || module.type == "onboard") && (module[channelType].amount <= column.channel || module[channelType].setting[column.channel].disable == true)
							) || (
								(module.type == "rtu" || module.type == "tcp") && typeof(module[channelType].remoteAddress[column.channel]) == "undefined"
							)
						){
							columns.splice(i, 1);
							i--;
						}
					}
				}
			}
		}

		if(columns.length <= 0){
			return {
				"hash": "#home/advanced/iotstar",
				"message": "<#Lang['?'].sendBackChannelIsEmpty>"
			};
		}
	}
};