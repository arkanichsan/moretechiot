$.extend(true, Lang, {
	"js/wise/manager/ping/rule/object.js": {
		"failed": "Failed"
	}
});