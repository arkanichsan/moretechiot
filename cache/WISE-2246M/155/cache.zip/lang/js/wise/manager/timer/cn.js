$.extend(true, Lang, {
	"js/wise/manager/timer/rule/object.js": {
		"timer": "定时器",
		"notTimeout": "未超时",
		"timeout": "已超时",
		"stop": "停止",
		"reset": "重置",
		"start": "启动",
		"pause": "暂停",
		"resume": "恢复"
	},
	"js/wise/manager/timer/rule/encoder.js": {
		"someoneTimerUseAlreadyRemovedRegister": "定时器使用了已经被移除的内部缓存器数值做为时间长度。"
	}
});