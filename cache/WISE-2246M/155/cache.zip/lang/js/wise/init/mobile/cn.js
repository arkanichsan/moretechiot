$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"internalRegister": "内部缓存器",
		"no": "编号",
		"channel": "通道",
		"address": "地址",
		"counter": "计数器:",
		"enterValue": "请输入数值：",
		"valueOfChannel": "$channel数值：",
		"none": "无",
		"diCounterX": "DI计数器$channel",
		"doCounterX": "DO计数器$channel",
		"internalRegisterX": "内部缓存器$channel",
		"ch": "通道",
		"outputChannel": "输出通道",
		"availableCommand": "可用命令",
		"transmit": "传送",
		"popup": {
			"areYouSureYouWantToLogout": "您确定要注销吗？",
			"idleTooLong": "您空闲过久，为了安全起见系统已将您注销，请重新登录即可。",
			"module": "模块：",
			"channel": "通道：",
			"value": "数值：",
			"outputChannelIsEmpty": "没有选择输出通道，请至少勾选一个输出通道后再按传送。"
		}
	}
});