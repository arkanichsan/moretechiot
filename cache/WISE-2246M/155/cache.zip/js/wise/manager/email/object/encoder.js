WISE.managers.emailManager.encodeXMLObject = function(xmlDoc){
	var xmlEMAIL = xmlDoc.createElement("EMAIL");

	for(var key in this.pool.emails){
		var email = this.pool.emails[key];
		var xmlE = xmlDoc.createElement("E");

		xmlE.setAttribute("idx", email.index);
		xmlE.setAttribute("server", email.smtpServer.url);
		xmlE.setAttribute("port", email.smtpServer.port);
		xmlE.setAttribute("security", email.authInfo.securityMode);
		if(email.authInfo.securityMode != 3){
			xmlE.setAttribute("id", email.authInfo.id);
			if(email.authInfo.password.plain == "" || email.authInfo.password.plain != padding("", email.authInfo.password.length, "*")){//setup new password
				xmlE.setAttribute("password", email.authInfo.password.plain);
				xmlE.setAttribute("password_len", email.authInfo.password.plain.length);
			}
			else{
				xmlE.setAttribute("password", email.authInfo.password.encoded);
				xmlE.setAttribute("password_len", email.authInfo.password.length);
			}
		}

		xmlE.setAttribute("sender", email.senderInfo.name);
		xmlE.setAttribute("sender_email", email.senderInfo.address);
		xmlE.setAttribute("nickname", email.name);

		if(email.description != ""){
			xmlE.setAttribute("desc", email.description);
		}

		var xmlRECIPIENT = xmlDoc.createElement("RECIPIENT");
		xmlRECIPIENT.appendChild(xmlDoc.createTextNode(email.receiverInfo.address.join(",")));
		xmlE.appendChild(xmlRECIPIENT);

		var xmlSUBJECT = xmlDoc.createElement("SUBJECT");
		xmlSUBJECT.appendChild(xmlDoc.createTextNode(email.subject));
		xmlE.appendChild(xmlSUBJECT);

		var xmlCONTENT = xmlDoc.createElement("CONTENT");
		xmlCONTENT.appendChild(xmlDoc.createTextNode(email.content));
		xmlE.appendChild(xmlCONTENT);

		xmlEMAIL.appendChild(xmlE);
	}

	if(xmlEMAIL.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlEMAIL);
				break;
			}
		}
	}
};

WISE.managers.emailManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.emails){
		this.pool.emails[key].index = ++index;
	}
};