WISE.managers.emailManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "EMAIL"){
		if(xmlDoc.tagName == "IF"){
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.email);
			ruleObject.rule.emailKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
		}
	}

	return ruleObject;
};