WISE.managers.lineBotManager.encodeXMLObject = function(xmlDoc){
	var xmlLINE_BOT = xmlDoc.createElement("LINE_BOT");

	// Message
	var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

	for(var key in this.pool.messages){
		var message = this.pool.messages[key];
		var xmlM = xmlDoc.createElement("M");

		xmlM.setAttribute("idx", message.index);
		xmlM.setAttribute("nickname", message.name);

		if(message.description != ""){
			xmlM.setAttribute("desc", message.description);
		}

		xmlM.appendChild(xmlDoc.createTextNode(message.content));

		xmlMESSAGE.appendChild(xmlM);
	}

	if(xmlMESSAGE.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlMESSAGE);
	}

    // FTP Server
    var xmlSENDBOX = null;
    var systemManager = WISE.managers.systemManager;
	var server = systemManager.pool.ftpServer;

    try{
        if(server.lineBot.enable == true){
			xmlSENDBOX = xmlDoc.createElement("SENDBOX");
			xmlSENDBOX.setAttribute("mode", "0");
			xmlSENDBOX.appendChild(xmlDoc.createTextNode(server.lineBot.content));

			xmlLINE_BOT.appendChild(xmlSENDBOX);
        }
    }
    catch(error){}

	// IP Camera
	var xmlCAMERA = xmlDoc.createElement("CAMERA");
	xmlCAMERA.setAttribute("mode", "0");

	var counter = 0;
	var moduleManager = WISE.managers.moduleManager;
	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			try{
				if(modules[moduleIndex].lineBot.enable == true){
					var xmlC = xmlDoc.createElement("C");
					xmlC.setAttribute("camera_idx", moduleIndex + 1);
					xmlC.setAttribute("idx", ++counter);

					var xmlMSG = xmlDoc.createElement("MSG");
					xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].lineBot.content));
					xmlC.appendChild(xmlMSG);

					xmlCAMERA.appendChild(xmlC);
				}
			}
			catch(error){}
		}
	}

	if(xmlCAMERA.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCAMERA);
	}

    // CGI Server
    var xmlCGI_SERVER = xmlDoc.createElement("CGI_SERVER");
	xmlCGI_SERVER.setAttribute("mode", "0");

    var cgiManager = WISE.managers.cgiManager;
    for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
        if(typeof(servers[sourceIndex]) == "undefined"){continue;}

        try{
            if(servers[sourceIndex].lineBot.enable == true){
        		var xmlC = xmlDoc.createElement("C");
                xmlC.setAttribute("idx", servers[sourceIndex].index);

    			var xmlMSG = xmlDoc.createElement("MSG");
    			xmlMSG.appendChild(xmlDoc.createTextNode(servers[sourceIndex].lineBot.content));
           		xmlC.appendChild(xmlMSG);

                xmlCGI_SERVER.appendChild(xmlC);
            }
        }
        catch(error){}
    }

	if(xmlCGI_SERVER.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCGI_SERVER);
	}

	// 
	if(xmlLINE_BOT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_BOT);
				break;
			}
		}
	}
};

WISE.managers.lineBotManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};