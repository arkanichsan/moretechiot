$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"internalRegister": "Internal Register",
		"no": "No.",
		"channel": "Ch.",
		"address": "Addr.",
		"counter": "Counter:",
		"enterValue": "Please enter the value:",
		"valueOfChannel": "The value of $channel:",
		"none": "None",
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel",
		"ch": "Ch.",
		"outputChannel": "Output Channel",
		"availableCommand": "Available Command",
		"transmit": "Transmit",
		"popup": {
			"areYouSureYouWantToLogout": "Are you sure you want to logout?",
			"idleTooLong": "Your login session has expired. For security reasons you will be logged out automatically. Please login again.",
			"module": "Module:",
			"channel": "Channel:",
			"value": "Value:",
			"outputChannelIsEmpty": "No output channel selected, please select at least one channel and then click the 'Transmit' button."
		}
	}
});