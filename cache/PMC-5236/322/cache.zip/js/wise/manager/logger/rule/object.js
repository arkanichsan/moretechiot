WISE.managers.loggerManager.pool.conditions = {
	"ftp": {
		"name": "<#Lang['?'].ftpUploadStatus>",
		"fileName": "cftp",
		"rule":{
			"value": 1//faild continue time
		},
		"check": function(){
			var loggerManager = WISE.managers.loggerManager;

			if(loggerManager.pool.ftp.enable == false){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			return this.name + " " + ruleColor("<#Lang['?'].uploadFailedContinuingXHours>".replace("$hours", this.rule.value), 2);
		},

		/*init and key will not be copied*/
		"init": function(){},
		"key": []
	}
};

WISE.managers.loggerManager.pool.actions = {
	"logger": {
		"name": "<#Lang['?'].dataLogger>",
		"fileName": "alogger",
		"rule":{
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			var loggerManager = WISE.managers.loggerManager;

			if(loggerManager.pool.dataLog.customizedLog.enable == false && loggerManager.pool.dataLog.ioModuleLog.enable == false && loggerManager.pool.dataLog.powerMeterLog.enable == false){
				return false;
			}

			if(this.rule.value == 2 && loggerManager.pool.dataLog.customizedLog.enable == false && loggerManager.pool.dataLog.ioModuleLog.enable == false){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var loggerManager = WISE.managers.loggerManager;
			var valueString = ["<#Lang['?'].stop>", "<#Lang['?'].start>", "<#Lang['?'].oneTimeLog>"];

			return this.name + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){},
		"key": []
	}
};

WISE.managers.loggerManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['ftp']['key'] = [];
	this.pool.actions['logger']['key'] = [];

	if(this.pool.ftp.enable == true){
		this.pool.conditions['ftp']['key'].push(true);
	}

	if(this.pool.dataLog.customizedLog.enable == true || this.pool.dataLog.ioModuleLog.enable == true || this.pool.dataLog.powerMeterLog.enable == true){
		this.pool.actions['logger']['key'].push(true);
	}
};
