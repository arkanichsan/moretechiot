$.extend(true, Lang, {
	"js/wise/manager/bluemix/rule/object.js": {
		"connectionStatus": "Connection Status",
		"offline": "Offline",
		"online": "Online",
		"bluemixConnectionStatus": "IBM Bluemix Connection Status",
		"subscribeMessage": "Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message",
		"functionStatus": "Function Status",
		"bluemixFunctionStatus": "IBM Bluemix Function Status",
		"publishMessage": "Publish Message",
		"publish": "Publish",
		"resetVariable": "Reset Variable",
		"reset": "Reset"
	}
});