(function($) {
	$.fn.insertAtCaret = function(option, p1, p2){

		if(option == "init"){
			return this.each(function(index){
				$(this).unbind("focus.insertAtCaret keyup.insertAtCaret mouseup.insertAtCaret");

				$(this).bind("focus.insertAtCaret", function(){
					this.isFocus = true;
				});

				$(this).bind("focus.insertAtCaret keyup.insertAtCaret mouseup.insertAtCaret", function(){
					//if(document.selection){
					if($.browser.msie && parseInt($.browser.version, 10) <= 8){
						var range = document.selection.createRange();

						if (range.parentElement() == this) {
						    var len = this.value.length, start, end;
							var normalizedValue = this.value.replace(/\r\n/g, "\n");

						    // Create a working TextRange that lives only in the input
						    var textInputRange = this.createTextRange();
						    textInputRange.moveToBookmark(range.getBookmark());

						    // Check if the start and end of the selection are at the very end
						    // of the input, since moveStart/moveEnd doesn't return what we want
						    // in those cases
						    var endRange = this.createTextRange();
						    endRange.collapse(false);

						    if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
						        start = end = len;
						    }
							else {
						        start = -textInputRange.moveStart("character", -len);
						        start += normalizedValue.slice(0, start).split("\n").length - 1;

						        if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
						            end = len;
						        }
								else {
						            end = -textInputRange.moveEnd("character", -len);
						            end += normalizedValue.slice(0, end).split("\n").length - 1;
						        }
						    }
						}

						this.selectionStart = start;
						this.selectionEnd = end;
					}
				});

				return true;
			});
		}
		else if(option == "insert"){
			return this.each(function(index){
				var insertValue = p1.toString();

				//if(document.selection){
				if($.browser.msie && parseInt($.browser.version, 10) <= 8){
					if(this.isFocus != true){
						this.selectionStart = this.selectionEnd = this.value.length;

						var rng = this.createTextRange();
						rng.moveEnd("character", this.value.length);
						rng.moveStart("character", this.value.length);
						rng.collapse(true);
						rng.select();
					}

					var startPos = this.selectionStart;
					var endPos = this.selectionEnd;

					var beforeCaretString = this.value.substring(0, startPos), afterCaretString = this.value.substring(endPos, this.value.length);
					this.value = beforeCaretString + insertValue + afterCaretString;

					var length = beforeCaretString.replace(/\r\n/g, "\n").length + insertValue.length;
					var rng = this.createTextRange();
					rng.moveEnd("character", length);
					rng.moveStart("character", length);
					rng.collapse(true);
					rng.select();

					$(this).triggerHandler("focus.insertAtCaret");// let ie8 calculate this.selectionStart and this.selectionEnd
				}
				else if (this.selectionStart || this.selectionStart == '0') {
					if(this.isFocus != true){
						this.selectionStart = this.selectionEnd = this.value.length;
					}

					var startPos = this.selectionStart;
					var endPos = this.selectionEnd;
					this.value = this.value.substring(0, startPos) + insertValue + this.value.substring(endPos, this.value.length);
					this.selectionStart = this.selectionEnd = startPos + insertValue.length;
				}
				else {
					this.value += insertValue;
				}

				this.focus();

				return true;
			});
		}
		else if(option == "select"){
			return this.each(function(index){

				if($.browser.msie && parseInt($.browser.version, 10) <= 8){
					var rng = this.createTextRange();
					rng.moveStart("character", this.value.substring(0, p1).replace(/\r\n/g, "\n").length);
					rng.collapse();
					rng.moveEnd("character", this.value.substring(p1, p1 + p2).replace(/\r\n/g, "\n").length);
					rng.select();
				}
				else if (this.selectionStart || this.selectionStart == '0') {
					this.selectionStart = p1;
					this.selectionEnd = p1 + p2;
				}

				this.focus();//ie8 doesn't trigger jQuery's focus
				$(this).triggerHandler("focus.insertAtCaret");// let ie8 calculate this.selectionStart and this.selectionEnd

				return true;
			});
		}
		else if(option == "range"){
			return {
				"index": this[0].selectionStart,
				"length": this[0].selectionEnd - this[0].selectionStart
			};
		}
	};
})(jQuery);
