$.extend(true, Lang, {
	"js/wise/manager/wechat/rule/object.js": {
		"weChat": "WeChat",
        "send": "Send"
	}
});