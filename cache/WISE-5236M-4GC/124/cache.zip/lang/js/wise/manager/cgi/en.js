$.extend(true, Lang, {
    "js/wise/manager/cgi/rule/object.js": {
        "cgiCommand": "CGI Command",
        "local": "Local",
        "remote": "Remote",
        "internalRegister": "Internal Register",
        "cgiSource": "CGI Source",
        "fromX": "From $address",
        "send": "Send"
    }
});