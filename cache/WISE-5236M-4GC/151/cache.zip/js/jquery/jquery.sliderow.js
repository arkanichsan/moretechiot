(function($) {
	$.fn.slideRowDown = function(duration, callback){
		var settings = $.extend(true, {
			"duration": "fast",
			"callback": function(){}
		}, {
			"duration": duration,
			"callback": callback
		});

		var $trs = $(this);
		var trsAmount = $trs.length;
		var trsAnimatedAmount = 0;

		return this.each(function(){//this is trs
			var $tr = $(this);
			if(settings.duration == 0 || $.fx.off == true){
				$tr.show();
				settings.callback.call($trs, $tr);
				return $tr;
			}

			var $tds = $tr.find(">td");
			var animateComplete = function(){
				var finished = $tr.data("finished");
				finished++;

				if(finished == $tr.data("total")){
					trsAnimatedAmount++;
					if(trsAnimatedAmount == trsAmount){
						settings.callback.call($trs, $tr);
					}
				}
				else{
					$tr.data("finished", finished);
				}
			};

			$tr.find(":animated").stop(true, true);

			$tr.show();

			$tr.data({"finished": 0, "total": $tds.length * 2});

			$tds.wrapInner("<div style='display:none;' class='wrapDiv'/>").children("div.wrapDiv").animate({"opacity": "show", "height": "show"}, settings.duration, function(){
				var $set = $(this);
				$set.replaceWith($set.contents());
				animateComplete();
			});

			$tds.each(function(){
				var processBorderCSS = function(css){
					if(css == "thin"){return "1px";}
					else if(css == "medium"){return "3px";}
					else if(css == "thick"){return "5px";}
					else{return css;}
				}

				if(typeof($(this).data("css")) == "undefined"){
					$(this).data("css", {
						"paddingTop": $(this).css("paddingTop"),
						"paddingBottom": $(this).css("paddingBottom"),
						"borderTopWidth": processBorderCSS($(this).css("borderTopWidth")),
						"borderBottomWidth": processBorderCSS($(this).css("borderBottomWidth"))
					});
				}

				$(this).css({"paddingTop": 0, "paddingBottom": 0, "borderTopWidth": 0, "borderBottomWidth": 0});
				$(this).animate($(this).data("css"), settings.duration, function(){
					//$(this).css({"paddingTop": "", "paddingBottom": "", "borderTopWidth": "", "borderBottomWidth": ""});
					animateComplete();
				});
			});

			return $tr;
		});
	};
})(jQuery);

(function($) {
	$.fn.slideRowUp = function(duration, callback){
		var settings = $.extend(true, {
			"duration": "fast",
			"callback": function(){}
		}, {
			"duration": duration,
			"callback": callback
		});

		var $trs = $(this);
		var trsAmount = $trs.length;
		var trsAnimatedAmount = 0;

		return this.each(function(){
			var $tr = $(this);
			if(settings.duration == 0 || $.fx.off == true){
				$tr.hide();
				settings.callback.call($trs, $tr);
				return $tr;
			}

			var $tds = $tr.find(">td");
			var animateComplete = function(){
				var finished = $tr.data("finished");
				finished++;

				if(finished == $tr.data("total")){
					trsAnimatedAmount++;
					$tr.hide();

					$tds.each(function(){
						$(this).css($(this).data("css"));
					});

					if(trsAnimatedAmount == trsAmount){
						settings.callback.call($trs, $tr);
					}
				}
				else{
					$tr.data("finished", finished);
				}
			};

			$tr.find(":animated").stop(true, true);

			$tr.data({"finished": 0, "total": $tds.length * 2});
			$tds.wrapInner("<div style='display:block;' class='wrapDiv'/>").children("div.wrapDiv").animate({opacity: "hide", height: "hide"}, settings.duration, function(){
				var $set = $(this);
				$set.replaceWith($set.contents());
				animateComplete();
			});

			$tds.each(function(){
				var processBorderCSS = function(css){
					if(css == "thin"){return "1px";}
					else if(css == "medium"){return "3px";}
					else if(css == "thick"){return "5px";}
					else{return css;}
				}

				if(typeof($(this).data("css")) == "undefined"){
					$(this).data("css", {
						"paddingTop": $(this).css("paddingTop"),
						"paddingBottom": $(this).css("paddingBottom"),
						"borderTopWidth": processBorderCSS($(this).css("borderTopWidth")),
						"borderBottomWidth": processBorderCSS($(this).css("borderBottomWidth"))
					});
				}

				$(this).animate({"paddingTop": 0, "paddingBottom": 0, "borderTopWidth": 0, "borderBottomWidth": 0}, settings.duration, function(){
					//$(this).css({"paddingTop": "", "paddingBottom": "", "borderTopWidth": "", "borderBottomWidth": ""});
					animateComplete();
				});
			});

			return $tr;
		});
	};
})(jQuery);
