WISE.managers.timerManager.pool.conditions = {
	"timer": {
		"name": "<#Lang['?'].timer>",
		"fileName": "ctimer",
		"rule":{
			"timerKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.timerKey == null){
				return false;
			}

			var timerManager = WISE.managers.timerManager;

			if(typeof(timerManager.pool.timers[this.rule.timerKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var timerManager = WISE.managers.timerManager;
			var timer = timerManager.pool.timers[this.rule.timerKey];
			var valueString = ["<#Lang['?'].notTimeout>", "<#Lang['?'].timeout>", "<#Lang['?'].stop>"];

			return this.name + "(" + timer.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.timerKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.timerManager.pool.actions = {
	"timer": {
		"name": "<#Lang['?'].timer>",
		"fileName": "atimer",
		"rule":{
			"timerKey": null,
			"value": 0,
			"frequency": -1
		},
		"check": function(){
			if(this.rule.timerKey == null){
				return false;
			}
			
			var timerManager = WISE.managers.timerManager;

			if(typeof(timerManager.pool.timers[this.rule.timerKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var timerManager = WISE.managers.timerManager;
			var timer = timerManager.pool.timers[this.rule.timerKey];
			var valueString = ["<#Lang['?'].reset>", "<#Lang['?'].start>", "<#Lang['?'].pause>", "<#Lang['?'].resume>"];

			return this.name + "(" + timer.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.timerKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.timerManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['timer']['key'] = [];
	this.pool.actions['timer']['key'] = [];

	for(var key in this.pool.timers){
		this.pool.conditions['timer']['key'].push(parseInt(key, 10));
		this.pool.actions['timer']['key'].push(parseInt(key, 10));
	}
};