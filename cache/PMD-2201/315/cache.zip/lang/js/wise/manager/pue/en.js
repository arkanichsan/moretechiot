﻿$.extend(true, Lang, {
	"js/wise/manager/pue/rule/object.js": {
		"pue": "PUE"
	}
});