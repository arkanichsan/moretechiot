$.extend(true, Lang, {
	"js/wise/core/desktop.js": {
		"all": "全部",
		"view": "預覽",
		"edit": "編輯",
		"internalRegister": "內部暫存器",
		"diCounter": "DI計數器",
		"assignValue": "自訂數值",
		"systemInformation": "系統資訊",
		"item": "項目",
		"dateYear": "日期(年)",
		"dateMonth": "日期(月)",
		"dateDay": "日期(日)",
		"timeHour": "時間(時)",
		"timeMinute": "時間(分)",
		"timeSecond": "時間(秒)",
		"signalStrengthDBM": "3G訊號強度(dBm)",
		"signalStrengthPercent": "3G訊號強度(%)"
	}
});