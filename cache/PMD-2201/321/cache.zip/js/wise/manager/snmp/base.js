WISE.managers.snmpManager = (function(){
	return new function() {
		this.pool = {
			traps: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.createTrap = function(settings){
			var trap = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"number": 6,
				"id": 1,
				"messages": {},
				"key": 0
			}, settings);
			
			return trap;
		};

		this.addTrap = function(trap){
			var retKey = this.pool.key;
			this.pool.traps[this.pool.key++] = trap;
			return retKey;
		};

		this.removeTrap = function(key){
			delete this.pool.traps[key];
		};

		this.getTrap = function(key){
			if(typeof(this.pool.traps[key]) != "undefined"){
				return this.pool.traps[key];
			}
			else{
				return null;
			}
		};

		this.setTrap = function(key, trap){
			this.pool.traps[key] = trap;
		};

		this.getTraps = function(){
			return this.pool.traps;
		};

		this.createMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,

				"type": 0,//0: channel, 1: user-defined
				"content": "",
				"format": 0//only for channel, 0: Opaque(Float), 1: OctetString, 2: Integer
			}, settings);
			
			return message;
		};

		this.addMessage = function(trap, message){
			var retKey = trap.key;
			trap.messages[trap.key++] = message;
			return retKey;
		};

		this.removeMessage = function(trap, key){
			delete trap.messages[key];
		};

		this.getMessage = function(trap, key){
			if(typeof(trap.messages[key]) != "undefined"){
				return trap.messages[key];
			}
			else{
				return null;
			}
		};

		this.setMessage = function(trap, key, message){
			trap.messages[key] = message;
		};

		this.getMessages = function(trap){
			return trap.messages;
		};
	};
})();
