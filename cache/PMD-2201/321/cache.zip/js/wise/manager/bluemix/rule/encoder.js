WISE.managers.bluemixManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "bluemixStatus"){
			xmlDoc.setAttribute("l_obj", "BLUEMIX");
			xmlDoc.setAttribute("l_ch", "BROKER");
			xmlDoc.setAttribute("op", "0");
			xmlDoc.setAttribute("r_obj", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "bluemixSubscribe"){
			xmlDoc.setAttribute("l_obj", "BLUEMIX");

			if(ruleObject.rule.commandKey != null){
				xmlDoc.setAttribute("l_idx", this.pool.subscribe.commands[ruleObject.rule.commandKey].index);
			}

			xmlDoc.setAttribute("l_ch", "SUB");
			xmlDoc.setAttribute("l_chn", this.pool.subscribe.variables[ruleObject.rule.variableKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);
			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "bluemixStatus"){
			xmlDoc.setAttribute("l_obj", "BLUEMIX");
			xmlDoc.setAttribute("l_ch", "BROKER");
			xmlDoc.setAttribute("op", ruleObject.rule.value);

			if(ruleObject.rule.delay > 0){
				xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
			}
		}
		else if(ruleObject.ruleObjectKey == "bluemixPublish"){
			xmlDoc.setAttribute("l_obj", "BLUEMIX");
			xmlDoc.setAttribute("l_ch", "PUB");
			xmlDoc.setAttribute("l_chn", this.pool.publish.messages[ruleObject.rule.messageKey].index);
			xmlDoc.setAttribute("op", "0");

			if(ruleObject.rule.delay > 0){
				xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
			}
		}
	}
};
