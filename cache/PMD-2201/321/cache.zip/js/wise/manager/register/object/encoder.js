WISE.managers.registerManager.encodeXMLObject = function(xmlDoc){
	var xmlIR = xmlDoc.createElement("IR");
	xmlIR.setAttribute("start_address", "60");

	if(this.pool._csvHeader != ""){
		xmlIR.setAttribute("csv_header", this.pool._csvHeader);
		xmlIR.setAttribute("csv_index", this.pool._csvIndex);
	}

	for(var i = 0, registers = this.pool.registers; i < this.pool.registers.length; i++){
		if(typeof(registers[i]) == "undefined"){continue;}

		var register = registers[i];
		var xmlI = xmlDoc.createElement("I");

		xmlI.setAttribute("idx", i + 1);
		xmlI.setAttribute("value", register.initialValue);
		xmlI.setAttribute("nickname", register.name);

		if(register.description != ""){
			xmlI.setAttribute("desc", register.description);
		}

		xmlIR.appendChild(xmlI);
	}

	if(xmlIR.childNodes.length > 0){
		xmlDoc.documentElement.appendChild(xmlIR);
	}
};

