WISE.managers.loggerManager = (function(){
	return new function() {
		this.pool = {
/*
			loggers: {},
			key: 0,
*/
			"dataLog":{
				"powerMeterLog":{
					"enable": false,
					"mode": 0,//0: average, 1: instantaneous
					"addHeader": false,
					"report": ""
				},
				"ioModuleLog":{
					"enable": false
				},
				"customizedLog":{
					"enable": false,
					"format": ""
				},
				"rate": 5,
				"keepTime": 3,//unit is month
				"fileNameFormat": 0,//0:YYYY-MM-DD, 1:DD-MM-YYYY
				"eof": 0//0:CRLF, 1:LF, 2:CR
			},
			"eventLog":{
				"keepTime": 12//unit is month
			},
			"ftp":{
				"enable": false,
				"url": "",
				"port": 21,
				"id": "",
				"password": {
					"plain": "",
					"encoded": "",
					"length": 0
				},
				"path": "",
				"upload": {
					"dataLog":{
						"powerMeterLog": {
							"enable": false
						},
						"ioModuleLog": {
							"enable": false
						},
						"customizedLog": {
							"enable": false
						},
						"period": 60//unit is min
					},
					"eventLog": {
						"enable": false,
						"period": 1//unit is day
					}
				}
			},
			"cloud":{
				"enable": false,
				"upload": {
					"dataLog":{
						"powerMeterLog": {
							"enable": false
						},
						"ioModuleLog": {
							"enable": false
						}
					}
				}
			},

			"conditions": [],
			"actions": []
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};
	};
})();
