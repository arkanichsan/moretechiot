$.extend(true, Lang, {
	"js/wise/extend/init/base.js": {
		"V": "电压",
		"I": "电流",
		"kW": "实功率",
		"kvar": "无效功率",
		"kVA": "视在功率",
		"PF": "功率因数",
		"actualDemand": "实际需求量",
		"forecastDemand": "预测需求量",
		"hourlyMaximumDemand": "本小时最高需求量",
		"dailyMaximumDemand": "本日最高需求量",
		"monthlyMaximumDemand": "本月最高需求量",
		"dailyAccumElectricity": "本日累计用电度数",
		"monthlyAccumElectricity": "本月累计用电度数",
		"yearlyAccumElectricity": "本年累计用电度数",
		"wiringType": {
			"0": "无",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT",
			"6": "3P3W2CT(HW)",
			"7": "3P3W3CT(HW)",
			"8": "3P4W3CT(HW)"
		},
		"wiringMode": {
			"0": "自动",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT"
		},
		"voltageMode": {
			"0": "自动",
			"1": "相电压",
			"2": "线电压"
		},
		"phaseSequence": {
			"0": "逆相序",
			"1": "正相序"
		}
	}
});