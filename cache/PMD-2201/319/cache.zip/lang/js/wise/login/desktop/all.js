var LangLogin = {
	"adminAlreadyLogin": {
		"en": "Administrator is already logged in.",
		"tw": "系統管理員已登入。",
		"cn": "系统管理员已登录。"
	},
	"reachMaximumNumberOfLoginUser": {
		"en": "System has reached the maximum number of logged in users.",
		"tw": "系統已經達到最大的可登入人數。",
		"cn": "系统已经达到最大的可登录人数。"
	},
	"passwordIncorrect": {
		"en": "The password is incorrect.",
		"tw": "密碼錯誤。",
		"cn": "密码错误。"
	},
	"runtimeServerNotStartup": {
		//"en": "The run-time server does not startup, please check the setting of the server.",
		//"tw": "伺服器尚未啟動，請檢查伺服器的設定。",
		//"cn": "服务器尚未启动，请检查服务器的设定。"
		"en": "The system is busy, please try again later.",
		"tw": "系統忙碌中，請稍後再試。",
		"cn": "系统忙碌中，请稍后再试。"
	},
	"nickname": {
		"en": "Nickname:",
		"tw": "名稱:",
		"cn": "名称:"
	},
	"password": {
		"en": "Password:",
		"tw": "密碼:",
		"cn": "密码:"
	},
	"forgotPassword": {
		"en": "Forgot password?",
		"tw": "忘記密碼？",
		"cn": "忘记密码？"
	},
	"sendPasswordToX": {
		"en": "Sending the password to $email...",
		"tw": "將密碼傳送至 $email 中...",
		"cn": "将密码传送至 $email 中..."
	},
	"sentSuccessfully": {
		"en": "Sent Successfully.",
		"tw": "傳送成功。",
		"cn": "传送成功。"
	},
	"sentFailed": {
		"en": "Sent failed.",
		"tw": "傳送失敗。",
		"cn": "传送失败。"
	},
	"retry": {
		"en": "(Retry)",
		"tw": "(重試)",
		"cn": "(重试)"
	},
	"language": {
		"en": "Language:",
		"tw": "語系:",
		"cn": "语言:"
	},
	"rememberMe": {
		"en": "Remember me",
		"tw": "記住我",
		"cn": "记住我"
	},
	"login": {
		"en": "Login",
		"tw": "登入",
		"cn": "登录"
	},
	"fileCanNotLoad": {
		"en": "Some files could not be loaded, please reload this page again.",
		"tw": "部分檔案無法載入，請重新讀取此頁面。",
		"cn": "部分文件无法加载，请再次刷新此页面。"
	},
	"loadingPleaseWait": {
		"en": "Loading, please wait...",
		"tw": "載入中，請稍後。",
		"cn": "加载中，请稍后。"
	},
	"runtimeServerNoResponse": {
		//"en": "The run-time server is not responding, please check the status of the server.",
		//"tw": "伺服器沒有回應，請檢查伺服器的狀態。",
		//"cn": "服务器没有回应，请检查服务器的状态。"
		"en": "The system is busy, please try again later.",
		"tw": "系統忙碌中，請稍後再試。",
		"cn": "系统忙碌中，请稍后再试。"
	},
	"fileNotFound": {
		"en": "The system can't find the file, please check if the firmware file is correct.",
		"tw": "找不到檔案，請檢查韌體檔是否完整。",
		"cn": "找不到文件，请检查固件文件是否完整。"
	},
	"modbusTableChange": {
		"en": "Alert! Change of Modbus Address",
		"tw": "Modbus位址變更通知",
		"cn": "Modbus地址变更通知"
	},
	"modbusTableChangeDescription": {
		"en": "After firmware version v3.0.0, some of the Modbus address of power meters and I/O modules are changed. Please refer to the User's Manual (Appendix I) after version v3.0.0 or 'Modbus Table Information' on the Main Page to verify your address used for data access.",
		"tw": "韌體版本從v3.0.0開始，電錶與I/O模組的Modbus位址有所調整，請參考版本v3.0.0之後的使用者手冊(附錄一)或主頁面中'Modbus Table資訊'來調整數據的讀取位址。",
		"cn": "固件版本从v3.0.0开始，电测模块与I/O模块的Modbus地址有所调整，请参考版本v3.0.0之后的使用者手册(附录一)或主页面中'Modbus Table信息'来调整数据的读取地址。"
	},
	"ok": {
		"en": "OK",
		"tw": "確定",
		"cn": "确定"
	},
	"neverShowAgain": {
		"en": "Do not show this message again",
		"tw": "不再顯示",
		"cn": "不再显示"
	}
};
