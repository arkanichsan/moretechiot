WISE.managers.ruleManager.encodeXMLObject = function(xmlDoc){
	var xmlRULE = xmlDoc.createElement("RULE");

	for(var i = 0; i < this.pool.executionOrder.length; i++){
		var rule = this.pool.rules[this.pool.executionOrder[i]];
		var xmlR = xmlDoc.createElement("R");

		xmlR.setAttribute("idx", i + 1);
		xmlR.setAttribute("in_use", rule.enable == true ? "1" : "0");
		xmlR.setAttribute("op", (function(){//return 0 for only one condition, 1 is and, 2 is or
			if(rule.ifConditions.executionOrder.length > 1){
				if(rule.ifConditions.operate == 0){return 2;}
				else if(rule.ifConditions.operate == 1){return 1;}
			}
			else{
				return 0;
			}
		})());
		xmlR.setAttribute("nickname", rule.name);

		if(rule.description != ""){
			xmlR.setAttribute("desc", rule.description);
		}

		for(var j = 0, ruleTypeArray = [["ifConditions", "IF"], ["thenActions", "THEN"], ["elseActions", "ELSE"]]; j < ruleTypeArray.length; j++){
			for(var k = 0; k < rule[ruleTypeArray[j][0]].executionOrder.length; k++){
				var ruleObject = rule[ruleTypeArray[j][0]].rules[rule[ruleTypeArray[j][0]].executionOrder[k]];

				var xmlElement = xmlDoc.createElement(ruleTypeArray[j][1]);
				xmlElement.setAttribute("idx", k + 1);

				WISE.managers[ruleObject.managerKey].encodeXMLRule(xmlElement, ruleObject);

				xmlR.appendChild(xmlElement);
			}
		}

		xmlRULE.appendChild(xmlR);
	}

	if(xmlRULE.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlRULE);
				break;
			}
		}
	}
};

WISE.managers.ruleManager.updateIndex = function(){
	var index = 0;
	for(var i = 0; i < this.pool.executionOrder.length; i++){
		this.pool.rules[this.pool.executionOrder[i]].index = ++index;
	}
};
