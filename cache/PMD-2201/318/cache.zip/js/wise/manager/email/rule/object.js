WISE.managers.emailManager.pool.actions = {
	"email": {
		"name": "<#Lang['?'].email>",
		"fileName": "aemail",
		"rule":{
			"emailKey": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.emailKey == null){
				return false;
			}
			
			var emailManager = WISE.managers.emailManager;

			if(typeof(emailManager.pool.emails[this.rule.emailKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var emailManager = WISE.managers.emailManager;
			var email = emailManager.pool.emails[this.rule.emailKey];
			var valueString = ["<#Lang['?'].send>"];

			return this.name + "(" + email.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.emailKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.emailManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['email']['key'] = [];

	for(var key in this.pool.emails){
		this.pool.actions['email']['key'].push(parseInt(key, 10));
	}
};