WISE.managers.pmcManager = (function(){
	return new function() {
		this.pool = {
			contractCapacity:{
				enable: false,
				capacity: 1
			},
			demand:{
				interval: 15//unit is min
			},
			carbonFootprint:{
				factor: 0.612
			},
			groups:{
				name : "" ,
				node : "" ,
				level : ""  ,
				index : "" ,
				UID : "" ,
				child : [],
				parent_UID : "",
				indent : ""
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function()
		{
			var pmcManager = WISE.managers.pmcManager;
			root = pmcManager.pool.groups ;
			var error = get_leaf(root) ;
			if(error == "error")
			{
				return {
					"hash": "#home/system/group",
					"message": "<#Lang['?'].someoneGroupsAreError>"
				};
			}
			else return null ;
		};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};
	};
})();

function get_leaf(obj)
{
	var error_str = "" ;
	if( obj.node == "node" )
	{
		for( var i = 0 ; i < obj.child.length ; i++ )
		{
			error_str = get_leaf( obj.child[i] );
			if(error_str == "error")return "error";
		}
	}
	
	if( obj.node == "leaf" )
	{
		/*
		var port = "comport" ;
		if(obj.type == "TCP" )port = "network" ;
		var set_info = WISE.managers.moduleManager.pool.interfaces ;
		try {
			set_info[port][obj.com].modules[Number(obj.modules)-1].powerMeter ;
		}
		catch (e) {
			return "error";
		}
		*/
		if( WISE.managers.moduleManager.getModuleByKey(obj.key) == null )return "error";
	}
	
	return error_str  ;
}
