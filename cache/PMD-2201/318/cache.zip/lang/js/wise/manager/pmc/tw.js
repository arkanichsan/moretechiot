$.extend(true, Lang, {
	"js/wise/manager/pmc/base.js": {
		"someoneGroupsAreError": "電錶群組設定中所設定的電錶，部分已遭移除，請再次確認。"
	}
});