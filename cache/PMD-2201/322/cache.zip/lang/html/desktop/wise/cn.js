$.extend(true, Lang, {
	"html/desktop/frame.htm": {
		"resetRule": "清除设置",
		"loadRule": "读取设置",
		"saveRule": "写入设置",
		"logout": "注销",
		"freeSpaceOnSDCard": "microSD卡剩余空间。",
		"enterPasswordToContinue": "请输入密码以继续操作...",
		"enterPasswordBelow": "您闲置过久，如果您要继续编辑，请在下方输入密码：",
		"password": "密码:",
		"login": "登录"
	},
	"html/desktop/home.htm": {
		"saveAndLogout": "写入并注销",
		"logout": "注销",
		"popup": {
			"pleaseWaitAFewSeconds": "请稍候几秒钟。",
			"pleaseWaitAFewSecondsAndDontCloseWindow": "请稍候几秒钟。在此过程中请勿关闭窗口。",
			"clearSuccess": "清除成功。",
			"loadSuccess": "读取成功。",
			"loadFailed": "读取失败。",
			"saveFailed": "储存失败。",
			"systemInitializing": "系统正在初始化中，请稍后再试。",
			"saveBeforeLogout": "您是否要在注销前写入设置？"
		}
	},
	"html/desktop/home/menu.htm": {
		"mainPage": "主页面",
		"systemSetting": "系统参数设置",
		"moduleSetting": "I/O模块设置",
		"loggerSetting": "记录器设置",
		"iotSetting": "IoT平台设置",
		"advancedSetting": "高级功能设置",
		"rulesSetting": "逻辑规则设置",
		"channelStatus": "实时信息显示",
		"sendToX": "传送至聊天室$name",
		"sendToXChatRoom": "传送至$length个聊天室",
		"noSendToAnyChatRoom": "不传送至任何一个聊天室",
		"oneOnOne": "1对1",
		"group": "群组"
	},
	"html/desktop/home/system.htm": {
		"systemSettingPage": "系统参数设置页面",
		"dateAndTime": "日期与时间",
		"timeSynchronization": "时间校时",
		"macAddress": "MAC地址",
		"port": "端口",
		"ddns": "动态域名系统(DDNS)",
		"connectionStatus": "联机状态",
		"status": "状态",
		"connectionInformation": "联机信息",
		"connected": "已联机",
		"disconnected": "已断线",
		"connecting": "联机中...",
		"disconnect": "断线",
		"connect": "联机",
		"cancel": "取消",
		"signalStrength": "讯号强度",
		"cloudManagerSystem": "云端管理系统",
		"localFTPServer": "本机FTP服务器",
		"firmwareUpdateSetting": "固件更新设置",
		"firmwareInformation": "固件信息",
		"currentVersion": "目前版本",
		"availableVersion": "最新版本",
		"check": "检查",
		"newFirmwareRelease": "有新的固件(版本: $version)发布。",
		"checkFailed": "检查失败。",
		"firmwareUpdate": "固件更新",
		"firmware": "固件",
		"browse": "浏览...",
		"update": "更新",
		"popup": {
			"doNotColseThisWindow": "请勿关闭或离开此页面",
			"selectFirmwareToUpload": "请选择一个固件文件上传。",
			"areYouSureYouWantToUpdateFirmware": "您确定要更新固件？所有尚未储存的设置在更新固件后将会消失。",
			"areYouSureYouWantToLeave": "固件正在更新中，离开此页面可能会导致固件失败，您确定是否要离开此页面？",
			"firmwareUploading": "固件上传中...",
			"firmwareUploadFailedUploadTimeout": "固件上传失败，固件上传时间过长，建议从与控制器同一个局域网络内的计算机上传固件。",
			"firmwareUpdating": "固件更新中...",
			"firmwareUpdateFailedFirmwareIsIncorrect": "固件更新失败，固件文件不正确。",
			"firmwareUpdateFailedNotEnoughDiskSpace": "固件更新失败，磁盘空间不足。",
			"firmwareUpdateFailedUnzipError": "固件更新失败，解压缩固件文件失败。",
			"firmwareUpdateFailed": "固件更新失败。",
			"systemRestarting": "系统重新启动中...",
			"firmwareUpdateSuccessToVersionXPressOKToLogout": "固件成功更新成$version版，按下确定按钮后，系统会将您注销，请重新登录即可。",
			"firmwareUpdateFailedPressOKToLogout": "固件更新失败，按下确定按钮后，系统会将您注销，请重新登录即可。"
		},
		"vpn":{
			"VPNSetting":"VPN設置",
			"VPNState":"VPN状态",
			"ip": "IP",
			"mask": "掩码",
			"gateway": "网关",
			"dns": "DNS服务器IP",
			"online":"上线",
			"offline":"断线",
			"connecting":"连线中",
			"enable":"启用",
			"disable":"停用"
		}
	},
	"html/desktop/home/system/menu.htm": {
		"timeSetting": "时间设置",
		"networkSetting": "网络设置",
		"vpnSetting": "VPN设置",
		"snmpSetting": "SNMP设置",
		"securitySetting": "安全设置",
		"interfaceSetting": "I/O接口设置",
		"otherSetting": "其它设置",
		//----------------------pmc--------------------------
		"GroupSetting": "电测模块群组设置"
		//---------------------------------------------------
	},
	"html/desktop/home/system/time.htm": {
		"timeSettingPage": "时间设置页面",
		"date": "日期",
		"time": "时间",
		"loadTime": "时间复制",
		"load": "读取",
		"loadComputerTimeSetting": "读取此计算机的时间设置",
		"timeSynchronizationSetting": "时间校时设置",
		"functionStatus": "功能状态",
		"sntpTimeServer": "SNTP时间服务器",
		"useDefaultSNTPTimeServers": "使用预设的SNTP时间服务器",
		"port": "端口",
		"syncInterval": "同步间隔",
		"timeZoneSetting": "时区设置",
		"timeZone": "时区",
		"timeZoneKey": {
			"Dateline Standard Time": "(UTC-12:00) 国际日期变更线以西",
			"UTC-11": "(UTC-11:00) 协调世界时 -11",
			"Hawaiian Standard Time": "(UTC-10:00) 夏威夷",
			"Alaskan Standard Time": "(UTC-09:00) 阿拉斯加",
			"Pacific Standard Time": "(UTC-08:00) 太平洋时间 (美国和加拿大)",
			"Pacific Standard Time (Mexico)": "(UTC-08:00) 巴亚加利福尼亚",
			"Mountain Standard Time": "(UTC-07:00) 山地时间 (美国和加拿大)",
			"Mountain Standard Time (Mexico)": "(UTC-07:00) 奇瓦瓦，拉巴斯，马扎特兰",
			"US Mountain Standard Time": "(UTC-07:00) 亚利桑那",
			"Canada Central Standard Time": "(UTC-06:00) 萨斯喀彻温",
			"Central Standard Time (Mexico)": "(UTC-06:00) 瓜达拉哈拉，墨西哥城，蒙特雷",
			"Central Standard Time": "(UTC-06:00) 中部时间 (美国和加拿大)",
			"Central America Standard Time": "(UTC-06:00) 中美洲",
			"US Eastern Standard Time": "(UTC-05:00) 印地安那州 (东部)",
			"Eastern Standard Time": "(UTC-05:00) 东部时间 (美国和加拿大)",
			"Eastern Standard Time (Mexico)": "(UTC-05:00) 切图马尔",
			"SA Pacific Standard Time": "(UTC-05:00) 波哥大，利马，基多",
			"Venezuela Standard Time": "(UTC-04:30) 加拉加斯",
			"SA Western Standard Time": "(UTC-04:00) 乔治敦，拉巴斯，马老斯，圣胡安",
			"Central Brazilian Standard Time": "(UTC-04:00) 库亚巴",
			"Atlantic Standard Time": "(UTC-04:00) 大西洋时间 (加拿大)",
			"Paraguay Standard Time": "(UTC-04:00) 亚松森",
			"Newfoundland Standard Time": "(UTC-03:30) 纽芬兰",
			"Pacific SA Standard Time": "(UTC-03:00) 圣地亚哥",
			"Bahia Standard Time": "(UTC-03:00) 萨尔瓦多",
			"Montevideo Standard Time": "(UTC-03:00) 蒙得维的亚",
			"Greenland Standard Time": "(UTC-03:00) 格陵兰",
			"SA Eastern Standard Time": "(UTC-03:00) 卡宴，福塔雷萨",
			"Argentina Standard Time": "(UTC-03:00) 布宜诺斯艾利斯",
			"E. South America Standard Time": "(UTC-03:00) 巴西利亚",
			"UTC-2": "(UTC-02:00) 协调世界时 -02",
			"Cape Verde Standard Time": "(UTC-01:00) 佛得角群岛",
			"Azores Standard Time": "(UTC-01:00) 亚速尔群岛",
			"Morocco Standard Time": "(UTC) 卡萨布兰卡",
			"UTC": "(UTC) 协调世界时",
			"GMT Standard Time": "(UTC) 都柏林，爱丁堡，里斯本，伦敦",
			"Greenwich Standard Time": "(UTC) 蒙罗维亚，雷克雅未克",
			"W. Europe Standard Time": "(UTC+01:00) 阿姆斯特丹，柏林，伯尔尼，罗马，斯德哥尔摩，维也纳",
			"Central Europe Standard Time": "(UTC+01:00) 贝尔格莱德，布拉迪斯拉发，布达佩斯，卢布尔雅那，布拉格",
			"Romance Standard Time": "(UTC+01:00) 布鲁塞尔，哥本哈根，马德里，巴黎",
			"Central European Standard Time": "(UTC+01:00) 萨拉热窝，斯科普里，华沙，萨格勒布",
			"W. Central Africa Standard Time": "(UTC+01:00) 中非西部",
			"Namibia Standard Time": "(UTC+01:00) 温得胡克",
			"Jordan Standard Time": "(UTC+02:00) 安曼",
			"GTB Standard Time": "(UTC+02:00) 雅典，布加勒斯特",
			"Middle East Standard Time": "(UTC+02:00) 贝鲁特",
			"Egypt Standard Time": "(UTC+02:00) 开罗",
			"Syria Standard Time": "(UTC+02:00) 大马士革",
			"E. Europe Standard Time": "(UTC+02:00) 东部欧洲",
			"South Africa Standard Time": "(UTC+02:00) 哈拉雷，比勒陀利亚",
			"FLE Standard Time": "(UTC+02:00) 赫尔辛基，基辅，里加，索非亚，塔林，维尔纽斯",
			"Turkey Standard Time": "(UTC+02:00) 伊斯坦布尔",
			"Israel Standard Time": "(UTC+02:00) 耶路撒冷",
			"Kaliningrad Standard Time": "(UTC+02:00) 加里宁格勒 (RTZ 1)",
			"Libya Standard Time": "(UTC+02:00) 的黎波里",
			"Arabic Standard Time": "(UTC+03:00) 巴格达",
			"Arab Standard Time": "(UTC+03:00) 科威特，利雅得",
			"Belarus Standard Time": "(UTC+03:00) 明斯克",
			"Russian Standard Time": "(UTC+03:00) 莫斯科，圣彼得堡，伏尔加格勒克 (RTZ 2)",
			"E. Africa Standard Time": "(UTC+03:00) 内罗毕",
			"Iran Standard Time": "(UTC+03:30) 德黑兰",
			"Arabian Standard Time": "(UTC+04:00) 阿布扎比，马斯喀特",
			"Azerbaijan Standard Time": "(UTC+04:00) 巴库",
			"Russia Time Zone 3 Standard Time": "(UTC+04:00) 伊热夫斯克，萨马拉 (RTZ 3)",
			"Mauritius Standard Time": "(UTC+04:00) 路易港",
			"Georgian Standard Time": "(UTC+04:00) 第比利斯",
			"Caucasus Standard Time": "(UTC+04:00) 埃里温",
			"Afghanistan Standard Time": "(UTC+04:30) 喀布尔",
			"West Asia Standard Time": "(UTC+05:00) 阿什哈巴德，塔什干",
			"Ekaterinburg Standard Time": "(UTC+05:00) 叶卡捷琳堡 (RTZ 4)",
			"Pakistan Standard Time": "(UTC+05:00) 伊斯兰堡，卡拉奇",
			"India Standard Time": "(UTC+05:30) 马德拉斯，加尔各答，孟买，新德里",
			"Sri Lanka Standard Time": "(UTC+05:30) 斯里加亚渥登普拉",
			"Nepal Standard Time": "(UTC+05:45) 加德满都",
			"Central Asia Standard Time": "(UTC+06:00) 阿斯塔纳",
			"Bangladesh Standard Time": "(UTC+06:00) 达卡",
			"N. Central Asia Standard Time": "(UTC+06:00) 新西伯利亚 (RTZ 5)",
			"Myanmar Standard Time": "(UTC+06:30) 仰光",
			"SE Asia Standard Time": "(UTC+07:00) 曼谷，河内，雅加达",
			"North Asia Standard Time": "(UTC+07:00) 克拉斯诺亚尔斯克 (RTZ 6)",
			"China Standard Time": "(UTC+08:00) 北京，重庆，香港特别行政区，乌鲁木齐",
			"North Asia East Standard Time": "(UTC+08:00) 伊尔库茨克 (RTZ 7)",
			"Singapore Standard Time": "(UTC+08:00) 吉隆坡，新加坡",
			"W. Australia Standard Time": "(UTC+08:00) 珀斯",
			"Taipei Standard Time": "(UTC+08:00) 台北",
			"Ulaanbaatar Standard Time": "(UTC+08:00) 乌兰巴托",
			"Tokyo Standard Time": "(UTC+09:00) 大坂，扎幌，东京",
			"Korea Standard Time": "(UTC+09:00) 首尔",
			"Yakutsk Standard Time": "(UTC+09:00) 雅库茨克 (RTZ 8)",
			"Cen. Australia Standard Time": "(UTC+09:30) 阿德莱德",
			"AUS Central Standard Time": "(UTC+09:30) 达尔文",
			"E. Australia Standard Time": "(UTC+10:00) 布里斯班",
			"AUS Eastern Standard Time": "(UTC+10:00) 堪培拉，墨尔本，悉尼",
			"West Pacific Standard Time": "(UTC+10:00) 关岛，莫尔兹比港",
			"Tasmania Standard Time": "(UTC+10:00) 霍巴特",
			"Magadan Standard Time": "(UTC+10:00) 马加丹",
			"Vladivostok Standard Time": "(UTC+10:00) 海参崴，马加丹 (RTZ 9)",
			"Russia Time Zone 10 Standard Time": "(UTC+11:00) 乔库尔达赫 (RTZ 10)",
			"Central Pacific Standard Time": "(UTC+11:00) 所罗门群岛，新喀里多尼亚",
			"Russia Time Zone 11 Standard Time": "(UTC+12:00) 阿纳德尔，堪察加彼得罗巴甫洛夫斯克 (RTZ 11)",
			"New Zealand Standard Time": "(UTC+12:00) 奥克兰，惠灵顿",
			"UTC+12": "(UTC+12:00) 协调世界时 +12",
			"Fiji Standard Time": "(UTC+12:00) 斐济",
			"Tonga Standard Time": "(UTC+13:00) 努库阿洛法",
			"Samoa Standard Time": "(UTC+13:00) 萨摩亚群岛",
			"Line Islands Standard Time": "(UTC+14:00) 圣诞岛"
		},
		"daylightSavingTime": "夏令时",
		"tip": {
			"date": "点选月历上的日期以变更日期设置。",
			"time": "修改时间设置。",
			"loadTime": "读取浏览器端计算机的系统时间设置。",
			"functionStatus": "勾选'启用'以启用时间校时功能。",
			"sntpTimeServer": "输入SNTP时间服务器地址。",
			"port": "输入SNTP时间服务器使用的端口。",
			"syncInterval": "设置校时的频率。",
			"timeZone": "设置此此控制器所处的时区。",
			"daylightSavingTime": "勾选'启用'以启用日光节约时间功能。"
		},
		"popup": {
			"timeServerIsEmpty": "SNTP 时间服务器不能为空，必须指定至少一个服务器地址。",
			"saveFailed": "储存失败。"
		}
	},
	"html/desktop/home/system/network.htm": {
		"networkSetting": "网络设置",
		"connectionMode": "联机模式",
		"ip": "IP",
		"specifyIPAddress": "指定IP地址",
		"obtainIPAddressViaDHCP": "自动取得IP地址(DHCP)",
		"mask": "掩码",
		"gateway": "网关",
		"dns": "DNS服务器IP",
		"mobileNetwork": "移动网络",
		"dialNumber": "拨接号码",
		"apn": "接入点名称",
		"authentication": "账号验证",
		"username": "账号",
		"password": "密码",
		"referToThisDocumentToConfigureTheSetting": "请参考<a href='http://wise.icpdas.com/downloads/gprs_apn.pdf' target='_blank'>此文件</a>做对应的设置。",
		"mobileCode": "移动设备代码",
		"mcc": "国家代码",
		"mnc": "网络代码",
		"referToThisWebPageToConfigureTheSetting": "请参考<a href='https://en.wikipedia.org/wiki/Mobile_country_code' target='_blank'>此网页</a>做对应的设置。",
		"autoConnectWhenPowerOn": "开机时自动联机",
		"connectionTesting": "联机测试",
		"testing": "测试",
		"connectSuccessfully": "联机成功。",
		"connectFailed": "联机失败。",
		"mobileNetworkNoResponsePleaseCheckServerSetting": "移动网络无响应，请确认移动网络设置是否正确。",
		"userAuthenticationFailedPleaseCheckUsernameOrPasswordSetting": "使用者认证错误，请确认用户名称及密码设置是否正确。",
		"securityAuthenticationFailedPleaseCheckSecuritySetting": "安全性验证错误，请确认安全性设置是否正确。",
		"unknownErrorPleaseCheckMobileNetworkSetting": "不明的错误，请确认移动网络设置是否正确。",
		"saveAndConnect": "储存并联机",
		"disablePINCodeFromSIMCardFirst": "请取消SIM卡的PIN码",
		"portSetting": "端口设置",
		"webServerPort": "网页服务器端口",
		"modbusTCPPort": "Modbus TCP端口",
		"modbusNetID": "Modbus NetID",
		"ddnsSetting": "动态域名系统(DDNS)设置",
		"serviceX": "服务$number",
		"serviceProvider": "服务提供商",
		"domainName": "域名",
		"token": "更新代码",
		"status": "状态",
		"lastUpdateTime": "上次更新时间",
		"lastUpdateStatus": "上次更新状态",
		"externalIP": "上次注册IP",
		"updateSuccess": "更新成功。",
		"connectionFailed": "联机失败。",
		"authorizationFailed": "认证失败。",
		"domainNameNotExist": "域名不存在。",
		"unknownError": "未知的错误。",
		"cloudManagerSystemSetting": "云端管理系统设置",
		"functionStatus": "功能状态",
		"serverAddress": "服务器地址",
		"createAccount": "建立账号",
		"specifyServerAddress": "自定义服务器地址",
		"serverPort": "服务器端口",
		"connecting": "联机中。",
		"connected": "已联机。",
		"connectionStatus": "联机状态",
		"unableEstablishConnectionWithServer": "无法与服务器建立联机。",
		"usernameOrPasswordError": "账号或密码错误。",
		"reachMaximumDeviceAmount": "装置数量已达上限。",
		"unableEstablishConnectionWithDatabase": "无法与数据库建立联机。",
		"unableToConnectToTheSystem": "无法与系统取得联机！",
		"useUtilityToSearchSystemIP": "您的系统IP地址可能已经改变，请使用专用工具程序重新寻找系统IP地址并使用其IP地址重新登入。",
		"errorOccursInSettingCheckSettingsAgain": "您的网络设置可能发生错误，请重新检查设置。",
		"systemLostConnectionWithCloudAccessViaIPDirectly": "您的系统已经与云端断线，可能是联机问题或登入的账号或密码错误。请直接透过IP登入系统进行操作。",
		"macAddress": "MAC地址：",
		"tip": {
			"connectionMode": "设置网络卡取得IP的方式。",
			"ip": "输入控制器IP地址。",
			"mask": "输入控制器掩码。",
			"gateway": "输入控制器网关。",
			"dns": "输入DNS服务器IP。",
			"dialNumber": "输入移动网络的拨接号码。",
			"apn": "输入移动网络所使用的接入点名称(APN)。",
			"authentication": "输入登入移动网络的用户账号与密码。",
			"mobileCode": "勾选'启用'以启用移动设备代码功能。",
			"mcc": "输入移动设备国家代码(MCC)。",
			"mnc": "输入移动设备网络代码(MNC)。",
			"autoConnectWhenPowerOn": "勾选'启用'以启用开机自动联机功能。",
			"connectionTesting": "按下测试后，系统将会依据您的设置，尝试建立联机至您设置的移动网络上，以确定设置正确。",
			"webServerPort": "输入控制器网页服务器端口。",
			"modbusTCPPort": "输入控制器Modbus TCP端口。",
			"modbusNetID": "输入控制器NetID。",
			"serviceProvider": "设置动态域名系统的服务提供商。",
			"username": "输入登入服务提供商的使用者账号。",
			"password": "输入登入服务提供商的用户密码。",
			"domainName": "输入服务提供商提供的动态域名。",
			"token": "输入服务提供商提供的更新代码。",
			"status": "目前的动态域名系统状态。",
			"cloud": {
				"functionStatus": "勾选'启用'以启用云端管理系统功能。",
				"serverAddress": "输入云端服务器的地址。",
				"serverPort": "输入云端服务器的端口。",
				"username": "输入登入云端服务器的使用者账号。",
				"password": "输入登入云端服务器的用户密码。",
				"connectionStatus": "目前与云端管理系统的联机状态。"
			}
		},
		"popup": {
			"areYouSureYouWantToChangeSettingMaybeLostConnection": "您确定要改变设置吗？当这个动作完成后有可能与系统失去联机，所有尚未存盘的设置将会消失。",
			"areYouSureYouWantToChangeSettingRedirectAutomatically": "您确定要改变设置吗？当这个动作完成后，网页将会被导向新的网络地址，所有尚未存档的设置将会消失。",
			"pleaseWaitAFewSeconds": "请稍候几秒钟。",
			"saveSuccessPressOKRedirect": "储存成功。按下『确定』后网页将自动导向到新的网络地址。",
			"modifykNetworkFailed": "修改网络设置失败。",
			"modifykPortFailed": "修改端口设置失败。",
			"areYouSureYouWantToTestMobileNetworkSettingTheMobileNetworkWillBeDisconnected": "您确定要测试移动网络设置吗？此举将导致正在透过移动网络存取系统的用户断线。",
			"dialNumberIsEmpty": "拨接号码不能为空白。",
			"apnIsEmpty": "APN不能为空白。",
			"mccIsEmpty": "国家代码不能为空白。",
			"mncIsEmpty": "网络代码不能为空白。",
			"modifykWebServerPortSuccessfully": "修改网页服务器端口成功。",
			"modifykModbusTCPPortSuccessfully": "修改Modbus TCP端口成功。",
			"modifykModbusNetIDSuccessfully": "修改Modbus NetID成功。",
			"modifykWebServerPortFailed": "修改网页服务器端口失败。",
			"modifykModbusTCPPortFailed": "修改Modbus TCP端口失败。",
			"modifykModbusNetIDFailed": "修改Modbus NetID失败。",
			"saveFailed": "储存失败。",
			"usernameIsEmpty": "账号不能为空白。",
			"passwordIsEmpty": "密码不能为空白。",
			"domainNameIsEmpty": "域名不能为空白。",
			"tokenIsEmpty": "更新代码不能为空白。",
			"serverAddressIsEmpty": "服务器地址不能为空。",
			"areYouSureYouWantToChangeSettingAccessViaCloudMaybeLostConnectionWithCloud": "您确定要改变设置吗？因为您正透过云端存取系统，此举可能会造成系统无法重新与云端建立联机。"
		}
	},
	"html/desktop/home/system/snmp.htm": {
		"snmpSettingPage": "SNMP设置页面",
		"version": "版本",
		"readCommunityName": "Read Community Name",
		"writeCommunityName": "Write Community Name",
		"trapCommunityName": "Trap Community Name",
		"contact": "Contact",
		"location": "Location",
		"snmpManagerList": "SNMP Manager列表",
		"address": "地址",
		"polling": "Read/Write",
		"trap": "Trap",
		"noSNMPManagerExistClickThisButtonToAdd": "无设置SNMP Manager，请按此按钮新增。",
		"remove": "移除",
		"tip": {
			"version": "设置SNMP Trap使用的版本。",
			"readCommunityName": "输入Read Community Name。",
			"writeCommunityName": "输入Write Community Name。",
			"trapCommunityName": "输入Trap Community Name。",
			"contact": "输入Contact信息。",
			"location": "输入Location信息。",
			"polling": "设置是否允许接收来自此SNMP Manager的Read/Write命令。若无勾选任何SNMP Manager，则代表允许接收来自任何SNMP Manager的Read/Write命令。",
			"trap": "设置是否允许发送SNMP Trap至此SNMP Manager。"
		},
		"popup": {
			"addressIsEmpty": "地址不能为空。",
			"addressExists": "地址已经存在。",
			"readCommunityNameIsEmpty": "Read Community Name不能为空。",
			"writeCommunityNameIsEmpty": "Write Community Name不能为空。",
			"trapCommunityNameIsEmpty": "Trap Community Name不能为空。",
			"atLeastSelectOneFunction": "SNMP Manager必须至少启用一项功能。",
			"saveFailed": "储存失败。"
		}
	},
	"html/desktop/home/system/security.htm": {
		"adminPasswordSetting": "管理者密码设置",
		"currentPassword": "目前密码",
		"newPassword": "新密码",
		"retypeNewPassword": "确认新密码",
		"guestPasswordSetting": "访客密码设置",
		"adminProfileSetting": "管理者数据设置",
		"emailAddress": "电子邮件信箱",
		"localFTPSetting": "本机FTP服务器设置",
		"id": "账号",
		"password": "密码",
		"changePassword": "变更密码",
		"serverStatus": "服务器状态",
		"idleTimeSetting": "空闲时间设置",
		"idleTime": "空闲时间",
		"tip": {
			"adminPassword": "输入目前的管理者密码确认进行修改。",
			"adminNewPassword": "输入新的管理者密码。",
			"adminRetypeNewPassword": "再次输入新的管理者密码进行确认。",
			"guestPassword": "输入目前的访客密码确认进行修改。",
			"guestNewPassword": "输入新的访客密码。",
			"guestRetypeNewPassword": "再次输入新的访客密码进行确认。",
			"emailAddress": "输入管理者的电子邮件信箱。当管理者忘记密码时，可以将机器上的旋转开关(Rotary Switch)转至8后，再进入到登录画面并按下『忘记密码？』，系统将会把管理者密码寄至此信箱中。",
			"ftpEnable": "勾选'启用'以开启本机端FTP服务器服务。",
			"id": "登录本机FTP服务器所使用的账号。",
			"password": "勾选'变更密码以设置新的本机FTP服务器密码。",
			"idleTime": "设置使用者登录网页后的空闲时间，当网页静置超过空闲时间后，使用者将被自动注销。"
		},
		"popup": {
			"passwordIsEmpty": "密码不能为空。",
			"retypePasswordNotMatch": "输入两次新的密码不一致。",
			"passwordIncorrect": "密码错误。",
			"saveFailed": "储存失败。",
			"adminEmailIsEmpty": "电子邮件信箱不能为空。"
		}
	},
	"html/desktop/home/system/interface.htm": {
		"ioInterfaceSettingPage": "I/O接口设置页面",
		"function": "功能",
		"dconMaster": "连接DCON设备",
		"modbusRTUMaster": "连接Modbus RTU设备",
		"modbusRTUSlave": "连接HMI或SCADA",
		"modbusTCPMaster": "连接Modbus TCP设备",
		"modbusTCPSlave": "连接HMI或SCADA",
		"modem": "连接GTM-203M-3GWA设备",
		"timeout": "联机超时",
		"silentInterval": "指令间隔时间",
		"tip": {
			"function": "选择此I/O接口的功能。",
			"baudrate": "设置此COM串行端口的Baudrate设置。",
			"parity": "设置此COM串行端口的Parity设置。",
			"stopbits": "设置此COM串行端口的Stop bits设置。",
			"timeout": "输入此COM串行端口的联机超时设置。",
			"checksum": "设置此COM串行端口的Checksum设置。",
			"silentInterval": "输入此COM串行端口的指令间隔时间设置。"
		}
	},
	"html/desktop/home/module.htm": {
		"moduleSettingPage": "模块设置页面",
		"none": "无",
		"moduleNameOrNickname": "型号 / 名称",
		"noModuleExist": "无设置模块",
		"no": "编号",
		"address": "地址",
		"pollingTimeout": "轮询超时(毫秒)",
		"ipAndPort": "IP与端口",
		"netID": "NetID"
	},
	"html/desktop/home/module/menu.htm": {
		"xwboardSetting": "XW-Board设置",
		"xvboardSetting": "XV-Board设置",
		"ioModuleSetting": "I/O模块设置"
	},
	"html/desktop/home/module/local.htm": {
		"xwboardSettingPage": "XW-Board设置页面",
		"xvboardSettingPage": "XV-Board设置页面",
		"module": "模块",
		"none": "无",
		"tip": {
			"module": "设置控制器所安装的模块型号。"
		}
	},
	"html/desktop/home/module/local/setting.htm": {
		"moduleXSetting": "模块 $moduleName 设置",
		"digitalChannel": "数字通道",
		"chX": "通道$no",
		"aiType": "AI 类型",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "温度单位",
		"celsius": "摄氏(°C)",
		"fahrenheit": "华氏(°F)",
		"diAttribute": "DI 参数",
		"doAttribute": "DO 参数",
		"aiAttribute": "AI 参数",
		"aoAttribute": "AO 参数",
		"channel": "通道",
		"ch": "通道",
		"counterType": "计数器类型",
		"counterInitialValue": "计数器初始值",
		"powerOnValue": "开机时默认值",
		"advancedFunction": "高级功能",
		"type": "类型",
		"deadband": "Deadband区间",
		"scale": "线性转换",
		"rising": "升缘",
		"falling": "降缘",
		"pulseOutput": "脉冲(Pulse)输出",
		"autoOFF": "自动归复",
		"mappingToDI": "复制DI讯号",
		"pulseHigh": "高点时间:",
		"pulseLow": "低点时间:",
		"autoOFFAfterXSeconds": "$input 秒后自动回复为OFF",
		"cloneDIXChannelStatus": "复制 DI 通道 $di 状态",
		"scaleMin": "最小值:",
		"scaleMax": "最大值:",
		"scaleUnit": "单位:",
		"tip": {
			"nickname": "输入对此模块的名称。",
			"description": "输入关于此模块的说明。",
			"digitalChannel": "选择数字通道的功能。同一个数字信道上您可以选择当做DI或DO使用。",
			"aiType": "设置此模块之AI类型。",
			"temperatureUnit": "设置此模块之AI通道温度显示单位。"
		}
	},
	"html/desktop/home/module/remote.htm": {
		"remoteIOModuleSettingPage": "远程I/O模块设置页面",
		"dconModuleList": "DCON 模块列表",
		"modbusRTUList": "Modbus RTU 模块列表",
		"modbusTCPList": "Modbus TCP 模块列表",
		"i7000Series": "I-7000系列",
		"m7000Series": "M-7000系列",
		"tMSeries": "tM系列",
		"lcSeries": "LC系列",
		"dlSeries": "DL系列",
		"irSeries": "IR系列",
		"interfaceNotEnable": "此串行端口尚未启用，请至<a href='#home/system/interface'>I/O接口设置<\/a>页面中启用后即可使用。",
		"interfaceIsModbusRTUSlave": "此串行端口已经设置为HMI模式，请至<a href='#home/system/interface'>I/O接口设置<\/a>页面中修改为Modbus RTU Master后即可连接I/O设备。",
		"no": "编号",
		"address": "地址",
		"module": "模块",
		"moduleNameOrNickname": "型号 / 名称",
		"pollingTimeout": "轮询超时(毫秒)",
		"retryInterval": "超时重试时间(秒)",
		"ip": "IP",
		"port": "端口",
		"netID": "NetID",
		"search": "搜寻",
		"noModuleExistClickThisButtonToAdd": "无设置模块，请按此按钮新增。",
		"icpdasModule": "泓格模块",
		"decreaseNo": "编号上移",
		"increaseNo": "编号下移",
		"copy": "复制",
		"removeModule": "移除",
		"moduleSettingConflict": "部分模块设置发生冲突。",
		"selectModuleYouWant": "请选择每个地址上您想使用的模块。",
		"previousMoudle": "原设置模块",
		"scannedMoudle": "扫描后模块",
		"none": "无",
		"scanAddressRange": "扫描地址范围：",
		"scanAddressRangeFromAToB": "扫描 $inputFrom 到 $inputTo 地址。依照您设置的扫描地址数目，这个过程所花费的时间将需数秒至数十秒不等。",
		"comPort": "串行端口",
		"silentInterval": "指令间隔时间",
		"timeout": "逾时时间",
		"scan": "扫描",
		"popup": {
			"reachMaximumModulesAmount": "达到最大模块数量。最大的I/O模块数量为$ioModule个且单一端口为$totalModule个（含电测模块与I/O模块）。",
			"moduleNotFound": "无此模块，请输入模块的型号以进行搜寻并从结果中选择一个型号。",
			"nicknameOrModuleNameIsEmpty": "名称 / 型号不能为空。",
			"nicknameIsEmpty": "名称不能为空。",
			"ipIsEmpty": "IP不能为空。"
		}
	},
	"html/desktop/home/module/remote/modbus.htm": {
		"moduleXSetting": "模块 $moduleName 设置",
		"no": "编号",
		"address": "地址",
		"ip": "IP",
		"port": "端口",
		"netID": "NetID",
		"scanRate": "更新速率",
		"pollingTimeout": "轮询超时时间",
		"retryInterval": "超时重试时间",
		"modbusTableSetting": "Modbus地址对应表设置",
		"dataModel": "数据类型",
		"startAddress": "起始地址",
		"length": "数据数量",
		"type": "格式",
		"hexType": "HEX格式",
		"hex": "HEX",
		"real": "实际",
		"minimum": "最小值:",
		"maximum": "最大值:",
		"dataAdjustment": "数据调整",
		"scaleRatio": "线性转换倍率",
		"offset": "偏移量",
		"deadband": "Deadband区间",
		"add": "加入",
		"modbusTable": "Modbus地址对应表",
		"addressSetting": "地址设置",
		"nicknameSetting": "名称设置",
		"localAddress": "本机<br>地址",
		"removeAllBlock": "清除所有设置",
		"collapseAllBlock": "全部缩合",
		"expandAllBlock": "全部展开",
		"noBlockInModbusTable": "尚未设置地址对应表",
		"dataAddress": "数据地址",
		"hexMinimum": "HEX最小值",
		"hexMaximum": "HEX最大值",
		"realMinimum": "实际最小值",
		"realMaximum": "实际最大值",
		"remove": "移除",
		"unit": "单位",
		"tip": {
			"nickname": "输入对此模块的名称。",
			"description": "输入对此模块的说明。",
			"no": "设置此模块的编号，编号将决定此模块的数据所存放的Modbus地址。",
			"address": "设置此模块的RS-485地址，请确认此设置与模块内部设置相同即可正常联机。",
			"ip": "输入此模块的IP地址。",
			"port": "输入此模块的端口。",
			"netID": "输入此模块的NetID。",
			"scanRateForRTU": "输入每隔多久时间更新一次此模块之通道数据，设置为0则会不间断更新。",
			"scanRateForTCP": "输入每隔多久时间更新一次此模块之通道数据。",
			"pollingTimeout": "输入轮询此模块时的超时时间。",
			"retryInterval": "输入当轮询模块发生超时状况时，下一次轮询此模块的时间间隔。",
			"dataModel": "选择远程Modbus模块上的数据类型。",
			"startAddress": "输入远程Modsbus模块的数据起始地址。",
			"length": "输入欲取回的数据数量。",
			"type": "设置使用何种格式显示读取的数据。",
			"hexType": "输入HEX转换所需的相关数据。",
			"scaleRatio": "输入数据的线性转换倍率，原始数据会被乘上此倍率成为新的资料。",
			"offset": "输入数据的线性转换偏移量，乘上线性转换倍率后的数据会被加上此偏移量成为新的数据。",
			"deadband": "输入此模块数据用于规则设置时所需的Deadband区间。"
		},
		"popup": {
			"addressReachMaximum": "数据的地址必须小于或等于65535。",
			"addressAlreadyExist": "部分数据的地址已经存在于Modbus地址对应表中。",
			"lengthReachMaximum": "数据的长度达到超过限制，数据最大长度为$length。",
			"modbusTableReachMaximum": "Modbus地址对应表的长度超过限制，Modbus地址对应表最大长度为$maxLength。",
			"hexMaximumEqualToMinimum": "HEX的最大值不能等于最小值。",
			"realMaximumLessThanMinimum": "实际值的最大值不能小于或等于最小值。",
			"nicknameIsEmpty": "名称不能为空。"
		}
	},
	"html/desktop/home/module/remote/icpdas.htm": {
		"moduleXSetting": "模块 $moduleName 设置",
		"no": "编号",
		"address": "地址",
		"scanRate": "更新速率",
		"pollingTimeout": "轮询超时时间",
		"retryInterval": "超时重试时间",
		"aiType": "AI类型",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "温度单位",
		"celsius": "摄氏(°C)",
		"fahrenheit": "华氏(°F)",
		"diAttribute": "DI参数",
		"doAttribute": "DO参数",
		"aiAttribute": "AI参数",
		"aoAttribute": "AO参数",
		"channel": "通道",
		"ch": "通道",
		"resetCounterWhenPowerOn": "启动时重置计数器",
		"advancedFunction": "高级功能",
		"autoOFF": "自动归复",
		"mappingToDI": "复制DI讯号",
		"autoOFFAfterXSeconds": "$input 秒后自动回复为OFF",
		"cloneDIXChannelStatus": "复制 DI 通道 $di 状态",
		"type": "类型",
		"deadband": "Deadband区间",
		"scale": "线性转换",
		"scaleMin": "最小值:",
		"scaleMax": "最大值:",
		"scaleUnit": "单位:",
		"tip": {
			"nickname": "输入对此模块的名称。",
			"description": "输入对此模块的说明。",
			"no": "设置此模块的编号，编号将决定此模块的数据所存放的Modbus地址。",
			"address": "设置此模块的RS-485地址，请确认此设置与模块内部设置相同即可正常联机。",
			"scanRate": "输入每隔多久时间更新一次此模块之通道数据，设置为0则会不间断更新。",
			"pollingTimeout": "输入轮询此模块时的超时时间。",
			"retryInterval": "输入当轮询模块发生超时状况时，下一次轮询此模块的时间间隔。",
			"aiType": "设置AI讯号模式",
			"temperatureUnit": "设置温度单位。"
		}
	},
	"html/desktop/home/module/remote/ir.htm": {
		"moduleXSetting": "模块 $moduleName 设置",
		"no": "编号",
		"address": "地址",
		"ip": "IP",
		"port": "端口",
		"netID": "NetID",
		"scanRate": "更新速率",
		"pollingTimeout": "轮询超时时间",
		"retryInterval": "超时重试时间",
		"commandNumber": "命令编号",
		"noCommandExistClickThisButtonToAdd": "无可用命令，请按新增以增加可用命令。",
		"add": "新增",
		"remove": "移除",
		"tip": {
			"nickname": "输入此模块的名称。",
			"description": "输入此模块的说明。",
			"no": "设置此模块的编号，编号将决定此模块的数据所存放的Modbus地址。",
			"address": "设置此模块的RS-485地址，请确认此设置与模块内部设置相同方可正常联机。",
			"ip": "输入此模块的IP地址。",
			"port": "输入此模块的端口。",
			"netID": "输入此模块的NetID。",
			"scanRate": "输入每隔多久时间更新一次此模块之通道数据，设置为0则会不间断更新。",
			"pollingTimeout": "输入轮询此模块时的超时时间。",
			"retryInterval": "输入当轮询模块发生超时状况时，下一次轮询此模块的时间间隔。",
			"commandNumber": "加入模块上已设置的命令编号。"
		}
	},
	"html/desktop/home/logger.htm": {
		"loggerSettingPage": "记录器设置页面",
		"powerMeterDataLogger": "电力数据记录器",
		"ioModuleDataLogger": "I/O数据记录器",
		"userDefinedDataLogger": "自定义数据记录器",
		"logAttribute": "记录文件参数",
		"ftpUploadFunction": "FTP上传功能",
		"dataLogUploadFunction": "数据记录文件上传功能",
		"powerMeterDataLog": "电力数据记录文件",
		"ioModuleDataLog": "I/O数据记录文件",
		"userDefinedDataLog": "自定义数据记录文件",
		"eventLogUploadFunction": "事件记录文件上传功能",
		"eventLog": "事件记录文件",
		"cloudUploadFunction": "云端上传功能"
	},
	"html/desktop/home/logger/menu.htm": {
		"dataLoggerSetting": "数据记录器设置",
		"eventLoggerSetting": "事件记录器设置",
		"ftpUploadSetting": "FTP上传设置",
		"cloudUploadSetting": "云端上传设置"
	},
	"html/desktop/home/logger/data.htm": {
		"powerMeterDataLoggerSetting": "电力数据记录器设置",
		"functionStatus": "功能状态",
		"logMode": "记录模式",
		"average": "平均值",
		"instantaneous": "瞬间值",
		"report": "报表",
		"english": "英文",
		"traditionalChinese": "繁体中文",
		"simplifiedChinese": "简体中文",
		"ioModuleDataLoggerSetting": "I/O数据记录器设置",
		"userDefinedDataLoggerSetting": "自定义数据记录器设置",
		"dataFormat": "数据格式",
		"insert": "插入",
		"logAttributeSetting": "记录文件参数设置",
		"logInterval": "记录间距",
		"fileNameFormat": "文件名格式",
		"endOfLineChar": "结尾字符格式",
		"columnHeader": "标头",
		"add": "附加",
		"logFileRetentionTime": "记录文件保留时间",
		"dataLoggerRateDes":"(请配合各电测模块或I/O模块更新速率。)",
		"tip": {
			"functionStatus": "勾选'启用'以启用数据记录器功能。",
			"logMode": "设置记录数据之计算方式。",
			"columnHeader": "勾选'附加'以附加标头到记录文件中。",
			"report": "设置是否产生Excel格式报表。",
			"dataFormat": "输入数据记录的格式。",
			"logInterval": "设置每笔记录之写入时间间距。",
			"fileNameFormat": "设置记录文件之文件名格式。",
			"endOfLineChar": "设置每笔记录数据之结尾字符格式。",
			"logFileRetentionTime": "设置记录文件之保留时间。"
		},
		"popup": {
			"dataFormatIsEmpty": "数据格式不能为空白。"
		}
	},
	"html/desktop/home/logger/event.htm": {
		"eventLoggerSetting": "事件记录器设置页面",
		"logFileRetentionTime": "记录文件保留时间",
		"tip": {
			"logFileRetentionTime": "设置记录文件之保留时间。"
		}
	},
	"html/desktop/home/logger/ftp.htm": {
		"ftpUploadSettingPage": "FTP上传设置页面",
		"functionStatus": "功能状态",
		"remoteFTPServer": "远程FTP服务器",
		"address": "网址",
		"port": "端口",
		"id": "账号",
		"password": "密码",
		"path": "路径",
		"ftpSettingTest": "远程FTP服务器设置测试",
		"send": "传送",
		"sentSuccessfully": "传送成功。",
		"sentFailed": "传送失败。",
		"dataLogUploadFunction": "数据记录文件上传功能",
		"uploadPowerMeterDataLog": "上传电力数据记录文件",
		"uploadIOModuleDataLog": "上传I/O数据记录文件",
		"uploadUserDefinedDataLog": "上传自定义数据记录文件",
		"eventLogUploadFunction": "事件记录文件上传功能",
		"uploadEventLog": "上传事件记录文件",
		"frequency": "频率",
		"everyXMinutes": "每 $minute 分钟",
		"everyXHour": "每 $hour 小时",
		"everyXHours": "每 $hour 小时",
		"eventLogUploadSetting": "事件记录文件上传设置",
		"onceADay": "一天一次",
		"onceAWeek": "一周一次",
		"onceAMonth": "一个月一次",
		"enablePowerMeterDataLoggerFirst": "请先启用电力数据记录器。",
		"enableIOModuleDataLoggerFirst": "请先启用I/O数据记录器。",
		"enableUserDefinedDataLoggerFirst": "请先启用自定义数据记录器。",
		"tip": {
			"functionStatus": "勾选'启用'以启用记录器上传至远程FTP服务器的功能。",
			"dataLogUploadFunction": "选择欲上传的数据记录文件类型并设置上传频率。",
			"eventLogUploadFunction": "选择欲上传的事件记录文件类型并设置上传频率。",
			"frequency": "设置记录文件的上传周期。",
			"remoteFTPServer": "输入远程FTP服务器信息。",
			"address": "输入远程FTP服务器网址。",
			"port": "输入远程FTP服务器端口。",
			"id": "输入远程FTP服务器登录账号。",
			"password": "输入远程FTP服务器登录密码。",
			"path": "输入远程FTP服务器记录文件的上传路径。",
			"ftpSettingTest": "按下传送后，系统将会依据您的设置，尝试登入远程FTP服务器并建立一个文件夹与传送测试文件，以确定设置正确。"
		},
		"popup": {
			"urlIsEmpty": "网址不能为空白。",
			"idIsEmpty": "账号不能为空白。"
		}
	},
	"html/desktop/home/logger/cloud.htm": {
		"cloudUploadSettingPage": "云端上传设置页面",
		"functionStatus": "功能状态",
		"dataLogUploadFunction": "数据记录文件上传功能",
		"uploadPowerMeterDataLog": "上传电力数据记录文件",
		"uploadIOModuleDataLog": "上传I/O数据记录文件",
		"enablePowerMeterDataLoggerFirst": "请先启用电力数据记录器。",
		"enableIOModuleDataLoggerFirst": "请先启用I/O数据记录器。",
		"enableCloudFunctionFirst": "需启用『系统参数设置 > 网络设置 > 云端管理系统』功能才可上传数据记录文件。",
		"tip": {
			"functionStatus": "勾选'启用'以启用记录器上传至云端的功能。",
			"dataLogUploadFunction": "选择欲上传的数据记录文件类型。"
		}
	},
	"html/desktop/home/iot.htm": {
		"iotSettingPage": "IoT平台设置页面",
		"azureDescription": "系统提供了与Microsoft Azure平台连接的功能，能够发布至Microsoft Azure或接收来自Microsoft Azure的讯息，并将收到的讯息作为工作逻辑的判断条件。",
		"bluemixDescription": "系统提供了与IBM Bluemix平台连接的功能，能够发布至IBM Bluemix或接收来自IBM Bluemix的讯息，并将收到的讯息作为工作逻辑的判断条件。",
		"mqttDescription": "系统提供了MQTT客户端的功能，能够发布(Publish)信息至指定的Broker或订阅(Subscribe)Topic，并将收到的信息作为工作逻辑的判断条件。"
	},
	"html/desktop/home/iot/menu.htm": {
		"azureSetting": "Microsoft Azure平台设置",
		"bluemixSetting": "IBM Bluemix平台设置",
		"mqttSetting": "MQTT设置"
	},
	"html/desktop/home/iot/azure.htm": {
		"azureSettingPage": "Microsoft Azure设置页面",
		"functionStatus": "功能状态",
		"sasToken": "SAS令牌",
		"keepAliveTime": "Keep Alive时间",
		"periodicallyPublishInterval": "周期性发布间隔",
		"input0RepresentDisablePeriodicallyPublish": "输入0代表停用周期性发布。",
		"connectionTesting": "联机测试",
		"testing": "测试",
		"connectSuccessfully": "联机成功。",
		"connectFailed": "联机失败。",
		"publishAndSubscribeSetting": "讯息发布与接收设置",
		"publish": "发布",
		"subscribe": "接收",
		"message": "讯息",
		"createNewPublishMessage": "新增发布讯息",
		"copy": "复制",
		"remove": "移除",
		"noMessageExist": "无设置信息。",
		"variableName": "参数名称",
		"add": "新增",
		"variable": "参数",
		"noVariableNameExist": "无设置参数名称。",
		"tip": {
			"functionStatus": "勾选'启用'以启用Microsoft Azure功能。",
			"sasToken": "输入Microsoft Azure所提供的SAS令牌字符串。",
			"keepAliveTime": "输入Keep Alive时间。",
			"periodicallyPublishInterval": "输入周期性发布讯息的间隔时间。所有启用『周期性发布』的讯息会依据此间隔持续周期性地自动发布。",
			"connectionTesting": "按下测试后，系统将会依据您的设置，尝试建立联机至Microsoft Azure上，以确定设置正确。",
			"variableName": "输入参数名称。一组参数是由名称与数值所组成，该名称所对应的数值可用于IF条件中。"
		},
		"popup": {
			"sasTokenIsEmpty": "SAS令牌不能为空白。",
			"variableNameIsEmpty": "参数名称不能为空。",
			"variableNameIsDuplicate": "参数名称不能重复。"
		}
	},
	"html/desktop/home/iot/azure/publish.htm": {
		"messageType": "讯息类型",
		"channelData": "信道数据",
		"userDefinedData": "自定义资料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"autoPublish": "自动发布",
		"dataChangeGreatX": "当数值变动大于$threshold时",
		"periodicallyPublish": "周期性发布",
		"none": "无",
		"message": "讯息",
		"publishMessageXSetting": "发布讯息 $name 设置",
		"tip": {
			"nickname": "输入此讯息的名称。",
			"description": "输入此讯息的说明。",
			"messageType": "设置此讯息的数据类型。",
			"channelData": "选择欲作为此讯息内容的信道。",
			"userDefinedData": "输入欲作为此讯息内容的数据。",
			"autoPublish": "选择此讯息自动发布的时间点。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"noAvailableChannelData": "无可用的信道数据。请先新增至少一个模块或内部缓存器。",
			"userDefinedDataIsEmpty": "自定义资料不能为空白。"
		}
	},
	"html/desktop/home/iot/bluemix.htm": {
		"bluemixSettingPage": "IBM Bluemix设置页面",
		"functionStatus": "功能状态",
		"organizationID": "组织名称",
		"deviceType": "装置类型",
		"deviceID": "装置名称",
		"deviceAuthenticationToken": "鉴别记号",
		"keepAliveTime": "Keep Alive时间",
		"periodicallyPublishInterval": "周期性发布间隔",
		"input0RepresentDisablePeriodicallyPublish": "输入0代表停用周期性发布。",
		"connectionTesting": "联机测试",
		"testing": "测试",
		"connectSuccessfully": "联机成功。",
		"connectFailed": "联机失败。",
		"publishAndSubscribeSetting": "讯息发布与接收设置",
		"publish": "发布",
		"subscribe": "接收",
		"message": "讯息",
		"createNewPublishMessage": "新增发布讯息",
		"copy": "复制",
		"remove": "移除",
		"noMessageExist": "无设置信息。",
		"commandName": "命令名称",
		"variableName": "参数名称",
		"add": "新增",
		"command": "命令",
		"variable": "参数",
		"noCommandNameExist": "无设置命令名称。",
		"noVariableNameExist": "无设置参数名称。",
		"tip": {
			"functionStatus": "勾选'启用'以启用IBM Bluemix功能。",
			"organizationID": "输入组织名称(Organization ID)。",
			"deviceType": "输入设备类型(Device Type)。",
			"deviceID": "输入设备名称(Device ID)。",
			"deviceAuthenticationToken": "输入鉴别记号(Device Authentication Token)。",
			"keepAliveTime": "输入Keep Alive时间。",
			"periodicallyPublishInterval": "输入周期性发布讯息的间隔时间。所有启用『周期性发布』的讯息会依据此间隔持续周期性地自动发布。",
			"connectionTesting": "按下测试后，系统将会依据您的设置，尝试建立联机至IBM Bluemix上，以确定设置正确。",
			"commandName": "输入命令名称。该名称可用于IF条件中。",
			"variableName": "输入参数名称。一组参数是由名称与数值所组成，该名称所对应的数值可用于IF条件中。"
		},
		"popup": {
			"organizationIDIsEmpty": "组织名称不能为空白。",
			"deviceTypeIsEmpty": "装置类型不能为空白。",
			"deviceIDIsEmpty": "装置名称不能为空白。",
			"deviceAuthenticationTokenIsEmpty": "鉴别记号不能为空白。",
			"commandNameIsEmpty": "命令名称不能为空。",
			"commandNameIsDuplicate": "命令名称不能重复。",
			"variableNameIsEmpty": "参数名称不能为空。",
			"variableNameIsDuplicate": "参数名称不能重复。"
		}
	},
	"html/desktop/home/iot/bluemix/publish.htm": {
		"eventID": "事件名称",
		"messageType": "讯息类型",
		"channelData": "信道数据",
		"userDefinedData": "自定义资料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"autoPublish": "自动发布",
		"dataChangeGreatX": "当数值变动大于$threshold时",
		"periodicallyPublish": "周期性发布",
		"none": "无",
		"message": "讯息",
		"publishMessageXSetting": "发布讯息 $name 设置",
		"tip": {
			"nickname": "输入此讯息的名称。",
			"description": "输入此讯息的说明。",
			"eventID": "输入此讯息的事件名称(Event ID)。",
			"messageType": "设置此讯息的数据类型。",
			"channelData": "选择欲作为此讯息内容的信道。",
			"userDefinedData": "输入欲作为此讯息内容的数据。",
			"autoPublish": "选择此讯息自动发布的时间点。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"eventIDIsEmpty": "事件名称不能为空。",
			"noAvailableChannelData": "无可用的信道数据。请先新增至少一个模块或内部缓存器。",
			"userDefinedDataIsEmpty": "自定义资料不能为空白。"
		}
	},
	"html/desktop/home/iot/mqtt.htm": {
		"mqttSettingPage": "MQTT设置页面",
		"brokerSetting": "Broker设置",
		"topicImportExport": "Topic汇入/汇出",
		"address": "地址",
		"port": "端口",
		"initialStatus": "初始状态",
		"createNewOne": "新增MQTT Broker",
		"noBrokerExist": "无设置MQTT Broker。",
		"copy": "复制",
		"remove": "移除",
		"importTopic": "汇入Topic",
		"export": "汇出",
		"popup": {
			"importingPleaseWait": "汇入中，请稍候...",
			"noExportTopicPleaseSelectLastOneTopic": "无可汇出的Topic，请至少勾选一个Topic再汇出。",
			"importFailed": "汇入失败。",
			"importFailedFileFormatIsInvalid": "汇入失败，文件格式不正确。",
			"importSuccess": "汇入成功。",
			"reachMaximumBrokerAmount": "已达到最大Broker数量。"
		}
	},
	"html/desktop/home/iot/mqtt/broker.htm": {
		"brokerAttributeSetting": "Broker参数设置",
		"initialStatus": "初始状态",
		"address": "地址",
		"port": "端口",
		"authentication": "账号验证",
		"id": "账号",
		"password": "密码",
		"clientID": "客户端名称",
		"encryption": "加密传输",
		"keepAliveTime": "Keep Alive时间",
		"connectionTesting": "联机测试",
		"testing": "测试",
		"connectSuccessfully": "联机成功。",
		"connectFailed": "联机失败。",
		"messageSetting": "讯息设置",
		"message": "信息",
		"periodicallyPublishInterval": "周期性发布间隔",
		"input0RepresentDisablePeriodicallyPublish": "输入0代表停用周期性发布。",
		"topicPrefix": "Topic前置字符串",
		"publishAndSubscribeSetting": "Publish与Subscribe设置",
		"createNewPublishMessage": "新增Publish讯息",
		"createNewSubscribeTopic": "新增Subscribe Topic",
		"noTopicExist": "无设置Topic。",
		"noMessageExist": "无设置信息。",
		"copy": "复制",
		"remove": "移除",
		"brokerXSetting": "Broker $name 设置",
		"tip": {
			"nickname": "输入此Broker的名称。",
			"description": "输入此Broker的说明。",
			"initialStatus": "设置当系统启动时，此Broker的初始状态。",
			"address": "输入此Broker的地址。",
			"port": "输入此Broker的端口。",
			"authentication": "若您的Broker要求认证，请勾选'启用'以启用账号验证功能。",
			"lastWill": "勾选'启用'以启用Last Will功能。",
			"clientID": "输入客户端名称(Client ID)。维持空白时系统将自动产生。",
			"encryption": "设置在数据传输时是否开启加密功能。",
			"keepAliveTime": "输入Keep Alive时间。",
			"periodicallyPublishInterval": "输入周期性发布Topic的间隔时间。所有启用『周期性发布』的Topic会依据此间隔持续周期性地自动发布。",
			"topicPrefix": "输入Topic前置字符串。可在每一个Topic设置中设置是否使用前置字符串。",
			"connectionTesting": "按下测试后，系统将会依据您的设置，尝试建立联机至您设置的Broker上，以确定设置正确。"
		},
		"popup": {
			"reachMaximumAmount": "达到最大数量。",
			"nicknameIsEmpty": "Broker名称不能为空白。",
			"addressIsEmpty": "地址不能为空白。",
			"idIsEmpty": "账号不能为空白。",
			"willTopicIsEmpty": "Will Topic不能为空白。",
			"willMessageIsEmpty": "Will信息不能为空白。"
		}
	},
	"html/desktop/home/iot/mqtt/broker/publish.htm": {
		"messageType": "信息类型",
		"channelData": "信道数据",
		"userDefinedData": "自定义资料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"usePrefix": "使用前置字符串",
		"import": "汇入",
		"use": "使用",
		"retain": "保留信息(Retain)",
		"autoPublish": "自动发布",
		"dataChangeGreatX": "当数值变动大于$threshold时",
		"periodicallyPublish": "周期性发布",
		"none": "无",
		"message": "讯息",
		"publishMessageXSetting": "Publish信息 $name 设置",
		"tip": {
			"nickname": "输入此信息的名称。",
			"description": "输入此信息的说明。",
			"messageType": "设置此信息的数据类型。",
			"channelData": "选择欲作为此信息内容的信道。",
			"userDefinedData": "输入欲作为此信息内容的数据。",
			"topic": "输入此信息欲发布到的Topic名称。",
			"qos": "设置此信息的QoS。",
			"retain": "勾选'启用'以开启此信息的保留功能。",
			"autoPublish": "选择此信息自动发布的时间点。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"noAvailableChannelData": "无可用的信道数据。请先新增至少一个模块或内部缓存器。",
			"userDefinedDataIsEmpty": "自定义资料不能为空白。",
			"topicIsEmpty": "Topic不能为空白。"
		}
	},
	"html/desktop/home/iot/mqtt/broker/subscribe.htm": {
		"usePrefix": "使用前置字符串",
		"import": "汇入",
		"use": "使用",
		"subscribeTopicXSetting": "Subscribe Topic $name 设置",
		"tip": {
			"nickname": "输入此Topic的名称。",
			"description": "输入此Topic的说明。",
			"topic": "输入欲订阅的Topic名称。",
			"qos": "设置此Topic的QoS。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"topicIsEmpty": "Topic不能为空白。",
			"topicContainIllegalCharacter": "Topic不能含有+或#符号。"
		}
	},
	"html/desktop/home/advanced.htm": {
		"advancedSettingPage": "高级功能设置页面",
		"internalRegisterDescription": "提供48个内部缓存器(Internal register)，可做为暂存的变量，可透过Modbus address来读取或设置内部缓存器变量值，亦可作为IF判断条件及THEN/ELSE执行动作。",
		"timerDescription": "定时器(Timer)提供 超时/未超时 的判断条件功能，让用户可编辑需搭配时间计划的工作逻辑；也提供了实时地重置/启动定时器的功能，让IF-THEN-ELSE工作逻辑在时间计划的管控上更加有弹性。",
		"scheduleDescription": "时间表(Schedule)功能可用以执行规律性的日期计划任务。时间表功能提供了万年历的日期点选接口及周期性的执行设置，以供用户设计出更加灵活弹性的日期计划。",
		"emailDescription": "电子邮件(Email)发送功能可于特殊事件发生时，传送预先设置的电子邮件至特定收件者的电子邮件信箱，快速地将即时消息传递给相关人员。信件内容可包含实时的I/O通道信息，用户可随时掌握系统状况。",
		"cgiDescription": "CGI命令发送功能提供用户将发送CGI指令的动作编入工作逻辑当中，便能实时地与安全监控系统连接互动。",
		"smsDescription": "SMS功能提供用户将SMS警报发送动作编入工作逻辑当中，即可于预定事件发生时传递即时消息与相关人员，且也可接收特定手机传送的简讯命令，具备实时通道数据查询及通道数据修改的功能。",
		"statusDescription": "实时信息显示设置功能提供用户自行编排模块通道信息显示页面，可将位于不同模块的通道信息集中于自定页面中。",
		"hmiDescription": "Flash HMI 编辑器提供管理者透过丰富的Flash图形组件，可以快速的设计HMI人机界面，以建立现场设备信息的监控页面。",
		"snmpTrapDescription": "SNMP Trap功能能够在特殊事件发生时，主动将通道等数据实时地发送至远程SNMP Manager上，让SNMP Manager进行相对应的处理。",
		"pueDescription": "提供使用者计算器房等设施的能源使用效率，此数值亦可作为IF判断条件。",
		"lineNotifyDescription": "LINE Notify发送功能可于发生特殊事件时，主动将讯息推拨至手机上的LINE App中。"
	},
	"html/desktop/home/advanced/menu.htm": {
		"internalRegisterSetting": "内部缓存器设置",
		"timerSetting": "定时器设置",
		"scheduleSetting": "时间表设置",
		"emailSetting": "电子邮件设置",
		"cgiCommandSetting": "CGI命令设置",
		"smsSetting": "SMS简讯设置",
		"statusSetting": "实时信息显示设置",
		"hmiSetting": "Flash HMI设置",
		"snmpTrapSetting": "SNMP Trap设置",
		"lineNotifySetting": "LINE Notify设置"
	},
	"html/desktop/home/advanced/register.htm": {
		"internalRegisterSettingPage": "内部缓存器设置页面",
		"no": "编号",
		"initialValue": "初始值",
		"noInternalRegisterExistClickThisButtonToAdd": "无设置内部缓存器，请按此按钮新增。",
		"copy": "复制",
		"remove": "移除",
		"internalRegister": "内部缓存器",
		"retainVariable": "断电保持",
		"popup": {
			"reachMaximumAmount": "达到最大数量。"
		}
	},
	"html/desktop/home/advanced/register/setting.htm": {
		"internalRegisterXSetting": "内部缓存器 $name 设置",
		"no": "编号",
		"initialValue": "初始值",
		"tip": {
			"no": "内部缓存器的编号。",
			"nickname": "输入对此内部缓存器的名称。",
			"description": "输入对此内部缓存器的说明。",
			"initialValue": "输入此内部缓存器的初始值。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。"
		}
	},
	"html/desktop/home/advanced/timer.htm": {
		"timerSettingPage": "定时器设置页面",
		"timer": "定时器",
		"initialStatus": "初始状态",
		"period": "时间长度",
		"stop": "停止",
		"start": "启动",
		"assignPeriod": "指定时间",
		"internalRegister": "内部缓存器",
		"no": "编号",
		"alreadyRemove": "(已被移除)",
		"noTimerExistClickThisButtonToAdd": "无设置定时器，请按此按钮新增。",
		"copy": "复制",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "达到最大数量。",
			"someoneTimerUseAlreadyRemovedRegister": "不可将已被移除的内部缓存器数值设为定时器时间长度的参考。"
		}
	},
	"html/desktop/home/advanced/timer/setting.htm": {
		"timerXSetting": "定时器 $name 设置",
		"initialStatus": "初始状态",
		"period": "时间长度",
		"stop": "停止",
		"start": "启动",
		"assignPeriod": "指定时间",
		"internalRegister": "内部缓存器",
		"no": "编号",
		"tip": {
			"nickname": "输入对此定时器的名称。",
			"description": "输入对此定时器的说明。",
			"initialStatus": "设置当控制器启动时，此定时器的初始状态。",
			"period": "输入此定时器的时间长度。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。"
		}
	},
	"html/desktop/home/advanced/schedule.htm": {
		"scheduleSettingPage": "时间表设置页面",
		"mode": "模式",
		"calendar": "万年历型",
		"repeat": "周期型",
		"createNewOne": "新增时间表",
		"copy": "复制",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "达到最大数量。"
		}
	},
	"html/desktop/home/advanced/schedule/setting.htm": {
		"scheduleXSetting": "时间表 $name 设置",
		"schedule": "时间表",
		"scheduleDetailSetting": "时间表内容设置",
		"initialStatus": "初始状态",
		"mode": "模式",
		"calendar": "万年历型",
		"repeat": "周期型",
		"date": "日期",
		"startMonth": "起始月份",
		"duration": "月份长度",
		"month": "个月",
		"day": "星期",
		"exceptionDate": "例外日期",
		"timeRange": "时间范围",
		"add": "新增",
		"remove": "移除",
		"selectAll": "全部选取",
		"unSelectAll": "清除选取",
		"selectWeekday": "工作日",
		"selectWeekend": "周末",
		"inRange": "范围内",
		"outOfRange": "范围外",
		"tip": {
			"nickname": "输入对此时间表的名称。",
			"description": "输入对此时间表的说明。",
			"initialStatus": "设置当控制器启动时，此时间表的初始状态。",
			"mode": "选择时间表的运作模式：万年历型可针对一年内的所有日期作个别设置，周期型则是以'周'为单位，在勾选'周'内的特定日期后进行作周期性的运作。",
			"calendarDate": "设置时间表的日期范围。",
			"day": "勾选设置每周中的时间表日期。",
			"exceptionDate": "设置周期性时间表中的例外日期，周期性时间表会略过所指定的例外日期。",
			"timeRange": "设置时间表中的时间区间。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"selectAtLeastOneDate": "请至少选择一个时间表内的日期。",
			"selectAtLeastOneDay": "请至少在一周当中选择一天。",
			"selectAtLeastOneTimeRange": "请至少设置一组时间范围。",
			"startTimeIsSameWithEndTime": "起始时间不能与结束时间相同。",
			"timeRangeIsOverlap": "时间范围不能重迭。"
		}
	},
	"html/desktop/home/advanced/email.htm": {
		"emailSettingPage": "电子邮件设置页面",
		"subject": "主旨",
		"receiver": "收件者",
		"createNewOne": "新增电子邮件",
		"copy": "复制",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "达到最大数量。"
		}
	},
	"html/desktop/home/advanced/email/setting.htm": {
		"emailXSetting": "电子邮件 $name 设置",
		"email": "电子邮件",
		"smtpServerSetting": "SMTP服务器设置",
		"smtpServer": "SMTP服务器地址",
		"specifySMTPServer": "指定SMTP服务器地址",
		"port": "端口",
		"authentication": "账号验证",
		"id": "账号",
		"password": "密码",
		"security": "安全性",
		"noSecurity": "无加密",
		"emailAddressSetting": "电子邮件地址设置",
		"senderName": "发件人名称",
		"senderEmail": "发件人电子邮件",
		"receiverEmail": "收件者电子邮件",
		"add": "新增",
		"remove": "移除",
		"emailSettingTest": "电子邮件设置测试",
		"send": "传送",
		"sentSuccessfully": "传送成功。",
		"sentFailed": "传送失败。",
		"emailContenttSetting": "电子邮件内容设置",
		"subject": "主旨",
		"content": "内文",
		"insert": "插入",
		"tip": {
			"nickname": "输入对此电子邮件的名称。",
			"description": "输入对此电子邮件的说明。",
			"smtpServer": "输入SMTP服务器地址。",
			"port": "输入SMTP服务器端口。",
			"authentication": "若SMTP服务器不允许匿名，请勾选启用账号验证并输入帐户信息。",
			"id": "输入登录账号。",
			"password": "输入登录密码。",
			"security": "设置SMTP服务器的加密方式。",
			"senderName": "输入发件人名称。",
			"senderEmail": "输入发件人电子邮件地址。",
			"receiverEmail": "输入收件者电子邮件地址。",
			"emailSettingTest": "按下传送后，系统将会依据您的设置，发送一封测试邮件到第一位收件者的电子邮件信箱中。",
			"emailSubject": "输入此电子邮件主旨。",
			"emailContent": "输入电子邮件本文内容。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"smtpServerIsEmpty": "SMTP服务器地址不能为空白。",
			"idIsEmpty": "账号不能为空白。",
			"senderNameIsEmpty": "发件人名称不能为空白。",
			"senderEmailIsEmpty": "发件人电子邮件地址不能为空白。",
			"receiverEmailIsEmpty": "收件者电子邮件地址个数必须大于或等于1个。",
			"subjectIsEmpty": "主旨不能为空白。",
			"contentIsEmpty": "内文不能为空白。"
		}
	},
	"html/desktop/home/advanced/cgi.htm": {
		"cgiCommandSetting": "CGI命令设置页面",
		"cgiServerAddress": "CGI服务器地址",
		"port": "端口",
		"commandNumber": "命令个数",
		"noCGIServerExistClickThisButtonToAdd": "无设置CGI服务器，请按此按钮新增。",
		"copy": "复制",
		"remove": "移除",
		"cgiServer": "CGI服务器",
		"popup": {
			"cgiServerAddressIsEmpty": "CGI服务器地址不能为空白。",
			"reachMaximumAmount": "达到最大数量。",
			"commandIsEmpty": "CGI服务器的命令个数必须大于或等于1个。"
		}
	},
	"html/desktop/home/advanced/cgi/server.htm": {
		"cgiServerAddress": "CGI服务器地址",
		"port": "端口",
		"authentication": "账号验证",
		"type": "认证类型",
		"id": "账号",
		"password": "密码",
		"retryTimes": "重试次数",
		"times": "次",
		"cgiCommandSetting": "CGI命令设置",
		"cgiCommand": "CGI命令",
		"createNewOne": "新增CGI命令",
		"copy": "复制",
		"remove": "移除",
		"cgiServerXSetting": "CGI服务器 $name 设置",
		"tip": {
			"nickname": "输入对此CGI服务器的名称。",
			"description": "输入对此CGI服务器的说明。",
			"cgiServerAddress": "输入此CGI服务器的地址。",
			"port": "输入此CGI服务器的端口。",
			"authentication": "若您的CGI服务器要求认证，请勾选'启用'以启用账号验证功能。",
			"type": "设置此CGI服务器认证类型。",
			"id": "输入此CGI服务器的认证账号。",
			"password": "输入此CGI服务器的认证密码。",
			"retryTimes": "输入当此CGI命令发送失败时，重新尝试发送的次数。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"cgiServerAddressIsEmpty": "CGI服务器地址不能为空白。",
			"idIsEmpty": "账号不能为空白。",
			"commandIsEmpty": "CGI命令个数必须大于或等于1个。"
		}
	},
	"html/desktop/home/advanced/cgi/server/command.htm": {
		"cgiCommand": "CGI命令",
		"source": "来源",
		"module": "模块",
		"channel": "通道",
		"no": "编号",
		"insert": "插入",
		"connectionTesting": "联机测试",
		"testing": "测试",
		"responseContentSetting": "响应内容设置",
		"saveAsFile": "储存成档案",
		"savePath": "储存路径",
		"fileName": "檔名",
		"yyyyDescription": "四位数公元年。",
		"HHDescription": "时，数值从00到23。",
		"MMDescription": "月，数值从01到12。",
		"mmDescription": "分，数值从00到59。",
		"ddDescription": "日，数值从01到31。",
		"ssDescription": "秒，数值从00到59。",
		"sendBackViaEmail": "透过电子邮件寄出",
		"sentSuccessfully": "传送成功。",
		"sentFailed": "传送失败。",
		"cgiCommandXSetting": "CGI命令 $name 设置",
		"tip": {
			"nickname": "输入对此CGI命令的名称。",
			"description": "输入对此CGI命令的说明。",
			"cgiCommand": "输入此CGI命令的内容。",
			"connectionTesting": "按下测试后，系统将会依据您的设置，尝试传送一个CGI命令至您设置的服务器上，以确定设置正确。",
			"saveAsFile": "勾选'启用'以启用将CGI响应的内容储存成档案功能。",
			"savePath": "输入档案储存于SD卡的路径。",
			"fileName": "输入档案的档名。若您没有输入附文件名，系统会尝试以CGI响应的Content-Type来决定附档名。",
			"sendBackViaEmail": "配置文件案欲透过的电子邮件设置寄出。",
			"setupEmailFirst": "请先设置电子邮件。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"cgiCommandIsEmpty": "CGI命令内容不能为空白。",
			"fileNameIsEmpty": "档名不能为空白。",
			"fileNameIsInvalid": "档名不能为index或default。"
		}
	},
	"html/desktop/home/advanced/sms.htm": {
		"smsSettingPage": "SMS简讯设置页面",
		"smsAlarm": "SMS简讯警报",
		"smsCommand": "SMS简讯命令",
		"pinCode": "PIN码",
		"smsCommandFunction": "SMS简讯命令功能",
		"authorizedPhoneNumbers": "授权手机号码",
		"add": "新增",
		"copy": "复制",
		"remove": "移除",
		"smsAlarmsList": "SMS简讯警报列表",
		"phoneNumbers": "电话号码",
		"message": "讯息",
		"createNewSMSAlarm": "新增SMS简讯警报",
		"smsCommandsList": "SMS简讯命令行表",
		"command": "命令",
		"commandString": "命令字符串",
		"createNewSMSCommand": "新增SMS简讯命令",
		"tip": {
			"pinCode": "输入SIM卡设置的PIN码。",
			"smsCommandFunction": "设置是否开启SMS简讯命令功能。",
			"authorizedPhoneNumbers": "设置允许发送SMS简讯命令的手机门号，系统只会接受来自这些门号的命令。门号必须包含除了国际冠码以外的所有号码。"
		},
		"popup": {
			"reachMaximumAmount": "达到最大数量。",
			"authorizedPhoneNumbersIsEmpty": "授权手机号码的个数必须大于或等于1个。"
		}
	},
	"html/desktop/home/advanced/sms/alarms.htm": {
		"smsAlarmXSetting": "SMS简讯警报 $name 设置",
		"smsAlarm": "SMS简讯警报",
		"phoneNumbers": "电话号码",
		"add": "新增",
		"remove": "移除",
		"message": "讯息",
		"unicode": "多国语言支持(Unicode)",
		"insert": "插入",
		"tip": {
			"nickname": "输入对此SMS简讯警报的名称。",
			"description": "输入对此SMS简讯警报的说明。",
			"phoneNumbers": "输入接收SMS简讯警报的手机号码。",
			"unicode": "若讯息中使用了非英文或数字的字符时，请勾选此选项。",
			"message": "输入SMS简讯警报讯息内容。单封SMS简讯最大讯息长度为160个字符，使用Unicode时最大讯息长度为70个字符。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"phoneNumbersIsEmpty": "电话号码的个数必须大于或等于1个。",
			"messageIsEmpty": "讯息不能为空白。"
		}
	},
	"html/desktop/home/advanced/sms/quickcommands.htm": {
		"smsCommandSetting": "SMS简讯命令设置",
		"command": "命令",
		"commandString": "命令字符串编辑器",
		"insert": "插入",
		"value": "数值",
		"none": "无",
		"tip": {
			"command": "输入简短的命令。",
			"commandString": "设置欲取代的命令字符串。"
		},
		"popup": {
			"quickCommandIsEmpty": "命令不能为空白。",
			"originalCommandIsEmpty": "命令字符串不能为空白。",
			"quickCommandIsUsed": "命令已经被使用过。"
		}
	},
	"html/desktop/home/advanced/status.htm": {
		"customizeStatusSetting": "实时信息显示设置页面",
		"groupAmount": "群组数量",
		"createNewOne": "新增信息显示页面",
		"copy": "复制",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "达到最大数量。"
		}
	},
	"html/desktop/home/advanced/status/setting.htm": {
		"customizeStatusXSetting": "实时信息显示 $name 设置",
		"customizeStatus": "实时信息显示",
		"createNewGroup": "新增群组",
		"addStatus": "新增通道数据",
		"none": "无",
		"internalRegister": "内部缓存器",
		"source": "来源",
		"module": "模块",
		"channel": "通道",
		"no": "编号",
		"add": "新增",
		"group": "群组",
		"tip": {
			"nickname": "输入对此信息显示页面的名称。",
			"description": "输入对此信息显示页面的说明。"
		},
		"popup": {
			"reachMaximumAmount": "达到最大数量。",
			"nicknameIsEmpty": "名称不能为空白。"
		}
	},
	"html/desktop/home/advanced/hmi.htm": {
		"loadingFlashPlayer": "载入Flash HMI Tools中，请稍候。",
		"popup": {
			"loadFlashPlayerFailed": "Flash HMI Tools加载错误，请检查Flash Player的状态。",
			"flashPlayerVersionTooOld": "Flash Player的版本过旧，请更新Flash Player。"
		}
	},
	"html/desktop/home/advanced/snmp.htm": {
		"snmpTrapSettingPage": "SNMP Trap设置页面",
		"specificTrapID": "Specific ID",
		"messageNumber": "变数绑定数量",
		"noSNMPTrapExistClickThisButtonToAdd": "无设置SNMP Trap，请按此按钮新增。",
		"copy": "复制",
		"remove": "移除",
		"snmpTrap": "SNMP Trap",
		"popup": {
			"messageNumberIsZero": "SNMP Trap的变量绑定数量必须大于或等于1。"
		}
	},
	"html/desktop/home/advanced/snmp/message.htm": {
		"specificTrapID": "Specific ID",
		"snmpTrapMessageList": "SNMP Trap变数绑定列表",
		"content": "内容",
		"format": "格式",
		"createNewMessage": "新增变数绑定",
		"copy": "复制",
		"remove": "移除",
		"snmpTrapXSetting": "SNMP Trap $name 设置",
		"tip": {
			"nickname": "输入此SNMP Trap的名称。",
			"description": "输入此SNMP Trap的说明。",
			"specificTrapID": "输入此SNMP Trap的Specific ID。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"messageNumberIsZero": "SNMP Trap变量绑定数量必须大于或等于1。"
		}
	},
	"html/desktop/home/advanced/snmp/message/setting.htm": {
		"snmpTrapMessageSettingPage": "SNMP Trap变量绑定设置页面",
		"type": "类型",
		"channelData": "通道数据",
		"userDefinedData": "自定义资料",
		"format": "格式",
		"insert": "插入",
		"none": "无",
		"tip": {
			"type": "设置变量绑定的类型。",
			"channelData": "选择作为绑定变量的通道。",
			"format": "设置通道数据的型态。",
			"userDefinedData": "输入欲作为变量绑定的自定义数据。"
		},
		"popup": {
			"noAvailableChannelData": "无可用的通道数据。请先新增至少一个模块或内部缓存器。",
			"userDefinedDataIsEmpty": "自定义资料不能为空白。"
		}
	},
	"html/desktop/home/advanced/linenotify.htm": {
		"lineNotifyMessageSettingPage": "LINE Notify讯息设置页面",
		"lineNotifyCameraSettingPage": "LINE Notify与网络摄影机连动设置页面",
		"lineNotifyChatRoomSettingPage": "LINE Notify聊天室设置页面",
		"message": "讯息",
		"ipCamera": "网络摄影机",
		"chatRoom": "聊天室",
		"content": "内容",
		"chatRoomNumber": "聊天室数量",
		"createNewMessage": "新增讯息",
		"noMessageExist": "无设置讯息。",
		"copy": "复制",
		"remove": "移除",
		"functionStatus": "功能状态",
		"noCameraExist": "无设置网络摄影机",
		"type": "类型",
		"accessToken": "存取令牌",
		"createNewChatRoom": "新增聊天室",
		"noChatRoomExist": "无设置聊天室。",
		"oneOnOne": "1对1",
		"group": "群组",
		"popup": {
			"someMessageNoChatRoom": "部分讯息未指定任何聊天室。"
		}
	},
	"html/desktop/home/advanced/linenotify/message.htm": {
		"content": "内容",
		"insert": "插入",
		"chatRoom": "聊天室",
		"createNewChatRoom": "新增聊天室",
		"unSelectAll": "全不选",
		"selectAll": "全选",
		"message": "讯息",
		"messageXSetting": "讯息 $name 设置",
		"tip": {
			"nickname": "输入此讯息的名称。",
			"description": "输入此讯息的说明。",
			"content": "输入此讯息的内容。",
			"chatRoom": "设置讯息欲传送到的聊天室。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。",
			"contentIsEmpty": "内容不能为空白。",
			"chatRoomIsEmpty": "聊天室不能为空，请至少选择一个聊天室。"
		}
	},
	"html/desktop/home/advanced/linenotify/chatroom.htm": {
		"type": "类型",
		"accessToken": "存取令牌",
		"oneOnOne": "1对1",
		"group": "群组",
		"chatRoomXSetting": "聊天室 $name 设置",
		"tip": {
			"nickname": "输入此聊天室的名称。",
			"description": "输入此聊天室的说明。",
			"type": "此聊天的类型。",
			"accessToken": "此聊天室的存取令牌。"
		},
		"popup": {
			"nicknameIsEmpty": "名称不能为空白。"
		}
	},
	"html/desktop/home/rules.htm": {
		"ruleOverview": "规则总览",
		"noRuleExist": "无设置规则，请尝试点选左边的按钮以新增一条规则。",
		"noCondition": "无条件",
		"noAction": "无动作",
		"delayXSecond": "延迟$delay秒"
	},
	"html/desktop/home/rules/menu.htm": {
		"addRule": "新增规则",
		"moveUp": "上移",
		"moveDown": "下移",
		"remove": "移除",
		"copy": "复制",
		"popup": {
			"reachMaximumAmount": "达到最大数量。"
		}
	},
	"html/desktop/home/rules/rule.htm": {
		"ruleInfomationSetting": "规则信息设置",
		"rule": "规则",
		"status": "状态",
		"ruleContentSetting": "规则内容设置",
		"addCondition": "新增判断条件:",
		"noCondition": "无判断条件",
		"addAction": "新增执行动作:",
		"noAction": "无执行动作",
		"selectCondition": "选择判断条件",
		"selectAction": "选择执行动作",
		"oneTimeAction": "单次性动作",
		"repaetAction": "重复性动作",
		"delayXSecondAfterExecution": "执行后延迟$delay秒。",
		"setting": "设置",
		"copy": "复制",
		"remove": "移除",
		"tip": {
			"nickname": "输入对此规则的名称。",
			"description": "输入对此规则的说明。",
			"status": "设置是否启用此规则。"
		},
		"popup": {
			"reachMaximumAmount": "达到最大数量。",
			"nicknameIsEmpty": "名称不能为空白。",
			"conditionAmountIsZero": "条件个数必须大于或等于1个。",
			"actionAmountIsZero": "动作个数必须大于或等于1个。",
			"existErrorRule": "红色边框的规则发生错误，请先修正他们。"
		}
	},
	"html/desktop/home/rules/rule/cai.htm": {
		"aiConditionSetting": "AI条件设置",
		"moduleAndChannel": "模块与通道",
		"operator": "运算符",
		"value": "比较数值",
		"channel": "通道",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cci.htm": {
		"discreteInputConditionSetting": "Discrete Input条件设置",
		"moduleAndAddress": "模块与地址",
		"interface": "I/O界面",
		"module": "模块",
		"address": "地址",
		"status": "比较状态",
		"tip": {
			"moduleAndAddress": "选择模块与地址。",
			"status": "设置此地址的比较状态，当地址状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cco.htm": {
		"coilOutputConditionSetting": "Coil Output条件设置",
		"moduleAndAddress": "模块与地址",
		"interface": "I/O界面",
		"module": "模块",
		"address": "地址",
		"status": "比较状态",
		"tip": {
			"moduleAndAddress": "选择模块与地址。",
			"status": "设置此地址的比较状态，当地址状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cdi.htm": {
		"diConditionSetting": "DI条件设置",
		"moduleAndChannel": "模块与通道",
		"interface": "I/O界面",
		"module": "模块",
		"channel": "通道",
		"status": "比较状态",
		"tip": {
			"moduleAndChannel": "选择模块与通道。",
			"status": "设置此通道的比较状态，当通道状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cdic.htm": {
		"diCounterConditionSetting": "DI计数器条件设置",
		"moduleAndChannel": "模块与通道",
		"operator": "运算符",
		"value": "比较数值",
		"channel": "通道",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cregister.htm": {
		"registerConditionSetting": "内部缓存器条件设置",
		"no": "编号",
		"operator": "运算符",
		"value": "比较数值"
	},
	"html/desktop/home/rules/rule/cri.htm": {
		"inputRegisterConditionSetting": "Input Register条件设置",
		"moduleAndAddress": "模块与地址",
		"operator": "运算符",
		"value": "比较数值",
		"address": "地址",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cro.htm": {
		"holdingRegisterConditionSetting": "Holding Register条件设置",
		"moduleAndAddress": "模块与地址",
		"operator": "运算符",
		"value": "比较数值",
		"address": "地址",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cstatus.htm": {
		"connectionStatusConditionSetting": "模块联机状态条件设置",
		"interface": "I/O界面",
		"module": "模块",
		"status": "状态",
		"tip": {
			"module": "选择模块。",
			"status": "设置此模块的比较状态，当联机状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/crule.htm": {
		"ruleStatusConditionSetting": "规则状态条件设置",
		"rule": "规则",
		"status": "状态",
		"tip": {
			"rule": "选择已设置之规则。",
			"status": "使用规则之执行状态作为条件，当所选择之规则状态与此设置相符则条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cschedule.htm": {
		"scheduleConditionSetting": "时间表条件设置",
		"schedule": "时间表",
		"status": "状态",
		"tip": {
			"schedule": "选择已设置之时间表。",
			"status": "以目前的时间在此时间表的范围内或范围外来做为条件。"
		}
	},
	"html/desktop/home/rules/rule/csdcard.htm": {
		"sdCardStatusConditionSetting": "SD卡状态条件设置",
		"status": "状态",
		"tip": {
			"status": "以SD卡目前的状态来做为条件。"
		}
	},
	"html/desktop/home/rules/rule/ctimer.htm": {
		"timerConditionSetting": "定时器条件设置",
		"timer": "定时器",
		"status": "状态",
		"tip": {
			"timer": "选择已设置之定时器。",
			"status": "以此定时器目前的计时状态来做为条件。"
		}
	},
	"html/desktop/home/rules/rule/cazurestatus.htm": {
		"azureConnectionStatusConditionSetting": "Microsoft Azure联机状态条件设置",
		"status": "状态",
		"tip": {
			"status": "设置Microsoft Azure的比较状态，当联机状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cbluemixstatus.htm": {
		"bluemixConnectionStatusConditionSetting": "IBM Bluemix联机状态条件设置",
		"status": "状态",
		"tip": {
			"status": "设置IBM Bluemix的比较状态，当联机状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cbroker.htm": {
		"mqttConnectionStatusConditionSetting": "MQTT Broker联机状态条件设置",
		"status": "状态",
		"tip": {
			"broker": "选择已设置之Broker。",
			"status": "设置此Broker的比较状态，当联机状态与比较状态相同时则此条件成立。"
		}
	},
	"html/desktop/home/rules/rule/cazuresubscribe.htm": {
		"azureSubscribeMessageConditionSetting": "Microsoft Azure接收讯息条件设置",
		"name": "名称",
		"variableName": "参数名称",
		"operator": "运算符",
		"value": "比较数值",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cbluemixsubscribe.htm": {
		"bluemixSubscribeMessageConditionSetting": "IBM Bluemix接收讯息条件设置",
		"name": "名称",
		"commandName": "命令名称",
		"variableName": "参数名称",
		"operator": "运算符",
		"value": "比较数值",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/ctopic.htm": {
		"mqttSubscribeTopicConditionSetting": "MQTT Subscribe Topic条件设置",
		"operator": "运算符",
		"value": "比较数值",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/cftp.htm": {
		"ftpUploadStatusConditionSetting": "FTP上传状态条件设置",
		"status": "状态",
		"uploadFailedContinuingXHours": "上传持续失败 $input 小时"
	},
	"html/desktop/home/rules/rule/csignal.htm": {
		"signalStrengthConditionSetting": "移动网络信号强度条件设置",
		"unit": "单位",
		"percent": "百分比",
		"operator": "运算符",
		"value": "比较数值",
		"bit": "位元"
	},
	"html/desktop/home/rules/rule/aao.htm": {
		"aoActionSetting": "AO动作设置",
		"moduleAndChannel": "模块与通道",
		"operator": "运算符",
		"value": "设置数值",
		"channel": "通道",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/aro.htm": {
		"holdingRegisterActionSetting": "Holding Register动作设置",
		"moduleAndAddress": "模块与地址",
		"operator": "运算符",
		"value": "设置数值",
		"address": "地址",
		"no": "编号"
	},
	"html/desktop/home/rules/rule/ado.htm": {
		"doActionSetting": "DO动作设置",
		"moduleAndChannel": "模块与通道",
		"interface": "I/O界面",
		"module": "模块",
		"channel": "通道",
		"status": "设置状态",
		"pulseOutput": "脉冲输出",
		"tip": {
			"moduleAndChannel": "选择模块与通道。",
			"status": "设置通道状态动作。"
		}
	},
	"html/desktop/home/rules/rule/adic.htm": {
		"diCounterActionSetting": "DI计数器动作设置",
		"moduleAndChannel": "模块与通道",
		"interface": "I/O界面",
		"module": "模块",
		"channel": "通道",
		"action": "动作",
		"tip": {
			"moduleAndChannel": "选择模块与通道。",
			"action": "重置此DI通道之计数器。"
		}
	},
	"html/desktop/home/rules/rule/aco.htm": {
		"coilOutputActionSetting": "Coil Output动作设置",
		"moduleAndAddress": "模块与地址",
		"interface": "I/O界面",
		"module": "模块",
		"channel": "通道",
		"status": "设置状态",
		"tip": {
			"moduleAndAddress": "选择模块与地址。",
			"status": "设置地址状态动作。"
		}
	},
	"html/desktop/home/rules/rule/aemail.htm": {
		"emailActionSetting": "电子邮件动作设置",
		"email": "电子邮件",
		"action": "动作",
		"emailInformation": "电子邮件信息",
		"receiverEmail": "收件者电子邮件",
		"subject": "主旨",
		"content": "内文",
		"tip": {
			"email": "选择已设置之电子邮件。",
			"action": "发送所选择之电子邮件。"
		}
	},
	"html/desktop/home/rules/rule/acgi.htm": {
		"cgiCommandActionSetting": "CGI命令动作设置",
		"cgiCommand": "CGI命令",
		"server": "服务器",
		"command": "命令",
		"action": "动作",
		"tip": {
			"cgiCommand": "选择欲发送的CGI命令。",
			"action": "发送预先设置的CGI命令。"
		}
	},
	"html/desktop/home/rules/rule/atimer.htm": {
		"timerActionSetting": "定时器动作设置",
		"timer": "定时器",
		"action": "动作",
		"resetDescription": "重置代表将定时器归零并停止计时。",
		"startDescription": "启动代表将定时器开始(或重新)计时。",
		"pauseDescription": "暂停代表将定时器暂停计时。",
		"resumeDescription": "恢复代表将定时器恢复计时。",
		"tip": {
			"timer": "选择已设置之定时器。",
			"action": "变更所选择定时器之状态。"
		}
	},
	"html/desktop/home/rules/rule/aschedule.htm": {
		"scheduleActionSetting": "时间表动作设置",
		"schedule": "时间表",
		"action": "动作",
		"tip": {
			"schedule": "选择已设置之时间表。",
			"action": "变更所选择时间表之执行状态。"
		}
	},
	"html/desktop/home/rules/rule/arule.htm": {
		"ruleStatusActionSetting": "规则状态动作设置",
		"rule": "规则",
		"action": "动作",
		"tip": {
			"rule": "选择已设置之规则。",
			"action": "变更所选择规则之执行状态。"
		}
	},
	"html/desktop/home/rules/rule/aregister.htm": {
		"registerActionSetting": "内部缓存器动作设置",
		"no": "编号",
		"operator": "运算符",
		"value": "设置数值"
	},
	"html/desktop/home/rules/rule/alogger.htm": {
		"dataLoggerActionSetting": "数据记录器动作设置",
		"action": "动作",
		"tip": {
			"action": "变更数据记录器之状态為进行单次记录。"
		}
	},
	"html/desktop/home/rules/rule/asms.htm": {
		"smsAlarmActionSetting": "SMS简讯警报动作设置",
		"smsAlarm": "SMS简讯警报",
		"action": "动作",
		"send": "传送",
		"smsAlarmInformation": "SMS简讯警报信息",
		"phoneNumbers": "电话号码",
		"message": "讯息",
		"tip": {
			"smsAlarm": "选择欲发送的SMS简讯警报。",
			"action": "发送预先设置的SMS简讯警报。"
		}
	},
	"html/desktop/home/rules/rule/asnmp.htm": {
		"snmpTrapActionSetting": "SNMP Trap动作设置",
		"trap": "Trap",
		"action": "动作",
		"send": "传送",
		"snmpTrapInformation": "SNMP Trap信息",
		"message": "变数绑定",
		"tip": {
			"trap": "选择已设置之SNMP Trap。",
			"action": "发送所选择之SNMP Trap。",
			"message": "将发送的SNMP Trap变数绑定。"
		}
	},
	"html/desktop/home/rules/rule/air.htm": {
		"infraredActionSetting": "红外线动作设置",
		"commandAndChannel": "命令与通道",
		"command": "命令",
		"pressCtrlToMultipleSelect": "按住Ctrl可复选通道。",
		"tip": {
			"module": "选择模块。",
			"commandAndChannel": "设置发送的命令与输出通道。"
		},
		"popup": {
			"channelIsEmpty": "通道不能为空，请至少选择一个通道输出命令。"
		}
	},
	"html/desktop/home/rules/rule/aazurestatus.htm": {
		"azureFunctionStatusActionSetting": "Microsoft Azure功能状态动作设置",
		"status": "状态",
		"tip": {
			"status": "设置Microsoft Azure功能状态。"
		}
	},
	"html/desktop/home/rules/rule/abluemixstatus.htm": {
		"bluemixFunctionStatusActionSetting": "IBM Bluemix功能状态动作设置",
		"status": "状态",
		"tip": {
			"status": "设置IBM Bluemix功能状态。"
		}
	},
	"html/desktop/home/rules/rule/abroker.htm": {
		"mqttBrokerFunctionStatusActionSetting": "MQTT Broker功能状态动作设置",
		"status": "状态",
		"tip": {
			"broker": "选择已设置之Broker。",
			"status": "设置所选择Broker之状态。"
		}
	},
	"html/desktop/home/rules/rule/aazurepublish.htm": {
		"azurePublishMessageActionSetting": "Microsoft Azure发布讯息动作设置",
		"message": "讯息",
		"action": "动作",
		"publish": "发布",
		"azurePublishMessageInformation": "Microsoft Azure发布讯息信息",
		"content": "内容",
		"tip": {
			"message": "选择已设置之讯息。",
			"action": "发布所选择之讯息。",
			"content": "将发送的讯息内容。"
		}
	},
	"html/desktop/home/rules/rule/abluemixpublish.htm": {
		"bluemixPublishMessageActionSetting": "IBM Bluemix发布讯息动作设置",
		"message": "讯息",
		"action": "动作",
		"publish": "发布",
		"bluemixPublishMessageInformation": "IBM Bluemix发布讯息信息",
		"content": "内容",
		"tip": {
			"message": "选择已设置之讯息。",
			"action": "发布所选择之讯息。",
			"content": "将发送的讯息内容。"
		}
	},
	"html/desktop/home/rules/rule/amessage.htm": {
		"mqttPublishMessageActionSetting": "MQTT Publish信息动作设置",
		"message": "信息",
		"action": "动作",
		"publish": "发布",
		"mqttPublishMessageInformation": "MQTT Publish信息资讯",
		"content": "内容",
		"tip": {
			"message": "选择已设置之信息。",
			"action": "发布所选择之信息。",
			"topic": "欲发送讯息所属的Topic。",
			"content": "将发送的信息内容。"
		}
	},
	"html/desktop/home/rules/rule/alinenotify.htm": {
		"lineNotifyActionSetting": "LINE Notify动作设置",
		"message": "讯息",
		"action": "动作",
		"messageInformation": "讯息信息",
		"chatRoom": "聊天室",
		"content": "内容",
		"tip": {
			"message": "选择已设置之讯息。",
			"action": "发送所选择之讯息。"
		}
	},
	"html/desktop/home/status.htm": {
		"none": "无"
	},
	"html/desktop/home/status/menu.htm": {
		"internalRegister": "内部缓存器",
		"customizeStatus": "实时信息显示",
		"connecting": "联机中",
		"offline": "断线",
		"online": "联机",
		"other": "其他",
		"eventLogger": "事件记录器",
		"fileList": "档案清单"
	},
	"html/desktop/home/status/default.htm": {
		"internalRegister": "内部缓存器",
		"no": "编号",
		"channel": "通道",
		"address": "地址",
		"counter": "计数器:",
		"none": "无",
		"diCounterX": "DI计数器$channel",
		"internalRegisterX": "内部缓存器$no"
	},
	"html/desktop/home/status/event.htm": {
		"eventLogger": "事件记录器",
		"time": "时间",
		"type": "类型",
		"message": "讯息",
		"noEventLog": "无事件记录。"
	},
	"html/desktop/home/status/file.htm": {
		"fileList": "档案清单",
		"list": "清单",
		"thumbnail": "缩图",
		"reload": "重新整理",
		"fileName": "檔名",
		"fileSize": "档案大小",
		"time": "时间",
		"noFile": "无档案",
		"loading": "加载中..."
	}
});