var itemInformation = {
	"meterValue": [//array order decision local modbus table order and rule drop down list order
		{"tagName": "V",     "unit": "V",     "name": "<#Lang['?'].V>"},
		{"tagName": "I",     "unit": "A",     "name": "<#Lang['?'].I>"},
		{"tagName": "KW",    "unit": "kW",    "name": "<#Lang['?'].kW>"},
		{"tagName": "KVAR",  "unit": "kvar",  "name": "<#Lang['?'].kvar>"},
		{"tagName": "KVA",   "unit": "kVA",   "name": "<#Lang['?'].kVA>"},
		{"tagName": "PF",    "unit": "",      "name": "<#Lang['?'].PF>"},
		{"tagName": "KWH",   "unit": "kWh",   "name": "kWh"},
		{"tagName": "KVARH", "unit": "kvarh", "name": "kvarh"},
		{"tagName": "KVAH",  "unit": "kVAh",  "name": "kVAh"}
	],
	"statisticsValue": [
		{"tagName": "MCD",   "unit": "kW",    "name": "<#Lang['?'].actualDemand>"},
		{"tagName": "MPD",   "unit": "kW",    "name": "<#Lang['?'].forecastDemand>"},
		{"tagName": "MDH",   "unit": "kW",    "name": "<#Lang['?'].hourlyMaximumDemand>"},
		{"tagName": "MDD",   "unit": "kW",    "name": "<#Lang['?'].dailyMaximumDemand>"},
		{"tagName": "MDM",   "unit": "kW",    "name": "<#Lang['?'].monthlyMaximumDemand>"},
		{"tagName": "DTE",   "unit": "kWh",   "name": "<#Lang['?'].dailyAccumElectricity>"},
		{"tagName": "MTE",   "unit": "kWh",   "name": "<#Lang['?'].monthlyAccumElectricity>"},
		{"tagName": "YTE",   "unit": "kWh",   "name": "<#Lang['?'].yearlyAccumElectricity>"}
	]
};

var wiringTypeLanguageMappingTable = {
   	"0": "<#Lang['?'].wiringType['0']>",
   	"1": "<#Lang['?'].wiringType['1']>",
   	"2": "<#Lang['?'].wiringType['2']>",
   	"3": "<#Lang['?'].wiringType['3']>",
   	"4": "<#Lang['?'].wiringType['4']>",
   	"5": "<#Lang['?'].wiringType['5']>",
   	"6": "<#Lang['?'].wiringType['6']>",
	"7": "<#Lang['?'].wiringType['7']>",
	"8": "<#Lang['?'].wiringType['8']>"
};

var wiringModeLanguageMappingTable = {
   	 "0": "<#Lang['?'].wiringMode['0']>",
   	 "1": "<#Lang['?'].wiringMode['1']>",
   	 "2": "<#Lang['?'].wiringMode['2']>",
   	 "3": "<#Lang['?'].wiringMode['3']>",
   	 "4": "<#Lang['?'].wiringMode['4']>",
   	 "5": "<#Lang['?'].wiringMode['5']>"
};

var voltageModeLanguageMappingTable = {
   	 "0": "<#Lang['?'].voltageMode['0']>",
   	 "1": "<#Lang['?'].voltageMode['1']>",
   	 "2": "<#Lang['?'].voltageMode['2']>"
};

var phaseSequenceLanguageMappingTable = {
   	 "0": "<#Lang['?'].phaseSequence['0']>",
   	 "1": "<#Lang['?'].phaseSequence['1']>"
};

//overwrite
WISE.managers.moduleManager.totalIOModuleAmount = totalIOModuleAmount;
WISE.managers.moduleManager.totalExtendedModuleAmount = 32 - totalIOModuleAmount;
WISE.managers.moduleManager.totalExtendedBonusModuleAmount = totalExtendedBonusModuleAmount;//submeter quota
WISE.managers.moduleManager.moduleInfoModbusTableMaxLength = 50;//module info of power meter
delete WISE.managers.moduleManager.icpdasModule.remoteModuleInformation.tM;
delete WISE.managers.moduleManager.icpdasModule.remoteModuleInformation.LC;

WISE.managers.moduleManager._decodeXMLObject = WISE.managers.moduleManager.decodeXMLObject;
WISE.managers.moduleManager.decodeXMLObject = function(xmlDoc){
	this._decodeXMLObject(xmlDoc);

	var moduleManager = this;
	var processModuleToPowerMeterModule = function($xmlMODULE, module, type, manufacturer, modelName){
		moduleManager.modbusModule.initAllBlock(module);//downward compatibility to 1.0.4, maybe there are exist <RI> or <CO> in <MODULE> Tag
		module = moduleManager.modbusModule.createPowerMeterModule(type, manufacturer, modelName, module);
		if(module == null){return;}

		var $xmlMETER = $xmlMODULE.find("> METER");
		$.extend(true, module, {
			"powerMeter": {
				"isMainPowerMeter": $xmlMETER.attr("main") == "true" ? true : false
			}
		});

		//fill in loop or phase name
		var $xmlLOOPs = $xmlMETER.find("> LOOP");
		for(var i = 0; i < $xmlLOOPs.length; i++){
			var $xmlLOOP = $($xmlLOOPs[i]);
			var loop = parseInt($xmlLOOP.attr("idx"), 10);

			try{
				var item = module.powerMeter.channel[loop];
				item.name = $xmlLOOP.attr("nickname") || "";
				item.isSinglePhase = $xmlLOOP.attr("single") == "1" ? true : false;
			}
			catch(error){}

			var $xmlPHASEs = $xmlLOOP.find("> PHASE");
			for(var j = 0; j < $xmlPHASEs.length; j++){
				var $xmlPHASE = $($xmlPHASEs[j]);
				var phase = parseInt($xmlPHASE.attr("idx"), 10);

				try{
					var item = module.powerMeter.channel[loop][phase];
					item.name = $xmlPHASE.attr("nickname") || "";
				}
				catch(error){}
			}
		}

		if(module.powerMeter.phase == 1){//move 1-phase powermeter's phase name to loop
			for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
				module.powerMeter.channel[loop].name = module.powerMeter.channel[loop][0].name;
				module.powerMeter.channel[loop][0].name = "";
			}
		}

		//fill in I/O nickname and AO/DO power on value
		$xmlMETER.find("> IO > *").each(function(index){
			var tagName = $(this)[0].tagName;

			$(this).find("> CH").each(function(index){
				var channel = module.powerMeter.io[tagName][parseInt($(this).attr("idx"), 10)];
				if(typeof(channel) == "undefined"){return;}

				if($(this).attr("nickname")){
					channel.name = $(this).attr("nickname");
				}

				if(tagName == "DO" || tagName == "AO"){
					if($(this).attr("power_on")){
						channel.initial.value = parseInt($(this).attr("power_on"), 10);
					}
				}

				if(tagName == "DO"){
					if($(this).attr("back_off")){
						channel.advancedFunction = 2;
						channel.autoOFF = parseInt($(this).attr("back_off"), 10);
					}
					else if($(this).attr("di_map")){
						channel.advancedFunction = 3;
						channel.mappingDI = $(this).attr("di_map") == "1" ? true : false;
					}
					else{
						channel.advancedFunction = 0;
					}
				}
				else if(tagName == "AI"){
					if($(this).attr("deadband")){
						channel.deadband = parseFloat($(this).attr("deadband"), 10);
					}

					if($(this).attr("scale_max") && $(this).attr("scale_min")){
						channel.scale.max = parseFloat($(this).attr("scale_max"), 10);
						channel.scale.min = parseFloat($(this).attr("scale_min"), 10);
					}
				}
			});
		});

		//fill in CUSTOM_DATA nickname
		$xmlMETER.find("> CUSTOM_DATA > *").each(function(index){
			if($(this).attr("nickname")){
				var channel = module.powerMeter.customizedData[parseInt($(this).attr("idx"), 10)];
				if(typeof(channel) == "undefined"){return;}

				channel.name = $(this).attr("nickname");
			}
		});
	};

	var $xmlCOM = $(xmlDoc).find("WISE > COM");
	for(var i = 0; i < $xmlCOM.length; i++){
		var source = $($xmlCOM[i]).attr("idx");

		if($($xmlCOM[i]).attr("type") == "2"){//rtu
			var $xmlMODULEs = $($xmlCOM[i]).find("> MODULE");
			for(var j = 0; j < $xmlMODULEs.length; j++){
				var $xmlMODULE = $($xmlMODULEs[j]);

				var $xmlMETER = $xmlMODULE.find("> METER");
				if($xmlMETER.length > 0){
					var moduleIndex = parseInt($xmlMODULE.attr("idx"), 10) - 1;
					var module = this.pool.interfaces.comport[source].modules[moduleIndex];

					var manufacturer = $xmlMODULE.attr("meter_group");
					var modelName = $xmlMODULE.attr("meter_name");

					processModuleToPowerMeterModule($xmlMODULE, module, "rtu", manufacturer, modelName);
				}
			}
		}
	}

	var $xmlTCP = $(xmlDoc).find("WISE > TCP");
	for(var i = 0; i < $xmlTCP.length; i++){
		var source = 0;

		var $xmlMODULEs = $($xmlTCP[i]).find("> MODULE");
		for(var j = 0; j < $xmlMODULEs.length; j++){
			var $xmlMODULE = $($xmlMODULEs[j]);

			var $xmlMETER = $xmlMODULE.find("> METER");
			if($xmlMETER.length > 0){
				var moduleIndex = parseInt($xmlMODULE.attr("idx"), 10) - 1;
				var module = this.pool.interfaces.network[source].modules[moduleIndex];

				var manufacturer = $xmlMODULE.attr("meter_group");
				var modelName = $xmlMODULE.attr("meter_name");

				processModuleToPowerMeterModule($xmlMODULE, module, "tcp", manufacturer, modelName);
			}
		}
	}
};

WISE.getMainPowerMetersInfo = function(){
	var moduleManager = WISE.managers.moduleManager;
	var retArray = [];

	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.comport.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.comport[sourceIndex]) == "undefined" || moduleManager.pool.interfaces.comport[sourceIndex].type != "comport485"){continue;}

		if(moduleManager.pool.interfaces.comport[sourceIndex].protocol == "modbusRTU"){
			var modules = moduleManager.pool.interfaces.comport[sourceIndex].modules;

			for(var moduleIndex = 0; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined" || typeof(modules[moduleIndex].powerMeter) == "undefined"){continue;}

				if(modules[moduleIndex].powerMeter.isMainPowerMeter == true){
					retArray.push({
						"sourceType": "comport",
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex,
						"module": modules[moduleIndex]
					});
				}
			}
		}
	}

	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.network.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.network[sourceIndex]) == "undefined"){continue;}

		if(moduleManager.pool.interfaces.network[sourceIndex].protocol == "modbusTCP"){
			var modules = moduleManager.pool.interfaces.network[sourceIndex].modules;

			for(var moduleIndex = 0; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined" || typeof(modules[moduleIndex].powerMeter) == "undefined"){continue;}

				if(modules[moduleIndex].powerMeter.isMainPowerMeter == true){
					retArray.push({
						"sourceType": "network",
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex,
						"module": modules[moduleIndex]
					});
				}
			}
		}
	}

	return retArray;
};

//new
WISE.managers.moduleManager.modbusModule.createPowerMeterModule = function(type, manufacturer, modelName, module/*pass settings to create module*/){
	try{
		var powerMeterInformation = this.powerMeterInformation[{"rtu": "modbusRTU", "tcp": "modbusTCP"}[type]][manufacturer][modelName];
	}
	catch(error){
		var powerMeterInformation = null;
	}
	if(powerMeterInformation == null){return null;}

	if(typeof(module.key) == "undefined"){
		var module = this.createModule(module, type);
		module.scanInterval = 5;//move to settings
	}

	$.extend(true, module, {
		"extendedModule": "powerMeter",
		"powerMeter": {
			"modelName": modelName,
			"manufacturer": manufacturer,
			"pt": powerMeterInformation.pt,
			"ct": powerMeterInformation.ct,
			"wiringType": powerMeterInformation.wiringType,
			"wiringMode": powerMeterInformation.wiringMode,
			"voltageMode": powerMeterInformation.voltageMode,
			"phaseSequence": powerMeterInformation.phaseSequence,
			"switchable": powerMeterInformation.switchable,
			"resettable": powerMeterInformation.resettable,
			"phase": powerMeterInformation.phase,
			"loop": powerMeterInformation.loop,
			"io": powerMeterInformation.io,
			"channel": powerMeterInformation.channel,
			"customizedData": powerMeterInformation.customizedData,
			"format": powerMeterInformation.format
		}
	});

	module.CICB = {"blockArray":[], "remoteAddress":{}};
	module.COCB = {"blockArray":[], "remoteAddress":{}};
	module.RICB = {"blockArray":[], "remoteAddress":{}};
	module.ROCB = {"blockArray":[], "remoteAddress":{}};

	//add default block
	for(var dataModelIndex = 0, dataModelArray = ["CI", "CO", "RI", "RO"]; dataModelIndex < dataModelArray.length; dataModelIndex++){
		var dataModel = dataModelArray[dataModelIndex];

		for(i = 0; i < powerMeterInformation.modbusTable[dataModel].length; i++){
			this.addBlock(module, dataModel, 
				$.extend(true, dataModel == "RI" || dataModel == "RO" ? {
					"hexMin": "0000",
					"hexMax": "0000",
					"realMin": 0,
					"realMax": 0
				} : {}, powerMeterInformation.modbusTable[dataModel][i])
			);
		}

		dataModel = dataModel + "CB";
		for(i = 0; i < powerMeterInformation.modbusTable[dataModel].length; i++){
			this.addBlock(module, dataModel, 
				$.extend(true, dataModel == "RICB" || dataModel == "ROCB" ? {
					"hexMin": "0000",
					"hexMax": "0000",
					"realMin": 0,
					"realMax": 0
				} : {}, powerMeterInformation.modbusTable[dataModel][i])
			);
		}
	}

	//insert loop and phase info into remoteAddress
	for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
		for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
			for(var i = 0; i < module.powerMeter.channel[loop][phase].meterValue.length; i++){
				var item = module.powerMeter.channel[loop][phase].meterValue[i];
				if(typeof(item) == "undefined"){continue;}

				var dataModel = module.powerMeter.format[item.format].dataModel;
				module[dataModel].remoteAddress[item.address].type = "channel";
				module[dataModel].remoteAddress[item.address].loop = loop;
				module[dataModel].remoteAddress[item.address].phase = phase;
				module[dataModel].remoteAddress[item.address].itemID = item.itemID;
				module[dataModel].remoteAddress[item.address].itemType = "meterValue";
				module[dataModel].remoteAddress[item.address].itemIndex = item.itemIndex;
				module[dataModel].remoteAddress[item.address].unit = item.unit;
			}

			for(var i = 0; i < module.powerMeter.channel[loop][phase].statisticsValue.length; i++){
				var item = module.powerMeter.channel[loop][phase].statisticsValue[i];
				if(typeof(item) == "undefined"){continue;}

				module["RICB"].remoteAddress[item.address].type = "channel";
				module["RICB"].remoteAddress[item.address].loop = loop;
				module["RICB"].remoteAddress[item.address].phase = phase;
				module["RICB"].remoteAddress[item.address].itemID = item.itemID;
				module["RICB"].remoteAddress[item.address].itemType = "statisticsValue";
				module["RICB"].remoteAddress[item.address].itemIndex = item.itemIndex;
				module["RICB"].remoteAddress[item.address].unit = item.unit;
			}
		}
	}

	for(var typeIndex = 0, typeArray = ["DI", "DO", "AI", "AO"]; typeIndex < typeArray.length; typeIndex++){
		var type = typeArray[typeIndex];

		for(var i = 0; i < module.powerMeter.io[type].length; i++){
			var channel = module.powerMeter.io[type][i];
			var dataModel = module.powerMeter.format[channel.format].dataModel;
			module[dataModel].remoteAddress[channel.address].type = "io";
			module[dataModel].remoteAddress[channel.address].channelType = type;//io.DI, io,DO, io.AI, io.AO
			module[dataModel].remoteAddress[channel.address].channelIndex = i;
		}
	}

	for(var i = 0; i < module.powerMeter.customizedData.length; i++){
		var channel = module.powerMeter.customizedData[i];
		var dataModel = module.powerMeter.format[channel.format].dataModel;
		module[dataModel].remoteAddress[channel.address].type = "customizedData";
		module[dataModel].remoteAddress[channel.address].customizedDataIndex = i;
	}

	var createCustomizedDataRuleItem = WISE.managers.moduleManager.modbusModule.createPowerMeterModule.createCustomizedDataRuleItem;
	if(typeof(createCustomizedDataRuleItem) == "function"){
		createCustomizedDataRuleItem(module);
	}

	return module;
};

WISE.powerMeterModuleInfo = function(sourceType, sourceIndex, moduleIndex){
	var moduleInfo = "";
	var module = WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

	if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "comport485"){
		if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusRTU"){
			moduleInfo += module.powerMeter.modelName;
			moduleInfo += "(" + module.modbusRTU.address + ":" + module.name + ")";
		}
	}
	else if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].type == "network"){
		if(WISE.managers.moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusTCP"){
			moduleInfo += module.powerMeter.modelName;
			moduleInfo += "(" + integerToIP(module.modbusTCP.ip) + ":" + module.modbusTCP.port + "/" + module.modbusTCP.netID + ":" + module.name + ")";
		}
	}

	return {
		"toString": function(){
			return moduleInfo;
		},
		"name": module.name,
		"modelName": module.powerMeter.modelName,
		"module": module
	};
};

WISE.managers.moduleManager.processExtendedModuleSettingFile = function(xmlDocArray){
	//process power meter xml infomation
	if(typeof(WISE.managers.moduleManager.modbusModule.powerMeterInformation) == "undefined"){
		WISE.managers.moduleManager.modbusModule.powerMeterInformation = {
			"modbusRTU": {},
			"modbusTCP": {}
		};
	}

	for(var i = 0; i < xmlDocArray.length; i++){
		var $xmlPMC_METER = $(xmlDocArray[i]).find("> PMC_METER");
		if($xmlPMC_METER.length <= 0){
			return false;//not found meter profile
		}

		var powerMeterInformation = WISE.managers.moduleManager.modbusModule.powerMeterInformation[{"0": "modbusRTU", "1": "modbusTCP"}[$xmlPMC_METER.attr("module_type")]];

		if(typeof(powerMeterInformation[$xmlPMC_METER.attr("group")]) == "undefined"){
			powerMeterInformation[$xmlPMC_METER.attr("group")] = {};
		}

		var info = {
			"phase": parseInt($xmlPMC_METER.attr("phase"), 10),
			"loop": parseInt($xmlPMC_METER.attr("loop"), 10),
			"pt": (function(){
				var pt = [];

				var $xmlPTs = $xmlPMC_METER.find("> INFO > PT");
				for(var i = 0; i < $xmlPTs.length; i++){
					var $xmlPT = $($xmlPTs[i]);
					pt[$xmlPT.attr("idx")] = {
						//"value": "1",
						"range": {
							"min": parseFloat($xmlPT.attr("min")),
							"max": parseFloat($xmlPT.attr("max")),
						},
						"format": parseInt($xmlPT.attr("group"), 10),
						"editable": Boolean(parseInt($xmlPT.attr("write"), 10))
					};
				}

				return pt;
			})(),
			"ct": (function(){
				var ct = [];

				var $xmlCTs = $xmlPMC_METER.find("> INFO > CT");
				for(var i = 0; i < $xmlCTs.length; i++){
					var $xmlCT = $($xmlCTs[i]);
					ct[$xmlCT.attr("idx")] = {
						//"value": "1",
						"range": {
							"min": parseFloat($xmlCT.attr("min")),
							"max": parseFloat($xmlCT.attr("max")),
						},
						"format": parseInt($xmlCT.attr("group"), 10),
						"editable": Boolean(parseInt($xmlCT.attr("write"), 10))
					};
				}

				return ct;
			})(),
			"wiringType": (function(){
				var type = [];

				var $xmlWIRING_TYPEs = $xmlPMC_METER.find("> INFO > WIRING_TYPE");
				for(var i = 0; i < $xmlWIRING_TYPEs.length; i++){
					var $xmlWIRING_TYPE = $($xmlWIRING_TYPEs[i]);

					var option = {};
					var itemValue = $xmlWIRING_TYPE.attr("item_value");
					if(typeof(itemValue) != "undefined" && itemValue != ""){
						var itemNameArray = ($xmlWIRING_TYPE.attr("item_name") || "").split(",");
						var itemKeyArray = ($xmlWIRING_TYPE.attr("item_key") || "").split(",");

						var itemValueArray = itemValue.split(",");
						for(var j = 0; j < itemValueArray.length; j++){
							option[itemValueArray[j]] = {
								"name": wiringTypeLanguageMappingTable[itemKeyArray[j]] || itemNameArray[j] || "",
								"isHardwareControl": false
							}
						}
					}

					var itemHW = $xmlWIRING_TYPE.attr("item_hw");
					if(typeof(itemHW) != "undefined" && itemHW != ""){
						var itemHWArray = itemHW.split(",");
						for(var j = 0; j < itemHWArray.length; j++){
							option[itemHWArray[j]].isHardwareControl = true;
						}
					}

					type[parseInt($xmlWIRING_TYPE.attr("idx"), 10)] = {
						"option": option,
						"wiringMode": (function(){
							var index = parseInt($xmlWIRING_TYPE.attr("mode_idx"), 10);
							return isNaN(index) ? null : index;
						})()
					};
				}

				return type;
			})(),
			"wiringMode": (function(){
				var mode = [];

				var $xmlWIRING_MODEs = $xmlPMC_METER.find("> INFO > WIRING_MODE");
				for(var i = 0; i < $xmlWIRING_MODEs.length; i++){
					var $xmlWIRING_MODE = $($xmlWIRING_MODEs[i]);

					var option = {};
					var itemValue = $xmlWIRING_MODE.attr("item_value");
					if(typeof(itemValue) != "undefined" && itemValue != ""){
						var itemNameArray = ($xmlWIRING_MODE.attr("item_name") || "").split(",");
						var itemKeyArray = ($xmlWIRING_MODE.attr("item_key") || "").split(",");

						var itemValueArray = itemValue.split(",");
						for(var j = 0; j < itemValueArray.length; j++){
							option[itemValueArray[j]] = {
								"name": wiringModeLanguageMappingTable[itemKeyArray[j]] || itemNameArray[j] || ""
							}
						}
					}

					mode[parseInt($xmlWIRING_MODE.attr("idx"), 10)] = {
						"option": option
					};
				}

				return mode;
			})(),
			"voltageMode": (function(){
				var mode = [];

				var $xmlDISPLAY_VOLTAGEs = $xmlPMC_METER.find("> INFO > DISPLAY_VOLTAGE");
				for(var i = 0; i < $xmlDISPLAY_VOLTAGEs.length; i++){
					var $xmlDISPLAY_VOLTAGE = $($xmlDISPLAY_VOLTAGEs[i]);

					var option = {};
					var itemValue = $xmlDISPLAY_VOLTAGE.attr("item_value");
					if(typeof(itemValue) != "undefined" && itemValue != ""){
						var itemNameArray = ($xmlDISPLAY_VOLTAGE.attr("item_name") || "").split(",");
						var itemKeyArray = ($xmlDISPLAY_VOLTAGE.attr("item_key") || "").split(",");

						var itemValueArray = itemValue.split(",");
						for(var j = 0; j < itemValueArray.length; j++){
							option[itemValueArray[j]] = {
								"name": voltageModeLanguageMappingTable[itemKeyArray[j]] || itemNameArray[j] || ""
							}
						}
					}

					mode[parseInt($xmlDISPLAY_VOLTAGE.attr("idx"), 10)] = {
						"option": option
					};
				}

				return mode;
			})(),
			"phaseSequence": (function(){
				var sequence = [];

				var $xmlPHASE_SEQUENCEs = $xmlPMC_METER.find("> INFO > PHASE_SEQUENCE");
				for(var i = 0; i < $xmlPHASE_SEQUENCEs.length; i++){
					var $xmlPHASE_SEQUENCE = $($xmlPHASE_SEQUENCEs[i]);

					var option = {};
					var itemValue = $xmlPHASE_SEQUENCE.attr("item_value");
					if(typeof(itemValue) != "undefined" && itemValue != ""){
						var itemNameArray = ($xmlPHASE_SEQUENCE.attr("item_name") || "").split(",");
						var itemKeyArray = ($xmlPHASE_SEQUENCE.attr("item_key") || "").split(",");

						var itemValueArray = itemValue.split(",");
						for(var j = 0; j < itemValueArray.length; j++){
							option[itemValueArray[j]] = {
								"name": phaseSequenceLanguageMappingTable[itemKeyArray[j]] || itemNameArray[j] || ""
							}
						}
					}

					sequence[parseInt($xmlPHASE_SEQUENCE.attr("idx"), 10)] = {
						"option": option
					};
				}

				return sequence;
			})(),
			"resettable": (function(){
				var $xmlRESETs = $xmlPMC_METER.find("> INFO > RESET").not("[note]");
				if($xmlRESETs.length > 0){
					return true;
				}
				else{
					return false;
				}
			})(),
			"modbusTable": (function(){
				var modbusTable = {"CI": [], "CO": [], "RI": [], "RO": [], "CICB": [], "COCB": [], "RICB": [], "ROCB": []};

				var $xmlBLOCKs = $xmlPMC_METER.find("> MODBUS > POLL > *");
				for(var i = 0; i < $xmlBLOCKs.length; i++){
					var $xmlBLOCK = $($xmlBLOCKs[i]);
					var settings = {
						"disable": true,
						"startAddress": parseInt($xmlBLOCK.attr("start_add"), 10),
						//"length": parseInt($xmlBLOCK.attr("len"), 10) / (parseInt($xmlBLOCK.attr("type"), 10) > 2 ? 2 : 1)
						"length": parseInt($xmlBLOCK.attr("len"), 10)
					};

					if($xmlBLOCK[0].tagName == "CI" || $xmlBLOCK[0].tagName == "CO" ||  $xmlBLOCK[0].tagName == "RI" || $xmlBLOCK[0].tagName == "RO"){
						settings.disable = true;
					}
					else{
						settings.startAddressForRule = settings.startAddress;
						settings.startAddress = 0;
					}

					if($xmlBLOCK[0].tagName == "RI" || $xmlBLOCK[0].tagName == "RO" || $xmlBLOCK[0].tagName == "RICB" || $xmlBLOCK[0].tagName == "ROCB"){
						//settings.type = parseInt($xmlBLOCK.attr("type"), 10);
						settings.type = 0;//make all register can be use
/*
						settings.scaleRatio = parseFloat($xmlBLOCK.attr("ratio"));
						settings.offset = parseFloat($xmlBLOCK.attr("offset"));
						settings.deadband = parseFloat($xmlBLOCK.attr("deadband"));

						if(settings.type == 2){
							settings.hexMin = $xmlBLOCK.attr("hex_min");
							settings.hexMax = $xmlBLOCK.attr("hex_max");
							settings.realMin = parseFloat($xmlBLOCK.attr("real_min"));
							settings.realMax = parseFloat($xmlBLOCK.attr("real_max"));
						}
						else{
							settings.hexMin = settings.hexMax = "0000";
							settings.realMin = settings.realMax = 0;
						}
*/
					}

					modbusTable[$xmlBLOCK[0].tagName].push(settings);
				}

				return modbusTable;
			})(),
			"switchable": $xmlPMC_METER.attr("switchable") == "1" ? true : false,
			"channel": (function(){
				var totalLoop = parseInt($xmlPMC_METER.attr("loop"), 10);
				var totalPhase = parseInt($xmlPMC_METER.attr("phase"), 10);
				var channel = [];

				for(var loop = 0; loop < totalLoop; loop++){
					channel[loop] = [];
					channel[loop].name = "";//variable
					if(totalPhase == 3){
						channel[loop].isSinglePhase = false;//determine the view is display in single phase or three phase
					}

					var $xmlLOOP = $xmlPMC_METER.find("> LOOP[idx='" + loop + "']");
					channel[loop].resettable = $xmlLOOP.attr("reset_idx") || false;

					for(var phase = 0; phase < (totalPhase == 3 ? 4 : totalPhase); phase++){
						channel[loop][phase] = {
							"name": "",//variable
							"meterValue": [],
							"statisticsValue": []
						};

						var $xmlPHASE = $xmlLOOP.find("> PHASE[idx='" + phase + "']");
						var $xmlTYPEs = $xmlPHASE.children();
						for(var type = 0; type < $xmlTYPEs.length; type++){
							var $xmlTYPE = $($xmlTYPEs[type]);
							var tagName = $xmlTYPEs[type].tagName;
							var itemIndex, unit; 

							for(var i = 0; i < itemInformation.meterValue.length; i++){
								if(itemInformation.meterValue[i].tagName == tagName){
									unit = itemInformation.meterValue[i].unit;
									itemIndex = i;
									break;
								}
							}

							channel[loop][phase].meterValue[itemIndex] = {
								"address": parseInt($xmlTYPE.attr("add"), 10),
								"format": parseInt($xmlTYPE.attr("group"), 10),
								"unit": unit,
								"itemID": tagName,
								"itemIndex": itemIndex
							};
						}

						if($xmlPHASE.attr("statistics") == "1" && $xmlPHASE.attr("statistics_add")){
							for(var i = 0; i < itemInformation.statisticsValue.length; i++){
								channel[loop][phase].statisticsValue[i] = {
									"address": parseInt($xmlPHASE.attr("statistics_add"), 10) + i * 2,
									"format": -1,
									"unit": itemInformation.statisticsValue[i].unit,
									"itemID": itemInformation.statisticsValue[i].tagName,
									"itemIndex": i
								};
							}
						}

					}
				}

				return channel;
			})(),
			"io": (function(){
				var io = {};

				for(var typeIndex = 0, typeArray = ["DI", "DO", "AI", "AO"]; typeIndex < typeArray.length; typeIndex++){
					var type = typeArray[typeIndex];

					io[type] = (function(){
						var channel = [];

						var $xmlTYPEs = $xmlPMC_METER.find("> IO > " + type);
						for(var i = 0; i < $xmlTYPEs.length; i++){
							var $xmlTYPE = $($xmlTYPEs[i]);
							var $xmlPOWERON = $xmlTYPE.find("> POWER_ON");

							var ioSettings = {
								"name": "",//variable
								"address": parseInt($xmlTYPE.attr("add"), 10),
								"format": parseInt($xmlTYPE.attr("group"), 10),
								"initial": null
							};

							if((type == "DO" || type == "AO") && $xmlPOWERON.length > 0){
								ioSettings.initial = {
									"value": 0,
									"address": parseInt($xmlPOWERON.attr("add"), 10),
									"format": parseInt($xmlPOWERON.attr("group"), 10),
								};
							}

							if(type == "DO"){
								ioSettings.advancedFunction = 0;
								ioSettings.autoOFF = 1;
								ioSettings.mappingDI = false;
							}
							else if(type == "AI"){
								ioSettings.deadband = 0;
								//ioSettings.offset = 0;
								ioSettings.scale = {
									max: 0,
									min: 0
								};
							}

							channel[parseInt($xmlTYPE.attr("idx"), 10)] = ioSettings;
						}

						return channel;
					})();
				}

				return io;
			})(),
			"customizedData": (function(){
				var customizedData = [];

				var $xmlCDs = $xmlPMC_METER.find("> CUSTOM_DATA > *");
				for(var i = 0; i < $xmlCDs.length; i++){
					var $xmlCD = $($xmlCDs[i]);

					customizedData[parseInt($xmlCD.attr("idx"), 10)] = {
						"name": "",//variable
						"ruleName": $xmlCD.attr("name"),
						"groupName": $xmlCD.attr("team"),
						"itemName": $xmlCD.attr("subname"),
						"address": parseInt($xmlCD.attr("add"), 10),
						"format": parseInt($xmlCD.attr("group"), 10)
					};
				}

				customizedData.CI = {};
				customizedData.CO = {};
				customizedData.RI = {};
				customizedData.RO = {};

				return customizedData;
			})(),
			"format": (function(){
				var format = [];

				var $xmlGROUPs = $xmlPMC_METER.find("> FORMAT_GROUP > GROUP");
				for(var i = 0; i < $xmlGROUPs.length; i++){
					var $xmlGROUP = $($xmlGROUPs[i]);

					format[parseInt($xmlGROUP.attr("idx"), 10)] = $.extend(true, {
						"dataModel": {"0": "CO", "1": "CI", "3": "RI", "4": "RO"}[$xmlGROUP.attr("device_add_type")],
						"transform": Boolean(parseInt($xmlGROUP.attr("formula"), 10)),
						"formula": [],//not implemented yet
						"local": {//local modbus table(put the value from device)
							"dataModel": {"0": "CO", "1": "CI", "3": "RI", "4": "RO"}[$xmlGROUP.attr("local_add_type") || $xmlGROUP.attr("device_add_type")]
						}
					}, $xmlGROUP.attr("device_add_type") == "3" || $xmlGROUP.attr("device_add_type") == "4" ? {
						"type": parseInt($xmlGROUP.attr("device_data_type"), 10),
						"scaleRatio": parseFloat($xmlGROUP.attr("ratio") || 1),
						"offset": parseFloat($xmlGROUP.attr("offset") || 0),
						"hexMin": $xmlGROUP.attr("hex_min") || "0000",
						"hexMax": $xmlGROUP.attr("hex_max") || "0000",
						"realMin": parseFloat($xmlGROUP.attr("real_min") || 0),
						"realMax": parseFloat($xmlGROUP.attr("real_max") || 0),
						"local": {//local modbus table(put the value from device)
							"type": parseInt($xmlGROUP.attr("local_data_type") || $xmlGROUP.attr("device_data_type"), 10)
						}
					} : null);
				}

				format[-1] = {//special for statistics value
					"dataModel": "RICB",
					"transform": "0",
					"formula": [],
					"type": 5,
					"scaleRatio": 1,
					"offset": 0,
					"hexMin": "0000",
					"hexMax": "0000",
					"realMin": 0,
					"realMax": 0,
					"local": {
						"dataModel": "RI",
						"type": 5
					}
				};

				return format;
			})()
		};

		for(var channelIndex = 0; channelIndex < info.customizedData.length; channelIndex++){
			var channel = info.customizedData[channelIndex];
			var dataModel = info.format[channel.format].dataModel;

			if(typeof(info.customizedData[dataModel][channel.ruleName]) == "undefined"){
				info.customizedData[dataModel][channel.ruleName] = {};
			}

			if(typeof(info.customizedData[dataModel][channel.ruleName][channel.groupName || ""]) == "undefined"){
				info.customizedData[dataModel][channel.ruleName][channel.groupName || ""] = [];
			}

			channel.channelIndex = (info.customizedData[dataModel][channel.ruleName][channel.groupName || ""].push(channelIndex)) - 1;
		}

		powerMeterInformation[$xmlPMC_METER.attr("group")][$xmlPMC_METER.attr("name")] = info;
	}

	return true;
}
