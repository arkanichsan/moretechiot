WISE.managers.lineNotifyManager.encodeXMLObject = function(xmlDoc){
	var xmlLINE_NOTIFY = xmlDoc.createElement("LINE_NOTIFY");

	// Message
	var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

	for(var key in this.pool.messages){
		var message = this.pool.messages[key];
		var xmlM = xmlDoc.createElement("M");

		xmlM.setAttribute("idx", message.index);
		xmlM.setAttribute("nickname", message.name);

		if(message.description != ""){
			xmlM.setAttribute("desc", message.description);
		}

		var chatRooms = [];
		for(var i = 0; i < message.chatRooms.length; i++){
			var key = message.chatRooms[i];

			if(typeof(this.pool.chatRooms[key]) != "undefined"){
				chatRooms.push(this.pool.chatRooms[key].index);
			}
		}
		xmlM.setAttribute("target_token", chatRooms.join(","));

		xmlM.appendChild(xmlDoc.createTextNode(message.content));

		xmlMESSAGE.appendChild(xmlM);
	}

	if(xmlMESSAGE.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlMESSAGE);
	}

	// Chat Room
	var xmlTOKEN = xmlDoc.createElement("TOKEN");

	for(var key in this.pool.chatRooms){
		var chatRoom = this.pool.chatRooms[key];
		var xmlT = xmlDoc.createElement("T");

		xmlT.setAttribute("idx", chatRoom.index);
		xmlT.setAttribute("nickname", chatRoom.name);

		if(chatRoom.description != ""){
			xmlT.setAttribute("desc", chatRoom.description);
		}

		xmlT.setAttribute("token", chatRoom.token);
		xmlT.setAttribute("type", chatRoom.type);

		xmlTOKEN.appendChild(xmlT);
	}

	if(xmlTOKEN.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlTOKEN);
	}

	// 
	if(xmlLINE_NOTIFY.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_NOTIFY);
				break;
			}
		}
	}
};

WISE.managers.lineNotifyManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}

	index = 0;
	for(var key in this.pool.chatRooms){
		this.pool.chatRooms[key].index = ++index;
	}
};