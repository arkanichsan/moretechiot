function RTUinit()
{
	RTUDataType = ["Int16","UInt16","Float","Int32","UInt32","Float"];
	RTURange = ["-32768~32767 "," 0~65535",,"-2147483648 ~2147483647" ,"0~4294967295","Floating Point"];
	RTUtypeArray = ["CO" , "CI" , "RI" , "RO"];
}
function InserRTUTable(TableObj){
	RTUinit();
	var html_str ='';
	html_str += InserDataInfoTable("RTU");
	for(var type in RTUtypeArray)
	{
		var StartAddress;//IO StartAddress
		AddAddress = 0;//PMC Address
		if(typeCount[typeArray[type]] >0)
		{
			html_str += InserTableTitle(TypeTitle[typeArray[type]]);
			if(typeArray[type] == "AI" || typeArray[type] == "AO")
				for(var i = 0 ; i < SelectInfo[RTUtypeArray[type]].blockArray.length ; i++)
				{
					AddParamterAddress = 0;
					LengthType = 1;
					if(SelectInfo[RTUtypeArray[type]].blockArray[i].type >= 2||SelectInfo[RTUtypeArray[type]].blockArray[i].scaleRatio != 1 || SelectInfo[RTUtypeArray[type]].blockArray[i].offset != 0)
						LengthType = 2;
					StartAddress=SelectInfo[RTUtypeArray[type]].blockArray[i].startAddress;
					for(var j = 0 ; j < SelectInfo[RTUtypeArray[type]].blockArray[i].length ; j++ )
					{
						html_str += '<tr>';
						if(SelectInfo[RTUtypeArray[type]].blockArray[i].name[j] !="")
							html_str += '<td  style="word-break:break-all;">' + padLeft((StartAddress+AddParamterAddress).toString(),padLeft_num) + '('+SelectInfo[RTUtypeArray[type]].blockArray[i].name[j]+')</td>';
						else
							html_str += '<td>' + padLeft((StartAddress+AddParamterAddress).toString(),padLeft_num) + '</td>';
							
						html_str += '<td>' +  padLeft((SA + AddAddress+ModbusAddress[typeArray[type]]).toString(), padLeft_num)  + '</td>';
						html_str += '<td>' +  LengthType + '</td>';	
						if(SelectInfo[RTUtypeArray[type]].blockArray[i].scaleRatio != 1 || SelectInfo[RTUtypeArray[type]].blockArray[i].offset != 0)
						{
							html_str += '<td>Float</td>';
							html_str += '<td>Floating Point</td>';
						}
						else
						{
							html_str += '<td>' + RTUDataType[SelectInfo[RTUtypeArray[type]].blockArray[i].type] + '</td>'
							if(SelectInfo[RTUtypeArray[type]].blockArray[i].type != 2)
								html_str += '<td>' + RTURange[SelectInfo[RTUtypeArray[type]].blockArray[i].type] + '</td>'
							else
								html_str +=  '<td>' + SelectInfo[RTUtypeArray[type]].blockArray[i].realMin + '~' + SelectInfo[RTUtypeArray[type]].blockArray[i].realMax + '</td>';
						}
						html_str += '</tr>';
						if(SelectInfo[RTUtypeArray[type]].blockArray[i].type<=2)
							AddParamterAddress += 1;
						else
							AddParamterAddress += LengthType;
						AddAddress += LengthType;
					}
				}
			else
				for(var DataAddress in SelectInfo[RTUtypeArray[type]].remoteAddress)
				{
					html_str += '<tr>';
					if(SelectInfo[RTUtypeArray[type]].remoteAddress[DataAddress].name != "" )
						html_str += '<td  style="word-break:break-all;">' + padLeft(DataAddress,padLeft_num) +'('+ SelectInfo[RTUtypeArray[type]].remoteAddress[DataAddress].name + ')' + '</td>';
					else
						html_str += '<td>' +  padLeft(DataAddress,padLeft_num) + '</td>';
					html_str += '<td>' +  padLeft((SA + AddAddress+ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
					html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
					html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
					html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
					html_str += '</tr>';
					AddAddress += AddressBit[typeArray[type]];
				}
			html_str += '</table>';
			html_str += '<div><br /></div>';
		}
	}
	TableObj.html(html_str);
}