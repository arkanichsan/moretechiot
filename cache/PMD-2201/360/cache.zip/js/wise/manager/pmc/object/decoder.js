WISE.managers.pmcManager.decodeXMLObject = function(xmlDoc){
	var $xmlPMC = $(xmlDoc).find("WISE > PMC");
	if($xmlPMC.length > 0){
/*
		var $xmlDATALOG = $xmlPMC.find("> DATALOG:first");
		if($xmlDATALOG.length > 0){
			this.pool.dataLog.enable = true;
			this.pool.dataLog.rate = parseInt($xmlDATALOG.attr("rate"), 10);
			this.pool.dataLog.mode = parseInt($xmlDATALOG.attr("mode"), 10);
			this.pool.dataLog.fileNameFormat = parseInt($xmlDATALOG.attr("filename_format"), 10);
			this.pool.dataLog.eof = parseInt($xmlDATALOG.attr("eof"), 10);
			this.pool.dataLog.prependHeader = $xmlDATALOG.attr("header") == "1" ? true : false;
			this.pool.dataLog.keepTime = parseInt($xmlDATALOG.attr("keep_time"), 10);
			this.pool.dataLog.upload = {
				enable: $xmlDATALOG.attr("upload") == "1" ? true : false,
				period: parseInt($xmlDATALOG.attr("upload_period"), 10)
			};
		}

		var $EVENTLOG = $xmlPMC.find("> EVENTLOG:first");
		if($EVENTLOG.length > 0){
			this.pool.eventLog.keepTime = parseInt($EVENTLOG.attr("keep_time"), 10);
			this.pool.eventLog.upload = {
				enable: $EVENTLOG.attr("upload") == "1" ? true : false,
				period: parseInt($EVENTLOG.attr("upload_period"), 10)
			};
		}

		var $xmlFTP = $xmlPMC.find("> FTP:first");
		if($xmlFTP.length > 0){
			this.pool.ftp.enable = true;
			this.pool.ftp.url = $xmlFTP.attr("url");
			this.pool.ftp.port = parseInt($xmlFTP.attr("port"), 10);
			this.pool.ftp.id = $xmlFTP.attr("id");
			this.pool.ftp.password = (function(password, passwordLength){
				return {
					plain: padding("", passwordLength, "*"),
					encoded: password,
					length: passwordLength
				};
			})($xmlFTP.attr("password"), parseInt($xmlFTP.attr("password_len"), 10));
		}
*/
		var $xmlCONTRACTCAPACITY = $xmlPMC.find("> CONTRACTCAPACITY:first");
		if($xmlCONTRACTCAPACITY.length > 0){
			this.pool.contractCapacity.enable = true;
			this.pool.contractCapacity.capacity = parseInt($xmlCONTRACTCAPACITY.attr("capacity"), 10);
		}

		var $xmlDEMAND = $xmlPMC.find("> DEMAND:first");
		if($xmlDEMAND.length > 0){
			this.pool.demand.interval = parseInt($xmlDEMAND.attr("interval"), 10);
			if(typeof($xmlDEMAND.attr("unit"))!="undefined")
				this.pool.demand.unit = $xmlDEMAND.attr("unit");
		}

		var $xmlCARBONFOOTPRINT = $xmlPMC.find("> CARBONFOOTPRINT:first");
		if($xmlCARBONFOOTPRINT.length > 0){
			this.pool.carbonFootprint.factor = parseFloat($xmlCARBONFOOTPRINT.attr("factor"));
		}
		
		var $xmlGROUPS = $xmlPMC.find("> GROUPS:first");
		do_xml_node(this.pool.groups , $xmlGROUPS) ;
	}
};

function do_xml_node( obj , xmlDoc )
{
	if( xmlDoc.attr("node") == "node" )
	{
		obj.name = xmlDoc.attr("name");
		obj.node = "node" ;
		obj.level =Number( xmlDoc.attr("level"));
		obj.index = Number(xmlDoc.attr("index"));
		obj.UID = xmlDoc.attr("UID");
		obj.parent_UID = xmlDoc.attr("parent_UID");
		obj.child = new Array() ;
		obj.indent = true;
		
		if( xmlDoc.children().length > 0 )
		{
			for( var i = 0 ; i < xmlDoc.children().length ; i++ )
			{
				var port = "comport" ;
				if( $(xmlDoc.children()[i]).attr("type") == "TCP" )
					port = "network" ;
				if(obj.level == 2 && typeof(WISE.managers.moduleManager.pool.interfaces[port][$(xmlDoc.children()[i]).attr("com")].modules[$(xmlDoc.children()[i]).attr("modules")-1]) == "undefined")
					continue;
				obj.child[i] = new Object();
				do_xml_node(obj.child[i] , $(xmlDoc.children()[i]) ) ;
			}
			for (var i=0; i < obj.child.length; i++) {
				if ( obj.child[i] == undefined ) {
					obj.child.splice(i,1);
					i--;
				}
			}
		}
		else return ; 
	}	
	
	if( xmlDoc.attr("node") == "leaf" )
	{
		obj.name = xmlDoc.attr("name");
		obj.pm_name = xmlDoc.attr("pm_name");
		obj.loop_name = xmlDoc.attr("loop_name");
		obj.channel_name = xmlDoc.attr("channel_name");
		obj.node = "leaf" ;
		obj.level = Number(xmlDoc.attr("level"));
		obj.index = Number(xmlDoc.attr("index"));
		obj.type = xmlDoc.attr("type");
		obj.modules = Number(xmlDoc.attr("modules"));
		obj.com = Number(xmlDoc.attr("com"));
		obj.ch = Number(xmlDoc.attr("ch"));
		obj.UID = xmlDoc.attr("UID");
		obj.parent_UID = xmlDoc.attr("parent_UID");
		obj.child = new Array() ;
		
		var port = "comport" ;
		if(obj.type == "TCP" )port = "network" ;
		var set_info = WISE.managers.moduleManager.pool.interfaces ;
		obj.key =set_info[port][obj.com].modules[Number(obj.modules)-1].key ;
		
		return ;
	}
	return ;
}
