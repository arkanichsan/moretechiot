$.extend(true, Lang, {
	"js/wise/manager/module/base.js": {
		"humidity": "相對濕度",
		"celsiusTemperature": "溫度(°C)",
		"fahrenheitTemperature": "溫度(°F)",
		"celsiusDewPointTemperature": "露點溫度(°C)",
		"fahrenheitDewPointTemperature": "露點溫度(°F)",
		"ambientLight": "環境光",
		"particleCount": "微粒數"
	},
	"js/wise/manager/module/rule/object.js": {
		"icpdasModule": "泓格模組",
		"modbusModule": "Modbus模組",
		"diCounter": "DI計數器",
		"onToOFF": "ON至OFF",
		"offToON": "OFF至ON",
		"statusChange": "狀態改變",
		"change": "變動",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息",
		"reset": "重置",
		"connectionStatus": "連線狀態",
		"online": "連線",
		"offline": "斷線",
		"pulseOutput": "脈衝輸出",
		"infrared": "紅外線",
		"ch": "通道",
		"transmitCommand": "發送命令"
	}
});