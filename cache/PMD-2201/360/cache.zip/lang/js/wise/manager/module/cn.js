$.extend(true, Lang, {
	"js/wise/manager/module/base.js": {
		"humidity": "相对湿度",
		"celsiusTemperature": "温度(°C)",
		"fahrenheitTemperature": "温度(°F)",
		"celsiusDewPointTemperature": "露点温度(°C)",
		"fahrenheitDewPointTemperature": "露点温度(°F)",
		"ambientLight": "环境光",
		"particleCount": "微粒数"
	},
	"js/wise/manager/module/rule/object.js": {
		"icpdasModule": "泓格模块",
		"modbusModule": "Modbus模块",
		"diCounter": "DI计数器",
		"onToOFF": "ON至OFF",
		"offToON": "OFF至ON",
		"statusChange": "状态改变",
		"change": "变动",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息",
		"reset": "重置",
		"connectionStatus": "联机状态",
		"online": "联机",
		"offline": "断线",
		"pulseOutput": "脉冲输出",
		"infrared": "红外线",
		"ch": "通道",
		"transmitCommand": "发送命令"
	}
});
