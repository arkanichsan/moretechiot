$.extend(true, Lang, {
	"html/desktop/frame.htm": {
		"resetRule": "清除設定",
		"loadRule": "讀取設定",
		"saveRule": "寫入設定",
		"logout": "登出",
		"freeSpaceOnSDCard": "microSD卡剩餘空間。",
		"batteryStatus": "電池狀態",
		"enterPasswordToContinue": "請輸入密碼以繼續操作...",
		"enterPasswordBelow": "您閒置過久，如果您要繼續編輯，請在下方輸入密碼：",
		"password": "密碼:",
		"login": "登入"
	},
	"html/desktop/home.htm": {
		"saveAndLogout": "寫入並登出",
		"logout": "登出",
		"popup": {
			"pleaseWaitAFewSeconds": "請稍候幾秒鐘。",
			"pleaseWaitAFewSecondsAndDontCloseWindow": "請稍候幾秒鐘。在此過程中請勿關閉視窗。",
			"clearSuccess": "清除成功。",
			"loadSuccess": "讀取成功。",
			"loadFailed": "讀取失敗。",
			"saveFailed": "儲存失敗。",
			"systemInitializing": "系統正在初始化中，請稍後再試。",
			"saveBeforeLogout": "您是否要在登出前寫入設定？"
		}
	},
	"html/desktop/home/menu.htm": {
		"mainPage": "主頁面",
		"systemSetting": "系統參數設定",
		"moduleSetting": "模組設定",
		"loggerSetting": "記錄器設定",
		"iotSetting": "IoT平台設定",
		"advancedSetting": "進階功能設定",
		"rulesSetting": "邏輯規則設定",
		"channelStatus": "即時資訊顯示",
		"sendToX": "傳送至聊天室$name",
		"sendToXChatRoom": "傳送至$length個聊天室",
		"noSendToAnyChatRoom": "不傳送至任何一個聊天室",
		"oneOnOne": "1對1",
		"group": "群組"
	},
	"html/desktop/home/system.htm": {
		"systemSettingPage": "系統參數設定頁面",
		"dateAndTime": "日期與時間",
		"timeSynchronization": "時間校時",
		"port": "連接埠",
		"ddns": "動態網域名稱系統(DDNS)",
		"connectionStatus": "連線狀態",
		"status": "狀態",
		"connectionInformation": "連線資訊",
		"noSIMCardDetected": "未偵測到SIM卡",
		"modemError": "數據機錯誤",
		"connected": "已連線",
		"disconnected": "已斷線",
		"connecting": "連線中...",
		"disconnect": "斷線",
		"connect": "連線",
		"cancel": "取消",
		"signalStrength": "訊號強度",
		"cloudManagerSystem": "雲端管理系統",
		"localFTPServer": "本機FTP伺服器",
		"firmwareUpdateSetting": "韌體更新設定",
		"systemInformation": "系統資訊",
		"serialNumber": "序號",
		"firmwareInformation": "韌體資訊",
		"currentVersion": "目前版本",
		"availableVersion": "最新版本",
		"check": "檢查",
		"newFirmwareRelease": "有新的韌體(版本: $version)發佈。",
		"checkFailed": "檢查失敗。",
		"firmwareUpdate": "韌體更新",
		"firmware": "韌體",
		"browse": "瀏覽...",
		"update": "更新",
		"exportImportSettings": "匯出 / 匯入設定",
		"exportSettings": "匯出設定",
		"exportSettingsToFile": "匯出控制器設定至檔案上。",
		"export": "匯出",
		"exportingPleaseWait": "匯出中，請稍後...",
		"importSettings": "匯入設定",
		"importSettingsFromFile": "從檔案匯入設定至控制器。",
		"import": "匯入",
		"importingPleaseWait": "匯入中，請稍後...",
		"popup": {
			"doNotColseThisWindow": "請勿關閉或離開此頁面",
			"selectFirmwareToUpload": "請選擇一個韌體檔案上傳。",
			"areYouSureYouWantToUpdateFirmware": "您確定要更新韌體？所有尚未儲存的設定在更新韌體後將會消失。",
			"areYouSureYouWantToLeave": "韌體正在更新中，離開此頁面可能會導致韌體失敗，您確定是否要離開此頁面？",
			"firmwareUploading": "韌體上傳中...",
			"firmwareUploadFailedUploadTimeout": "韌體上傳失敗，韌體上傳時間過長，建議從與控制器同一個區域網路內的電腦上傳韌體。",
			"firmwareUpdating": "韌體更新中...",
			"firmwareUpdateFailedFirmwareIsIncorrect": "韌體更新失敗，韌體檔案不正確。",
			"firmwareUpdateFailedNotEnoughDiskSpace": "韌體更新失敗，磁碟空間不足。",
			"firmwareUpdateFailedUnzipError": "韌體更新失敗，解壓縮韌體檔案失敗。",
			"firmwareUpdateFailed": "韌體更新失敗。",
			"systemRestarting": "系統重新啟動中...",
			"firmwareUpdateSuccessToVersionXPressOKToLogout": "韌體成功更新成$version版，按下確定按鈕後，系統會將您登出，請重新登入即可。",
			"firmwareUpdateFailedPressOKToLogout": "韌體更新失敗，按下確定按鈕後，系統會將您登出，請重新登入即可。",
			"areYouSureYouWantToImportSettings": "您確定要從檔案匯入設定嗎？在您匯入檔案後，所有目前控制器上正在運行的設定將會被覆蓋。",
			"areYouSureYouWantToImportSettingsUnsave": "您確定要從檔案匯入設定嗎？在您匯入檔案後，所有未儲存與目前控制器上正在運行的設定將會被覆蓋。",
			"areYouSureYouWantToExportSettings": "您確定要匯出目前正在控制器運行的設定至檔案嗎？如果您要匯出尚未儲存的設定，請先儲存目前的設定後再點選匯出按鈕。",
			"importSuccessfully": "匯入成功。",
			"importFailedNotCompatible": "匯入失敗。此檔案不相容於此控制器。"
		},
		"vpn":{
			"VPNSetting":"VPN設定",
			"VPNState":"VPN狀態",
			"ip": "IP",
			"mask": "遮罩",
			"gateway": "閘道",
			"dns": "DNS伺服器IP",
			"online":"上線",
			"offline":"斷線",
			"connecting":"連線中",
			"enable":"啟用",
			"disable":"停用"
		}
	},
	"html/desktop/home/system/menu.htm": {
		"timeSetting": "時間設定",
		"networkSetting": "網路設定",
		"vpnSetting": "VPN設定",
		"snmpSetting": "SNMP設定",
		"securitySetting": "安全設定",
		"interfaceSetting": "I/O介面設定",
		"otherSetting": "其它設定",
		//----------------------pmc--------------------------
		"GroupSetting": "電錶群組設定"
		//---------------------------------------------------
	},
	"html/desktop/home/system/time.htm": {
		"timeSettingPage": "時間設定頁面",
		"date": "日期",
		"time": "時間",
		"loadTime": "時間複製",
		"load": "讀取",
		"loadComputerTimeSetting": "讀取此電腦的時間設定",
		"timeSynchronizationSetting": "時間校時設定",
		"functionStatus": "功能狀態",
		"sntpTimeServer": "SNTP時間伺服器",
		"useDefaultSNTPTimeServers": "使用預設的SNTP時間伺服器",
		"port": "連接埠",
		"syncInterval": "同步間隔",
		"timeZoneSetting": "時區設定",
		"timeZone": "時區",
		"timeZoneKey": {
			"Dateline Standard Time": "(UTC-12:00) 國際換日線以西",
			"UTC-11": "(UTC-11:00) 國際標準時間 -11",
			"Hawaiian Standard Time": "(UTC-10:00) 夏威夷",
			"Alaskan Standard Time": "(UTC-09:00) 阿拉斯加",
			"Pacific Standard Time": "(UTC-08:00) 太平洋時間 (美國和加拿大)",
			"Pacific Standard Time (Mexico)": "(UTC-08:00) 下加利福尼亞",
			"Mountain Standard Time": "(UTC-07:00) 山區時間 (美國和加拿大)",
			"Mountain Standard Time (Mexico)": "(UTC-07:00) 齊驊華，拉帕茲，馬札特蘭",
			"US Mountain Standard Time": "(UTC-07:00) 亞歷桑那",
			"Canada Central Standard Time": "(UTC-06:00) 薩克其萬 (加拿大)",
			"Central Standard Time (Mexico)": "(UTC-06:00) 瓜達拉加若，墨西哥城，蒙特利",
			"Central Standard Time": "(UTC-06:00) 中部時間 (美國和加拿大)",
			"Central America Standard Time": "(UTC-06:00) 中美洲",
			"US Eastern Standard Time": "(UTC-05:00) 印第安納 (東部)",
			"Eastern Standard Time": "(UTC-05:00) 東部時間 (美國和加拿大)",
			"Eastern Standard Time (Mexico)": "(UTC-05:00) 切圖馬爾",
			"SA Pacific Standard Time": "(UTC-05:00) 波哥大，利馬，基多",
			"Venezuela Standard Time": "(UTC-04:30) 卡拉卡斯",
			"SA Western Standard Time": "(UTC-04:00) 佐治敦，拉帕茲，瑪瑙斯，聖胡安",
			"Central Brazilian Standard Time": "(UTC-04:00) 古雅巴",
			"Atlantic Standard Time": "(UTC-04:00) 大西洋時間 (加拿大)",
			"Paraguay Standard Time": "(UTC-04:00) 亞松森",
			"Newfoundland Standard Time": "(UTC-03:30) 紐芬蘭",
			"Pacific SA Standard Time": "(UTC-03:00) 聖地牙哥",
			"Bahia Standard Time": "(UTC-03:00) 薩爾瓦多",
			"Montevideo Standard Time": "(UTC-03:00) 蒙特維多",
			"Greenland Standard Time": "(UTC-03:00) 格陵蘭",
			"SA Eastern Standard Time": "(UTC-03:00) 開雲，福塔力沙",
			"Argentina Standard Time": "(UTC-03:00) 布宜諾斯艾利斯",
			"E. South America Standard Time": "(UTC-03:00) 巴西利亞",
			"UTC-2": "(UTC-02:00) 國際標準時間 -02",
			"Cape Verde Standard Time": "(UTC-01:00) 維德角群島",
			"Azores Standard Time": "(UTC-01:00) 亞速爾群島",
			"Morocco Standard Time": "(UTC) 卡薩布蘭卡",
			"UTC": "(UTC) 國際標準時間",
			"GMT Standard Time": "(UTC) 都柏林，愛丁堡，里斯本，倫敦",
			"Greenwich Standard Time": "(UTC) 蒙羅維亞，雷克雅維克",
			"W. Europe Standard Time": "(UTC+01:00) 阿姆斯特丹，柏林，伯恩，羅馬，斯德哥爾摩，維也納",
			"Central Europe Standard Time": "(UTC+01:00) 貝爾格勒，布拉提斯拉瓦，布達佩斯，盧布亞納，布拉格",
			"Romance Standard Time": "(UTC+01:00) 布魯塞爾，哥本哈根，馬德里，巴黎",
			"Central European Standard Time": "(UTC+01:00) 塞拉耶佛，斯高彼亞，華沙，札格雷布",
			"W. Central Africa Standard Time": "(UTC+01:00) 中西非",
			"Namibia Standard Time": "(UTC+01:00) 溫吐克",
			"Jordan Standard Time": "(UTC+02:00) 安曼",
			"GTB Standard Time": "(UTC+02:00) 雅典，布加勒斯特",
			"Middle East Standard Time": "(UTC+02:00) 貝魯特",
			"Egypt Standard Time": "(UTC+02:00) 開羅",
			"Syria Standard Time": "(UTC+02:00) 大馬士革",
			"E. Europe Standard Time": "(UTC+02:00) 東歐",
			"South Africa Standard Time": "(UTC+02:00) 哈拉雷，皮托里",
			"FLE Standard Time": "(UTC+02:00) 赫爾辛基，凱耶夫，里加，蘇非亞，塔林，維爾紐斯",
			"Turkey Standard Time": "(UTC+02:00) 伊斯坦堡",
			"Israel Standard Time": "(UTC+02:00) 耶路撒冷",
			"Kaliningrad Standard Time": "(UTC+02:00) 加里寧格勒 (RTZ 1)",
			"Libya Standard Time": "(UTC+02:00) 的黎波里",
			"Arabic Standard Time": "(UTC+03:00) 巴格達",
			"Arab Standard Time": "(UTC+03:00) 科威特，利雅德",
			"Belarus Standard Time": "(UTC+03:00) 明斯克",
			"Russian Standard Time": "(UTC+03:00) 莫斯科，聖彼得堡，伏爾加格勒 (RTZ 2)",
			"E. Africa Standard Time": "(UTC+03:00) 奈洛比",
			"Iran Standard Time": "(UTC+03:30) 德黑蘭",
			"Arabian Standard Time": "(UTC+04:00) 阿布達比，馬斯喀特",
			"Azerbaijan Standard Time": "(UTC+04:00) 巴庫",
			"Russia Time Zone 3 Standard Time": "(UTC+04:00) 伊熱夫斯克，薩馬拉 (RTZ 3)",
			"Mauritius Standard Time": "(UTC+04:00) 路易士港",
			"Georgian Standard Time": "(UTC+04:00) 第比利斯",
			"Caucasus Standard Time": "(UTC+04:00) 葉里溫",
			"Afghanistan Standard Time": "(UTC+04:30) 喀布爾",
			"West Asia Standard Time": "(UTC+05:00) 阿什哈巴德，塔什干",
			"Ekaterinburg Standard Time": "(UTC+05:00) 葉卡捷琳堡 (RTZ 4)",
			"Pakistan Standard Time": "(UTC+05:00) 伊斯蘭馬巴德，克洛奇",
			"India Standard Time": "(UTC+05:30) 辰內，加爾各答，孟拜，新德里",
			"Sri Lanka Standard Time": "(UTC+05:30) 斯里哈亞華登尼普拉",
			"Nepal Standard Time": "(UTC+05:45) 加德滿都",
			"Central Asia Standard Time": "(UTC+06:00) 阿斯坦納",
			"Bangladesh Standard Time": "(UTC+06:00) 達卡",
			"N. Central Asia Standard Time": "(UTC+06:00) 新西伯利亞 (RTZ 5)",
			"Myanmar Standard Time": "(UTC+06:30) 仰光",
			"SE Asia Standard Time": "(UTC+07:00) 曼谷，河內，雅加達",
			"North Asia Standard Time": "(UTC+07:00) 克拉斯諾亞爾斯克 (RTZ 6)",
			"China Standard Time": "(UTC+08:00) 北京，重慶，香港特別行政區，烏魯木齊",
			"North Asia East Standard Time": "(UTC+08:00) 伊爾庫次克 (RTZ 7)",
			"Singapore Standard Time": "(UTC+08:00) 吉隆坡，新加坡",
			"W. Australia Standard Time": "(UTC+08:00) 伯斯",
			"Taipei Standard Time": "(UTC+08:00) 台北",
			"Ulaanbaatar Standard Time": "(UTC+08:00) 庫倫",
			"Tokyo Standard Time": "(UTC+09:00) 大阪，札幌，東京",
			"Korea Standard Time": "(UTC+09:00) 首爾",
			"Yakutsk Standard Time": "(UTC+09:00) 雅庫茨克 (RTZ 8)",
			"Cen. Australia Standard Time": "(UTC+09:30) 愛德蘭",
			"AUS Central Standard Time": "(UTC+09:30) 達爾文",
			"E. Australia Standard Time": "(UTC+10:00) 布里斯本",
			"AUS Eastern Standard Time": "(UTC+10:00) 坎培拉，墨爾本，雪梨",
			"West Pacific Standard Time": "(UTC+10:00) 關島，莫爾斯貝港",
			"Tasmania Standard Time": "(UTC+10:00) 霍巴特",
			"Magadan Standard Time": "(UTC+10:00) 馬加丹",
			"Vladivostok Standard Time": "(UTC+10:00) 海參崴，馬加丹 (RTZ 9)",
			"Russia Time Zone 10 Standard Time": "(UTC+11:00) 喬庫爾達赫 (RTZ 10)",
			"Central Pacific Standard Time": "(UTC+11:00) 索羅門群島，新喀里多尼亞群島",
			"Russia Time Zone 11 Standard Time": "(UTC+12:00) 阿納德爾，堪察加彼得巴甫洛夫斯克 (RTZ 11)",
			"New Zealand Standard Time": "(UTC+12:00) 奧克蘭，威靈頓",
			"UTC+12": "(UTC+12:00) 國際標準時間 +12",
			"Fiji Standard Time": "(UTC+12:00) 斐濟",
			"Tonga Standard Time": "(UTC+13:00) 努瓜婁發",
			"Samoa Standard Time": "(UTC+13:00) 薩摩亞",
			"Line Islands Standard Time": "(UTC+14:00) 聖誕島"
		},
		"daylightSavingTime": "日光節約時間",
		"tip": {
			"date": "點選月曆上的日期以變更日期設定。",
			"time": "修改時間設定。",
			"loadTime": "讀取瀏覽器端電腦的系統時間設定。",
			"functionStatus": "勾選'啟用'以啟用時間校時功能。",
			"sntpTimeServer": "輸入SNTP時間伺服器位址。",
			"port": "輸入SNTP時間伺服器使用的連接埠。",
			"syncInterval": "設定校時的頻率。",
			"timeZone": "設定此此控制器所處的時區。",
			"daylightSavingTime": "勾選'啟用'以啟用日光節約時間功能。"
		},
		"popup": {
			"timeServerIsEmpty": "SNTP 時間伺服器不能為空，必須指定至少一個伺服器位址。",
			"saveFailed": "儲存失敗。"
		}
	},
	"html/desktop/home/system/network.htm": {
		"networkSetting": "網路設定",
		"connectionMode": "連線模式",
		"ip": "IP",
		"specifyIPAddress": "指定IP位址",
		"obtainIPAddressViaDHCP": "自動取得IP位址(DHCP)",
		"mask": "遮罩",
		"gateway": "閘道",
		"dns": "DNS伺服器IP",
		"mobileNetwork": "行動網路",
		"dialNumber": "撥接號碼",
		"apn": "存取點名稱",
		"authentication": "帳號驗證",
		"username": "帳號",
		"password": "密碼",
		"referToThisDocumentToConfigureTheSetting": "請參考<a href='http://wise.icpdas.com/downloads/gprs_apn.pdf' target='_blank'>此文件</a>做對應的設定。",
		"mobileCode": "行動裝置代碼",
		"mcc": "國家代碼",
		"mnc": "網路代碼",
		"referToThisWebPageToConfigureTheSetting": "請參考<a href='https://en.wikipedia.org/wiki/Mobile_country_code' target='_blank'>此網頁</a>做對應的設定。",
		"autoConnectWhenPowerOn": "開機時自動連線",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"connectSuccessfully": "連線成功。",
		"connectFailed": "連線失敗。",
		"noSIMCardDetectedPleaseInsertSIMCard": "未偵測到SIM卡，請插入SIM卡。",
		"modemErrorPleaseRebootDeviceTryAgain": "數據機錯誤，請重新啟動裝置並重試。",
		"mobileNetworkNoResponsePleaseCheckServerSetting": "行動網路無回應，請確認行動網路設定是否正確。",
		"userAuthenticationFailedPleaseCheckUsernameOrPasswordSetting": "使用者認證錯誤，請確認使用者名稱及密碼設定是否正確。",
		"securityAuthenticationFailedPleaseCheckSecuritySetting": "安全性驗證錯誤，請確認安全性設定是否正確。",
		"unknownErrorPleaseCheckMobileNetworkSetting": "不明的錯誤，請確認行動網路設定是否正確。",
		"saveAndConnect": "儲存並連線",
		"disablePINCodeFromSIMCardFirst": "請取消SIM卡的PIN碼",
		"portSetting": "連接埠設定",
		"webServerPort": "網頁伺服器連接埠",
		"modbusTCPPort": "Modbus TCP連接埠",
		"modbusNetID": "Modbus NetID",
		"ddnsSetting": "動態網域名稱系統(DDNS)設定",
		"serviceX": "服務$number",
		"serviceProvider": "服務提供者",
		"domainName": "網域名稱",
		"token": "更新代碼",
		"status": "狀態",
		"lastUpdateTime": "上次更新時間",
		"lastUpdateStatus": "上次更新狀態",
		"externalIP": "上次註冊IP",
		"updateSuccess": "更新成功。",
		"connectionFailed": "連線失敗。",
		"authorizationFailed": "認證失敗。",
		"domainNameNotExist": "網域名稱不存在。",
		"unknownError": "未知的錯誤。",
		"iotStarConnectionSetting": "IoTstar連線設定",
		"functionStatus": "功能狀態",
		"serverAddress": "伺服器位址",
		"icpdasTrialService": "ICP DAS試用服務",
		"createAccount": "建立帳號",
		"specifyServerAddress": "自訂伺服器位址",
		"serverPort": "伺服器連接埠",
		"connecting": "連線中。",
		"connected": "已連線。",
		"connectionStatus": "連線狀態",
		"unableEstablishConnectionWithServer": "無法與伺服器建立連線。",
		"usernameOrPasswordError": "帳號或密碼錯誤。",
		"reachMaximumDeviceAmount": "裝置數量已達上限。",
		"unableEstablishConnectionWithDatabase": "無法與資料庫建立連線。",
		"unableToConnectToTheSystem": "無法與系統取得連線！",
		"useUtilityToSearchSystemIP": "您的系統IP位址可能已經改變，請使用專用工具程式重新尋找系統IP位址並使用其IP位址重新登入。",
		"errorOccursInSettingCheckSettingsAgain": "您的網路設定可能發生錯誤，請重新檢查設定。",
		"systemLostConnectionWithCloudAccessViaIPDirectly": "您的系統已經與雲端斷線，可能是連線問題或登入的帳號或密碼錯誤。請直接透過IP登入系統進行操作。",
		"macAddress": "MAC位址：",
		"tip": {
			"connectionMode": "設定網路卡取得IP的方式。",
			"ip": "輸入控制器IP位址。",
			"mask": "輸入控制器遮罩。",
			"gateway": "輸入控制器閘道。",
			"dns": "輸入DNS伺服器IP。",
			"dialNumber": "輸入行動網路的撥接號碼。",
			"apn": "輸入行動網路所使用的存取點名稱(APN)。",
			"authentication": "輸入登入行動網路的使用者帳號與密碼。",
			"mobileCode": "勾選'啟用'以啟用行動裝置代碼功能。",
			"mcc": "輸入行動裝置國家代碼(MCC)。",
			"mnc": "輸入行動裝置網路代碼(MNC)。",
			"autoConnectWhenPowerOn": "勾選'啟用'以啟用開機自動連線功能。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試建立連線至您設定的行動網路上，以確定設定正確。",
			"webServerPort": "輸入控制器網頁伺服器連接埠。",
			"modbusTCPPort": "輸入控制器Modbus TCP連接埠。",
			"modbusNetID": "輸入控制器NetID。",
			"serviceProvider": "設定動態網域名稱系統的服務提供者。",
			"username": "輸入登入服務提供者的使用者帳號。",
			"password": "輸入登入服務提供者的使用者密碼。",
			"domainName": "輸入服務提供者提供的動態網域名稱。",
			"token": "輸入服務提供者提供的更新代碼。",
			"status": "目前的動態網域名稱系統狀態。",
			"cloud": {
				"functionStatus": "勾選'啟用'以啟用雲端管理系統功能。",
				"serverAddress": "輸入雲端伺服器的位址。",
				"serverPort": "輸入雲端伺服器的連接埠。",
				"username": "輸入登入雲端伺服器的使用者帳號。",
				"password": "輸入登入雲端伺服器的使用者密碼。",
				"connectionStatus": "目前與雲端管理系統的連線狀態。"
			}
		},
		"popup": {
			"areYouSureYouWantToChangeSettingMaybeLostConnection": "您確定要改變設定嗎？當這個動作完成後有可能與系統失去連線，所有尚未存檔的設定將會消失。",
			"areYouSureYouWantToChangeSettingRedirectAutomatically": "您確定要改變設定嗎？當這個動作完成後，網頁將會被導向新的網路位址，所有尚未存檔的設定將會消失。",
			"pleaseWaitAFewSeconds": "請稍候幾秒鐘。",
			"saveSuccessPressOKRedirect": "儲存成功。按下『確定』後網頁將自動導向到新的網路位址。",
			"modifykNetworkFailed": "修改網路設定失敗。",
			"modifykPortFailed": "修改連接埠設定失敗。",
			"areYouSureYouWantToTestMobileNetworkSettingTheMobileNetworkWillBeDisconnected": "您確定要測試行動網路設定嗎？此舉將導致正在透過行動網路存取系統的使用者斷線。",
			"dialNumberIsEmpty": "撥接號碼不能為空白。",
			"apnIsEmpty": "APN不能為空白。",
			"mccIsEmpty": "國家代碼不能為空白。",
			"mncIsEmpty": "網路代碼不能為空白。",
			"modifykWebServerPortSuccessfully": "修改網頁伺服器連接埠成功。",
			"modifykModbusTCPPortSuccessfully": "修改Modbus TCP連接埠成功。",
			"modifykModbusNetIDSuccessfully": "修改Modbus NetID成功。",
			"modifykWebServerPortFailed": "修改網頁伺服器連接埠失敗。",
			"modifykModbusTCPPortFailed": "修改Modbus TCP連接埠失敗。",
			"modifykModbusNetIDFailed": "修改Modbus NetID失敗。",
			"saveFailed": "儲存失敗。",
			"usernameIsEmpty": "帳號不能為空白。",
			"passwordIsEmpty": "密碼不能為空白。",
			"domainNameIsEmpty": "網域名稱不能為空白。",
			"tokenIsEmpty": "更新代碼不能為空白。",
			"serverAddressIsEmpty": "伺服器位址不能為空。",
			"areYouSureYouWantToChangeSettingAccessViaCloudMaybeLostConnectionWithCloud": "您確定要改變設定嗎？因為您正透過雲端存取系統，此舉可能會造成系統無法重新與雲端建立連線。"
		}
	},
	"html/desktop/home/system/snmp.htm": {
		"snmpSettingPage": "SNMP設定頁面",
		"version": "版本",
		"readCommunityName": "Read Community Name",
		"writeCommunityName": "Write Community Name",
		"trapCommunityName": "Trap Community Name",
		"contact": "Contact",
		"location": "Location",
		"snmpManagerList": "SNMP Manager列表",
		"address": "位址",
		"polling": "Read/Write",
		"trap": "Trap",
		"noSNMPManagerExistClickThisButtonToAdd": "無設定SNMP Manager，請按此按鈕新增。",
		"remove": "移除",
		"tip": {
			"version": "設定SNMP Trap使用的版本。",
			"readCommunityName": "輸入Read Community Name。",
			"writeCommunityName": "輸入Write Community Name。",
			"trapCommunityName": "輸入Trap Community Name。",
			"contact": "輸入Contact資訊。",
			"location": "輸入Location資訊。",
			"polling": "設定是否允許接收來自此SNMP Manager的Read/Write命令。若無勾選任何SNMP Manager，則代表允許接收來自任何SNMP Manager的Read/Write命令。",
			"trap": "設定是否允許發送SNMP Trap至此SNMP Manager。"
		},
		"popup": {
			"addressIsEmpty": "位址不能為空。",
			"addressExists": "位址已經存在。",
			"readCommunityNameIsEmpty": "Read Community Name不能為空。",
			"writeCommunityNameIsEmpty": "Write Community Name不能為空。",
			"trapCommunityNameIsEmpty": "Trap Community Name不能為空。",
			"atLeastSelectOneFunction": "SNMP Manager必須至少啟用一項功能。",
			"saveFailed": "儲存失敗。"
		}
	},
	"html/desktop/home/system/security.htm": {
		"adminPasswordSetting": "管理者密碼設定",
		"currentPassword": "目前密碼",
		"newPassword": "新密碼",
		"retypeNewPassword": "確認新密碼",
		"guestPasswordSetting": "訪客密碼設定",
		"adminProfileSetting": "管理者資料設定",
		"emailAddress": "電子郵件信箱",
		"localFTPSetting": "本機FTP伺服器設定",
		"id": "帳號",
		"password": "密碼",
		"changePassword": "變更密碼",
		"serverStatus": "伺服器狀態",
		"idleTimeSetting": "閒置時間設定",
		"idleTime": "閒置時間",
		"tip": {
			"adminPassword": "輸入目前的管理者密碼確認進行修改。",
			"adminNewPassword": "輸入新的管理者密碼。",
			"adminRetypeNewPassword": "再次輸入新的管理者密碼進行確認。",
			"guestPassword": "輸入目前的訪客密碼確認進行修改。",
			"guestNewPassword": "輸入新的訪客密碼。",
			"guestRetypeNewPassword": "再次輸入新的訪客密碼進行確認。",
			"emailAddress": "輸入管理者的電子郵件信箱。當管理者忘記密碼時，可以將機器上的旋轉開關(Rotary Switch)轉至8後，再進入到登入畫面並按下『忘記密碼？』，系統將會把管理者密碼寄至此信箱中。",
			"ftpEnable": "勾選'啟用'以開啟本機端FTP伺服器服務。",
			"id": "登入本機FTP伺服器所使用的帳號。",
			"password": "勾選'變更密碼以設定新的本機FTP伺服器密碼。",
			"idleTime": "設定使用者登入網頁後的閒置時間，當網頁靜置超過閒置時間後，使用者將被自動登出。"
		},
		"popup": {
			"passwordIsEmpty": "密碼不能為空。",
			"retypePasswordNotMatch": "輸入兩次新的密碼不一致。",
			"passwordIncorrect": "密碼錯誤。",
			"saveFailed": "儲存失敗。",
			"adminEmailIsEmpty": "電子郵件信箱不能為空。"
		}
	},
	"html/desktop/home/system/interface.htm": {
		"ioInterfaceSettingPage": "I/O介面設定頁面",
		"function": "功能",
		"dconMaster": "連接DCON設備",
		"modbusRTUMaster": "連接Modbus RTU設備",
		"modbusRTUSlave": "連接HMI或SCADA",
		"modbusTCPMaster": "連接Modbus TCP設備",
		"modbusTCPSlave": "連接HMI或SCADA",
		"modem": "連接GTM-203M-3GWA設備",
		"timeout": "連線逾時",
		"silentInterval": "指令間隔時間",
		"tip": {
			"function": "選擇此I/O介面的功能。",
			"baudrate": "設定此COM序列埠的Baudrate設定。",
			"parity": "設定此COM序列埠的Parity設定。",
			"stopbits": "設定此COM序列埠的Stop bits設定。",
			"timeout": "輸入此COM序列埠的連線逾時設定。",
			"checksum": "設定此COM序列埠的Checksum設定。",
			"silentInterval": "輸入此COM序列埠的指令間隔時間設定。"
		}
	},
	"html/desktop/home/module.htm": {
		"moduleSettingPage": "模組設定頁面",
		"none": "無",
		"moduleNameOrNickname": "型號 / 名稱",
		"noModuleExist": "無設定模組",
		"no": "編號",
		"address": "位址",
		"pollingTimeout": "輪詢逾時(毫秒)",
		"ipAndPort": "IP與連接埠",
		"netID": "NetID"
	},
	"html/desktop/home/module/menu.htm": {
		"xwboardSetting": "XW-Board設定",
		"xvboardSetting": "XV-Board設定",
		"ioModuleSetting": "I/O模組設定"
	},
	"html/desktop/home/module/local.htm": {
		"xwboardSettingPage": "XW-Board設定頁面",
		"xvboardSettingPage": "XV-Board設定頁面",
		"module": "模組",
		"none": "無",
		"tip": {
			"module": "設定控制器所安裝的模組型號。"
		}
	},
	"html/desktop/home/module/local/setting.htm": {
		"moduleXSetting": "模組 $moduleName 設定",
		"digitalChannel": "數位通道",
		"chX": "通道$no",
		"aiType": "AI 類型",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "溫度單位",
		"celsius": "攝氏(°C)",
		"fahrenheit": "華氏(°F)",
		"diAttribute": "DI 參數",
		"doAttribute": "DO 參數",
		"aiAttribute": "AI 參數",
		"aoAttribute": "AO 參數",
		"channel": "通道",
		"ch": "通道",
		"counterType": "計數器類型",
		"counterInitialValue": "計數器初始值",
		"powerOnValue": "開機時預設值",
		"advancedFunction": "進階功能",
		"type": "類型",
		"deadband": "Deadband區間",
		"scale": "線性轉換",
		"rising": "升緣",
		"falling": "降緣",
		"pulseOutput": "脈衝(Pulse)輸出",
		"autoOFF": "自動歸復",
		"mappingToDI": "複製DI訊號",
		"pulseHigh": "高點時間:",
		"pulseLow": "低點時間:",
		"autoOFFAfterXSeconds": "$input 秒後自動回復為OFF",
		"cloneDIXChannelStatus": "複製 DI 通道 $di 狀態",
		"scaleMin": "最小值:",
		"scaleMax": "最大值:",
		"scaleUnit": "單位:",
		"tip": {
			"nickname": "輸入對此模組的名稱。",
			"description": "輸入關於此模組的說明。",
			"digitalChannel": "選擇數位通道的功能。同一個數位通道上您可以選擇當做DI或DO使用。",
			"aiType": "設定此模組之AI類型。",
			"temperatureUnit": "設定此模組之AI通道溫度顯示單位。"
		}
	},
	"html/desktop/home/module/remote.htm": {
		"remoteIOModuleSettingPage": "遠端I/O模組設定頁面",
		"dconModuleList": "DCON 模組清單",
		"modbusRTUList": "Modbus RTU 模組清單",
		"modbusTCPList": "Modbus TCP 模組清單",
		"i7000Series": "I-7000系列",
		"m7000Series": "M-7000系列",
		"tMSeries": "tM系列",
		"lcSeries": "LC系列",
		"dlSeries": "DL系列",
		"irSeries": "IR系列",
		"interfaceNotEnable": "此序列埠尚未啟用，請至<a href='#home/system/interface'>I/O介面設定</a>頁面中啟用後即可使用。",
		"interfaceIsModbusRTUSlave": "此序列埠已經設定為HMI模式，請至<a href='#home/system/interface'>I/O介面設定</a>頁面中修改為Modbus RTU Master後即可連接I/O設備。",
		"no": "編號",
		"address": "位址",
		"module": "模組",
		"moduleNameOrNickname": "型號 / 名稱",
		"pollingTimeout": "輪詢逾時(毫秒)",
		"retryInterval": "逾時重試時間(秒)",
		"ip": "IP",
		"port": "連接埠",
		"netID": "NetID",
		"search": "搜尋",
		"noModuleExistClickThisButtonToAdd": "無設定模組，請按此按鈕新增。",
		"icpdasModule": "泓格模組",
		"decreaseNo": "編號上移",
		"increaseNo": "編號下移",
		"copy": "複製",
		"removeModule": "移除",
		"moduleSettingConflict": "部分模組設定發生衝突。",
		"selectModuleYouWant": "請選擇每個位址上您想使用的模組。",
		"previousMoudle": "原設定模組",
		"scannedMoudle": "掃描後模組",
		"none": "無",
		"scanAddressRange": "掃描位址範圍：",
		"scanAddressRangeFromAToB": "掃描 $inputFrom 到 $inputTo 位址。依照您設定的掃描位址數目，這個過程所花費的時間將需數秒至數十秒不等。",
		"comPort": "序列埠",
		"silentInterval": "指令間隔時間",
		"timeout": "逾時時間",
		"scan": "掃描",
		"popup": {
			"reachMaximumModulesAmount": "達到最大模組數量。最大的I/O模組數量為$ioModule個且單一連接埠為$totalModule個（含電錶與I/O模組）。",
			"moduleNotFound": "無此模組，請輸入模組的型號以進行搜尋並從結果中選擇一個型號。",
			"nicknameOrModuleNameIsEmpty": "名稱 / 型號不能為空。",
			"nicknameIsEmpty": "名稱不能為空。",
			"ipIsEmpty": "IP不能為空。"
		}
	},
	"html/desktop/home/module/remote/modbus.htm": {
		"moduleXSetting": "模組 $moduleName 設定",
		"no": "編號",
		"address": "位址",
		"ip": "IP",
		"port": "連接埠",
		"netID": "NetID",
		"scanRate": "更新速率",
		"pollingTimeout": "輪詢逾時時間",
		"retryInterval": "逾時重試時間",
		"modbusTableSetting": "Modbus位址對應表設定",
		"dataModel": "資料類型",
		"startAddress": "起始位址",
		"length": "資料數量",
		"type": "格式",
		"hexType": "HEX格式",
		"hex": "HEX",
		"real": "實際",
		"minimum": "最小值:",
		"maximum": "最大值:",
		"dataAdjustment": "資料調整",
		"scaleRatio": "線性轉換倍率",
		"offset": "偏移量",
		"deadband": "Deadband區間",
		"add": "加入",
		"modbusTable": "Modbus位址對應表",
		"addressSetting": "位址設定",
		"nicknameSetting": "名稱設定",
		"localAddress": "本機<br>位址",
		"removeAllBlock": "清除所有設定",
		"collapseAllBlock": "全部縮合",
		"expandAllBlock": "全部展開",
		"noBlockInModbusTable": "尚未設定位址對應表",
		"dataAddress": "資料位址",
		"hexMinimum": "HEX最小值",
		"hexMaximum": "HEX最大值",
		"realMinimum": "實際最小值",
		"realMaximum": "實際最大值",
		"remove": "移除",
		"unit": "單位",
		"tip": {
			"nickname": "輸入對此模組的名稱。",
			"description": "輸入對此模組的說明。",
			"no": "設定此模組的編號，編號將決定此模組的數據所存放的Modbus位址。",
			"address": "設定此模組的RS-485位址，請確認此設定與模組內部設定相同即可正常連線。",
			"ip": "輸入此模組的IP位址。",
			"port": "輸入此模組的連接埠。",
			"netID": "輸入此模組的NetID。",
			"scanRateForRTU": "輸入每隔多久時間更新一次此模組之通道資料，設定為0則會不間斷更新。",
			"scanRateForTCP": "輸入每隔多久時間更新一次此模組之通道資料。",
			"pollingTimeout": "輸入輪詢此模組時的逾時時間。",
			"retryInterval": "輸入當輪詢模組發生逾時狀況時，下一次輪詢此模組的時間間隔。",
			"dataModel": "選擇遠端Modbus模組上的資料類型。",
			"startAddress": "輸入遠端Modsbus模組的資料起始位址。",
			"length": "輸入欲取回的資料數量。",
			"type": "設定使用何種格式顯示讀取的資料。",
			"hexType": "輸入HEX轉換所需的相關資料。",
			"scaleRatio": "輸入資料的線性轉換倍率，原始資料會被乘上此倍率成為新的資料。",
			"offset": "輸入資料的線性轉換偏移量，乘上線性轉換倍率後的資料會被加上此偏移量成為新的資料。",
			"deadband": "輸入此模組數據用於規則設定時所需的Deadband區間。"
		},
		"popup": {
			"addressReachMaximum": "資料的位址必須小於或等於65535。",
			"addressAlreadyExist": "部分資料的位址已經存在於Modbus位址對應表中。",
			"lengthReachMaximum": "資料的長度達到超過限制，資料最大長度為$length。",
			"modbusTableReachMaximum": "Modbus位址對應表的長度超過限制，Modbus位址對應表最大長度為$maxLength。",
			"hexMaximumEqualToMinimum": "HEX的最大值不能等於最小值。",
			"realMaximumLessThanMinimum": "實際值的最大值不能小於或等於最小值。",
			"nicknameIsEmpty": "名稱不能為空。"
		}
	},
	"html/desktop/home/module/remote/icpdas.htm": {
		"moduleXSetting": "模組 $moduleName 設定",
		"no": "編號",
		"address": "位址",
		"scanRate": "更新速率",
		"pollingTimeout": "輪詢逾時時間",
		"retryInterval": "逾時重試時間",
		"aiType": "AI類型",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "溫度單位",
		"celsius": "攝氏(°C)",
		"fahrenheit": "華氏(°F)",
		"diAttribute": "DI參數",
		"doAttribute": "DO參數",
		"aiAttribute": "AI參數",
		"aoAttribute": "AO參數",
		"channel": "通道",
		"ch": "通道",
		"resetCounterWhenPowerOn": "啟動時重置計數器",
		"advancedFunction": "進階功能",
		"autoOFF": "自動歸復",
		"mappingToDI": "複製DI訊號",
		"autoOFFAfterXSeconds": "$input 秒後自動回復為OFF",
		"cloneDIXChannelStatus": "複製 DI 通道 $di 狀態",
		"type": "類型",
		"deadband": "Deadband區間",
		"scale": "線性轉換",
		"scaleMin": "最小值:",
		"scaleMax": "最大值:",
		"scaleUnit": "單位:",
		"tip": {
			"nickname": "輸入對此模組的名稱。",
			"description": "輸入對此模組的說明。",
			"no": "設定此模組的編號，編號將決定此模組的數據所存放的Modbus位址。",
			"address": "設定此模組的RS-485位址，請確認此設定與模組內部設定相同即可正常連線。",
			"scanRate": "輸入每隔多久時間更新一次此模組之通道資料，設定為0則會不間斷更新。",
			"pollingTimeout": "輸入輪詢此模組時的逾時時間。",
			"retryInterval": "輸入當輪詢模組發生逾時狀況時，下一次輪詢此模組的時間間隔。",
			"aiType": "設定AI訊號模式",
			"temperatureUnit": "設定溫度單位。"
		}
	},
	"html/desktop/home/module/remote/ir.htm": {
		"moduleXSetting": "模組 $moduleName 設定",
		"no": "編號",
		"address": "位址",
		"ip": "IP",
		"port": "連接埠",
		"netID": "NetID",
		"scanRate": "更新速率",
		"pollingTimeout": "輪詢逾時時間",
		"retryInterval": "逾時重試時間",
		"commandNumber": "命令編號",
		"noCommandExistClickThisButtonToAdd": "無可用命令，請按新增以增加可用命令。",
		"add": "新增",
		"remove": "移除",
		"tip": {
			"nickname": "輸入此模組的名稱。",
			"description": "輸入此模組的說明。",
			"no": "設定此模組的編號，編號將決定此模組的數據所存放的Modbus位址。",
			"address": "設定此模組的RS-485位址，請確認此設定與模組內部設定相同方可正常連線。",
			"ip": "輸入此模組的IP位址。",
			"port": "輸入此模組的連接埠。",
			"netID": "輸入此模組的NetID。",
			"scanRate": "輸入每隔多久時間更新一次此模組之通道資料，設定為0則會不間斷更新。",
			"pollingTimeout": "輸入輪詢此模組時的逾時時間。",
			"retryInterval": "輸入當輪詢模組發生逾時狀況時，下一次輪詢此模組的時間間隔。",
			"commandNumber": "加入模組上已設定的命令編號。"
		}
	},
	"html/desktop/home/logger.htm": {
		"loggerSettingPage": "記錄器設定頁面",
		"powerMeterDataLogger": "電力資料記錄器",
		"ioModuleDataLogger": "I/O資料記錄器",
		"userDefinedDataLogger": "自訂資料記錄器",
		"logAttribute": "記錄檔參數",
		"ftpUploadFunction": "FTP上傳功能",
		"dataLogUploadFunction": "資料記錄檔上傳功能",
		"powerMeterDataLog": "電力資料記錄檔",
		"ioModuleDataLog": "I/O資料記錄檔",
		"userDefinedDataLog": "自訂資料記錄檔",
		"eventLogUploadFunction": "事件記錄檔上傳功能",
		"eventLog": "事件記錄檔"
	},
	"html/desktop/home/logger/menu.htm": {
		"dataLoggerSetting": "資料記錄器設定",
		"eventLoggerSetting": "事件記錄器設定",
		"ftpUploadSetting": "FTP上傳設定"
	},
	"html/desktop/home/logger/data.htm": {
		"powerMeterDataLoggerSetting": "電力資料記錄器設定",
		"functionStatus": "功能狀態",
		"logMode": "記錄模式",
		"average": "平均值",
		"instantaneous": "瞬間值",
		"report": "報表",
		"english": "英文",
		"traditionalChinese": "繁體中文",
		"simplifiedChinese": "簡體中文",
		"ioModuleDataLoggerSetting": "I/O資料記錄器設定",
		"userDefinedDataLoggerSetting": "自訂資料記錄器設定",
		"dataFormat": "資料格式",
		"insert": "插入",
		"logAttributeSetting": "記錄檔參數設定",
		"logInterval": "記錄間距",
		"fileNameFormat": "檔案名稱格式",
		"endOfLineChar": "結尾字元格式",
		"columnHeader": "標頭",
		"add": "附加",
		"logFileRetentionTime": "記錄檔保留時間",
		"dataLoggerRateDes":"(請配合各電錶或I/O模組更新速率。)",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用資料記錄器功能。",
			"logMode": "設定記錄資料之計算方式。",
			"columnHeader": "勾選'附加'以附加標頭到記錄檔中。",
			"report": "設定是否產生Excel格式報表。",
			"dataFormat": "輸入資料記錄的格式。",
			"logInterval": "設定每筆記錄之寫入時間間距。",
			"fileNameFormat": "設定記錄檔之檔案名稱格式。",
			"endOfLineChar": "設定每筆記錄資料之結尾字元格式。",
			"logFileRetentionTime": "設定記錄檔之保留時間。"
		},
		"popup": {
			"dataFormatIsEmpty": "資料格式不能為空白。"
		}
	},
	"html/desktop/home/logger/event.htm": {
		"eventLoggerSetting": "事件記錄器設定頁面",
		"logFileRetentionTime": "記錄檔保留時間",
		"tip": {
			"logFileRetentionTime": "設定記錄檔之保留時間。"
		}
	},
	"html/desktop/home/logger/ftp.htm": {
		"ftpUploadSettingPage": "FTP上傳設定頁面",
		"functionStatus": "功能狀態",
		"remoteFTPServer": "遠端FTP伺服器",
		"address": "網址",
		"port": "連接埠",
		"id": "帳號",
		"password": "密碼",
		"path": "路徑",
		"ftpSettingTest": "遠端FTP伺服器設定測試",
		"send": "傳送",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"dataLogUploadFunction": "資料記錄檔上傳功能",
		"uploadPowerMeterDataLog": "上傳電力資料記錄檔",
		"uploadIOModuleDataLog": "上傳I/O資料記錄檔",
		"uploadUserDefinedDataLog": "上傳自訂資料記錄檔",
		"eventLogUploadFunction": "事件記錄檔上傳功能",
		"uploadEventLog": "上傳事件記錄檔",
		"frequency": "頻率",
		"everyXMinutes": "每 $minute 分鐘",
		"everyXHour": "每 $hour 小時",
		"everyXHours": "每 $hour 小時",
		"eventLogUploadSetting": "事件記錄檔上傳設定",
		"onceADay": "一天一次",
		"onceAWeek": "一週一次",
		"onceAMonth": "一個月一次",
		"enablePowerMeterDataLoggerFirst": "請先啟用電力資料記錄器。",
		"enableIOModuleDataLoggerFirst": "請先啟用I/O資料記錄器。",
		"enableUserDefinedDataLoggerFirst": "請先啟用自訂資料記錄器。",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用記錄器上傳至遠端FTP伺服器的功能。",
			"dataLogUploadFunction": "選擇欲上傳的資料記錄檔類型並設定上傳頻率。",
			"eventLogUploadFunction": "選擇欲上傳的事件記錄檔類型並設定上傳頻率。",
			"frequency": "設定記錄檔的上傳週期。",
			"remoteFTPServer": "輸入遠端FTP伺服器資訊。",
			"address": "輸入遠端FTP伺服器網址。",
			"port": "輸入遠端FTP伺服器連接埠。",
			"id": "輸入遠端FTP伺服器登入帳號。",
			"password": "輸入遠端FTP伺服器登入密碼。",
			"path": "輸入遠端FTP伺服器記錄檔的上傳路徑。",
			"ftpSettingTest": "按下傳送後，系統將會依據您的設定，嘗試登入遠端FTP伺服器並建立一個目錄與傳送測試檔案，以確定設定正確。"
		},
		"popup": {
			"urlIsEmpty": "網址不能為空白。",
			"idIsEmpty": "帳號不能為空白。"
		}
	},
	"html/desktop/home/logger/email.htm":{
		"send": "傳送",
		"sentSuccessfully": "傳送成功。",
		"recordsDateRange": "檔案記錄日期範圍",
		"date":"日期",
		"statementsCategory": "報表類別",
		"dailyReport": "日報表",
		"monthlyReport": "月報表",
		"weeklyReport":"週報表",
		"annualReport":"年報表",
		"receiverEmail": "收件者電子郵件",
		"language": "語系",
		"english": "英文",
		"traditionalChinese": "繁體中文",
		"simplifiedChinese": "簡體中文",
		"enable":"啟用",
		"disable":"停用",
		
		"ReportSendingSetting":"寄發報表設定",
		"ReportSendingFunction":"寄發報表功能",
		"functionStatus":"功能狀態",
		"ReportSendingSettingpage":"寄發報表設定頁面",
		"SendingSettings":"寄發設定",
		"ResendFunction":"補寄功能",
		"Selectemail":"電子郵件選擇",
		'Selectemail_tip':'需設定<a href="#home/advanced/email">『進階功能設定 &gt; 電子郵件設定』</a>功能才可透過Email寄發報表。',
		"Compressedfile":"壓縮檔",
		"Generatecompressedfile":"加入壓縮檔(.zip)",
		"NoEmailexists":"無設定電子郵件",
		"ReportTypecantbeempty":"報表類別不能為空。",
		"emailRemovedAlarm":"寄發報表設定中所設定的電子郵件，已遭移除，請再次確認及設定。",
		"SendingTime":"寄發時間",
		
		"tip": {
			"dailyReport": "日報表為每日結束時寄發",
			"monthlyReport": "月報表為每月結束時寄發",
			"weeklyReport":"週報表為每週六結束時寄發",
			"annualReport":"年報表為每年結束時寄發"
		}
	},
	"html/desktop/home/iot.htm": {
		"iotSettingPage": "IoT平台設定頁面",
		"azureDescription": "系統提供了與Microsoft Azure平台連接的功能，能夠發佈至Microsoft Azure或接收來自Microsoft Azure的訊息，並將收到的訊息作為工作邏輯的判斷條件。",
		"bluemixDescription": "系統提供了與IBM Bluemix平台連接的功能，能夠發佈至IBM Bluemix或接收來自IBM Bluemix的訊息，並將收到的訊息作為工作邏輯的判斷條件。",
		"mqttDescription": "系統提供了MQTT客戶端的功能，能夠發佈(Publish)訊息至指定的Broker或訂閱(Subscribe)Topic，並將收到的訊息作為工作邏輯的判斷條件。",
		"realTimeDescription": "系統提供了即時資料傳送功能，讓使用者可以挑選欲傳送至IoTstar上的模組通道資料並存入資料庫中，更可直接從資料庫中對模組通道進行控制。",
		"historicalDescription": "系統提供了歷史資料傳送功能，能夠將模組通道資料傳送至IoTstar並匯入至資料庫中，以利進行長期的資料分析。",
		"lineBotDescription": "IoTstar提供了Bot Service功能，可於系統發生特殊事件時主動將訊息推撥至手機上的LINE App中。此外，也可以透過LINE App直接查詢模組與I/O通道狀態，以及改變通道輸出數值。"
	},
	"html/desktop/home/iot/menu.htm": {
		"azureSetting": "Microsoft Azure平台設定",
		"bluemixSetting": "IBM Bluemix平台設定",
		"mqttSetting": "MQTT設定",
		"iotStarSetting": "IoTstar設定",
		"realTimeSetting": "即時資料傳送設定",
		"historicalSetting": "歷史資料傳送設定",
		"lineBotSetting": "Bot Service設定"
	},
	"html/desktop/home/iot/azure.htm": {
		"azureSettingPage": "Microsoft Azure設定頁面",
		"functionStatus": "功能狀態",
		"sasToken": "SAS權杖",
		"keepAliveTime": "Keep Alive時間",
		"periodicallyPublishInterval": "週期性發佈間隔",
		"input0RepresentDisablePeriodicallyPublish": "輸入0代表停用週期性發佈。",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"connectSuccessfully": "連線成功。",
		"connectFailed": "連線失敗。",
		"publishAndSubscribeSetting": "訊息發佈與接收設定",
		"publish": "發佈",
		"subscribe": "接收",
		"message": "訊息",
		"createNewPublishMessage": "新增發佈訊息",
		"copy": "複製",
		"remove": "移除",
		"noMessageExist": "無設定訊息。",
		"variableName": "參數名稱",
		"add": "新增",
		"variable": "參數",
		"noVariableNameExist": "無設定參數名稱。",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用Microsoft Azure功能。",
			"sasToken": "輸入Microsoft Azure所提供的SAS權杖字串。",
			"keepAliveTime": "輸入Keep Alive時間。",
			"periodicallyPublishInterval": "輸入週期性發佈訊息的間隔時間。所有啟用『週期性發佈』的訊息會依據此間隔持續週期性地自動發佈。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試建立連線至Microsoft Azure上，以確定設定正確。",
			"variableName": "輸入參數名稱。一組參數是由名稱與數值所組成，該名稱所對應的數值可用於IF條件中。"
		},
		"popup": {
			"sasTokenIsEmpty": "SAS權杖不能為空白。",
			"variableNameIsEmpty": "參數名稱不能為空。",
			"variableNameIsDuplicate": "參數名稱不能重複。"
		}
	},
	"html/desktop/home/iot/azure/publish.htm": {
		"messageType": "訊息類型",
		"channelData": "通道資料",
		"userDefinedData": "自訂資料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"autoPublish": "自動發佈",
		"dataChangeGreatX": "當數值變動大於$threshold時",
		"periodicallyPublish": "週期性發佈",
		"none": "無",
		"message": "訊息",
		"publishMessageXSetting": "發佈訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"messageType": "設定此訊息的資料類型。",
			"channelData": "選擇欲作為此訊息內容的通道。",
			"userDefinedData": "輸入欲作為此訊息內容的資料。",
			"autoPublish": "選擇此訊息自動發佈的時間點。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"noAvailableChannelData": "無可用的通道資料。請先新增至少一個模組或內部暫存器。",
			"userDefinedDataIsEmpty": "自訂資料不能為空白。"
		}
	},
	"html/desktop/home/iot/bluemix.htm": {
		"bluemixSettingPage": "IBM Bluemix設定頁面",
		"functionStatus": "功能狀態",
		"organizationID": "組織名稱",
		"deviceType": "裝置類型",
		"deviceID": "裝置名稱",
		"deviceAuthenticationToken": "鑑別記號",
		"keepAliveTime": "Keep Alive時間",
		"periodicallyPublishInterval": "週期性發佈間隔",
		"input0RepresentDisablePeriodicallyPublish": "輸入0代表停用週期性發佈。",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"connectSuccessfully": "連線成功。",
		"connectFailed": "連線失敗。",
		"publishAndSubscribeSetting": "訊息發佈與接收設定",
		"publish": "發佈",
		"subscribe": "接收",
		"message": "訊息",
		"createNewPublishMessage": "新增發佈訊息",
		"copy": "複製",
		"remove": "移除",
		"noMessageExist": "無設定訊息。",
		"commandName": "命令名稱",
		"variableName": "參數名稱",
		"add": "新增",
		"command": "命令",
		"variable": "參數",
		"noCommandNameExist": "無設定命令名稱。",
		"noVariableNameExist": "無設定參數名稱。",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用IBM Bluemix功能。",
			"organizationID": "輸入組織名稱(Organization ID)。",
			"deviceType": "輸入裝置類型(Device Type)。",
			"deviceID": "輸入裝置名稱(Device ID)。",
			"deviceAuthenticationToken": "輸入鑑別記號(Device Authentication Token)。",
			"keepAliveTime": "輸入Keep Alive時間。",
			"periodicallyPublishInterval": "輸入週期性發佈訊息的間隔時間。所有啟用『週期性發佈』的訊息會依據此間隔持續週期性地自動發佈。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試建立連線至IBM Bluemix上，以確定設定正確。",
			"commandName": "輸入命令名稱。該名稱可用於IF條件中。",
			"variableName": "輸入參數名稱。一組參數是由名稱與數值所組成，該名稱所對應的數值可用於IF條件中。"
		},
		"popup": {
			"organizationIDIsEmpty": "組織名稱不能為空白。",
			"deviceTypeIsEmpty": "裝置類型不能為空白。",
			"deviceIDIsEmpty": "裝置名稱不能為空白。",
			"deviceAuthenticationTokenIsEmpty": "鑑別記號不能為空白。",
			"commandNameIsEmpty": "命令名稱不能為空。",
			"commandNameIsDuplicate": "命令名稱不能重複。",
			"variableNameIsEmpty": "參數名稱不能為空。",
			"variableNameIsDuplicate": "參數名稱不能重複。"
		}
	},
	"html/desktop/home/iot/bluemix/publish.htm": {
		"eventID": "事件名稱",
		"messageType": "訊息類型",
		"channelData": "通道資料",
		"userDefinedData": "自訂資料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"autoPublish": "自動發佈",
		"dataChangeGreatX": "當數值變動大於$threshold時",
		"periodicallyPublish": "週期性發佈",
		"none": "無",
		"message": "訊息",
		"publishMessageXSetting": "發佈訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"eventID": "輸入此訊息的事件名稱(Event ID)。",
			"messageType": "設定此訊息的資料類型。",
			"channelData": "選擇欲作為此訊息內容的通道。",
			"userDefinedData": "輸入欲作為此訊息內容的資料。",
			"autoPublish": "選擇此訊息自動發佈的時間點。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"eventIDIsEmpty": "事件名稱不能為空。",
			"noAvailableChannelData": "無可用的通道資料。請先新增至少一個模組或內部暫存器。",
			"userDefinedDataIsEmpty": "自訂資料不能為空白。"
		}
	},
	"html/desktop/home/iot/mqtt.htm": {
		"mqttSettingPage": "MQTT設定頁面",
		"brokerSetting": "Broker設定",
		"topicImportExport": "Topic匯入/匯出",
		"address": "位址",
		"port": "連接埠",
		"initialStatus": "初始狀態",
		"createNewOne": "新增MQTT Broker",
		"noBrokerExist": "無設定MQTT Broker。",
		"copy": "複製",
		"remove": "移除",
		"importTopic": "匯入Topic",
		"export": "匯出",
		"popup": {
			"importingPleaseWait": "匯入中，請稍候...",
			"noExportTopicPleaseSelectLastOneTopic": "無可匯出的Topic，請至少勾選一個Topic再匯出。",
			"importFailed": "匯入失敗。",
			"importFailedFileFormatIsInvalid": "匯入失敗，檔案格式不正確。",
			"importSuccess": "匯入成功。",
			"reachMaximumBrokerAmount": "已達到最大Broker數量。"
		}
	},
	"html/desktop/home/iot/mqtt/broker.htm": {
		"brokerAttributeSetting": "Broker參數設定",
		"initialStatus": "初始狀態",
		"address": "位址",
		"port": "連接埠",
		"authentication": "帳號驗證",
		"id": "帳號",
		"password": "密碼",
		"clientID": "客戶端名稱",
		"encryption": "加密傳輸",
		"keepAliveTime": "Keep Alive時間",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"connectSuccessfully": "連線成功。",
		"connectFailed": "連線失敗。",
		"messageSetting": "訊息設定",
		"message": "訊息",
		"periodicallyPublishInterval": "週期性發佈間隔",
		"input0RepresentDisablePeriodicallyPublish": "輸入0代表停用週期性發佈。",
		"topicPrefix": "Topic前置字串",
		"publishAndSubscribeSetting": "Publish與Subscribe設定",
		"createNewPublishMessage": "新增Publish訊息",
		"createNewSubscribeTopic": "新增Subscribe Topic",
		"noTopicExist": "無設定Topic。",
		"noMessageExist": "無設定訊息。",
		"copy": "複製",
		"remove": "移除",
		"brokerXSetting": "Broker $name 設定",
		"tip": {
			"nickname": "輸入此Broker的名稱。",
			"description": "輸入此Broker的說明。",
			"initialStatus": "設定當系統啟動時，此Broker的初始狀態。",
			"address": "輸入此Broker的位址。",
			"port": "輸入此Broker的連接埠。",
			"authentication": "若您的Broker要求認證，請勾選'啟用'以啟用帳號驗證功能。",
			"lastWill": "勾選'啟用'以啟用Last Will功能。",
			"clientID": "輸入客戶端名稱(Client ID)。維持空白時系統將自動產生。",
			"encryption": "設定在資料傳輸時是否開啟加密功能。",
			"keepAliveTime": "輸入Keep Alive時間。",
			"periodicallyPublishInterval": "輸入週期性發佈Topic的間隔時間。所有啟用『週期性發佈』的Topic會依據此間隔持續週期性地自動發佈。",
			"topicPrefix": "輸入Topic前置字串。可在每一個Topic設定中設定是否使用前置字串。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試建立連線至您設定的Broker上，以確定設定正確。"
		},
		"popup": {
			"reachMaximumAmount": "達到最大數量。",
			"nicknameIsEmpty": "Broker名稱不能為空白。",
			"addressIsEmpty": "位址不能為空白。",
			"idIsEmpty": "帳號不能為空白。",
			"willTopicIsEmpty": "Will Topic不能為空白。",
			"willMessageIsEmpty": "Will訊息不能為空白。"
		}
	},
	"html/desktop/home/iot/mqtt/broker/publish.htm": {
		"messageType": "訊息類型",
		"channelData": "通道資料",
		"userDefinedData": "自訂資料",
		"insert": "插入",
		"useJSONFormat": "使用JSON格式",
		"usePrefix": "使用前置字串",
		"import": "匯入",
		"use": "使用",
		"retain": "保留訊息(Retain)",
		"autoPublish": "自動發佈",
		"dataChangeGreatX": "當數值變動大於$threshold時",
		"periodicallyPublish": "週期性發佈",
		"none": "無",
		"message": "訊息",
		"publishMessageXSetting": "Publish訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"messageType": "設定此訊息的資料類型。",
			"channelData": "選擇欲作為此訊息內容的通道。",
			"userDefinedData": "輸入欲作為此訊息內容的資料。",
			"topic": "輸入此訊息欲發佈到的Topic名稱。",
			"qos": "設定此訊息的QoS。",
			"retain": "勾選'啟用'以開啟此訊息的保留功能。",
			"autoPublish": "選擇此訊息自動發佈的時間點。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"noAvailableChannelData": "無可用的通道資料。請先新增至少一個模組或內部暫存器。",
			"userDefinedDataIsEmpty": "自訂資料不能為空白。",
			"topicIsEmpty": "Topic不能為空白。"
		}
	},
	"html/desktop/home/iot/mqtt/broker/subscribe.htm": {
		"usePrefix": "使用前置字串",
		"import": "匯入",
		"use": "使用",
		"subscribeTopicXSetting": "Subscribe Topic $name 設定",
		"tip": {
			"nickname": "輸入此Topic的名稱。",
			"description": "輸入此Topic的說明。",
			"topic": "輸入欲訂閱的Topic名稱。",
			"qos": "設定此Topic的QoS。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"topicIsEmpty": "Topic不能為空白。",
			"topicContainIllegalCharacter": "Topic不能含有+或#符號。"
		}
	},
	"html/desktop/home/iot/realtime.htm": {
		"realTimeDataSendingSettingPage": "即時資料傳送設定頁面",
		"functionStatus": "功能狀態",
		"addChannel": "新增通道",
		"insert": "插入",
		"channelList": "通道列表",
		"channel": "通道",
		"name": "名稱",
		"noChannelExist": "無設定通道。",
		"moveUp": "上移",
		"moveDown": "下移",
		"remove": "移除",
		"none": "無",
		"internalRegisterX": "內部暫存器$channel",
		"diCounterX": "DI計數器$channel",
		"doCounterX": "DO計數器$channel",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用傳送功能。",
			"interface": "設定欲插入模組的介面。",
			"module": "設定欲插入的模組。",
			"channel": "設定欲插入的通道。",
			"source": "設定欲插入的內部暫存器來源。",
			"no": "設定欲插入的內部暫存器編號。",
			"setupModuleOrIRFirst": "請先設定I/O模組或內部暫存器。"
		},
		"popup": {
			"nameIsDuplicate": "名稱不能重複。",
			"channelReachMaximum": "通道數量不能超過1000個。",
			"channelIsEmpty": "通道數量必須大於或等於1個。"
		}
	},
	"html/desktop/home/iot/historical.htm": {
		"historicalDataSendingSettingPage": "歷史資料傳送設定頁面",
		"functionStatus": "功能狀態",
		"sendingType": "傳送類型",
		"powerData": "電力資料",
		"ioChannelData": "I/O通道資料",
		"enableDataLoggerFirst": "需啟用『<a href='#home/logger/data'>資料記錄器</a>』功能才能使用此功能。",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用傳送功能。",
			"sendingType": "選擇欲傳送的資料類型。"
		}
	},
	"html/desktop/home/iot/linebot.htm": {
		"lineBotMessageSettingPage": "Bot Service訊息設定頁面",
		"message": "訊息",
		"content": "內容",
		"createNewMessage": "新增訊息",
		"noMessageExist": "無設定訊息。",
		"copy": "複製",
		"remove": "移除",
		"functionStatus": "功能狀態"
	},
	"html/desktop/home/iot/linebot/message.htm": {
		"content": "內容",
		"insert": "插入",
		"message": "訊息",
		"messageXSetting": "訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"content": "輸入此訊息的內容。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"contentIsEmpty": "內容不能為空白。"
		}
	},
	"html/desktop/home/advanced.htm": {
		"advancedSettingPage": "進階功能設定頁面",
		"internalRegisterDescription": "內部暫存器(Internal register)可做為暫存的變數，可透過Modbus address來讀取或設定內部暫存器變數值，亦可作為IF判斷條件及THEN/ELSE執行動作，可進行四則運算。",
		"timerDescription": "計時器(Timer)提供 逾時/未逾時 的判斷條件功能，讓使用者可編輯需搭配時間排程的工作邏輯；也提供了即時地重置/啟動計時器的功能，讓IF-THEN-ELSE工作邏輯在時間排程的管控上更加有彈性。",
		"scheduleDescription": "排程(Schedule)功能可用以執行規律性的日期排程任務。排程功能提供了萬年曆的日期點選介面及週期性的執行設定，以供使用者設計出更加靈活彈性的日期排程。",
		"emailDescription": "電子郵件(Email)發送功能可於特殊事件發生時，傳送預先設定的電子郵件至特定收件者的電子郵件信箱，快速地將即時訊息傳遞給相關人員。信件內容可包含即時的I/O通道資訊，使用者可隨時掌握系統狀況。",
		"cgiDescription": "CGI命令功能包含傳送與接收兩部分，使用者可設定多個CGI伺服器及所欲傳送的CGI命令，將傳送的動作編入工作邏輯中；或是分析接收到的CGI命令內容，作為邏輯的條件判斷，即時地與安全監控系統進行互動。",
		"smsDescription": "SMS功能提供使用者將SMS警報發送動作編入工作邏輯當中，即可於預定事件發生時傳遞即時訊息與相關人員，且也可接收特定手機傳送的簡訊命令，具備即時通道數據查詢及通道數據修改的功能。",
		"statusDescription": "即時資訊顯示設定功能提供使用者自行編排模組通道資訊顯示頁面，可將位於不同模組的通道資訊集中於自定頁面中。",
		"hmiDescription": "Flash HMI 編輯器提供管理者透過豐富的Flash圖形元件，可以快速的設計HMI人機介面，以建立現場設備資訊的監控頁面。",
		"snmpTrapDescription": "SNMP Trap功能能夠在特殊事件發生時，主動將通道等數據即時地發送至遠端SNMP Manager上，讓SNMP Manager進行相對應的處理。",
		"pueDescription": "提供使用者計算機房等設施的能源使用效率，此數值亦可作為IF判斷條件。",
		"lineNotifyDescription": "LINE Notify發送功能可於發生特殊事件時，主動將訊息推撥至手機上的LINE App中。",
		"messengerDescription": "Messenger發送功能可於發生特殊事件時，主動將訊息推撥至手機上的Messenger App中。",
        "weChatDescription": "微信發送功能可於發生特殊事件時，主動將訊息推撥至手機上的微信App企業應用中。",
		"pingDescription": "Ping功能允許使用者透過ICMP封包來監控PMC或遠端設備的連線狀況，當網路不穩或是斷線時進行對應的處理。"
	},
	"html/desktop/home/advanced/menu.htm": {
		"internalRegisterSetting": "內部暫存器設定",
		"timerSetting": "計時器設定",
		"scheduleSetting": "排程設定",
		"emailSetting": "電子郵件設定",
		"cgiCommandSetting": "CGI命令設定",
		"smsSetting": "SMS簡訊設定",
		"statusSetting": "即時資訊顯示設定",
		"hmiSetting": "Flash HMI設定",
		"snmpTrapSetting": "SNMP Trap設定",
		"lineNotifySetting": "LINE Notify設定",
		"messengerSetting": "Messenger設定",
        "weChatSetting": "微信設定",
		"pingSetting": "Ping設定"
	},
	"html/desktop/home/advanced/register.htm": {
		"internalRegisterSettingPage": "內部暫存器設定頁面",
		"no": "編號",
		"initialValue": "初始值",
		"noInternalRegisterExistClickThisButtonToAdd": "無設定內部暫存器，請按此按鈕新增。",
		"copy": "複製",
		"remove": "移除",
		"internalRegister": "內部暫存器",
		"retainVariable": "斷電保持",
		"popup": {
			"reachMaximumAmount": "達到最大數量。"
		}
	},
	"html/desktop/home/advanced/register/setting.htm": {
		"internalRegisterXSetting": "內部暫存器 $name 設定",
		"no": "編號",
		"initialValue": "初始值",
		"equationSetting": "方程式設定",
		"functionStatus": "功能狀態",
		"expressionContent": "方程式內容",
		"insert": "插入",
		"supportFollowingOperator": "支援以下運算子：",
		"plusDescription": "加號",
		"minusDescription": "減號",
		"timesDescription": "乘號",
		"divideDescription": "除號",
		"superscriptDescription": "次方",
		"parenthesisDescription": "括號",
		"expressionVerification": "試算",
		"verifying": "試算",
		"verifySuccessfully": "試算成功。",
		"verifyFailed": "試算失敗。",
		"tip": {
			"no": "內部暫存器的編號。",
			"nickname": "輸入對此內部暫存器的名稱。",
			"description": "輸入對此內部暫存器的說明。",
			"initialValue": "輸入此內部暫存器的初始值。",
			"functionStatus": "勾選'啟用'以啟用內部暫存器的方程式功能。",
			"expressionContent": "輸入此內部暫存器的方程式內容。",
			"expressionVerification": "按下驗證後，系統會檢查您輸入的方程式內容是否正確，並將結果顯示於畫面中。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"expressionIsEmpty": "方程式內容不能為空白。"
		}
	},
	"html/desktop/home/advanced/timer.htm": {
		"timerSettingPage": "計時器設定頁面",
		"timer": "計時器",
		"initialStatus": "初始狀態",
		"period": "時間長度",
		"stop": "停止",
		"start": "啟動",
		"assignPeriod": "指定時間",
		"internalRegister": "內部暫存器",
		"no": "編號",
		"alreadyRemove": "(已被移除)",
		"noTimerExistClickThisButtonToAdd": "無設定計時器，請按此按鈕新增。",
		"copy": "複製",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "達到最大數量。",
			"someoneTimerUseAlreadyRemovedRegister": "不可將已被移除的內部暫存器數值設為計時器時間長度的參考。"
		}
	},
	"html/desktop/home/advanced/timer/setting.htm": {
		"timerXSetting": "計時器 $name 設定",
		"initialStatus": "初始狀態",
		"period": "時間長度",
		"stop": "停止",
		"start": "啟動",
		"assignPeriod": "指定時間",
		"internalRegister": "內部暫存器",
		"no": "編號",
		"tip": {
			"nickname": "輸入對此計時器的名稱。",
			"description": "輸入對此計時器的說明。",
			"initialStatus": "設定當控制器啟動時，此計時器的初始狀態。",
			"period": "輸入此計時器的時間長度。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。"
		}
	},
	"html/desktop/home/advanced/schedule.htm": {
		"scheduleSettingPage": "排程設定頁面",
		"mode": "模式",
		"calendar": "萬年曆型",
		"repeat": "週期型",
		"createNewOne": "新增排程",
		"copy": "複製",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "達到最大數量。"
		}
	},
	"html/desktop/home/advanced/schedule/setting.htm": {
		"scheduleXSetting": "排程 $name 設定",
		"schedule": "排程",
		"scheduleDetailSetting": "排程內容設定",
		"initialStatus": "初始狀態",
		"mode": "模式",
		"calendar": "萬年曆型",
		"repeat": "週期型",
		"date": "日期",
		"startMonth": "起始月份",
		"duration": "月份長度",
		"month": "個月",
		"day": "星期",
		"exceptionDate": "例外日期",
		"timeRange": "時間範圍",
		"add": "新增",
		"remove": "移除",
		"selectAll": "全部選取",
		"unSelectAll": "清除選取",
		"selectWeekday": "工作日",
		"selectWeekend": "週末",
		"inRange": "範圍內",
		"outOfRange": "範圍外",
		"tip": {
			"nickname": "輸入對此排程的名稱。",
			"description": "輸入對此排程的說明。",
			"initialStatus": "設定當控制器啟動時，此排程的初始狀態。",
			"mode": "選擇排程的運作模式：萬年曆型可針對一年內的所有日期作個別設定，週期型則是以'週'為單位，在勾選'週'內的特定日期後進行作週期性的運作。",
			"calendarDate": "設定排程的日期範圍。",
			"day": "勾選設定每週中的排程日期。",
			"exceptionDate": "設定週期性排程中的例外日期，週期性排程會略過所指定的例外日期。",
			"timeRange": "設定排程中的時間區間。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"selectAtLeastOneDate": "請至少選擇一個排程內的日期。",
			"selectAtLeastOneDay": "請至少在一週當中選擇一天。",
			"selectAtLeastOneTimeRange": "請至少設定一組時間範圍。",
			"startTimeIsSameWithEndTime": "起始時間不能與結束時間相同。",
			"timeRangeIsOverlap": "時間範圍不能重疊。"
		}
	},
	"html/desktop/home/advanced/email.htm": {
		"emailSettingPage": "電子郵件設定頁面",
		"subject": "主旨",
		"receiver": "收件者",
		"createNewOne": "新增電子郵件",
		"copy": "複製",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "達到最大數量。"
		}
	},
	"html/desktop/home/advanced/email/setting.htm": {
		"emailXSetting": "電子郵件 $name 設定",
		"email": "電子郵件",
		"smtpServerSetting": "SMTP伺服器設定",
		"smtpServer": "SMTP伺服器位址",
		"specifySMTPServer": "指定SMTP伺服器位址",
		"port": "連接埠",
		"authentication": "帳號驗證",
		"id": "帳號",
		"password": "密碼",
		"security": "安全性",
		"noSecurity": "無加密",
		"emailAddressSetting": "電子郵件位址設定",
		"senderName": "寄件者名稱",
		"senderEmail": "寄件者電子郵件",
		"receiverEmail": "收件者電子郵件",
		"add": "新增",
		"remove": "移除",
		"emailSettingTest": "電子郵件設定測試",
		"send": "傳送",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"emailContenttSetting": "電子郵件內容設定",
		"subject": "主旨",
		"content": "內文",
		"insert": "插入",
		"tip": {
			"nickname": "輸入對此電子郵件的名稱。",
			"description": "輸入對此電子郵件的說明。",
			"smtpServer": "輸入SMTP伺服器位址。",
			"port": "輸入SMTP伺服器連接埠。",
			"authentication": "若SMTP伺服器不允許匿名，請勾選啟用帳號驗證並輸入帳號資訊。",
			"id": "輸入登入帳號。",
			"password": "輸入登入密碼。",
			"security": "設定SMTP伺服器的加密方式。",
			"senderName": "輸入寄件者名稱。",
			"senderEmail": "輸入寄件者電子郵件地址。",
			"receiverEmail": "輸入收件者電子郵件地址。",
			"emailSettingTest": "按下傳送後，系統將會依據您的設定，發送一封測試郵件到第一位收件者的電子郵件信箱中。",
			"emailSubject": "輸入此電子郵件主旨。",
			"emailContent": "輸入電子郵件本文內容。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"smtpServerIsEmpty": "SMTP伺服器位址不能為空白。",
			"idIsEmpty": "帳號不能為空白。",
			"senderNameIsEmpty": "寄件者名稱不能為空白。",
			"senderEmailIsEmpty": "寄件者電子郵件地址不能為空白。",
			"receiverEmailIsEmpty": "收件者電子郵件地址個數必須大於或等於1個。",
			"subjectIsEmpty": "主旨不能為空白。",
			"contentIsEmpty": "內文不能為空白。"
		}
	},
	"html/desktop/home/advanced/cgi.htm": {
		"cgiCommandSettingPage": "CGI命令設定頁面",
		"sendSetting": "傳送設定",
		"receiveSetting": "接收設定",
		"cgiServerAddress": "CGI伺服器位址",
		"port": "連接埠",
		"commandNumber": "命令個數",
		"createNewOne": "新增CGI伺服器",
		"noCGIServerExist": "無設定CGI伺服器。",
		"copy": "複製",
		"remove": "移除",
		"variableName": "參數名稱",
		"sourceAddress": "來源位址",
		"cgiVariableQueryExample": "CGI參數查詢範例",
		"cgiVariable": "CGI參數",
		"cgiSource": "CGI來源",
		"add": "新增",
		"noVariableNameExist": "無設定參數名稱。",
		"noSourceAddressExist": "無設定來源位址。",
		"tip": {
			"variableName": "輸入參數名稱。一組參數是由名稱與數值所組成，該名稱所對應的數值可用於IF條件中。",
			"sourceAddress": "輸入來源位址。該來源位址可用於IF條件中，用來篩選來自特定位址的CGI命令。"
		},
		"popup": {
			"variableNameIsEmpty": "參數名稱不能為空。",
			"variableNameIsDuplicate": "參數名稱不能重複。",
			"sourceAddressIsEmpty": "來源位址不能為空。",
			"sourceAddressIsDuplicate": "來源位址不能重複。"
		}
	},
	"html/desktop/home/advanced/cgi/server.htm": {
		"cgiServerAddress": "CGI伺服器位址",
		"port": "連接埠",
		"authentication": "帳號驗證",
		"type": "認證類型",
		"id": "帳號",
		"password": "密碼",
		"retryTimes": "重試次數",
		"times": "次",
		"fileTransfer": "檔案傳輸",
		"createFTPServer": "新增FTP伺服器",
		"cgiCommandSetting": "CGI命令設定",
		"cgiMethod": "CGI命令方法",
		"cgiCommand": "CGI命令",
		"createNewOne": "新增CGI命令",
		"noCGICommandExist": "無設定CGI命令。",
		"copy": "複製",
		"remove": "移除",
		"cgiServer": "CGI伺服器",
		"cgiServerXSetting": "CGI伺服器 $name 設定",
		"tip": {
			"nickname": "輸入此CGI伺服器的名稱。",
			"description": "輸入此CGI伺服器的說明。",
			"cgiServerAddress": "輸入此CGI伺服器的位址。",
			"port": "輸入此CGI伺服器的連接埠。",
			"authentication": "若您的CGI伺服器要求認證，請勾選'啟用'以啟用帳號驗證功能。",
			"type": "設定此CGI伺服器認證類型。",
			"id": "輸入此CGI伺服器的認證帳號。",
			"password": "輸入此CGI伺服器的認證密碼。",
			"retryTimes": "輸入當此CGI命令發送失敗時，重新嘗試發送的次數。",
			"fileTransfer": "設定相關儲存檔案所欲上傳的遠端FTP伺服器。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"cgiServerAddressIsEmpty": "CGI伺服器位址不能為空白。",
			"idIsEmpty": "帳號不能為空白。",
			"commandIsEmpty": "CGI命令個數必須大於或等於1個。"
		}
	},
	"html/desktop/home/advanced/cgi/server/command.htm": {
		"cgiMethod": "CGI命令方法",
		"cgiCommand": "CGI命令",
		"cgiContent": "CGI命令內容",
		"insert": "插入",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"responseContentSetting": "回應內容設定",
		"saveAsFile": "儲存成檔案",
		"savePath": "儲存路徑",
		"fileName": "檔名",
		"yyyyDescription": "四位數西元年。",
		"HHDescription": "時，數值從00到23。",
		"MMDescription": "月，數值從01到12。",
		"mmDescription": "分，數值從00到59。",
		"ddDescription": "日，數值從01到31。",
		"ssDescription": "秒，數值從00到59。",
		"sendBackViaEmail": "透過電子郵件寄出",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"cgiCommandXSetting": "CGI命令 $name 設定",
		"tip": {
			"nickname": "輸入此CGI命令的名稱。",
			"description": "輸入此CGI命令的說明。",
			"cgiMethod": "設定此CGI命令發送的方法。",
			"cgiCommand": "輸入此CGI命令發送的位置。",
			"cgiContent": "輸入此CGI命令發送的內容。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試傳送一個CGI命令至您設定的伺服器上，以確定設定正確。",
			"saveAsFile": "勾選「啟用」可將CGI回應的內容儲存成檔案。",
			"savePath": "輸入檔案儲存於microSD卡的路徑。",
			"fileName": "輸入檔案的檔名。若您沒有輸入副檔名，系統會嘗試以CGI回應的Content-Type來決定副檔名。",
			"sendBackViaEmail": "設定CGI回應存檔後，檔案立即透過所選的電子郵件設定寄出。",
			"setupEmailFirst": "請先設定電子郵件。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"cgiCommandIsEmpty": "CGI命令內容不能為空白。",
			"fileNameIsEmpty": "檔名不能為空白。",
			"fileNameIsInvalid": "檔名不能為index或default。"
		}
	},
	"html/desktop/home/advanced/sms.htm": {
		"smsSettingPage": "SMS簡訊設定頁面",
		"smsAlarm": "SMS簡訊警報",
		"smsCommand": "SMS簡訊命令",
		"pinCode": "PIN碼",
		"smsCommandFunction": "SMS簡訊命令功能",
		"authorizedPhoneNumbers": "授權手機號碼",
		"add": "新增",
		"copy": "複製",
		"remove": "移除",
		"smsAlarmsList": "SMS簡訊警報列表",
		"phoneNumbers": "電話號碼",
		"message": "訊息",
		"createNewSMSAlarm": "新增SMS簡訊警報",
		"smsCommandsList": "SMS簡訊命令列表",
		"command": "命令",
		"commandString": "命令字串",
		"createNewSMSCommand": "新增SMS簡訊命令",
		"tip": {
			"pinCode": "輸入SIM卡設定的PIN碼。",
			"smsCommandFunction": "設定是否開啟SMS簡訊命令功能。",
			"authorizedPhoneNumbers": "設定允許發送SMS簡訊命令的手機門號，系統只會接受來自這些門號的命令。門號必須包含除了國際冠碼以外的所有號碼。"
		},
		"popup": {
			"reachMaximumAmount": "達到最大數量。",
			"authorizedPhoneNumbersIsEmpty": "授權手機號碼的個數必須大於或等於1個。"
		}
	},
	"html/desktop/home/advanced/sms/alarms.htm": {
		"smsAlarmXSetting": "SMS簡訊警報 $name 設定",
		"smsAlarm": "SMS簡訊警報",
		"phoneNumbers": "電話號碼",
		"add": "新增",
		"remove": "移除",
		"message": "訊息",
		"unicode": "多國語言支援(Unicode)",
		"insert": "插入",
		"tip": {
			"nickname": "輸入對此SMS簡訊警報的名稱。",
			"description": "輸入對此SMS簡訊警報的說明。",
			"phoneNumbers": "輸入接收SMS簡訊警報的手機號碼。",
			"unicode": "若訊息中使用了非英文或數字的字元時，請勾選此選項。",
			"message": "輸入SMS簡訊警報訊息內容。單封SMS簡訊最大訊息長度為160個字元，使用Unicode時最大訊息長度為70個字元。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"phoneNumbersIsEmpty": "電話號碼的個數必須大於或等於1個。",
			"messageIsEmpty": "訊息不能為空白。"
		}
	},
	"html/desktop/home/advanced/sms/quickcommands.htm": {
		"smsCommandSetting": "SMS簡訊命令設定",
		"command": "命令",
		"commandString": "命令字串編輯器",
		"insert": "插入",
		"value": "數值",
		"none": "無",
		"tip": {
			"command": "輸入簡短的命令。",
			"commandString": "設定欲取代的命令字串。"
		},
		"popup": {
			"quickCommandIsEmpty": "命令不能為空白。",
			"originalCommandIsEmpty": "命令字串不能為空白。",
			"quickCommandIsUsed": "命令已經被使用過。"
		}
	},
	"html/desktop/home/advanced/status.htm": {
		"customizeStatusSetting": "即時資訊顯示設定頁面",
		"groupAmount": "群組數量",
		"createNewOne": "新增資訊顯示頁面",
		"copy": "複製",
		"remove": "移除",
		"popup": {
			"reachMaximumAmount": "達到最大數量。"
		}
	},
	"html/desktop/home/advanced/status/setting.htm": {
		"customizeStatusXSetting": "即時資訊顯示 $name 設定",
		"customizeStatus": "即時資訊顯示",
		"createNewGroup": "新增群組",
		"addStatus": "新增通道資料",
		"none": "無",
		"internalRegister": "內部暫存器",
		"source": "來源",
		"module": "模組",
		"channel": "通道",
		"no": "編號",
		"add": "新增",
		"group": "群組",
		"tip": {
			"nickname": "輸入對此資訊顯示頁面的名稱。",
			"description": "輸入對此資訊顯示頁面的說明。"
		},
		"popup": {
			"reachMaximumAmount": "達到最大數量。",
			"nicknameIsEmpty": "名稱不能為空白。"
		}
	},
	"html/desktop/home/advanced/hmi.htm": {
		"loadingFlashPlayer": "載入Flash HMI Tools中，請稍候。",
		"popup": {
			"loadFlashPlayerFailed": "Flash HMI Tools載入錯誤，請檢查Flash Player的狀態。",
			"flashPlayerVersionTooOld": "Flash Player的版本過舊，請更新Flash Player。"
		}
	},
	"html/desktop/home/advanced/snmp.htm": {
		"snmpTrapSettingPage": "SNMP Trap設定頁面",
		"specificTrapID": "Specific ID",
		"messageNumber": "變數綁定數量",
		"noSNMPTrapExistClickThisButtonToAdd": "無設定SNMP Trap，請按此按鈕新增。",
		"copy": "複製",
		"remove": "移除",
		"snmpTrap": "SNMP Trap",
		"popup": {
			"messageNumberIsZero": "SNMP Trap的變數綁定數量必須大於或等於1。"
		}
	},
	"html/desktop/home/advanced/snmp/message.htm": {
		"specificTrapID": "Specific ID",
		"snmpTrapMessageList": "SNMP Trap變數綁定列表",
		"content": "內容",
		"format": "格式",
		"createNewMessage": "新增變數綁定",
		"copy": "複製",
		"remove": "移除",
		"snmpTrapXSetting": "SNMP Trap $name 設定",
		"tip": {
			"nickname": "輸入此SNMP Trap的名稱。",
			"description": "輸入此SNMP Trap的說明。",
			"specificTrapID": "輸入此SNMP Trap的Specific ID。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"messageNumberIsZero": "SNMP Trap變數綁定數量必須大於或等於1。"
		}
	},
	"html/desktop/home/advanced/snmp/message/setting.htm": {
		"snmpTrapMessageSettingPage": "SNMP Trap變數綁定設定頁面",
		"type": "類型",
		"channelData": "通道資料",
		"userDefinedData": "自訂資料",
		"format": "格式",
		"insert": "插入",
		"none": "無",
		"tip": {
			"type": "設定變數綁定的類型。",
			"channelData": "選擇作為綁定變數的通道。",
			"format": "設定通道資料的型態。",
			"userDefinedData": "輸入欲作為變數綁定的自訂資料。"
		},
		"popup": {
			"noAvailableChannelData": "無可用的通道資料。請先新增至少一個模組或內部暫存器。",
			"userDefinedDataIsEmpty": "自訂資料不能為空白。"
		}
	},
	"html/desktop/home/advanced/linenotify.htm": {
		"lineNotifyMessageSettingPage": "LINE Notify訊息設定頁面",
		"lineNotifyCameraSettingPage": "LINE Notify與網路攝影機連動設定頁面",
		"lineNotifyChatRoomSettingPage": "LINE Notify聊天室設定頁面",
		"message": "訊息",
		"ipCamera": "網路攝影機",
		"chatRoom": "聊天室",
		"content": "內容",
		"chatRoomNumber": "聊天室數量",
		"createNewMessage": "新增訊息",
		"noMessageExist": "無設定訊息。",
		"copy": "複製",
		"remove": "移除",
		"functionStatus": "功能狀態",
		"noCameraExist": "無設定網路攝影機",
		"type": "類型",
		"accessToken": "存取權杖",
		"createNewChatRoom": "新增聊天室",
		"noChatRoomExist": "無設定聊天室。",
		"oneOnOne": "1對1",
		"group": "群組",
		"popup": {
			"someMessageNoChatRoom": "部分訊息未指定任何聊天室。"
		}
	},
	"html/desktop/home/advanced/linenotify/message.htm": {
		"content": "內容",
		"insert": "插入",
		"chatRoom": "聊天室",
		"createNewChatRoom": "新增聊天室",
		"unSelectAll": "全不選",
		"selectAll": "全選",
		"message": "訊息",
		"messageXSetting": "訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"content": "輸入此訊息的內容。",
			"chatRoom": "設定訊息欲傳送到的聊天室。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"contentIsEmpty": "內容不能為空白。",
			"chatRoomIsEmpty": "聊天室不能為空，請至少選擇一個聊天室。"
		}
	},
	"html/desktop/home/advanced/linenotify/chatroom.htm": {
		"type": "類型",
		"accessToken": "存取權杖",
		"oneOnOne": "1對1",
		"group": "群組",
		"chatRoomXSetting": "聊天室 $name 設定",
		"tip": {
			"nickname": "輸入此聊天室的名稱。",
			"description": "輸入此聊天室的說明。",
			"type": "此聊天的類型。",
			"accessToken": "此聊天室的存取權杖。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。"
		}
	},
	"html/desktop/home/advanced/messenger.htm": {
		"message": "訊息",
		"ipCamera": "網路攝影機",
		"cgiServer": "CGI伺服器",
		"messengerSettingPage": "Messenger設定頁面",
		"functionStatus": "功能狀態",
		"token": "粉絲專頁權杖",
		"tokenDescription": "位於『我的應用程式 > 產品 > Messenger > 設定』中。",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"messageList": "訊息列表",
		"content": "內容",
		"noMessageExist": "無設定訊息。",
		"createNewMessage": "新增訊息",
		"messengerDisable": "Messenger已停用",
		"copy": "複製",
		"remove": "移除",
		"messengerCameraSettingPage": "Messenger與網路攝影機連動設定頁面",
		"camera": "網路攝影機",
		"messengerCGIServerSettingPage": "Messenger與CGI伺服器連動設定頁面",
		"cgiServer": "CGI伺服器",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用Messenger功能。",
			"token": "輸入粉絲專頁的權杖。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，發送一則測試訊息到Messenger中。"
		},
		"popup": {
			"tokenIsEmpty": "粉絲專頁權杖不能為空白。",
			"someCameraEnableButMessengerDisable": "部分網路攝影機與已停用的Messageer設定進行了連動。",
			"someCGIServerEnableButMessengerDisable": "部分CGI伺服器與已停用的Messageer設定進行了連動。"
		}
	},
	"html/desktop/home/advanced/messenger/message.htm": {
		"content": "內容",
		"insert": "插入",
		"message": "訊息",
		"messageXSetting": "訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"content": "輸入此訊息的內容。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"contentIsEmpty": "內容不能為空白。"
		}
	},
	"html/desktop/home/advanced/wechat.htm": {
		"message": "訊息",
		"ipCamera": "網路攝影機",
		"cgiServer": "CGI伺服器",
		"weChatSettingPage": "微信設定頁面",
		"functionStatus": "功能狀態",
		"corpIdDescription": "位於『我的企業 > 企業訊息』中。",
		"agentIdDescription": "位於『企業應用 > 自建應用』中。",
		"secretDescription": "位於『企業應用 > 自建應用』中。",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"messageList": "訊息列表",
		"content": "內容",
		"noMessageExist": "無設定訊息。",
		"createNewMessage": "新增訊息",
		"copy": "複製",
		"remove": "移除",
		"weChatCameraSettingPage": "微信與網路攝影機連動設定頁面",
		"moduleNameOrNickname": "型號 / 名稱",
		"ipAndPort": "IP與連接埠",
		"weCharCGIServerSettingPage": "微信與CGI伺服器連動設定頁面",
		"name": "名稱",
		"serverAddressAndPort": "伺服器位址與連接埠",
		"tip": {
			"functionStatus": "勾選'啟用'以啟用微信功能。",
			"corpId": "輸入企業訊息中的CorpID。",
			"agentId": "輸入自建應用中的AgentId。",
			"secret": "輸入自建應用中的Secret。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，發送一則測試訊息到微信App企業應用中。"
		},
		"popup": {
			"corpIdIsEmpty": "CorpID不能為空白。",
			"agentIdIsEmpty": "AgentId不能為空白。",
			"secretIsEmpty": "Secret不能為空白。",
			"messageIsEmpty": "訊息個數必須大於或等於1個。"
		}
	},
	"html/desktop/home/advanced/wechat/message.htm": {
		"content": "內容",
		"insert": "插入",
		"message": "訊息",
		"messageXSetting": "訊息 $name 設定",
		"tip": {
			"nickname": "輸入此訊息的名稱。",
			"description": "輸入此訊息的說明。",
			"content": "輸入此訊息的內容。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"contentIsEmpty": "內容不能為空白。"
		}
	},
	"html/desktop/home/advanced/ping.htm": {
		"pingSettingPage": "Ping設定頁面",
		"target": "目標",
		"timeout": "逾時時間(毫秒)",
		"interval": "間隔時間(秒)",
		"createNewOne": "新增Ping",
		"noPingExist": "無設定Ping。",
		"copy": "複製",
		"remove": "移除"
	},
	"html/desktop/home/advanced/ping/setting.htm": {
		"pingXSetting": "Ping $name 設定",
		"pingAttributeSetting": "Ping參數設定",
		"target": "目標",
		"timeout": "逾時時間",
		"interval": "間隔時間",
		"failCondition": "失敗條件",
		"continuousFailedXTimes": "連續失敗達 $inputFail 次",
		"accumulatedFailedXTimesNearYTest": "近 $inputTest 次測試中，累積失敗達 $inputFail 次",
		"pingTesting": "Ping測試",
		"ping": "Ping",
		"pingSuccessfully": "Ping成功。",
		"pingFailed": "Ping失敗。",
		"responseTime": "回應時間：",
		"tip": {
			"nickname": "輸入此Ping的名稱。",
			"description": "輸入此Ping的說明。",
			"target": "輸入此Ping的目標。",
			"timeout": "輸入此Ping的測試逾時時間。",
			"interval": "輸入此Ping的測試間隔時間。",
			"failCondition": "設定此Ping的失敗條件。當此條件成立後，可以在IF-THEN-ELSE中觸發動作。",
			"pingTesting": "按下Ping後，系統將會依據您的設定，嘗試傳送一個Ping封包至您設定的目標上，以確定設定正確。"
		},
		"popup": {
			"targetIsEmpty": "目標不能為空白。",
			"failedTimeGreaterThenTestTimes": "累積失敗次數不能大於測試次數。"
		}
	},
	"html/desktop/home/rules.htm": {
		"ruleOverview": "規則總覽",
		"noRuleExist": "無設定規則，請嘗試點選左邊的按鈕以新增一條規則。",
		"noCondition": "無條件",
		"noAction": "無動作",
		"delayXSecond": "延遲$delay秒"
	},
	"html/desktop/home/rules/menu.htm": {
		"addRule": "新增規則",
		"moveUp": "上移",
		"moveDown": "下移",
		"remove": "移除",
		"copy": "複製",
		"popup": {
			"reachMaximumAmount": "達到最大數量。"
		}
	},
	"html/desktop/home/rules/rule.htm": {
		"ruleInfomationSetting": "規則資訊設定",
		"rule": "規則",
		"status": "狀態",
		"ruleContentSetting": "規則內容設定",
		"addCondition": "新增判斷條件:",
		"noCondition": "無判斷條件",
		"addAction": "新增執行動作:",
		"noAction": "無執行動作",
		"selectCondition": "選擇判斷條件",
		"selectAction": "選擇執行動作",
		"oneTimeAction": "單次性動作",
		"repaetAction": "重複性動作",
		"delayXSecondAfterExecution": "執行後延遲$delay秒。",
		"setting": "設定",
		"copy": "複製",
		"remove": "移除",
		"tip": {
			"nickname": "輸入對此規則的名稱。",
			"description": "輸入對此規則的說明。",
			"status": "設定是否啟用此規則。"
		},
		"popup": {
			"reachMaximumAmount": "達到最大數量。",
			"nicknameIsEmpty": "名稱不能為空白。",
			"conditionAmountIsZero": "條件個數必須大於或等於1個。",
			"actionAmountIsZero": "動作個數必須大於或等於1個。",
			"existErrorRule": "紅色邊框的規則發生錯誤，請先修正他們。"
		}
	},
	"html/desktop/home/rules/rule/cai.htm": {
		"aiConditionSetting": "AI條件設定",
		"moduleAndChannel": "模組與通道",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cao.htm": {
		"aoConditionSetting": "AO條件設定",
		"moduleAndChannel": "模組與通道",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cci.htm": {
		"discreteInputConditionSetting": "Discrete Input條件設定",
		"moduleAndAddress": "模組與位址",
		"status": "比較狀態",
		"tip": {
			"moduleAndAddress": "選擇模組與位址。",
			"status": "設定此位址的比較狀態，當位址狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cco.htm": {
		"coilOutputConditionSetting": "Coil Output條件設定",
		"moduleAndAddress": "模組與位址",
		"status": "比較狀態",
		"tip": {
			"moduleAndAddress": "選擇模組與位址。",
			"status": "設定此位址的比較狀態，當位址狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cdi.htm": {
		"diConditionSetting": "DI條件設定",
		"moduleAndChannel": "模組與通道",
		"status": "比較狀態",
		"tip": {
			"moduleAndChannel": "選擇模組與通道。",
			"status": "設定此通道的比較狀態，當通道狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cdic.htm": {
		"diCounterConditionSetting": "DI計數器條件設定",
		"moduleAndChannel": "模組與通道",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cdo.htm": {
		"doConditionSetting": "DO條件設定",
		"moduleAndChannel": "模組與通道",
		"status": "比較狀態",
		"tip": {
			"moduleAndChannel": "選擇模組與通道。",
			"status": "設定此通道的比較狀態，當通道狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cregister.htm": {
		"registerConditionSetting": "內部暫存器條件設定",
		"no": "編號",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cri.htm": {
		"inputRegisterConditionSetting": "Input Register條件設定",
		"moduleAndAddress": "模組與位址",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cro.htm": {
		"holdingRegisterConditionSetting": "Holding Register條件設定",
		"moduleAndAddress": "模組與位址",
		"operator": "運算子",
		"value": "比較數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cstatus.htm": {
		"connectionStatusConditionSetting": "模組連線狀態條件設定",
		"status": "狀態",
		"module": "模組",
		"tip": {
			"module": "選擇模組。",
			"status": "設定此模組的比較狀態，當連線狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/crule.htm": {
		"ruleStatusConditionSetting": "規則狀態條件設定",
		"rule": "規則",
		"status": "狀態",
		"tip": {
			"rule": "選擇已設定之規則。",
			"status": "使用規則之執行狀態作為條件，當所選擇之規則狀態與此設定相符則條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cschedule.htm": {
		"scheduleConditionSetting": "排程條件設定",
		"schedule": "排程",
		"status": "狀態",
		"tip": {
			"schedule": "選擇已設定之排程。",
			"status": "以目前的時間在此排程的範圍內或範圍外來做為條件。"
		}
	},
	"html/desktop/home/rules/rule/csdcard.htm": {
		"sdCardStatusConditionSetting": "SD卡狀態條件設定",
		"status": "狀態",
		"tip": {
			"status": "以SD卡目前的狀態來做為條件。"
		}
	},
	"html/desktop/home/rules/rule/ctimer.htm": {
		"timerConditionSetting": "計時器條件設定",
		"timer": "計時器",
		"status": "狀態",
		"tip": {
			"timer": "選擇已設定之計時器。",
			"status": "以此計時器目前的計時狀態來做為條件。"
		}
	},
	"html/desktop/home/rules/rule/ccgi.htm": {
		"cgiCommandConditionSetting": "CGI命令條件設定",
		"nameAndAddress": "名稱與位址",
		"variableName": "參數名稱",
		"sourceAddress": "來源位址",
		"anywhere": "任何地方",
		"operator": "運算子",
		"value": "比較數值",
		"bit": "位元"
	},
	"html/desktop/home/rules/rule/cazurestatus.htm": {
		"azureConnectionStatusConditionSetting": "Microsoft Azure連線狀態條件設定",
		"status": "狀態",
		"tip": {
			"status": "設定Microsoft Azure的比較狀態，當連線狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cbluemixstatus.htm": {
		"bluemixConnectionStatusConditionSetting": "IBM Bluemix連線狀態條件設定",
		"status": "狀態",
		"tip": {
			"status": "設定IBM Bluemix的比較狀態，當連線狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cbroker.htm": {
		"mqttConnectionStatusConditionSetting": "MQTT Broker連線狀態條件設定",
		"status": "狀態",
		"tip": {
			"broker": "選擇已設定之Broker。",
			"status": "設定此Broker的比較狀態，當連線狀態與比較狀態相同時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/cazuresubscribe.htm": {
		"azureSubscribeMessageConditionSetting": "Microsoft Azure接收訊息條件設定",
		"name": "名稱",
		"variableName": "參數名稱",
		"operator": "運算子",
		"value": "比較數值"
	},
	"html/desktop/home/rules/rule/cbluemixsubscribe.htm": {
		"bluemixSubscribeMessageConditionSetting": "IBM Bluemix接收訊息條件設定",
		"name": "名稱",
		"commandName": "命令名稱",
		"variableName": "參數名稱",
		"operator": "運算子",
		"value": "比較數值"
	},
	"html/desktop/home/rules/rule/ctopic.htm": {
		"mqttSubscribeTopicConditionSetting": "MQTT Subscribe Topic條件設定",
		"operator": "運算子",
		"value": "比較數值"
	},
	"html/desktop/home/rules/rule/cftp.htm": {
		"ftpUploadStatusConditionSetting": "FTP上傳狀態條件設定",
		"status": "狀態",
		"uploadFailedContinuingXHours": "上傳持續失敗 $input 小時"
	},
	"html/desktop/home/rules/rule/csignal.htm": {
		"signalStrengthConditionSetting": "行動網路訊號強度條件設定",
		"unit": "單位",
		"percent": "百分比",
		"operator": "運算子",
		"value": "比較數值",
		"bit": "位元",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/cping.htm": {
		"pingConditionSetting": "Ping條件設定",
		"ping": "Ping",
		"status": "狀態",
		"tip": {
			"ping": "選擇已設定之Ping。",
			"status": "當Ping的結果為失敗時則此條件成立。"
		}
	},
	"html/desktop/home/rules/rule/aao.htm": {
		"aoActionSetting": "AO動作設定",
		"moduleAndChannel": "模組與通道",
		"operator": "運算子",
		"value": "設定數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/aro.htm": {
		"holdingRegisterActionSetting": "Holding Register動作設定",
		"moduleAndAddress": "模組與位址",
		"operator": "運算子",
		"value": "設定數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/ado.htm": {
		"doActionSetting": "DO動作設定",
		"moduleAndChannel": "模組與通道",
		"status": "設定狀態",
		"pulseOutput": "脈衝輸出",
		"tip": {
			"moduleAndChannel": "選擇模組與通道。",
			"status": "設定通道狀態動作。"
		}
	},
	"html/desktop/home/rules/rule/adic.htm": {
		"diCounterActionSetting": "DI計數器動作設定",
		"moduleAndChannel": "模組與通道",
		"action": "動作",
		"tip": {
			"moduleAndChannel": "選擇模組與通道。",
			"action": "重置此DI通道之計數器。"
		}
	},
	"html/desktop/home/rules/rule/aco.htm": {
		"coilOutputActionSetting": "Coil Output動作設定",
		"moduleAndAddress": "模組與位址",
		"status": "設定狀態",
		"tip": {
			"moduleAndAddress": "選擇模組與位址。",
			"status": "設定位址狀態動作。"
		}
	},
	"html/desktop/home/rules/rule/aemail.htm": {
		"emailActionSetting": "電子郵件動作設定",
		"email": "電子郵件",
		"action": "動作",
		"emailInformation": "電子郵件資訊",
		"receiverEmail": "收件者電子郵件",
		"subject": "主旨",
		"content": "內文",
		"tip": {
			"email": "選擇已設定之電子郵件。",
			"action": "發送所選擇之電子郵件。"
		}
	},
	"html/desktop/home/rules/rule/acgi.htm": {
		"cgiCommandActionSetting": "CGI命令動作設定",
		"cgiCommand": "CGI命令",
		"server": "伺服器",
		"command": "命令",
		"action": "動作",
		"tip": {
			"cgiCommand": "選擇欲發送的CGI命令。",
			"action": "發送預先設定的CGI命令。"
		}
	},
	"html/desktop/home/rules/rule/atimer.htm": {
		"timerActionSetting": "計時器動作設定",
		"timer": "計時器",
		"action": "動作",
		"resetDescription": "重置代表將計時器歸零並停止計時。",
		"startDescription": "啟動代表將計時器開始(或重新)計時。",
		"pauseDescription": "暫停代表將計時器暫停計時。",
		"resumeDescription": "恢復代表將計時器恢復計時。",
		"tip": {
			"timer": "選擇已設定之計時器。",
			"action": "變更所選擇計時器之狀態。"
		}
	},
	"html/desktop/home/rules/rule/aschedule.htm": {
		"scheduleActionSetting": "排程動作設定",
		"schedule": "排程",
		"action": "動作",
		"tip": {
			"schedule": "選擇已設定之排程。",
			"action": "變更所選擇排程之執行狀態。"
		}
	},
	"html/desktop/home/rules/rule/arule.htm": {
		"ruleStatusActionSetting": "規則狀態動作設定",
		"rule": "規則",
		"action": "動作",
		"tip": {
			"rule": "選擇已設定之規則。",
			"action": "變更所選擇規則之執行狀態。"
		}
	},
	"html/desktop/home/rules/rule/aregister.htm": {
		"registerActionSetting": "內部暫存器動作設定",
		"no": "編號",
		"operator": "運算子",
		"value": "設定數值",
		"commandName": "命令名稱",
		"variableName": "參數名稱"
	},
	"html/desktop/home/rules/rule/alogger.htm": {
		"dataLoggerActionSetting": "資料記錄器動作設定",
		"action": "動作",
		"tip": {
			"action": "變更資料記錄器之狀態為進行單次記錄。"
		}
	},
	"html/desktop/home/rules/rule/asms.htm": {
		"smsAlarmActionSetting": "SMS簡訊警報動作設定",
		"smsAlarm": "SMS簡訊警報",
		"action": "動作",
		"send": "傳送",
		"smsAlarmInformation": "SMS簡訊警報資訊",
		"phoneNumbers": "電話號碼",
		"message": "訊息",
		"tip": {
			"smsAlarm": "選擇欲發送的SMS簡訊警報。",
			"action": "發送預先設定的SMS簡訊警報。"
		}
	},
	"html/desktop/home/rules/rule/asnmp.htm": {
		"snmpTrapActionSetting": "SNMP Trap動作設定",
		"trap": "Trap",
		"action": "動作",
		"send": "傳送",
		"snmpTrapInformation": "SNMP Trap資訊",
		"message": "變數綁定",
		"tip": {
			"trap": "選擇已設定之SNMP Trap。",
			"action": "發送所選擇之SNMP Trap。",
			"message": "將發送的SNMP Trap變數綁定。"
		}
	},
	"html/desktop/home/rules/rule/areboot.htm": {
		"rebootActionSetting": "重新啟動系統動作設定",
		"action": "動作",
		"reboot": "重新啟動",
		"tip": {
			"rebootSystem": "重新啟動系統。"
		}
	},
	"html/desktop/home/rules/rule/areset.htm": {
		"resetActionSetting": "重置數據機動作設定",
		"action": "動作",
		"reset": "重置",
		"tip": {
			"resetModem": "重置數據機。"
		}
	},
	"html/desktop/home/rules/rule/air.htm": {
		"infraredActionSetting": "紅外線動作設定",
		"commandAndChannel": "命令與通道",
		"command": "命令",
		"pressCtrlToMultipleSelect": "按住Ctrl可複選通道。",
		"tip": {
			"module": "選擇模組。",
			"commandAndChannel": "設定發送的命令與輸出通道。"
		},
		"popup": {
			"channelIsEmpty": "通道不能為空，請至少選擇一個通道輸出命令。"
		}
	},
	"html/desktop/home/rules/rule/aazurestatus.htm": {
		"azureFunctionStatusActionSetting": "Microsoft Azure功能狀態動作設定",
		"status": "狀態",
		"tip": {
			"status": "設定Microsoft Azure功能狀態。"
		}
	},
	"html/desktop/home/rules/rule/abluemixstatus.htm": {
		"bluemixFunctionStatusActionSetting": "IBM Bluemix功能狀態動作設定",
		"status": "狀態",
		"tip": {
			"status": "設定IBM Bluemix功能狀態。"
		}
	},
	"html/desktop/home/rules/rule/abroker.htm": {
		"mqttBrokerFunctionStatusActionSetting": "MQTT Broker功能狀態動作設定",
		"status": "狀態",
		"tip": {
			"broker": "選擇已設定之Broker。",
			"status": "設定所選擇Broker之狀態。"
		}
	},
	"html/desktop/home/rules/rule/aazurepublish.htm": {
		"azurePublishMessageActionSetting": "Microsoft Azure發佈訊息動作設定",
		"message": "訊息",
		"action": "動作",
		"publish": "發佈",
		"azurePublishMessageInformation": "Microsoft Azure發佈訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發佈所選擇之訊息。",
			"content": "將發送的訊息內容。"
		}
	},
	"html/desktop/home/rules/rule/aazuresubscribe.htm": {
		"azureResetVariableActionnSetting": "Microsoft Azure重置參數動作設定",
		"variableName": "參數名稱",
		"action": "動作",
		"tip": {
			"variableName": "選擇已設定之參數名稱。",
			"action": "重置參數之數值。"
		}
	},
	"html/desktop/home/rules/rule/abluemixpublish.htm": {
		"bluemixPublishMessageActionSetting": "IBM Bluemix發佈訊息動作設定",
		"message": "訊息",
		"action": "動作",
		"publish": "發佈",
		"bluemixPublishMessageInformation": "IBM Bluemix發佈訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發佈所選擇之訊息。",
			"content": "將發送的訊息內容。"
		}
	},
	"html/desktop/home/rules/rule/abluemixsubscribe.htm": {
		"bluemixResetVariableActionnSetting": "IBM Bluemix重置參數動作設定",
		"name": "名稱",
		"commandName": "命令名稱",
		"variableName": "參數名稱",
		"action": "動作",
		"tip": {
			"name": "選擇已設定之命令與參數名稱。",
			"action": "重置參數之數值。"
		}
	},
	"html/desktop/home/rules/rule/amessage.htm": {
		"mqttPublishMessageActionSetting": "MQTT Publish訊息動作設定",
		"message": "訊息",
		"action": "動作",
		"publish": "發佈",
		"mqttPublishMessageInformation": "MQTT Publish訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發佈所選擇之訊息。",
			"topic": "欲發送訊息所屬的Topic。",
			"content": "將發送的訊息內容。"
		}
	},
	"html/desktop/home/rules/rule/atopic.htm": {
		"mqttResetTopicActionSetting": "MQTT重置Topic動作設定",
		"action": "動作",
		"tip": {
			"topic": "選擇已設定之Topic。",
			"action": "重置Topic之數值。"
		}
	},
	"html/desktop/home/rules/rule/alinenotify.htm": {
		"lineNotifyActionSetting": "LINE Notify動作設定",
		"message": "訊息",
		"action": "動作",
		"messageInformation": "訊息資訊",
		"chatRoom": "聊天室",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發送所選擇之訊息。"
		}
	},
	"html/desktop/home/rules/rule/alinebot.htm": {
		"lineBotActionSetting": "Bot Service動作設定",
		"message": "訊息",
		"action": "動作",
		"messageInformation": "訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發送所選擇之訊息。"
		}
	},
    "html/desktop/home/rules/rule/amessenger.htm": {
		"messengerActionSetting": "Messengar動作設定",
		"message": "訊息",
		"action": "動作",
		"messageInformation": "訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發送所選擇之訊息。"
		}
	},
    "html/desktop/home/rules/rule/awechat.htm": {
		"weChatActionSetting": "微信動作設定",
		"message": "訊息",
		"action": "動作",
		"messageInformation": "訊息資訊",
		"content": "內容",
		"tip": {
			"message": "選擇已設定之訊息。",
			"action": "發送所選擇之訊息。"
		}
	},
    "html/desktop/home/rules/rule/adelay.htm": {
		"delayProcessActionSetting": "延遲動作設定",
		"action": "動作",
		"delayXSecondOrSeconds": "延遲下一動作$input秒",
		"tip": {
			"action": "輸入延遲下一動作的秒數，此秒數將影響下一個動作執行的時間點。"
		}
	},
	"html/desktop/home/status.htm": {
		"none": "無"
	},
	"html/desktop/home/status/menu.htm": {
		"internalRegister": "內部暫存器",
		"customizeStatus": "即時資訊顯示",
		"connecting": "連線中",
		"offline": "斷線",
		"online": "連線",
		"other": "其他",
		"eventLogger": "事件記錄器",
		"fileList": "檔案清單"
	},
	"html/desktop/home/status/default.htm": {
		"internalRegister": "內部暫存器",
		"no": "編號",
		"channel": "通道",
		"address": "位址",
		"counter": "計數器:",
		"none": "無",
		"diCounterX": "DI計數器$channel",
		"internalRegisterX": "內部暫存器$no"
	},
	"html/desktop/home/status/event.htm": {
		"eventLogger": "事件記錄器",
		"time": "時間",
		"type": "類型",
		"message": "訊息",
		"noEventLog": "無事件記錄。"
	},
	"html/desktop/home/status/file.htm": {
		"fileList": "檔案清單",
		"list": "清單",
		"thumbnail": "縮圖",
		"reload": "重新整理",
		"fileName": "檔名",
		"fileSize": "檔案大小",
		"time": "時間",
		"noFile": "無檔案",
		"loading": "載入中..."
	}
});