$.extend(true, Lang, {
	"js/wise/manager/linenotify/rule/object.js": {
		"send": "Send"
	}
});