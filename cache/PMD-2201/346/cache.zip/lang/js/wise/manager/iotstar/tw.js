$.extend(true, Lang, {
	"js/wise/manager/iotstar/rule/encoder.js": {
		"sendBackChannelIsEmpty": "雲端即時資料回送的通道數量不能為0個。"
	}
});