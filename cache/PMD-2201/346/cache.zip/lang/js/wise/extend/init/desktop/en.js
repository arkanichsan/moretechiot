$.extend(true, Lang, {
	"js/wise/extend/init/desktop.js": {
		"pulseOutput": "Pulse Output",
		"powerMeter": "Power Meter",
		"channel": "Channel",
		"info": "Info.",
		"ch": "Ch.",
		"item": "Item",
		"no": "No.",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message",
		"pue": "PUE",
		"all": "All"
	}
});