WISE.managers.iotstarManager.encodeXMLObject = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;

	var xmlIOTSTAR = xmlDoc.createElement("IOTSTAR");

	if(this.pool.sendback.realtime.enable == true){
		var xmlREALTIME = xmlDoc.createElement("REALTIME");
		var columnName = "", columnData = "";
		for(var i = 0; i < this.pool.sendback.realtime.columns.length; i++){
			var column = this.pool.sendback.realtime.columns[i];
			var xmlCOL = xmlDoc.createElement("COL");
			xmlCOL.setAttribute("idx", i + 1);

			if(column.channelType == "IR"){
				xmlCOL.setAttribute("b_obj", "IR");
				xmlCOL.setAttribute("b_idx", column.registerIndex + 1);

				xmlCOL.setAttribute("uid", "ir");
				xmlCOL.setAttribute("channel", "IR" + (column.registerIndex + 1));

				columnData += WISE.getVariable("register", column.registerIndex) + ",";
			}
			else{
				var moduleInfo = processModuleInfo(xmlCOL, "b", column.moduleKey);
				var moduleManager = WISE.managers.moduleManager;
				var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
				var module = moduleInfo.module;

				if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
					var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, column.channelType, column.channel);
					xmlCOL.setAttribute("b_ch", channelAddressInfo[0]);
					xmlCOL.setAttribute("b_chn", channelAddressInfo[1]);

					xmlCOL.setAttribute("uid", module.uid);
					xmlCOL.setAttribute("channel", column.channelType + column.channel);

					columnData += WISE.getVariable(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, column.channelType, column.channel) + ",";
				}
				else{
					if(typeof(module.extendedModule) != "undefined"){
						xmlCOL.setAttribute("uid", module.uid);
						this.processExtendedModuleRealTimeTag(column, xmlCOL);

						columnData += this.encodeXMLObject.processExtendedModuleRule(column, xmlCOL) + ",";
					}
					else{
						if(column.channelType == "DIC"){
							xmlCOL.setAttribute("b_ch", "DI");
							xmlCOL.setAttribute("b_cnt", "1");
						}
						else{
							xmlCOL.setAttribute("b_ch", column.channelType);
						}

						xmlCOL.setAttribute("b_chn", column.channel);

						xmlCOL.setAttribute("uid", module.uid);
						xmlCOL.setAttribute("channel", column.channelType + column.channel);

						columnData += WISE.getVariable(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, column.channelType, column.channel) + ",";
					}
				}
			}

			xmlREALTIME.appendChild(xmlCOL);

			columnName += column.name + ",";
		}

		xmlIOTSTAR.appendChild(xmlREALTIME);

		var xmlCOLNAME = xmlDoc.createElement("COLNAME");
		xmlCOLNAME.appendChild(xmlDoc.createTextNode(columnName.substring(0, columnName.length - 1)));
		xmlREALTIME.appendChild(xmlCOLNAME);

		var xmlCOLDATA = xmlDoc.createElement("COLDATA");
		xmlCOLDATA.appendChild(xmlDoc.createTextNode(columnData.substring(0, columnData.length - 1)));
		xmlREALTIME.appendChild(xmlCOLDATA);
	}

	if(xmlIOTSTAR.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlIOTSTAR);
				break;
			}
		}
	}
};
