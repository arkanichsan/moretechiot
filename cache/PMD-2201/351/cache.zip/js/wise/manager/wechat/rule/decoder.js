WISE.managers.weChatManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "WECHAT"){
		if(xmlDoc.tagName == "IF"){
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.message);
			ruleObject.rule.messageKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
		}
	}

	return ruleObject;
};