var Lang = {};

var languageMapping = {
	"zh": "tw",
	"zh-tw": "tw",
	"zh-hk": "tw",
	"zh-sg": "tw",
	"zh-cn": "cn"
};

var defaultLanguage = currentLanguage = languageMapping[(window.navigator.userLanguage || window.navigator.language).toLowerCase()] || "en";

function login(character, key, idleTime, language){
	currentLanguage = language;

	/*logout when unload*/
	$(window).bind("unload", {"key": key}, function(event) {
		$(window).unbind("unload");

		var key = event.data.key;

		try{
			if(WISE.getUser().key != null){
				key = WISE.getUser().key;
			}
		}
		catch(error){}

		$.ajax({
			url: "./dll/wise.dll",
			type: "POST",
			data: "<?xml version='1.0' encoding='utf-8'?><LOGOUT key='" + key + "'/>",
			contentType: "text/xml",
			processData: false,
			cache: false,
			timeout: 3000,//important
			async: false//important
		});
	});

	var aliveKeeper = new function(){//prevent load file spend too much time, send alive keep the session
		var xhr = null;
		var pid = null;
		var that = this;
		var sender = function(){
			that.stop();

			pid = setTimeout(function(){
				xhr = $.ajax({ 
					url: "./dll/wise.dll",
					type: "POST",
					data: "<?xml version='1.0' encoding='utf-8'?><ALIVE key='" + key + "'/>",
					contentType: "text/xml",
					processData: false,
					cache: false,
					dataType: "xml"
				}).always(function(){
					sender();
				});
			}, 60 * 1000);
		};

		this.start = function(){
			sender();
		};

		this.stop = function(){
			if(xhr != null){
				xhr.abort();
			}

			clearTimeout(pid);
		};
	};
	aliveKeeper.start();

	$.Deferred(function(mainDeferred){
		var fileTotalAmount = 1/*for frame.htm*/, fileLoadedAmount = 0;
		var xmlFiles = [];//for extended module setting files

		fileLoader(["./js/wise/setting/mobile.js", "?./js/wise/extend/setting/mobile.js", "?./js/wise/extend/login/base.js"]).done(function(fileContents){
			for(var i = 0; i < fileContents.length; i++){
				insertScript(fileContents[i]);
			}

			fileTotalAmount += cssFiles.length + jsFiles.length + languageFiles.length;
		}).then(function(){
			if(typeof(filterOutInuseExtendedModuleFromCommand) == "function"){
				return filterOutInuseExtendedModuleFromCommand(xmlFiles, key).done(function(){
					fileTotalAmount += xmlFiles.length;
				});
			}
		}).then(function(){//load language file
			return fileLoader(languageFiles).progress(function(loadedAmount){
				mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
			}).done(function(fileContents){
				for(var i = 0; i < fileContents.length; i++){
					insertScript(fileContents[i]);
				}

				fileLoadedAmount += fileContents.length;
			});
		}).then(function(){//load css, js, html(frame), xml
			return fileLoader(cssFiles).progress(function(loadedAmount){//load css
				mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
			}).done(function(fileContents){
				for(var i = 0; i < fileContents.length; i++){
					insertStyle(fileContents[i]);
				}

				fileLoadedAmount += fileContents.length;
			});
		}).then(function(fileContents){
			return fileLoader(jsFiles).progress(function(loadedAmount){//load js
				mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
			}).done(function(fileContents){
				for(var i = 0; i < fileContents.length; i++){
					fileContents[i] = processLanguage(fileContents[i], jsFiles[i]);
					insertScript(fileContents[i]);
				}

				fileLoadedAmount += fileContents.length;
			});
		}).then(function(fileContents){
			return fileLoader(["html/mobile/frame.htm"]).progress(function(loadedAmount){//load frame
				mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
			}).done(function(fileContents){
				fileContents[0] = processLanguage(fileContents[0], "html/mobile/frame.htm");
				insertHTML(fileContents[0]);

				fileLoadedAmount += fileContents.length;
			});
		}).then(function(fileContents){
			return fileLoader(xmlFiles, true).progress(function(loadedAmount){//load xml
				mainDeferred.notify(fileLoadedAmount + loadedAmount, fileTotalAmount);
			}).then(function(fileContents){
				if(typeof(WISE.managers.moduleManager.processExtendedModuleSettingFile) == "function"){
					var xmlDocArray = [];
					for(var i = 0; i < fileContents.length; i++){
						xmlDocArray.push(fileContents[i]);
					}

					return WISE.managers.moduleManager.processExtendedModuleSettingFile(xmlDocArray);
				}

				fileLoadedAmount += fileContents.length;
			});
		}).progress(function(fileLoadedAmount, fileTotalAmount){
			//var percent = parseInt((fileLoadedAmount) / (fileTotalAmount + 1/*1 for load rule file*/) * 100, 10);
		}).done(function(){
			mainDeferred.resolve();
		}).fail(function(){
			mainDeferred.reject();
		});

		return mainDeferred.promise();
	}).done(function(){
		//$.fx.off = true;
		WISE.initialWISE();
		WISE.setUser(character, key, idleTime);
		WISE.language = language;

		WISE.loadRuleFile({
			ignoreDefaultHandler: true,
			error: function(){
				WISE.setWISE(WISE.createWISE(wiseModelName));
			},
			complete: function(){
				aliveKeeper.stop();
				init();
			}
		});
	}).fail(function(){
		aliveKeeper.stop();

		alert(LangLogin.fileCanNotLoad[language]);
		$(window).triggerHandler("unload");
	});
}

function onSubmitLogin(showErrorMessage){
	var password = $("#loginPassword").val();
	var language = $("#loginLanguage").val();
	var remember = $("#loginRememberMe").attr("checked");

	showLoader();
	checkUsernameAndPassword(password, function(xmlDoc){
		var $xmlLOGIN = $(xmlDoc).find("LOGIN");

		if($xmlLOGIN.length > 0){
			var reply = $xmlLOGIN.attr("reply");

			if(reply != null){
				if(reply == "admin" || reply == "guest"){
					setCookie("language", language);

					if(remember){
						setCookie("password", password, 4320);
					}
					else{
						setCookie("password", "", -1);
					}

					login(reply, $xmlLOGIN.attr("key"), $xmlLOGIN.attr("keepalive"), language);

					return false;
				}
				else{
					if(reply == "occupied"){//admin
						if(showErrorMessage == true){
							alert(LangLogin.adminAlreadyLogin[language]);
						}
					}
					else if(reply == "full"){//guest
						if(showErrorMessage == true){
							alert(LangLogin.reachMaximumNumberOfLoginUser[language]);
						}
					}
					else{
						if(showErrorMessage == true){
							alert(LangLogin.passwordIncorrect[language]);
						}

						setCookie("password", "", -1);
					}
				}
			}
		}

		hideLoader();
	}, function(){
		location.reload();
	});

	return false;
}

function showLoader(){
	$("#loader").show();
}

function hideLoader(){
	$("#loader").hide();
}

function showLoginPage(){
	hideLoader();

	$("#loginPassword").val("").triggerHandler("keydown");
	$("#loginLanguage").val(getCookie("language") || defaultLanguage).triggerHandler("change");
	$("#loginRememberMe").attr("checked", false);
	$("#loginContainer").show();

	onChangeLanguage();
}

function onChangeLanguage(){
	var language = $("#loginLanguage").val();

	//$("#loginPasswordHolder").val(LangLogin.password[language]).attr("holder", LangLogin.password[language]);
	//$("#loginPassword").triggerHandler("keydown");
	$("#loginPassword").attr("placeholder", LangLogin.password[language]);
	$("#loginRememberMeText").html(LangLogin.rememberMe[language]);
	$("#loginButton").val(LangLogin.login[language]);
}

function main(){
	$.when(
		fileLoader(["css/mobile/login.css"]).done(function(fileContents){
			for(var i = 0; i < fileContents.length; i++){
				insertStyle(fileContents[i]);
			}
		}),
		fileLoader(["html/mobile/login.htm"]).done(function(fileContents){
			for(var i = 0; i < fileContents.length; i++){
				insertHTML(fileContents[i]);
			}
		})
	).done(function(){
		if(serverDown == true){//server down, show error message
			$("#loader").hide();
			alert(LangLogin.runtimeServerNotStartup[getCookie("language") || defaultLanguage]);
		}
		else{
			$("#loginLanguage").bind("change", function(){
				$("#loginLanguageText").text($(this).find("option:selected").text());
			});
/*
			$("#loginPassword").bind("keydown", function(){
				setTimeout(function(){
					if($("#loginPassword").val().length == 0){
						$("#loginPasswordHolder").val($("#loginPasswordHolder").attr("holder"));
					}
					else{
						$("#loginPasswordHolder").val("");
					}
				}, 5);
			});
*/
			$.ajax({
				type: "POST",
				cache: false,
				//url: "dll/xml/name.xml",
				url: "dll/wise.dll",
				data: "<?xml version='1.0' encoding='utf-8'?><NAME/>",
				dataType: "xml",
				success: function(xmlDoc){
					$xmlNAME = $(xmlDoc).find("NAME");
					if($xmlNAME.length > 0){
						$("#loadingLoader").hide();

						//wiseModelName = $($xmlNAME[0]).attr("type");//golable variable
						wiseModelName = {//golable variable
							"2201PMD": "PMD-2201",//remember to modify ./html/desktop/home/module/menu.htm if add other model
							"4201PMD": "PMD-4201",
							"2206PMD": "PMD-2206",
							"4206PMD": "PMD-4206"
						}[$($xmlNAME[0]).attr("type") + ($($xmlNAME[0]).attr("subtype") || "") + ($($xmlNAME[0]).attr("series") || "")];

						var name = $($xmlNAME[0]).attr("name");
						if(typeof(name) != "undefined" && name != "null" && name != ""){
							$("#loginNameHandler").show();
							$("#loginName").text(name);
						}

						//submeter_quota
						totalExtendedBonusModuleAmount = parseInt($($xmlNAME[0]).attr("submeter_quota") || 32, 10);

						//io_quota
						totalIOModuleAmount = parseInt($($xmlNAME[0]).attr("io_quota") || 8, 10);

						showLoginPage();

						// Load language setting from cookie or use default langauge
						$("#loginLanguage").val(getCookie("language") || defaultLanguage).triggerHandler("change");
						onChangeLanguage();

						// Load password setting from cookie
						var password = getCookie("password");

						// If access from cloud
						var serialNumber = location.pathname.match(/([0-9A-Za-z]{16})/);
						if(serialNumber != null){
							password = getCookie("password_" + serialNumber[1]) || password;
							setCookie("password_" + serialNumber[1], "", {expiresTime: -1, path: "/"});// Clear password pass from cloud
						}

						if(password != null){
							$("#loginPassword").val(password).triggerHandler("keydown");
							$("#loginRememberMe").attr("checked", true);

							onSubmitLogin(false);
						}
					}
					else{
						this.error();
					}
				}
			});
		}
	});
}