function init(){
	//wideScreenMode = getCookie("wideScreenMode") == "true" ? true : false;
	wideScreenMode = screen.width > 1400 ? true : false;
	$("#container").css("width", wideScreenMode == true ? wideScreenContainerWidth + "px" : normalContainerWidth + "px");
	$("#foot").html(copyRight);

	$("#loadingLoader, #loginContainer, #loadingContainer, #loginRunTimeDownContainer").remove();
	$("#container").show();

	$("#topControlBarContainer").css({"display": "", "top": $("#topControlBarContainer").outerHeight(true) * -1}).animate({
		top: 0
	});

	//ajax global setup
	$.ajaxSetup({
		cache: true,
		beforeSend: function(jqXHR, settings){
			if(typeof(debugMode) != "undefined" && debugMode == true){/*check debug mode command*/
				if(/^<\?xml /.test(settings.data) == true){
					settings.data = "!" + (typeof(settings.data) != "undefined" ? settings.data : "");
				}
			}
		},
		success: function(data, textStatus, jqXHR){
			if(this.dataType == "xml"){
				serverNoResponse = false;

				if($(data).children().attr("reply") == "kick" && $(data).children().attr("key") == WISE.getUser().key){
					if(typeof(aliveChecker) != "undefined"){//avoid receive kick when first to load rule file failed, because aliveChecker is not ready to go
						aliveChecker.stopAliveTimer();
						aliveChecker.stopIdleTimer();

						disableHash(true);
						$("#idleMessage").show(0, function(){
							$("#idleLoginPassword").focus();
						});
					}

					this.error(jqXHR, "keyerror", "Key Error");
					return;
				}
			}

			if(typeof(this.done) == "function"){
				this.done(data, textStatus, jqXHR);
			}
		},
		done: function(){},
		error: function(jqXHR, textStatus, errorThrown){
			if(jqXHR.status == 500 || (jqXHR.status == 0 && (textStatus == "timeout" || textStatus == "error"))){
				if(typeof(serverNoResponse) == "undefined" || serverNoResponse == false){
					//$(".fixedDiv").hide();//hide all popup message
					insertMessage(LangLogin.runtimeServerNoResponse[WISE.language], 1);
					popupErrorWindow(LangLogin.runtimeServerNoResponse[WISE.language]);
				}

				serverNoResponse = true;
				//return;
			}
			else if(jqXHR.status == 404){
				popupErrorWindow(LangLogin.fileNotFound[WISE.language]);
			}

			if(typeof(this.fail) == "function"){
				this.fail(jqXHR, textStatus, errorThrown);
			}
		},
		fail: function(){}
	});

	/*WISE name*/
	updateWISEName = function(name){//is global
		$("#wiseNamePrevious").text(name);
		$("#wiseNameText").trigger("blur", [false]);
	};

	$("#wiseNamePrevious").text(WISE.$.name);
	$("#wiseNameText").hover(
		function(){
			if(!$(this).hasClass("active")){
				$(this).addClass("hover");
				$("#wiseNameLabel").show();
			}
		},
		function(){
			if(!$(this).hasClass("active")){
				$(this).removeClass("hover");
				$("#wiseNameLabel").hide();
			}
		}
	).bind("click", function(){
		if(!$(this).hasClass("active")){
			$(this).css({"textAlign": "left"}).addClass("active").select().animate({
				"width": "180px"
			}, "fast");
			$("#wiseNameSaveButton, #wiseNameLabel").show();
		}
	}).bind("blur", function(event, save, duration){
		if(save != true){
			$(this).val($("#wiseNamePrevious").text());
		}
		else{
			if($(this).val() == ""){
				$(this).val(WISE.$.modelName);
			}

			var wiseName = $(this).val();
			WISE.$.name = wiseName;
			$("#wiseNamePrevious").text(wiseName);
		}

		$(this).animate({
			"width": $("#wiseNamePrevious").innerWidth() + "px"
		}, typeof(duration) == "undefined" ? "fast" : duration);
		$(this).removeClass("active hover");
		$("#wiseNameSaveButton, #wiseNameLabel").hide();
	}).bind("keydown", function(event){
		if(event.which == 13){//ENTER
			$(this).trigger("blur", [true]);
		}
		else if(event.which == 27){//ESC
			$(this).trigger("blur", [false]);
		}
	}).trigger("blur", [false, 0]);

	$("#wiseNameSaveButton").bind("mousedown", function(event){
		$("#wiseNameText").trigger("blur", [true]);
	});

	WISE.bind("afterParse", function(){
		updateWISEName(WISE.$.name);
	}, "updateWISEName");

	if(WISE.getUser().character != "admin"){
		$("#wiseNameText").attr("disabled", true).css("cursor", "auto");
	}

	$("#topControlBar div").hover(
		function(){
			$(this).addClass("hover");
		},
		function(){
			$(this).removeClass("hover");
		}
	);

	$("#topControlBarNew").bind("click", function(){
		var confirmClearAllSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToClearAllSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!clear");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmClearAllSetting();
				//}
			});
		}
		else{
			confirmClearAllSetting();
		}
	});

	$("#topControlBarLoad").bind("click", function(){
		var confirmLoadSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLoadSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!load");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmLoadSetting();
				//}
			});
		}
		else{
			confirmLoadSetting();
		}
	});

	$("#topControlBarSave").bind("click", function(){
		var confirmSaveSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToSaveSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!save");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmSaveSetting();
				//}
			});
		}
		else{
			confirmSaveSetting();
		}
	});

	$("#topControlBarLogout").bind("click", function(){
		var confirmLogout = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLogout>", function(result){
				if(result == false){return;}

				redirectTo("#home!logout");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmLogout();
				//}
			});
		}
		else{
			confirmLogout();
		}
	});

	$("#logo, #logoTiny").bind("click", function(event){
		if(event.ctrlKey == true && event.altKey == true){
			redirectTo("#debug");
		}
		else{
			redirectTo("#home/main");
			$("#navigation li").removeClass("active");
		}
	});

	$("#infoBarBatteryStatus").hover(
		function(){
			$(this).find(".iconsRule, #infoBarBatteryStatusText").addClass("hover");
		},
		function(){
			$(this).find(".iconsRule, #infoBarBatteryStatusText").removeClass("hover");
		}
	);

	$("#infoBarSDFreeSpace").hover(
		function(){
			$(this).find(".iconsRule, #infoBarSDFreeSpaceText").addClass("hover");
		},
		function(){
			$(this).find(".iconsRule, #infoBarSDFreeSpaceText").removeClass("hover");
		}
	);

	$("#infoBarMessage").bind("click", function(event){
		$(document).unbind("click.infoBar");

		if($(this).hasClass("active")){
			$(this).removeClass("active");
			$("#infoBarDetailMessage").hide();
		}
		else{
			$(this).addClass("active").trigger("mouseenter");

			if($.browser.msie && parseInt($.browser.version, 10) <= 8){//IE8 fixed
				$("#infoBarDetailMessage").show();
			}
			else{
				$("#infoBarDetailMessage").fadeIn("fast");
			}

			$(document).bind("click.infoBar", function(event){
				$(document).unbind("click.infoBar");
				$("#infoBarMessage").triggerHandler("click");
				$("#infoBarMessage").trigger("mouseleave");
			});
		}

		event.stopPropagation();
	}).hover(
		function(){
			$(this).find(".iconsRule, .infoBarMessageText").addClass("hover");
		},
		function(){
			if($(this).hasClass("active")){return;}

			$(this).find(".iconsRule, .infoBarMessageText").removeClass("hover");
		}
	).disableSelection();

	$("#infoBarDetailMessage").bind("click", function(event){
		event.stopPropagation();
	});

	/*insert login message to status bar*/
	insertMessage("<#Lang['?'].loginSuccessfully>", 0, 0);
	insertMessage("<#Lang['?'].instantMessage>", 0, 2);

	/*browser compatibility process*/
	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$("#topControlBar, #infoBarDetailMessageTitleDummy1Content, #infoBarDetailMessageTitleDummy2Content, #infoBarDetailMessageContent").unwrap();
	}

	if($.browser.mozilla || $.browser.opera) {
		$("body").css("overflowY", "scroll");
	}
	else{
		$("html").css("overflowY", "scroll");
	}
	//$("html").css("overflowY", "scroll");

	if($.browser.webkit){//since chrome version 39, chinese line-height not same with english.
		$("body").css("lineHeight", "1.15");
	}

	if(WISE.getUser().character != "admin"){
		$("#topControlBar > *:not(#topControlBarLogout)").hide();
	}

	/*AccessPermission Comment Command*/
	addCommentCommand("AccessPermission", function(args){
		for(var i = 0; i < args.length; i++){
			if(WISE.getUser().character == args[i]){
				return true;
			}
		}

		redirectTo("#home", true);
		return false;
	});

	/*idle check*/
	$("#idleLoginPassword").keypress(function(event){
		if(event.which == 13){
			$("#idleLoginButton").click();
		}
	});

	$("#idleLoginButton").bind("click", function(){
		var disableInput = function(disable){
			if(disable == false){
				$("#idleLoginLoader").css("visibility", "hidden");
				$("#idleLoginPassword, #idleLoginButton").attr("disabled", false);
			}
			else{
				$("#idleLoginLoader").css("visibility", "visible");
				$("#idleLoginPassword, #idleLoginButton").attr("disabled", true);
			}
		};

		var xmlDoc = $.parseXML("<LOGIN/>");
		xmlDoc.documentElement.setAttribute("pw", $("#idleLoginPassword").val());

		$("#idleLoginStatus").empty();
		disableInput(true);

		$.ajax({ 
			//url: "./dll/xml/login.xml",
			url: "./dll/wise.dll",
			type: "POST",
			data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
			contentType: "text/xml",
			processData: false,
			cache: false,
			dataType: "xml",
			done: function(xmlDoc){
				var $xmlLOGIN = $(xmlDoc).find("LOGIN");
				var reply = $xmlLOGIN.attr("reply");

				if(reply == "admin" || reply == "guest"){
					if(reply == WISE.getUser().character){
						WISE.setUser(reply, $xmlLOGIN.attr("key"), $xmlLOGIN.attr("keepalive"));
						aliveChecker.startAliveTimer();
						aliveChecker.startIdleTimer();

						$("#idleLoginPassword").val("");
						$("#idleLoginStatus").empty();

						if(WISE.getUser().character == "guest"){//reload rule file, maybe it change by admin
							WISE.loadRuleFile({
								error: function(){
									WISE.resetWISE();
									updateWISEName(WISE.$.name);
								},
								complete: function(){
									disableInput(false);
									disableHash(false);
									$("#idleMessage").hide();

									redirectTo("#home");
								}
							});
						}
						else{
							disableInput(false);
							disableHash(false);
							$("#idleMessage").hide();

							if(typeof(afterLoginMenu) == "function"){afterLoginMenu();}
							if(typeof(afterLoginContent) == "function"){afterLoginContent();}
						}
					}
					else{
						var xmlDoc = $.parseXML("<LOGOUT/>");

						xmlDoc.documentElement.setAttribute("key", $xmlLOGIN.attr("key"));

						$.ajax({ 
							url: "./dll/wise.dll",
							type: "POST",
							data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
							contentType: "text/xml",
							processData: false,
							cache: false,
							dataType: "xml"
						});

						$("#idleLoginPassword").val("");
						$("#idleLoginStatus").text("<#Lang['?'].passwordIncorrect>");
						disableInput(false);
					}
				}
				else if(reply == "occupied" || reply == "full"){
					$("#idleLoginStatus").text("<#Lang['?'].reachMaximumNumberOfLoginUser>");
					disableInput(false);
				}
				else{
					$("#idleLoginPassword").val("");
					$("#idleLoginStatus").text("<#Lang['?'].passwordIncorrect>");
					disableInput(false);
				}
			}
		});
	});

	aliveChecker = WISE.createAliveChecker({
		"process": function($xmlALIVE){
			var freeSpace = parseFloat($xmlALIVE.attr("microsd"));
			if(!isNaN(freeSpace)){
				if(freeSpace >= 0){
					$("#infoBarSDFreeSpaceText").text(toFixed(freeSpace, 1) + "MB" + ($xmlALIVE.attr("log_day") ? "(" + "<#Lang['?'].approxXDays>".replace("$day", toFixed(parseFloat($xmlALIVE.attr("log_day")), 0)) + ")" : ""));
				}
				else{
					$("#infoBarSDFreeSpaceText").text("<#Lang['?'].noSDCard>");
					insertMessage("<#Lang['?'].noSDCard>")
				}
			}

			if($xmlALIVE.attr("ftp") == "0"){
				insertMessage("<#Lang['?'].ftpUploadFailed>")
			}

			$xmlM7000 = $xmlALIVE.find("> M7000");
			for(var i = 0; i < $xmlM7000.length; i++){
				if($($xmlM7000[i]).attr("init") == "-1"){
					insertMessage("<#Lang['?'].initModuleFailed>".replace("$moduleName", $($xmlM7000[i]).attr("name")).replace("$address", $($xmlM7000[i]).attr("address")), 1);
				}
			}

			$("#infoBarBatteryStatus .iconsRule").removeClass("batteryOK batteryFailed");
			if($xmlALIVE.attr("battery") == "1"){
				$("#infoBarBatteryStatusText").text("<#Lang['?'].ok>");
				$("#infoBarBatteryStatus .iconsRule").addClass("batteryOK");
			}
			else{
				$("#infoBarBatteryStatusText").text("<#Lang['?'].dead>");
				$("#infoBarBatteryStatus .iconsRule").addClass("batteryFailed");
			}
			
			switch($xmlALIVE.attr("reboot_record")){
				case "1"://Save Reboot
					showWaitingMessage("<#Lang['?'].vpn.VPNConnecting>");
					disableHash(true);
					var xmlDoc = $.parseXML("<VPN_REBOOT/>");
					xmlDoc.documentElement.setAttribute("key",WISE.getUser().key);
					WISE.startAjax("content", {
						url: "./dll/pmc.dll",
						type: "POST",
						data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
						contentType: "text/xml",
						processData: false,
						cache: false,
						dataType: "xml",
						done: function(xmlDoc){
							if($(xmlDoc).find("VPN_REBOOT").attr("reply")  == "ok")
								serverNoResponse = true;
						}
					});
				break;
				case "2"://reboot finish
					hideWaitingMessage();
					$("#contentLoader").hide();
					popupErrorWindow("<#Lang['?'].vpn.VPNError>", function(){redirectTo("#home/system/vpn");});
					disableHash(false);
				break;
			}
		},
		"timeout": function(){
			//show password input filed
			disableHash(true);
			$("#idleMessage").show(0, function(){
				$("#idleLoginPassword").focus();
			});
		}
	});

	$("*[tip]").livequery(
		function(){
			$(this).hover(
				function(){
					var that = this;
					$(this).attr(
						"pid",
						setTimeout(function(){
							$(that).showTip({"tip": $(that).attr("tip"), "position": $(that).attr("tip_position") ? $(that).attr("tip_position") : "top", "color": $(that).attr("tip_color") ? $(that).attr("tip_color") : "black"});
						}, 100)
					);
				},
				function(){
					clearTimeout($(this).attr("pid"));
					$(this).hideTip();
				}
			)
		},
		function(){
			clearTimeout($(this).attr("pid"));
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$("input[limit], input[range]").livequery(
		function(){
			$(this).bind("focus.validation", function(event){
				$(this).attr("valued", $(this).val());
				$(this).attr("valuep", $(this).val());
			});

			$(this).bind("keyup.validation", function(event){
				if(typeof($(this).attr("range")) != "undefined"){
					if($(this).attr("validation")){return;}

					if($(this).val() != "" && $(this).attr("valuep") != $(this).val()){
						var range = $(this).triggerHandler("getRange");
						var message = null;

						if(range.min != null && range.max != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsBetweenAToB>".replace("$minimum", range.min).replace("$maximum", range.max);
						}
						else if(range.min != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsGreaterEqualX>".replace("$minimum", range.min);
						}
						else if(range.max != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsLessEqualX>".replace("$maximum", range.max);
						}

						var value = Number($(this).val());
						if(isNaN(value)){value = 0;}
						if((range.min != null && value < range.min) || (range.max != null && value > range.max)){
							$(this).showTip({"tip": message, "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeyup").bind("blur.validationKeyup", function(){
								$(this).hideTip();
							});
						}
						else{
							$(this).hideTip();
						}
					}

					$(this).attr("valuep", $(this).val());
				}
			});

			$(this).bind("keypress.validation", function(event){
				if(event.which == 0 || event.which == 8 || event.which == 13){return;}//skip enter(13), backspace(8) and special key link F1..etc

				if($(this).attr("limit") == "int"){
					if(!(/[\d+-]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputInteger>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if($(this).attr("limit") == "float"){
					if(!(/[\d+-.Ee]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputIntegerOrFloatingPoint>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if($(this).attr("limit") == "hex"){
					if(!(/[0-9A-Fa-f]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputHEX>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if(typeof($(this).attr("limit")) != "undefined"){
					var limit = $(this).attr("limit");
					var from = limit.indexOf("["), to = limit.lastIndexOf("]");

					if(from != -1 && to != -1){
						var regex = new RegExp("[" + $(this).attr("limit").substring(from + 1, to) + "]", "g");

						if(!(regex.test(String.fromCharCode(event.which)))){
							$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldNotAllowInputThisChar>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
								$(this).hideTip();
							}).attr("validation", "failed");
							event.preventDefault();
						}
						else{
							$(this).hideTip().removeAttr("validation");
						}
					}
				}
			});

			$(this).bind("correctRange.validation", function(){
				if($(this).attr("limit") == "int" || $(this).attr("limit") == "float"){
					if($(this).val() == "" || isNaN($(this).val()) || !isFinite($(this).val())){//not number or is infinite
						if(typeof($(this).attr("default")) != "undefined"){
							$(this).val($(this).attr("default"));
						}
						else if(!isNaN($(this).attr("valued"))){
							$(this).val($(this).attr("valued"));
						}
						else{
							$(this).val("0");
						}
					}
					else{//no error, just format the number
						$(this).val(Number($(this).val()));
					}
				}
				else if($(this).attr("limit") == "hex"){
					if(!(/[0-9A-Fa-f]/g.test($(this).val()))){
						$(this).val(typeof($(this).attr("default")) != "undefined" ? $(this).attr("default") : "0");
					}
					else{//no error, just padding zero
						var maxLength = Number($(this).attr("maxlength"));
						if(!isNaN(maxLength)){
							var zeroArray = new Array(maxLength);
							for(var i = 0; i < zeroArray.length; i++){
								zeroArray[i] = "0";
							}
							$(this).val(zeroArray.join("").substring(0, maxLength - $(this).val().length) + $(this).val().toUpperCase());
						}
					}
				}
				else if(typeof($(this).attr("limit")) != "undefined"){
					var limit = $(this).attr("limit");
					var from = limit.indexOf("["), to = limit.lastIndexOf("]");

					if(from != -1 && to != -1){
						var notSign = "^";
						if($(this).attr("limit").charAt(from + 1) == "^"){
							notSign = "";
							from++;
						}

						var regex = new RegExp("[" + notSign + $(this).attr("limit").substring(from + 1, to) + "]", "g");
						var value = $(this).val().replace(regex, "");

						$(this).val(value == "" && typeof($(this).attr("default")) != "undefined" ? $(this).attr("default") : value);
					}
				}
			});

			$(this).bind("getRange.validation", function(){
				if(typeof($(this).attr("range")) != "undefined"){
					var min = null, max = null;
					var splitArray = $(this).attr("range").replace(/ /g, "").split("~");

					if(splitArray.length == 2){
						if(splitArray[0] != "" && !isNaN(min)){
							min = Number(splitArray[0]);
						}
						if(splitArray[1] != "" && !isNaN(max)){
							max = Number(splitArray[1]);
						}

						if(min != null && max != null && min > max){
							var temp = min;
							min = max;
							max = temp;
						}
					}

					return {"min": min, "max": max};
				}
			});

			$(this).bind("correctRange.validation", function(event){
				if(typeof($(this).attr("range")) != "undefined"){
					var range = $(this).triggerHandler("getRange");
					var value = Number($(this).val());
					if(isNaN(value)){value = 0;}

					if(range.min != null && value < range.min){
						$(this).val(range.min);
					}
					else if(range.max != null && value > range.max){
						$(this).val(range.max);
					}
					else{
						//$(this).val(value);
					}
				}
			});

			$(this).bindFirst("blur.validation", function(){
				if($(this).attr("require") == "false" && $(this).val() == ""){return;}

				$(this).triggerHandler("correctRange");
			});
		},
		function(){
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$("input[length], textarea[length]").livequery(
		function(){
			$(this).bindFirst("keyup.length", function(){
				if($(this).attr("validation")){return;}

				var length = parseInt($(this).attr("length"), 10);
				if(isNaN(length)){return;}

				if(wordCount($(this).val()) > length){
					$(this).showTip({
						"tip": "<#Lang['?'].tip.thisFieldContainsTooManyChar>",
						"position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"),
						"color": "red"
					}).unbind("blur.length").bindFirst("blur.length", function(){
						var length = parseInt($(this).attr("length"), 10);
						if(isNaN(length)){return;}

						$(this).val($(this).val().substr(0, wordCut($(this).val(), parseInt($(this).attr("length"), 10))));
						$(this).hideTip();
					});
				}
				else{
					$(this).hideTip();
				}
			});
		},
		function(){
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$("div.styleButton").livequery(function(){
		$(this).hover(
			function(){
				$(this).addClass("hover");
			},
			function(){
				$(this).removeClass("hover");
			}
		).bind("mousedown", function(){
			$(this).addClass("active");
		}).bind("mouseup mouseleave", function(){
			$(this).removeClass("active");
		}).disableSelection();
	});

	$.fn.checkInput = function(autoCorrect){
		return this.each(function(){
			if($(this).attr("limit") || $(this).attr("range")){
				$(this).triggerHandler("blur");
			}
			return $(this);
		});
	};

	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$(window).bind('scroll', {"originalTop": $('#infoBar').offset().top - 30}, function(event){
		    var $infoBar = $('#infoBar');
		    if($(window).scrollTop() > $infoBar.offset().top - 30){
				$infoBar.css({"position": "fixed", "left": "50%", "top": "30px", "bottom": "auto", "right": "auto", "marginLeft": ($("#container").width() / 2 - $infoBar.width()) + "px"});
				//$("#topBar").show().css({"top": (-1 * $("#topBar").outerHeight(true)) + "px", "opacity": 0}).animate({"top": 0, "opacity": 1});
				//has problem
				$("#topBarLogo").css({"marginLeft": ($("#container").width() / 2 * -1) + "px"});
				$("#topBar").fadeIn("fast");
		    }
			else{
				if($(window).scrollTop() <= event.data.originalTop){
					$infoBar.css({"position": "", "left": "", "top": "", "bottom": "", "right": "", "marginLeft": ""});
					//$("#topBar").animate({"top": (-1 * $("#topBar").outerHeight(true)) + "px", "opacity": 0}, function(){
					//	$(this).hide();
					//});
					//has problem
					$("#topBar").fadeOut("fast");
				}
			}
		});
	}

	/*Hash init*/
	if(typeof(WISE.managers.pueManager) != "undefined" && WISE.managers.pueManager.pool.isDefaultPage == true){
		redirectTo("#home/main/pue_information", true);
	}
	else{
		redirectTo("#home/main", true);
	}

	$.history.init(function(hash) {
		var processHash = function(){
			if(hashDisable == true || (typeof(is_editing) != "undefined" && is_editing == true)){//is_editing is defined in hmi.htm
				if(hash != redirectHash){//prevent loop redirect
					redirectHash = previousHash;
					redirectTo("#" + previousHash);
				}

				if(typeof(is_editing) != "undefined" && is_editing == true){//for HMI
					popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
						//correctionTitle();//inside hmi.htm
					});
				}
			}
			else{
				hashHandler(hash == "" ? "home" : hash);
			}

			previousHash = hash;
		}

		if($("#topMenu").attr("loaded")){
			processHash();
		}
		else{//load main menu
			if(typeof(jqXHRMenu) != "undefined"){
				jqXHRMenu.abort();
			}

			jqXHRMenu = $.ajax({
				url: "html/desktop" + "/" + currentLevel[0] + "/" + "menu.htm" + "?" + cacheString,
				type: "GET",
				dataType: "html",
				success: function(htmlString){
					if(processCommentCommand(htmlString) == false){return;}

					$("#topMenu").html(processLanguage(htmlString, this.url.split("?")[0])).attr("loaded", "true");

					processHash();
				}
			});
		}
	}, {"unescape": true});
}

/*
	insertMode = undefined or 0(normal insert)
	insertMode = 1(only insert to content)
	insertMode = 2(only insert to title)
*/
function insertMessage(message, level, insertMode){
	level = {0: "informationBalloon", 1: "exclamationSign"}[level || 0];

	if(insertMode != 1){
		$("#infoBarMessageWidth").html(message);
		$("#infoBarMessageIcon").attr("class", "iconsRule " + level + (function(){
			if($("#infoBarMessage").hasClass("active")){
				return " hover";
			}

			return "";
		})());

		if($("#infoBarMessageWidth").innerWidth() + 1 > parseInt($(".infoBarMessageText").css("maxWidth"), 10)){
			$(".infoBarMessageText").css({"textOverflow": "ellipsis"});
		}
		else{
			$(".infoBarMessageText").css({"textOverflow": ""});
		}

		$(".infoBarMessageText").html(message).stop().animate({
			"width": ($("#infoBarMessageWidth").innerWidth() + 1) + "px"
		}, "fast");
	}

	if(insertMode != 2){
		var date = new Date();
		var $row = $("<tr></tr>").append(
			$("<td></td>").text(padding(date.getHours(), 2) + ":" + padding(date.getMinutes(), 2) + ":" + padding(date.getSeconds(), 2))
		).append(
			$("<td></td>").css({"paddingTop": "2px", "paddingBottom": "2px", "lineHeight": "19px"}).append(
				$("<span></span>").attr("class", "iconsRule hover " + level).css("float", "left")
			).append(message)
		);

		var $firstRow = $("#infoBarDetailMessageTable tr:first");

		if($firstRow.hasClass("even")){
			$row.addClass("odd");
		}
		else{
			$row.addClass("even");
		}

		$row.prependTo("#infoBarDetailMessageTable");
		$("#infoBarDetailMessageTable tr:gt(9)").remove();
	}
}

function toggleWidth(){
	if(wideScreenMode == false){
		var containerWidth = wideScreenContainerWidth;
		$("#container").animate({"width": containerWidth + "px"})
		$("#right").animate({"width": ($("#right").width() + (wideScreenContainerWidth - normalContainerWidth)) + "px"})
		wideScreenMode = true;
	}
	else{
		var containerWidth = normalContainerWidth;
		$("#container").animate({"width": containerWidth + "px"})
		$("#right").animate({"width": ($("#right").width() - (wideScreenContainerWidth - normalContainerWidth)) + "px"})
		wideScreenMode = false;
	}
	setCookie("wideScreenMode", wideScreenMode);

	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$('#infoBar').animate({"marginLeft": (containerWidth / 2 - $('#infoBar').width()) + "px"});
		$("#topBarLogo").animate({"marginLeft": (containerWidth / 2 * -1) + "px"});
	}
}

//function guideline(){
//	$.guideLine("#navigation_list li[location='#home/system']", {"eventType": "click", "spotLight": {"reset": true, "innerDimension": true, "text":"test1234567890"}})
//	.guideLine("#navigation_2nd li[location='#home/system/interface']", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#remoteIOTab div.comport_2", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#comport_2 select.protocol", {
//		"eventType": "change",
//		"handler": function(){
//			if($(this).val() == "modbusRTU"){
//				return true;
//			}
//			else{
//				return false;
//			}
//		},
//		"spotLight": {"text":"test1234567890"}
//	})
//	.guideLine("#saveButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#popupOKButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#navigation_list li[location='#home/module']", {"eventType": "click", "spotLight": {"innerDimension": true, "text":"test1234567890"}})
//	.guideLine("#navigation_2nd li[location='#home/module/powermeter']", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#remoteIOTab div.comport_2", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#modbusRTUShowAllModuleButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("body>ul.ui-autocomplete:first>li:last", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#modbusRTUModuleListHandler div.icon.add", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#saveButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#popupOKButton", {
//		"eventType": "click",
//		"handler": function(){
//			$.spotLight("hide");
//		},
//		"spotLight": {"text":"test1234567890"}
//	})
//	.guideLine.start({
//		"spotLight": {
//			"close": function(){
//				$("#rightContent").unbind("resize.guideLine");
//				$.guideLine.stop();
//			}
//		}
//	});
//
//	$("#rightContent").resize(function(event){
//		$(window).resize();
//		event.stopPropagation();
//	});
//}

function showDownloadNotify(callback){
	if(getCookie("downloadNotify") != null){
		if(typeof(callback) == "function"){
			callback();
		}

		return;
	}

	disableHash(true);
	$("[id^=downloadNotify]").remove();
	$("html, body").scrollTop(0);

	// Create element
	$.each(["Top", "Bottom", "Right", "Left"], function(index, value){
		$("<div></div>").css({
			"position": "absolute",
			"opacity": 0.3,
			"backgroundColor": "#000",
			"zIndex": "1100"
		}).attr("id", "downloadNotify" + value).appendTo("body");
	});

	$("<div></div>").css({
		"position": "absolute",
		"zIndex": "1101",
		"border": "3px solid #666666",
		"boxSizing": "border-box"
	}).attr("id", "downloadNotifyBorder").appendTo("body");

	$("<div></div>").attr({"class": "spotLight", "id": "downloadNotifyTip"}).append(
		$("<div></div>").attr("class", "textLayer").css({
			"fontSize": "15px",
			"padding": "10px",
			"boxShadow": "rgba(0, 0, 0, 0.298039) 0px 1px 2px 2px"
		}).append(
			$("<div></div>").attr("class", "text").text("<#Lang['?'].tip.clickDownloadAfterCompleteAllSetting>")
		).append(
			$("<div></div>").css({
				"margin": "9px 0 3px 0",
				"textAlign": "center"
			}).append(
				$("<span></span>").attr("class", "spotLightButton").css({
					"position": "relative",
					"padding": "2px 8px"
				}).text("<#Lang['?'].close>").bind("click", function(){
					setCookie("downloadNotify", true, 525600);
					disableHash(false);
					$("[id^=downloadNotify]").remove();
					$(window).unbind("resize.downloadNotify");

					if(typeof(callback) == "function"){
						callback();
					}
				}).bind("mousedown", function(){
					$(this).css("top", "1px");
				}).bind("mouseup mouseleave", function(){
					$(this).css("top", "0px");
				})
			)
		).append(
			$("<div></div>").css("marginLeft", "94px").attr("class", "spotLightIcon bottom")
		)
	).appendTo("body");

	// Init position
	$("#downloadNotifyTop").css({
		"top": 0,
		"left": 0,
		"width": "100%",
		"height": $("html, body").scrollTop() + "px"
	});

	$("#downloadNotifyBottom").css({
		"top": $("html, body").scrollTop() + $(window).height() + "px",
		"left": 0,
		"width": "100%",
		"height": Math.max($(window).height(), $("body").height()) - ($("html, body").scrollTop() + $(window).height()) + "px"
	});

	$("#downloadNotifyLeft").css({
		"top": $("html, body").scrollTop() + "px",
		"left": 0,
		"width": 0,
		"height": $(window).height() + "px"
	});

	$("#downloadNotifyRight").css({
		"top": $("html, body").scrollTop() + "px",
		"left": $(window).width() + "px",
		"width": 0,
		"height": $(window).height() + "px"
	});

	$("#downloadNotifyBorder").css({
		"top": $("html, body").scrollTop() + "px",
		"left": 0,
		"width": $(window).width() + "px",
		"height": $(window).height() + "px",
    	"borderRadius": "3px"
	});

	// Adjust position
	var adjustDownloadNotify = function(resize){
		var $target = $("#topControlBarSave");
		var top = $target.offset().top,
			left = $target.offset().left,
			width = $target.innerWidth(),
			height = $target.innerHeight();

		$.when(
			$("#downloadNotifyTop").stop().animate({
				"top": 0,
				"left": 0,
				"width": "100%",
				"height": top + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyBottom").stop().animate({
				"top": top + height + "px",
				"left": 0,
				"width": "100%",
				"height": Math.max($(window).height(), $("body").height()) - (top + height) + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyLeft").stop().animate({
				"top": top + "px",
				"left": 0,
				"width": left + "px",
				"height": height + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyRight").stop().animate({
				"top": top + "px",
				"left": left + width + "px",
				"width": $(window).width() - (left + width) + "px",
				"height": height + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyBorder").stop().animate({
				"top": (top - 3) + "px",
				"left": (left - 3) + "px",
				"width": (width + 6) + "px",
				"height": (height + 6) + "px"
			}, !resize ? 600 : 0)
		).then(function(){
			$("#downloadNotifyTip").css({
				"top": (top + height) + "px",
				"left": ((left + (width - $("#downloadNotifyTip").outerWidth()) / 2) - 100) + "px"
			}).fadeIn(!resize ? 400 : 0);
		});
	};
	
	adjustDownloadNotify(false);

	$(window).unbind("resize.downloadNotify").bind("resize.downloadNotify", function(){
		adjustDownloadNotify(true);
	});
}

function startBreathingDownloadButton(){
	$("#topControlBarSave").attr({
		"tip_color": "yellow",
		"tip": "<#Lang['?'].tip.settingNotDownloadToController>"
	}).css({
		"backgroundColor": "rgba(246, 206, 124, 0)",
		"color": "rgba(246, 206, 124, 0)",
		"boxShadow": "0px 0px 10px 3px",
		"borderRadius": "30%"
	}).find("div").show().find("img").css({
		"animationName": "exclame",
    	"animationDuration": "500ms"
	});

	window.onbeforeunload = function() {
	    return "<#Lang['?'].tip.settingNotDownloadToController>";
	};

	breathingDownloadButton();
}

function breathingDownloadButton(){
	$("#topControlBarSave").animate({
		"backgroundColor": "rgba(246, 206, 124, 1)",
		"color": "rgba(246, 206, 124, 1)",
	}, 1500, "swing").animate({
		"backgroundColor": "rgba(246, 206, 124, 0.5)",
		"color": "rgba(246, 206, 124, 0.5)",
	}, 1500, "swing", breathingDownloadButton);
}

function stopBreathingDownloadButton(){
	$("#topControlBarSave").stop(true).attr({
		"tip": "<#Lang['html/desktop/frame.htm'].saveRule>",
		"tip_color": "black"
	}).css({
		"backgroundColor": "",
		"color": "",
		"boxShadow": "",
		"borderRadius": ""
	}).find("div").hide();

	window.onbeforeunload = null;
}

function stickyControlButton(handlerID, listID){
	var $handler = $("#" + handlerID);
	var $list = $("#" + listID);
	var $stickyBar = $handler.find(".stickyBar");

	if($list.is(":visible") != true){return}

	if($(window).height() + $(window).scrollTop() > $list.offset().top && $(window).height() + $(window).scrollTop() < $handler.offset().top + 45){
		if(!$stickyBar.hasClass("flow")){
			$stickyBar.addClass("flow");

			if($stickyBar.attr("from") == "top"){
				$stickyBar.stop().css("bottom", "-56px").animate({
					"bottom": "-16px"
				}, "fast");
			}
		}
	}
	else{
		if($(window).height() + $(window).scrollTop() < $handler.offset().top + 45){
			$stickyBar.attr("from", "top");
			if($stickyBar.hasClass("flow") && !$stickyBar.attr("run")){
				$stickyBar.stop().attr("run", true).animate({
					"bottom": "-56px"
				}, "fast", function(){
					$(this).removeClass("flow").removeAttr("run");
				});
			}
		}
		else{
			$stickyBar.attr("from", "bottom");
			$stickyBar.stop().removeClass("flow").css("bottom", "");
		}
	}
}