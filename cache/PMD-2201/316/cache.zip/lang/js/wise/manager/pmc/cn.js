﻿$.extend(true, Lang, {
	"js/wise/manager/pmc/base.js": {
		"someoneGroupsAreError": "电测模块群组设定中所设定的电表，部分已遭移除，请再次确认。"
	}
});