﻿$.extend(true, Lang, {
	"js/wise/manager/rule/base.js": {
		"copy": "复制"
	},
	"js/wise/manager/rule/rule/object.js": {
		"ruleStatus": "规则状态"
	},
	"js/wise/manager/rule/rule/encoder.js": {
		"someoneRulesAreError": "有规则发生错误，请修正它们。",
		"someoneRulesMissingConditionOrAction": "有规则中缺少条件或动作，请修正它们。"
	}
});
