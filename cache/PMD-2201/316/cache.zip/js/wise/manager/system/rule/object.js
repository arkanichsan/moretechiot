WISE.managers.systemManager.pool.conditions = {
	"sdCard": {
		"name": "<#Lang['?'].sdCardStatus>",
		"fileName": "csdcard",
		"rule":{
			"value": 0
		},
		"check": function(){
			return true;
		},
		"parseToString": function(){
			var valueString = ["<#Lang['?'].abnormal>"];

			return this.name + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	}
};

WISE.managers.systemManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['sdCard']['key'] = [];

	this.pool.conditions['sdCard']['key'].push(true);
};