$.extend(true, Lang, {
	"js/wise/manager/logger/rule/object.js": {
		"dataLogger": "資料記錄器",
		"moduleDataLogger": "I/O模組資料記錄器",
		"customizedDataLogger": "自訂資料記錄器",
		"oneTimeLog": "單次記錄"
	},
	"js/wise/manager/logger/object/encoder.js": {
		"year": "年",
		"month": "月",
		"day": "日",
		"hour": "時",
		"minute": "分",
		"second": "秒",
		"mode": "模式",
		"diCounterX": "DI計數器$channel",
		"doCounterX": "DO計數器$channel",
		"internalRegisterX": "內部暫存器$channel"
	}
});