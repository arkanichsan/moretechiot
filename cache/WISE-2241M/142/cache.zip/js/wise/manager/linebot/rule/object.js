WISE.managers.lineBotManager.pool.actions = {
	"message": {
		"name": "Bot Service",
		"fileName": "alinebot",
		"rule":{
			"messageKey": null,
			"frequency": -1
		},
		"check": function(){
			if(this.rule.messageKey == null){
				return false;
			}
			
			var lineBotManager = WISE.managers.lineBotManager;

			if(typeof(lineBotManager.pool.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var lineBotManager = WISE.managers.lineBotManager;
			var message = lineBotManager.pool.messages[this.rule.messageKey];

			return this.name + "(" + message.name + ") " + ruleColor("<#Lang['?'].send>", 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.messageKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.lineBotManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['message']['key'] = [];

	for(var key in this.pool.messages){
		this.pool.actions['message']['key'].push(parseInt(key, 10));
	}
};