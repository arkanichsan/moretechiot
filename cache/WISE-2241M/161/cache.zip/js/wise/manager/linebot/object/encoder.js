WISE.managers.lineBotManager.encodeXMLObject = function(xmlDoc){
	var xmlLINE_BOT = xmlDoc.getElementsByTagName("LINE_BOT")[0] || xmlDoc.createElement("LINE_BOT");

	// Message
	var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

	for(var key in this.pool.messages){
		var message = this.pool.messages[key];
		var xmlM = xmlDoc.createElement("M");

		xmlM.setAttribute("idx", message.index);
		xmlM.setAttribute("nickname", message.name);

		if(message.description != ""){
			xmlM.setAttribute("desc", message.description);
		}

		xmlM.appendChild(xmlDoc.createTextNode(message.content));

		xmlMESSAGE.appendChild(xmlM);
	}

	if(xmlMESSAGE.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlMESSAGE);
	}

	// IP Camera
	var xmlCAMERA = xmlLINE_BOT.getElementsByTagName("CAMERA")[0] || xmlDoc.createElement("CAMERA");

	var counter = 0;
	var moduleManager = WISE.managers.moduleManager;
	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			if(typeof(modules[moduleIndex].iotstar) != "undefined" && typeof(modules[moduleIndex].lineBot) != "undefined"){
				if(modules[moduleIndex].iotstar.enable == true && modules[moduleIndex].lineBot.enable == true){
					var xmlC = null;

					// Search
					for(var i = 0, xmlCs = xmlCAMERA.getElementsByTagName("C"); i < xmlCs.length; i++){
						var cameraIndex = parseInt(xmlCs[i].getAttribute("camera_idx"), 10);
						if(cameraIndex == moduleIndex + 1){
							xmlC = xmlCs[i];
							break;
						}
					}

					xmlC = xmlC || xmlDoc.createElement("C");
					xmlC.setAttribute("camera_idx", moduleIndex + 1);
					xmlC.setAttribute("idx", ++counter);
					xmlC.setAttribute("mode", 0);

					var xmlMSG = xmlC.getElementsByTagName("MSG")[0] || xmlDoc.createElement("MSG");

					if(xmlMSG.childNodes[0] !== undefined){
						xmlMSG.childNodes[0].nodeValue = "";
					}

					xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].lineBot.content));
					xmlC.appendChild(xmlMSG);

					xmlCAMERA.appendChild(xmlC);
				}
			}
		}
	}

	if(xmlCAMERA.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCAMERA);
	}

    // CGI Server
    var xmlCGI_SERVER = xmlLINE_BOT.getElementsByTagName("CGI_SERVER")[0] || xmlDoc.createElement("CGI_SERVER");

    var cgiManager = WISE.managers.cgiManager;
    for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
        if(typeof(servers[sourceIndex]) == "undefined"){continue;}

		if(typeof(servers[sourceIndex].iotstar) != "undefined" && typeof(servers[sourceIndex].lineBot) != "undefined"){
	        if(servers[sourceIndex].iotstar.enable == true && servers[sourceIndex].lineBot.enable == true){
				var xmlC = null;

				// Search
				for(var i = 0, xmlCs = xmlCGI_SERVER.getElementsByTagName("C"); i < xmlCs.length; i++){
					var serverIndex = parseInt(xmlCs[i].getAttribute("idx"), 10);
					if(serverIndex == servers[sourceIndex].index){
						xmlC = xmlCs[i];
						break;
					}
				}

				xmlC = xmlC || xmlDoc.createElement("C");
	            xmlC.setAttribute("idx", servers[sourceIndex].index);
	            xmlC.setAttribute("mode", 0);

				var xmlMSG = xmlC.getElementsByTagName("MSG")[0] || xmlDoc.createElement("MSG");

				if(xmlMSG.childNodes[0] !== undefined){
					xmlMSG.childNodes[0].nodeValue = "";
				}

				xmlMSG.appendChild(xmlDoc.createTextNode(servers[sourceIndex].lineBot.content));
	       		xmlC.appendChild(xmlMSG);

	            xmlCGI_SERVER.appendChild(xmlC);
	        }
		}
    }

	if(xmlCGI_SERVER.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCGI_SERVER);
	}

    // FTP Server
    var xmlSENDBOX = null;
    var systemManager = WISE.managers.systemManager;
	var server = systemManager.pool.ftpServer;

	if(typeof(server.iotstar) != "undefined" && typeof(server.lineBot) != "undefined"){
	    if(server.iotstar.enable == true && server.lineBot.enable == true){
			xmlSENDBOX = xmlLINE_BOT.getElementsByTagName("SENDBOX")[0] || xmlDoc.createElement("SENDBOX");
			xmlSENDBOX.setAttribute("mode", 0);

			if(xmlSENDBOX.childNodes[0] !== undefined){
				xmlSENDBOX.childNodes[0].nodeValue = "";
			}

			xmlSENDBOX.appendChild(xmlDoc.createTextNode(server.lineBot.content));

			xmlLINE_BOT.appendChild(xmlSENDBOX);
	    }
	}

	// 
	if(xmlLINE_BOT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_BOT);
				break;
			}
		}
	}
};

WISE.managers.lineBotManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};