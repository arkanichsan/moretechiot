WISE.managers.smsManager = (function(){
	return new function() {
		this.pool = {
			pinCode: {
				plain: "",
				encoded: "",
				length: 0
			},

			smsCommands: {
				enable: false,

				allowAccessPhone: {
					enable: true,
					numbers: []
				},

				quickCommands: []//	element must be {"customizeCommand": "", "originalCommand": ""}
			},

			smsAlarms: {},
			smsAlarmKey: 0,

			smsPhoneNumberGroups: {},
			smsPhoneNumberGroupKey: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxSMSAlarmAmount = 12;
		this.maxSMSQuickCommandAmount = 12;
		this.maxSMSPhoneNumberGroupAmount = 12;

		this.createSMSAlarm = function(settings){
			var smsAlarm = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"phoneNumbers": [],
				"unicode": false,
				"message": ""
			}, settings);

			return smsAlarm;
		};

		this.addSMSAlarm = function(smsAlarm){
			var retKey = this.pool.smsAlarmKey;
			this.pool.smsAlarms[this.pool.smsAlarmKey++] = smsAlarm;
			return retKey;
		};

		this.removeSMSAlarm = function(smsAlarmKey){
			delete this.pool.smsAlarms[smsAlarmKey];
		};

		this.getSMSAlarm = function(smsAlarmKey){
			if(typeof(this.pool.smsAlarms[smsAlarmKey]) != "undefined"){
				return this.pool.smsAlarms[smsAlarmKey];
			}
			else{
				return null;
			}
		};

		this.setSMSAlarm = function(smsAlarmKey, smsAlarm){
			this.pool.smsAlarms[smsAlarmKey] = smsAlarm;
		};

		this.getSMSAlarms = function(){
			return this.pool.smsAlarms;
		};

		// Phone number group
		this.createSMSPhoneNumberGroup = function(settings){
			var smsPhoneNumberGroup = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"phoneNumbers": []
			}, settings);

			return smsPhoneNumberGroup;
		};

		this.addSMSPhoneNumberGroup = function(smsPhoneNumberGroup){
			var retKey = this.pool.smsPhoneNumberGroupKey;
			this.pool.smsPhoneNumberGroups[this.pool.smsPhoneNumberGroupKey++] = smsPhoneNumberGroup;
			return retKey;
		};

		this.removeSMSPhoneNumberGroup = function(smsPhoneNumberGroupKey){
			delete this.pool.smsPhoneNumberGroups[smsPhoneNumberGroupKey];
		};

		this.getSMSPhoneNumberGroup = function(smsPhoneNumberGroupKey){
			if(typeof(this.pool.smsPhoneNumberGroups[smsPhoneNumberGroupKey]) != "undefined"){
				return this.pool.smsPhoneNumberGroups[smsPhoneNumberGroupKey];
			}
			else{
				return null;
			}
		};

		this.setSMSPhoneNumberGroup = function(smsPhoneNumberGroupKey, smsPhoneNumberGroup){
			this.pool.smsPhoneNumberGroups[smsPhoneNumberGroupKey] = smsPhoneNumberGroup;
		};

		this.getSMSPhoneNumberGroups = function(){
			return this.pool.smsPhoneNumberGroups;
		};
	};
})();
