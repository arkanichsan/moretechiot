$.extend(true, Lang, {
	"js/wise/manager/linebot/rule/object.js": {
		"send": "傳送"
	}
});