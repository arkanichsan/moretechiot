WISE.managers.snmpManager.pool.actions = {
	"trap": {
		"name": "<#Lang['?'].snmpTrap>",
		"fileName": "asnmp",
		"rule":{
			"trapKey": null,
			"frequency": -1
		},
		"check": function(){
			if(this.rule.trapKey == null){
				return false;
			}
			
			var snmpManager = WISE.managers.snmpManager;

			if(typeof(snmpManager.pool.traps[this.rule.trapKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var snmpManager = WISE.managers.snmpManager;
			var trap = snmpManager.pool.traps[this.rule.trapKey];

			return this.name + "(" + trap.name + ") " + ruleColor("<#Lang['?'].send>", 2);
		},

		/*init and key will not be copied*/
		"init": function(){
		},
		"key": []
	}
};

WISE.managers.snmpManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['trap']['key'] = [];

	for(var trapKey in this.pool.traps){
		if(this.pool.traps[trapKey].number == 6){
			//for(var messageKey in this.pool.traps[trapKey].messages){
				this.pool.actions['trap']['key'].push(parseInt(trapKey, 10));
			//	break;
			//}
		}
	}
};