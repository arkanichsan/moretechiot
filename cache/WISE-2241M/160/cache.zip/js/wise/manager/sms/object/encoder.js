WISE.managers.smsManager.encodeXMLObject = function(xmlDoc){
	var xmlSMS = xmlDoc.createElement("SMS");

	if(this.pool.pinCode.plain == "" || this.pool.pinCode.plain != padding("", this.pool.pinCode.length, "*")){//setup new password
		xmlSMS.setAttribute("pin", this.pool.pinCode.plain);
		xmlSMS.setAttribute("pin_len", this.pool.pinCode.plain.length);
	}
	else{
		xmlSMS.setAttribute("pin", this.pool.pinCode.encoded);
		xmlSMS.setAttribute("pin_len", this.pool.pinCode.length);
	}

	if(this.pool.smsCommands.enable == true){
		var xmlADMIN = xmlDoc.createElement("ADMIN");
		xmlADMIN.setAttribute("skip_check", this.pool.smsCommands.allowAccessPhone.enable == true ? "0" : "1");

		if(this.pool.smsCommands.allowAccessPhone.enable == true){
			for(var i = 0; i < this.pool.smsCommands.allowAccessPhone.numbers.length; i++){
				var xmlA = xmlDoc.createElement("A");
				xmlA.setAttribute("idx", i + 1);
				xmlA.appendChild(xmlDoc.createTextNode(this.pool.smsCommands.allowAccessPhone.numbers[i]));
				xmlADMIN.appendChild(xmlA);
			}
		}
		xmlSMS.appendChild(xmlADMIN);

		var xmlQUICK_CMD = xmlDoc.createElement("QUICK_CMD"), counter = 0;
		for(var quickCommandKey in this.pool.smsCommands.quickCommands){
			var quickCommand = this.pool.smsCommands.quickCommands[quickCommandKey];

			var xmlQ = xmlDoc.createElement("Q");
			xmlQ.setAttribute("idx", counter + 1);
			xmlQ.setAttribute("cmd", quickCommand.customizeCommand);

			var index = quickCommand.originalCommand.indexOf(":");
			xmlQ.setAttribute("type", quickCommand.originalCommand.substring(0, index));
			xmlQ.appendChild(xmlDoc.createTextNode(quickCommand.originalCommand.substring(index + 1)));

			xmlQUICK_CMD.appendChild(xmlQ);
			counter++;
		}
		xmlSMS.appendChild(xmlQUICK_CMD);
	}

	var xmlPHONEBOOK = null;
	for(var smsPhoneNumberGroupKey in this.pool.smsPhoneNumberGroups){
		xmlPHONEBOOK = xmlDoc.createElement("PHONEBOOK");
		xmlSMS.appendChild(xmlPHONEBOOK);
		break;
	}

	if(xmlPHONEBOOK != null){
		for(var smsPhoneNumberGroupKey in this.pool.smsPhoneNumberGroups){
			var smsPhoneNumberGroup = this.pool.smsPhoneNumberGroups[smsPhoneNumberGroupKey];

			var xmlGROUP = xmlDoc.createElement("GROUP");
			xmlGROUP.setAttribute("idx", smsPhoneNumberGroup.index);
			xmlGROUP.setAttribute("nickname", smsPhoneNumberGroup.name);

			for(var i = 0; i < smsPhoneNumberGroup.phoneNumbers.length; i++){
				var xmlNUM = xmlDoc.createElement("NUM");
				xmlNUM.setAttribute("idx", i + 1);
				xmlNUM.appendChild(xmlDoc.createTextNode(smsPhoneNumberGroup.phoneNumbers[i]));
				xmlGROUP.appendChild(xmlNUM);
			}

			xmlPHONEBOOK.appendChild(xmlGROUP);
		}
	}

	for(var smsAlarmKey in this.pool.smsAlarms){
		var smsAlarm = this.pool.smsAlarms[smsAlarmKey];

		var xmlS = xmlDoc.createElement("S");
		xmlS.setAttribute("idx", smsAlarm.index);
		xmlS.setAttribute("unicode", smsAlarm.unicode == true ? "8" : "0");
		xmlS.setAttribute("nickname", smsAlarm.name);

		if(smsAlarm.description != ""){
			xmlS.setAttribute("desc", smsAlarm.description);
		}

		var phoneNumbers = null;
		if(smsAlarm.phoneNumbers instanceof Array == true){
			phoneNumbers = smsAlarm.phoneNumbers;
		}
		else{
			var smsPhoneNumberGroup = this.pool.smsPhoneNumberGroups[smsAlarm.phoneNumbers];
			phoneNumbers = smsPhoneNumberGroup.phoneNumbers;
			xmlS.setAttribute("phonebook", smsPhoneNumberGroup.index);
		}

		for(var i = 0; i < phoneNumbers.length; i++){
			var xmlNUM = xmlDoc.createElement("NUM");
			xmlNUM.setAttribute("idx", i + 1);
			xmlNUM.appendChild(xmlDoc.createTextNode(phoneNumbers[i]));
			xmlS.appendChild(xmlNUM);
		}

		var xmlMSG = xmlDoc.createElement("MSG");
		xmlMSG.appendChild(xmlDoc.createTextNode(smsAlarm.message));
		xmlS.appendChild(xmlMSG);

		xmlSMS.appendChild(xmlS);
	}

	if(xmlSMS.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlSMS);
				break;
			}
		}
	}
};

WISE.managers.smsManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.smsAlarms){
		this.pool.smsAlarms[key].index = ++index;
	}

	var index = 0;
	for(var key in this.pool.smsPhoneNumberGroups){
		this.pool.smsPhoneNumberGroups[key].index = ++index;
	}
};