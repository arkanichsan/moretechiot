WISE.managers.bluemixManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "BLUEMIX"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("r_obj"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "SUB"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.subscribe);

				if($(xmlDoc).attr("l_idx")){
					ruleObject.rule.commandKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				}

				ruleObject.rule.variableKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.actions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "PUB"){
				ruleObject = WISE.createRuleObject(this.pool.actions.publish);
				ruleObject.rule.messageKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
		}
	}

	return ruleObject;
};
