WISE.managers.weChatManager.encodeXMLObject = function(xmlDoc){
    if(this.pool.enable == true){
        var xmlWECHAT = xmlDoc.createElement("WECHAT");
        xmlWECHAT.setAttribute("corp_id", this.pool.corpId);

        // Application
        var xmlAPPLICATION = xmlDoc.createElement("APPLICATION");

        for(var key in this.pool.applications){
            var application = this.pool.applications[key];
            var xmlA = xmlDoc.createElement("A");

            xmlA.setAttribute("idx", application.index);
            xmlA.setAttribute("agentid", application.agentId);
            xmlA.setAttribute("secret", application.secret);

            xmlAPPLICATION.appendChild(xmlA);
        }

        if(xmlAPPLICATION.childNodes.length > 0){
            xmlWECHAT.appendChild(xmlAPPLICATION);
        }

        // Message
        var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

        for(var key in this.pool.messages){
            var message = this.pool.messages[key];
            var xmlM = xmlDoc.createElement("M");

            xmlM.setAttribute("idx", message.index);
            xmlM.setAttribute("nickname", message.name);

            if(message.description != ""){
                xmlM.setAttribute("desc", message.description);
            }

            var applications = [];
            for(var i = 0; i < message.applications.length; i++){
                var key = message.applications[i];

                if(typeof(this.pool.applications[key]) != "undefined"){
                    applications.push(this.pool.applications[key].index);
                }
            }
            xmlM.setAttribute("app", applications.join(","));

            xmlM.appendChild(xmlDoc.createTextNode(message.content));

            xmlMESSAGE.appendChild(xmlM);
        }

        if(xmlMESSAGE.childNodes.length > 0){
            xmlWECHAT.appendChild(xmlMESSAGE);
        }

        // 
        if(xmlWECHAT.childNodes.length > 0){
            for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
                if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
                    xmlDoc.documentElement.childNodes[i].appendChild(xmlWECHAT);
                    break;
                }
            }
        } 
    }
};

WISE.managers.weChatManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.applications){
		this.pool.applications[key].index = ++index;
	}
    
    index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};