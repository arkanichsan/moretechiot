$.extend(true, Lang, {
	"html/mobile/frame.htm": {
		"goToDesktopVersion": "前往完整版網頁",
		"dialog": "訊息",
		"prompt": "提示"
	},

	"html/mobile/home/menu.htm": {
		"menu": "主選單",
		"home": "首頁",
		"internalRegister": "內部暫存器",
		"customizeStatus": "即時資訊顯示"
	},

	"html/mobile/home/main.htm": {
		"systemInformation": "系統資訊",
		"nickname": "名稱",
		"date": "日期",
		"time": "時間",
		"microSDSpace": "microSD卡剩餘空間",
		"none": "無",
		"totalNumberOfIOModule": "I/O模組數量",
		"moduleList": "模組列表",
		"interface": "介面",
		"address": "位址"
	},

	"html/mobile/home/status/default.htm": {
		"internalRegister": "內部暫存器",
		"no": "編號",
		"channel": "通道",
		"address": "位址",
		"counter": "計數器:",
		"enterValue": "請輸入數值：",
		"valueOfChannel": "$channel數值：",
		"none": "無",
		"diCounterX": "DI計數器$channel",
		"internalRegisterX": "內部暫存器$no",
		"popup": {
			"module": "模組：",
			"channel": "通道：",
			"value": "數值："
		}
	}
});