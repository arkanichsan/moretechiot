$.extend(true, Lang, {
	"js/wise/core/desktop.js": {
		"all": "All",
		"view": "View",
		"edit": "Edit",
		"internalRegister": "Internal Register",
		"diCounter": "DI Counter",
		"assignValue": "User-Defined",
		"systemInformation": "System Information",
		"item": "Item",
		"dateYear": "Date(Year)",
		"dateMonth": "Date(Month)",
		"dateDay": "Date(Day)",
		"timeHour": "Time(Hour)",
		"timeMinute": "Time(Minute)",
		"timeSecond": "Time(Second)",
		"signalStrengthDBM": "Mobile Network Signal Strength(dBm)",
		"signalStrengthPercent": "Mobile Network Signal Strength(%)"
	}
});