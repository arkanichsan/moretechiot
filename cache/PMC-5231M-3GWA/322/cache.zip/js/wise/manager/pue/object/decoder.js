WISE.managers.pueManager.decodeXMLObject = function(xmlDoc){
	var processExtendedModuleRule = function(xmlDoc, energys){
		var moduleManager = WISE.managers.moduleManager;

		var module = null;
		if($(xmlDoc).attr("l_obj") == "RTU"){
			module = moduleManager.pool.interfaces.comport[parseInt($(xmlDoc).attr("l_com"), 10)].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
		}
		else if($(xmlDoc).attr("l_obj") == "TCP"){
			module = moduleManager.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
		}

		if(module != null && module.extendedModule == "powerMeter"){//process extended module
			var channelInfo = module[$(xmlDoc).attr("l_ch")].remoteAddress[parseInt($(xmlDoc).attr("l_chn"), 10)];

			energys.push({
				"operator": $(xmlDoc).attr("op"),
				"moduleKey": module.key,
				"loop": channelInfo.loop,
				"phase": channelInfo.phase
			});

			return channelInfo;
		}
	};

	var $xmlPUE = $(xmlDoc).find("WISE > PUE");
	if($xmlPUE.length > 0){
		var $xmlP = $xmlPUE.find("> P");
		for(var i = 0; i < $xmlP.length; i++){
			var pue = this.createPUE({
				"name": $($xmlP[i]).attr("nickname"),
				"description": $($xmlP[i]).attr("desc"),
				"chartBoundary": {
					"minimum": typeof($($xmlP[i]).attr("min")) != "undefined" ? parseFloat($($xmlP[i]).attr("min")) : undefined,//Compatibility with old version(no min)
					"maximum": parseFloat($($xmlP[i]).attr("max"))
				},
				"chartMarker": (function(){
					var chartMarker = [];

					var $xmlM = $($xmlP[i]).find("MARKER > M");
					for(var j = 0; j < $xmlM.length; j++){
						chartMarker.push({
							"name": $($xmlM[j]).attr("name"),
							"value": $($xmlM[j]).attr("value")/*,
							"color": $($xmlM[j]).attr("color")*/
						});
					}

					return chartMarker;
				})(),
				"displayInPercentage": $($xmlP[i]).attr("percent") == "1" ? true : false
			});

			var channelInfo = null;
			var $xmlN = $($xmlP[i]).find("NUMERATOR > N");
			for(var j = 0; j < $xmlN.length; j++){
				channelInfo = processExtendedModuleRule($($xmlN[j]), pue.totalEnergys);
			}

			var $xmlD = $($xmlP[i]).find("DENOMINATOR > D");
			for(var j = 0; j < $xmlD.length; j++){
				channelInfo = processExtendedModuleRule($($xmlD[j]), pue.itEnergys);
			}

			if(channelInfo != null){
				pue.range = channelInfo.itemType + "_" + channelInfo.itemID;
			}

			this.pool.pues[parseInt($($xmlP[i]).attr("idx"), 10) - 1] = pue;
		}

		this.pool.isDefaultPage = $xmlPUE.attr("default") == "1" ? true : false;
	}
};