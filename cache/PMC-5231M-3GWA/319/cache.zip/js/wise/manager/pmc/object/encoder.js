WISE.managers.pmcManager.encodeXMLObject = function(xmlDoc){
	var xmlPMC = xmlDoc.createElement("PMC");
/*
	if(this.pool.dataLog.enable == true){
		var xmlDATALOG = xmlDoc.createElement("DATALOG");
		xmlDATALOG.setAttribute("rate", this.pool.dataLog.rate);
		xmlDATALOG.setAttribute("mode", this.pool.dataLog.mode);
		xmlDATALOG.setAttribute("filename_format", this.pool.dataLog.fileNameFormat);
		xmlDATALOG.setAttribute("eof", this.pool.dataLog.eof);
		xmlDATALOG.setAttribute("header", this.pool.dataLog.prependHeader == true ? "1" : "0");
		xmlDATALOG.setAttribute("keep_time", this.pool.dataLog.keepTime);
		if(this.pool.dataLog.upload.enable == true){
			xmlDATALOG.setAttribute("upload", "1");
			xmlDATALOG.setAttribute("upload_period", this.pool.dataLog.upload.period);
		}
		else{
			xmlDATALOG.setAttribute("upload", "0");
		}
		xmlPMC.appendChild(xmlDATALOG);
	}

	var xmlEVENTLOG = xmlDoc.createElement("EVENTLOG");
	xmlEVENTLOG.setAttribute("keep_time", this.pool.eventLog.keepTime);
	if(this.pool.eventLog.upload.enable == true){
		xmlEVENTLOG.setAttribute("upload", "1");
		xmlEVENTLOG.setAttribute("upload_period", this.pool.eventLog.upload.period);
	}
	else{
		xmlEVENTLOG.setAttribute("upload", "0");
	}
	xmlPMC.appendChild(xmlEVENTLOG);

	if(this.pool.ftp.enable == true){
		var xmlFTP = xmlDoc.createElement("FTP");
		xmlFTP.setAttribute("url", this.pool.ftp.url);
		xmlFTP.setAttribute("port", this.pool.ftp.port);
		xmlFTP.setAttribute("id", this.pool.ftp.id);

		if(this.pool.ftp.password.plain == "" || this.pool.ftp.password.plain != padding("", this.pool.ftp.password.length, "*")){//setup new password
			xmlFTP.setAttribute("password", this.pool.ftp.password.plain);
			xmlFTP.setAttribute("password_len", this.pool.ftp.password.plain.length);
		}
		else{
			xmlFTP.setAttribute("password", this.pool.ftp.password.encoded);
			xmlFTP.setAttribute("password_len", this.pool.ftp.password.length);
		}

		xmlPMC.appendChild(xmlFTP);
	}
*/
	if(this.pool.contractCapacity.enable == true){
		var xmlCONTRACTCAPACITY = xmlDoc.createElement("CONTRACTCAPACITY");
		xmlCONTRACTCAPACITY.setAttribute("capacity", this.pool.contractCapacity.capacity);
		xmlPMC.appendChild(xmlCONTRACTCAPACITY);
	}

	var xmlDEMAND = xmlDoc.createElement("DEMAND");
	xmlDEMAND.setAttribute("interval", this.pool.demand.interval);
	xmlPMC.appendChild(xmlDEMAND);

	var xmlCARBONFOOTPRINT = xmlDoc.createElement("CARBONFOOTPRINT");
	xmlCARBONFOOTPRINT.setAttribute("factor", this.pool.carbonFootprint.factor);
	xmlPMC.appendChild(xmlCARBONFOOTPRINT);
	
	do_node_xml( xmlPMC ,  this.pool.groups , xmlDoc) ;

	xmlDoc.documentElement.appendChild(xmlPMC);
};

function do_node_xml(parent , obj , xmlDoc )
{
	if( obj.node == "node" )
	{
		var xmlGROUP = xmlDoc.createElement("GROUPS");
		xmlGROUP.setAttribute("name", obj.name );
		xmlGROUP.setAttribute("node", obj.node);
		xmlGROUP.setAttribute("level", obj.level);
		xmlGROUP.setAttribute("index", obj.index);
		xmlGROUP.setAttribute("UID", obj.UID);
		xmlGROUP.setAttribute("parent_UID", obj.parent_UID);
		parent.appendChild(xmlGROUP)
		
		if( obj.child.length > 0 )for( var i = 0 ; i < obj.child.length ; i++ )do_node_xml(xmlGROUP , obj.child[i] , xmlDoc ) ;
		else return ; 
	}	
		
	if( obj.node == "leaf" )
	{
		var xmlGROUP = xmlDoc.createElement("GROUPS");
		xmlGROUP.setAttribute("name", obj.name );
		xmlGROUP.setAttribute("pm_name", obj.pm_name );
		xmlGROUP.setAttribute("loop_name", obj.loop_name );
		xmlGROUP.setAttribute("channel_name", obj.channel_name );
		xmlGROUP.setAttribute("node", obj.node);
		xmlGROUP.setAttribute("level", obj.level);
		xmlGROUP.setAttribute("index", obj.index);
		xmlGROUP.setAttribute("ch", obj.ch);
		xmlGROUP.setAttribute("UID", obj.UID);
		xmlGROUP.setAttribute("parent_UID", obj.parent_UID);
		
		var pm = WISE.managers.moduleManager.getModuleInfoByKey(obj.key) ;
		
		var type = "TCP" ;
		if( pm.sourceType == "comport")type = "RTU";
		com = pm.sourceIndex ;
		modules = pm.moduleIndex + 1 ;
		
		xmlGROUP.setAttribute("type", type);
		xmlGROUP.setAttribute("modules", modules);
		xmlGROUP.setAttribute("com", com);
		
		parent.appendChild(xmlGROUP);
		
		return ;
	}
	return ;
}
