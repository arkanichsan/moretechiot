﻿var have_pm = false ;
var have_io = false ;
var pm_amount = 0;
var io_amount = 0;


function check_pm_io()
{
	have_pm = false ;
	have_io = false ;
	pm_amount = 0;
	io_amount = 0;
	var registerManager = WISE.managers.registerManager;
	if(typeof(registerManager) != "undefined")
	{
		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registers.length; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}
			have_io = true ;
			break;
		}
	}

	//onboard
	var moduleManager = WISE.managers.moduleManager;
	if(typeof(moduleManager) != "undefined")
	{
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.onboard.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.onboard[sourceIndex]) == "undefined"){continue;}
		
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.onboard[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				onboard = moduleManager.pool.interfaces.onboard[sourceIndex].modules ;
				have_io = true ;
				break;
			}
		}

		//comport
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.comport.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.comport[sourceIndex]) == "undefined"){continue;}
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				
				if(typeof(modules[moduleIndex].powerMeter) != "undefined")
				{
					have_pm = true ;
					pm_amount++;
				}
				if(typeof(modules[moduleIndex].powerMeter) == "undefined")
				{
					have_io = true ;
					io_amount++;
				}
			}
		}

		//network
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.network.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.network[sourceIndex]) == "undefined" ){continue;}
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				
				if(typeof(modules[moduleIndex].powerMeter) != "undefined")
				{
					have_pm = true ;
					pm_amount++;
				}
				if(typeof(modules[moduleIndex].powerMeter) == "undefined")
				{
					have_io = true ;
					io_amount++;
				}
			}
		}
	}
}

function get_ir_info()
{
	var ir_a = new Array();
	var registerManager = WISE.managers.registerManager;
	if(typeof(registerManager) != "undefined")
	{
		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registers.length; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}
			var obj = new Object();
			obj.name = "<#Lang['pmGlobal'].internalRegister>" ;
			obj.type = 0 ;
			obj.modbus = "" ;
			obj.com = "" ;
			obj.modules = "" ;
			ir_a.push(obj);
			break;
		}
	}
	return ir_a ;
}

function get_xb_info()
{
	var xb_a = new Array();
	var moduleManager = WISE.managers.moduleManager;
	if(typeof(moduleManager) != "undefined")
	{
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.onboard.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.onboard[sourceIndex]) == "undefined"){continue;}
		
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.onboard[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				var obj = new Object();
				obj.name = WISE.moduleInfo("onboard", sourceIndex, moduleIndex) ;
				obj.type = 1 ;
				obj.modbus = "onboard" ;
				obj.com = sourceIndex ;
				obj.modules = moduleIndex ;
				xb_a.push(obj);
				break;
			}
		}
	}
	return xb_a;
}

function get_io_info()
{
	var io_a = new Array();
	var moduleManager = WISE.managers.moduleManager;
	if(typeof(moduleManager) != "undefined")
	{
		//comport
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.comport.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.comport[sourceIndex]) == "undefined"){continue;}
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				
				if(typeof(modules[moduleIndex].powerMeter) == "undefined")
				{
					var obj = new Object();
					obj.name = WISE.moduleInfo("comport", sourceIndex, moduleIndex) ;
					obj.type = 1 ;
					obj.modbus = "comport" ;
					obj.com = sourceIndex ;
					obj.modules = moduleIndex ;
					io_a.push(obj);
				}
			}
		}

		//network
		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.network.length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces.network[sourceIndex]) == "undefined" ){continue;}
			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}
				
				if(typeof(modules[moduleIndex].powerMeter) == "undefined")
				{
					var obj = new Object();
					obj.name = moduleManager.pool.interfaces.network[sourceIndex].modules[moduleIndex].name;
					obj.type = 1 ;
					obj.modbus = "network" ;
					obj.com = sourceIndex ;
					obj.modules = moduleIndex ;
					io_a.push(obj);
				}
			}
		}
	}
	return io_a;
}

function get_pm_info()
{
	var pm_comter = 0 ;
	var set_info = WISE.managers.moduleManager.pool.interfaces ;
	var pm_array = new Array();
	
	for( i = 0 ; i < set_info.comport.length ; i++ )
	{
		if(typeof( set_info.comport[i]) == "undefined"){continue;}
		if(set_info.comport[i].modules.length != 0)
		{
			for( j = 0 ; j < set_info.comport[i].modules.length ; j++)
			{
				if(typeof(set_info.comport[i].modules[j]) == "undefined"){continue;}
				if(set_info.comport[i].protocol == "modbusRTU" )
				{
					if(typeof(set_info.comport[i].modules[j].powerMeter) != "undefined")
					{
						var obj = new Object();
						obj.pm = set_info.comport[i].modules[j] ;
						obj.modbus = "comport" ;
						obj.com = i ;
						obj.modules = j ;
						obj.comter = pm_comter ;
						pm_array.push(obj);
						pm_comter++;
					}
				}
			}
		}
	}
	//TCP
	if(set_info.network[0].modules.length != 0)
	{
		for( j = 0 ; j < set_info.network[0].modules.length ; j++)
		{
			if(typeof(set_info.network[0].modules[j]) == "undefined"){continue;}
			if(typeof(set_info.network[0].modules[j].powerMeter) != "undefined")
			{
				var obj = new Object();
				obj.pm = set_info.network[0].modules[j] ;
				obj.modbus = "network" ;
				obj.com = 0 ;
				obj.modules = j ;
				obj.comter = pm_comter ;
				pm_array.push(obj);
				pm_comter++;
			}
		}
	}
	return pm_array ;
}

function get_channel_name(obj,type)
{
	if('undefined' == typeof(type)) type ="";
	var loop_name_a = new Array() ;
	
	var phase3_a = ["<#Lang['pmGlobal'].aphase>","<#Lang['pmGlobal'].bphase>","<#Lang['pmGlobal'].cphase>","<#Lang['pmGlobal'].sum>"];
	if(type == "V" || type == "I" || type == "PF" )phase3_a[3] = "<#Lang['pmGlobal'].average>";
	if(type == "")phase3_a[3] = "<#Lang['pmGlobal'].sum_average>" ;
	
	var counter = 0 ;
	for( var i = 0 ; i < obj.powerMeter.channel.length ; i++ )
	{
		var isSinglePhase =false
		if(typeof(obj.powerMeter.channel[i].isSinglePhase) != "undefined")
			isSinglePhase = obj.powerMeter.channel[i].isSinglePhase;
		
		var CT_loop_Count = 0;
		for( var j = 0 ; j < obj.powerMeter.channel[i].length ; j++ )
		{
			if(obj.powerMeter.phase != 3 )
			{
				if( obj.powerMeter.channel[i].name == "" )
					//loop_name_a[counter] = "<#Lang['pmGlobal'].loop>  " + (counter+1) ;
				loop_name_a[counter] = "CT" + (counter+1) ;
				else
					loop_name_a[counter] = obj.powerMeter.channel[i].name ;
			}
			else
			{
				if( isSinglePhase )
				{
					if(CT_loop_Count < 3)
					{
						if( obj.powerMeter.channel[i][j].name == "" )
							loop_name_a[counter] = "CT" + (i*3+j+1) ;
							//loop_name_a[counter] = "<#Lang['pmGlobal'].loop>  " + (i*3+j+1) ;
						else
							loop_name_a[counter] = obj.powerMeter.channel[i][j].name ;
						CT_loop_Count++;
					}
					else
					{
						loop_name_a[counter] = "<#Lang['pmGlobal'].sum>"
						if(type == "V" || type == "I" || type == "PF" )
							loop_name_a[counter] = "<#Lang['pmGlobal'].average>";
						else if(type == "")
							loop_name_a[counter]  = "<#Lang['pmGlobal'].sum_average>" ;
					}
				}
				else
				{
					if( obj.powerMeter.channel[i][j].name == "" )
						loop_name_a[counter] = phase3_a[j%4] ;
					else 
						loop_name_a[counter] = obj.powerMeter.channel[i][j].name ;
				}
			}
			counter++ ;
		}
	}
	return loop_name_a ;
}

function get_cb_channel_name(obj,type)
{
	if('undefined' == typeof(type)) type ="";
	var loop_name_a = new Array() ;
	
	var phase3_a = ["<#Lang['pmGlobal'].aphase>","<#Lang['pmGlobal'].bphase>","<#Lang['pmGlobal'].cphase>","<#Lang['pmGlobal'].sum>"];
	if(type == "V" || type == "I" || type == "PF" )phase3_a[3] = "<#Lang['pmGlobal'].average>";
	if(type == "")phase3_a[3] = "<#Lang['pmGlobal'].sum_average>" ;
	
	var counter = 0 ;
	for( var i = 0 ; i < obj.powerMeter.channel.length ; i++ )
	{
		var isSinglePhase =false
		if(typeof(obj.powerMeter.channel[i].isSinglePhase) != "undefined")
			isSinglePhase = obj.powerMeter.channel[i].isSinglePhase;
	
		var CT_loop_Count = 0;
		for( var j = 0 ; j < obj.powerMeter.channel[i].length ; j++ )
		{
			if(obj.powerMeter.phase != 3 )
			{
				//if( obj.powerMeter.channel[i].name == "" )loop_name_a[counter] = "<#Lang['pmGlobal'].loop>  " + (counter+1) ;
				//else loop_name_a[counter] = "<#Lang['pmGlobal'].loop>  " + (counter+1) + "("+obj.powerMeter.channel[i].name + ")";
				if( obj.powerMeter.channel[i].name == "" )
					loop_name_a[counter] = "CT" + (counter+1) ;
				else 
					loop_name_a[counter] = "CT" + (counter+1) + "("+obj.powerMeter.channel[i].name + ")";
			}
			else
			{
				if( isSinglePhase )
				{
					if(CT_loop_Count < 3)
					{
						if( obj.powerMeter.channel[i][j].name == "" )
							loop_name_a[counter] = "CT" + (i*3+j+1) ;
							//loop_name_a[counter] = "<#Lang['pmGlobal'].loop>  " + (i*3+j+1) ;
						else
							loop_name_a[counter] = obj.powerMeter.channel[i][j].name ;
						CT_loop_Count++;
					}
					else
					{
						loop_name_a[counter] = "<#Lang['pmGlobal'].sum>"
						if(type == "V" || type == "I" || type == "PF" )
							loop_name_a[counter] = "<#Lang['pmGlobal'].average>";
						else if(type == "")
							loop_name_a[counter]  = "<#Lang['pmGlobal'].sum_average>" ;
					}
				}
				else
					if( obj.powerMeter.channel[i][j].name == "" )
						loop_name_a[counter] = phase3_a[j%4] ;
					else 
						loop_name_a[counter] =  phase3_a[j%4]+"("+obj.powerMeter.channel[i][j].name + ")";
			}
			counter++ ;
		}
	}
	return loop_name_a ;
}

function get_loop_name(obj)
{
	var loop_name_a = new Array() ;
	for( var i = 0 ; i < obj.powerMeter.channel.length ; i++ )
	{
		if( obj.powerMeter.channel[i].name == "" )
			if(obj.powerMeter.phase == 3)
				loop_name_a[i] = "<#Lang['pmGlobal'].submeter>" + (i+1) ;
			else
				loop_name_a[i] = "CT" + (i+1) ;
			
			//loop_name_a[i] = "<#Lang['pmGlobal'].loop>  " + (i+1) ;
		else
			loop_name_a[i] =obj.powerMeter.channel[i].name ;
	}
	return loop_name_a ;
}

function get_cb_loop_name(obj)
{
	var loop_name_a = new Array() ;
	for( var i = 0 ; i < obj.powerMeter.channel.length ; i++ )
	{
		if( obj.powerMeter.channel[i].name == "" )
			//loop_name_a[i] = "<#Lang['pmGlobal'].loop>  " + (i+1) ;
			loop_name_a[i] = "<#Lang['pmGlobal'].submeter>" + (i+1) ;
		else
			//loop_name_a[i] ="<#Lang['pmGlobal'].loop>  " + (i+1)+"("+obj.powerMeter.channel[i].name +")";
			loop_name_a[i] ="<#Lang['pmGlobal'].submeter>" + (i+1)+"("+obj.powerMeter.channel[i].name +")";
	}
	return loop_name_a ;
}



function updateValue($textFiled, value)
{
	if(!$textFiled.attr("textColor")){
	$textFiled.attr("textColor", $textFiled.css("color"));
	}

	var previousValue = $textFiled.text();

	if(previousValue != value && previousValue != "-" && previousValue != ""){
	$textFiled.stop().css("color", "#FF0000").animate({"color": $textFiled.attr("textColor")}, 2000, "easeInExpo");
	}

	$textFiled.text(value);
}