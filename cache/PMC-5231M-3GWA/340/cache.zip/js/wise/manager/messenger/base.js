WISE.managers.messengerManager = (function(){
	return new function() {
		this.pool = {
            enable: false,
            pages: {},
            pageKey: 0,
			messages: {},
			messageKey: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};

		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
        this.maxPageAmount = 12;
		this.maxMessageAmount = 12;

        this.createPage = function(settings){
			var page = $.extend(true, {
				"index": 0,
				"token": ""
			}, settings);

			return page;
		};

		this.addPage = function(page){
			var retKey = this.pool.pageKey;
			this.pool.pages[this.pool.pageKey++] = page;
			return retKey;
		};

		this.removePage = function(key){
			delete this.pool.pages[key];
		};

		this.getPage = function(key){
			if(typeof(this.pool.pages[key]) != "undefined"){
				return this.pool.pages[key];
			}
			else{
				return null;
			}
		};

		this.setPage = function(key, page){
			this.pool.pages[key] = page;
		};

		this.getPages = function(){
			return this.pool.pages;
		};
        
        this.createMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"pages": [],
				"content": ""
			}, settings);

			return message;
		};

		this.addMessage = function(message){
			var retKey = this.pool.messageKey;
			this.pool.messages[this.pool.messageKey++] = message;
			return retKey;
		};

		this.removeMessage = function(key){
			delete this.pool.messages[key];
		};

		this.getMessage = function(key){
			if(typeof(this.pool.messages[key]) != "undefined"){
				return this.pool.messages[key];
			}
			else{
				return null;
			}
		};

		this.setMessage = function(key, message){
			this.pool.messages[key] = message;
		};

		this.getMessages = function(){
			return this.pool.messages;
		};
	};
})();
