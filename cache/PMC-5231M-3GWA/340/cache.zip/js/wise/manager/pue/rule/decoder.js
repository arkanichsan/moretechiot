WISE.managers.pueManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	if($(xmlDoc).attr("l_obj") == "PUE"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.pue);
			ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
			processCompareModule(xmlDoc, ruleObject);
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		}

		ruleObject.rule.pueIndex = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
	}

	return ruleObject;
};