$.extend(true, Lang, {
	"js/wise/extend/init/desktop.js": {
		"pulseOutput": "脈衝輸出",
		"powerMeter": "電錶",
		"channel": "通道",
		"info": "資訊",
		"ch": "通道",
		"item": "項目",
		"no": "編號",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息",
		"pue": "能源使用效率",
		"all": "全部"
	}
});