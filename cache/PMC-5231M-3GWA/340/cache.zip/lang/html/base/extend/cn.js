$.extend(true, Lang, {
	"global": {
		"ctX": "CT$no",
		"submeterX": "子电测模块$no",
		"phaseX": "相位$no",
		"totalOrAverage": "总和 / 平均",
		"basicValue": "基本数值",
		"statisticsValue": "统计数值",
		"ioInformation": "I/O信息",
		"otherInformation": "其他信息"
	}
});