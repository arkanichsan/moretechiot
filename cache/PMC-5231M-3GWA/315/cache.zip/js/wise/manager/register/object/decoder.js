WISE.managers.registerManager.decodeXMLObject = function(xmlDoc){
	var $xmlIR = $(xmlDoc).find("WISE > IR");
	if($xmlIR.length > 0){
		var $xmlI = $xmlIR.find("> I");
		for(var i = 0; i < $xmlI.length; i++){
			var register = this.createRegister({
				"name": $($xmlI[i]).attr("nickname"),
				"description": $($xmlI[i]).attr("desc"),
				"initialValue": parseFloat($($xmlI[i]).attr("value"))
			});

			this.pool.registers[parseInt($($xmlI[i]).attr("idx"), 10) - 1] = register;
		}
	}
};
