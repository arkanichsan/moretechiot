WISE.managers.loggerManager.encodeXMLObject = function(xmlDoc){
	var xmlDATALOG = xmlDoc.createElement("DATALOG");

	if(this.pool.dataLog.powerMeterLog.enable == true){
		var xmlPOWERLOG = xmlDoc.createElement("POWERLOG");
		xmlPOWERLOG.setAttribute("mode", this.pool.dataLog.powerMeterLog.mode);
		xmlPOWERLOG.setAttribute("header", this.pool.dataLog.powerMeterLog.addHeader == true ? "1" : "0");

		if(this.pool.dataLog.powerMeterLog.report != ""){
			xmlPOWERLOG.setAttribute("report", this.pool.dataLog.powerMeterLog.report);
		}

		xmlPOWERLOG.setAttribute("upload", this.pool.ftp.upload.dataLog.powerMeterLog.enable == true && this.pool.ftp.enable == true ? "1" : "0");
		xmlPOWERLOG.setAttribute("cloud", this.pool.cloud.upload.dataLog.powerMeterLog.enable == true && this.pool.cloud.enable == true ? "1" : "0");
		xmlDATALOG.appendChild(xmlPOWERLOG);
	}

	if(this.pool.dataLog.ioModuleLog.enable == true){
		var xmlIOLOG = xmlDoc.createElement("IOLOG");
		xmlIOLOG.setAttribute("upload", this.pool.ftp.upload.dataLog.ioModuleLog.enable == true && this.pool.ftp.enable == true ? "1" : "0");
		xmlIOLOG.setAttribute("cloud", this.pool.cloud.upload.dataLog.ioModuleLog.enable == true && this.pool.cloud.enable == true ? "1" : "0");
		xmlDATALOG.appendChild(xmlIOLOG);
	}

	if(this.pool.dataLog.customizedLog.enable == true){
		var xmlUSER_DEFINED = xmlDoc.createElement("USER_DEFINED");
		xmlUSER_DEFINED.setAttribute("upload", this.pool.ftp.upload.dataLog.customizedLog.enable == true && this.pool.ftp.enable == true ? "1" : "0");
		xmlUSER_DEFINED.setAttribute("header", CodeToName(this.pool.dataLog.customizedLog.format));
		xmlUSER_DEFINED.appendChild(xmlDoc.createTextNode(this.pool.dataLog.customizedLog.format));
		xmlDATALOG.appendChild(xmlUSER_DEFINED);
	}

	if(this.pool.dataLog.powerMeterLog.enable == true || this.pool.dataLog.ioModuleLog.enable == true || this.pool.dataLog.customizedLog.enable == true){
		var xmlLOG_SETTING = xmlDoc.createElement("LOG_SETTING");
		xmlLOG_SETTING.setAttribute("rate", this.pool.dataLog.rate);
		xmlLOG_SETTING.setAttribute("filename_format", this.pool.dataLog.fileNameFormat);
		xmlLOG_SETTING.setAttribute("eof", this.pool.dataLog.eof);
		xmlLOG_SETTING.setAttribute("keep_time", this.pool.dataLog.keepTime);
		if(this.pool.ftp.enable == true){
			xmlLOG_SETTING.setAttribute("upload_period", this.pool.ftp.upload.dataLog.period);
		}
		xmlDATALOG.appendChild(xmlLOG_SETTING);
	}

	var xmlEVENTLOG = xmlDoc.createElement("EVENTLOG");
	xmlEVENTLOG.setAttribute("keep_time", this.pool.eventLog.keepTime);
	xmlEVENTLOG.setAttribute("upload", this.pool.ftp.upload.eventLog.enable == true && this.pool.ftp.enable == true ? "1" : "0");
	if(this.pool.ftp.enable == true){
		xmlEVENTLOG.setAttribute("upload_period", this.pool.ftp.upload.eventLog.period);
	}
	xmlDATALOG.appendChild(xmlEVENTLOG);

	if(this.pool.ftp.enable == true){
		var xmlFTP = xmlDoc.createElement("FTP");
		xmlFTP.setAttribute("url", this.pool.ftp.url);
		xmlFTP.setAttribute("port", this.pool.ftp.port);
		xmlFTP.setAttribute("id", this.pool.ftp.id);
		if(this.pool.ftp.password.plain == "" || this.pool.ftp.password.plain != padding("", this.pool.ftp.password.length, "*")){//setup new password
			xmlFTP.setAttribute("password", this.pool.ftp.password.plain);
			xmlFTP.setAttribute("password_len", this.pool.ftp.password.plain.length);
		}
		else{
			xmlFTP.setAttribute("password", this.pool.ftp.password.encoded);
			xmlFTP.setAttribute("password_len", this.pool.ftp.password.length);
		}
		xmlFTP.setAttribute("path", this.pool.ftp.path);
		xmlDATALOG.appendChild(xmlFTP);
	}

	if(this.pool.cloud.enable == true){
		var xmlCLOUD = xmlDoc.createElement("CLOUD");
		xmlDATALOG.appendChild(xmlCLOUD);
	}

	for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
		if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
			xmlDoc.documentElement.childNodes[i].appendChild(xmlDATALOG);
			break;
		}
	}
};

function CodeToName(content)
{
	var content = content.replace(/</g, "&lt;"), index = 0;
	var content_a = content.split(',');
	var channel = "";
	
	for(var i in content_a)
	{
		if(content_a[i]!="")
		{
			var regex = new RegExp("\\$(X|C(\\d+)D(\\d+))(\\D+\\d+)|\\$(T(\\d+)|C(\\d+)M(\\d+))(\\D+\\d+)|\\$(I(\\d+))" + (typeof(WISE.buildVariableEditor.extendRegex) == "string" ? "|(" + WISE.buildVariableEditor.extendRegex + ")": ""), "g");
			var result = undefinedToEmptyString(regex.exec(content_a[i]));
			var $replaceElement = null;
			if(result[1].charAt(0) == "X"){//xwboard
				$replaceElement = WISE.buildVariableEditor.moduleProcessor({
					"sourceType": "onboard",
					"sourceIndex": 0,
					"moduleIndex": 0
				}, result[4]);
			}
			else if(result[1].charAt(0) == "C"){//dcon
				$replaceElement = WISE.buildVariableEditor.moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[2], 10),
					"moduleIndex": parseInt(result[3], 10) - 1
				}, result[4]);
			}
			else if(result[5].charAt(0) == "T"){//modbus tcp
				$replaceElement = WISE.buildVariableEditor.moduleProcessor({
					"sourceType": "network",
					"sourceIndex": 0,
					"moduleIndex": parseInt(result[6], 10) - 1
				}, result[9]);
			}
			else if(result[5].charAt(0) == "C"){//modbus rtu
				$replaceElement = WISE.buildVariableEditor.moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[7], 10),
					"moduleIndex": parseInt(result[8], 10) - 1
				}, result[9]);
			}
			else if(result[10].charAt(0) == "I"){//ir
				$replaceElement = WISE.buildVariableEditor.registerProcessor({
					"registerIndex": parseInt(result[11], 10) - 1,
					"moduleKey": null
				});
			}
			else{
				if(typeof(WISE.buildVariableEditor.extendReplaceElement) == "function"){
					$replaceElement = WISE.buildVariableEditor.extendReplaceElement(result.slice(14));
				}
			}

			if($replaceElement != null){//channel is exist
				if(typeof(elementProcessor) == "function"){
					elementProcessor($replaceElement, regex, result);
				}
				channel += $replaceElement.text()+",";
			}
			else
				channel += ""+",";
		}
		else
			channel += ""+",";
	}
	return channel;
}

function undefinedToEmptyString(objectArray){
	if(!objectArray){return objectArray;}

	for(var i = 0; i < objectArray.length; i++){
		if(typeof(objectArray[i]) == "undefined"){
			objectArray[i] = "";
		}
	}
	return objectArray;
};

