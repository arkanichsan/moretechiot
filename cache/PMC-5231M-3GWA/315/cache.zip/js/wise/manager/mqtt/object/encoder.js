WISE.managers.mqttManager.encodeXMLObject = function(xmlDoc){
	var xmlMQTT = xmlDoc.createElement("MQTT");
	var brokerCounter = 0;

	for(var brokerKey in this.pool.brokers){
		var broker = this.pool.brokers[brokerKey];
		var xmlBROKER = xmlDoc.createElement("BROKER");

		xmlBROKER.setAttribute("idx", broker.index);
		xmlBROKER.setAttribute("address", broker.address);
		xmlBROKER.setAttribute("port", broker.port);

		if(broker.authInfo.enable == true){
			xmlBROKER.setAttribute("username", broker.authInfo.id);
			if(broker.authInfo.password.plain == "" || broker.authInfo.password.plain != padding("", broker.authInfo.password.length, "*")){//setup new password
				xmlBROKER.setAttribute("password", broker.authInfo.password.plain);
				xmlBROKER.setAttribute("password_len", broker.authInfo.password.plain.length);
			}
			else{
				xmlBROKER.setAttribute("password", broker.authInfo.password.encoded);
				xmlBROKER.setAttribute("password_len", broker.authInfo.password.length);
			}
		}

		if(broker.will.enable == true){
			xmlBROKER.setAttribute("will_topic", broker.will.topicName);
			xmlBROKER.setAttribute("will_message", broker.will.payload);
			xmlBROKER.setAttribute("will_qos", broker.will.qos);
		}

		xmlBROKER.setAttribute("ssl_enable", broker.encryption == true ? "1" : "0");
		if(broker.clientId != ""){
			xmlBROKER.setAttribute("clientid", broker.clientId);
		}
		xmlBROKER.setAttribute("alive_timer", broker.keepAliveTimer);
		xmlBROKER.setAttribute("publish_period", broker.publishInterval);
		xmlBROKER.setAttribute("prefix", broker.prefix);

		xmlBROKER.setAttribute("enable", broker.initialStatus == true ? "1" : "0");

		xmlBROKER.setAttribute("nickname", broker.name);
		if(broker.description != ""){
			xmlBROKER.setAttribute("desc", broker.description);
		}

		//publish message
		var xmlPUBLISH = xmlDoc.createElement("PUBLISH");
		var messageCounter = 0;

		for(var messageKey in broker.publish.messages){
			var message = broker.publish.messages[messageKey];
			var xmlP = xmlDoc.createElement("P");

			xmlP.setAttribute("idx", message.index);

			if(message.usePrefix == true){
				xmlP.setAttribute("topic", broker.prefix != "" ? broker.prefix + "/" + message.topicName : message.topicName);
			}
			else{
				xmlP.setAttribute("topic", message.topicName);
			}

			xmlP.setAttribute("use_prefix", message.usePrefix == true ? "1" : "0");
			xmlP.setAttribute("data_type", message.type);
			xmlP.setAttribute("data", message.payload);
			xmlP.setAttribute("qos", message.qos);
			xmlP.setAttribute("retain", message.retain == true ? "1" : "0");

			if(message.autoPublish.timing & 1){
				xmlP.setAttribute("pub_gate", message.autoPublish.threshold);
			}
			if(message.autoPublish.timing & 2){
				xmlP.setAttribute("period_pub", "1");
			}
			else{
				xmlP.setAttribute("period_pub", "0");
			}

			xmlP.setAttribute("nickname", message.name);
			if(message.description != ""){
				xmlP.setAttribute("desc", message.description);
			}

			xmlPUBLISH.appendChild(xmlP);
			messageCounter++;
		}

		xmlPUBLISH.setAttribute("topic_num", messageCounter);
		xmlBROKER.appendChild(xmlPUBLISH);

		//subscribe topic
		var xmlSUBSCRIBE = xmlDoc.createElement("SUBSCRIBE");
		var topicCounter = 0;

		for(var topicKey in broker.subscribe.topics){
			var topic = broker.subscribe.topics[topicKey];
			var xmlS = xmlDoc.createElement("S");

			xmlS.setAttribute("idx", topic.index);

			if(topic.usePrefix == true){
				xmlS.setAttribute("topic", broker.prefix != "" ? broker.prefix + "/" + topic.topicName : topic.topicName);
			}
			else{
				xmlS.setAttribute("topic", topic.topicName);
			}

			xmlS.setAttribute("use_prefix", topic.usePrefix == true ? "1" : "0");
			xmlS.setAttribute("qos", topic.qos);

			xmlS.setAttribute("nickname", topic.name);
			if(topic.description != ""){
				xmlS.setAttribute("desc", topic.description);
			}

			xmlSUBSCRIBE.appendChild(xmlS);
			topicCounter++;
		}

		xmlSUBSCRIBE.setAttribute("topic_num", topicCounter);
		xmlBROKER.appendChild(xmlSUBSCRIBE);

		xmlMQTT.appendChild(xmlBROKER);
		brokerCounter++;
	}

	xmlMQTT.setAttribute("num", brokerCounter);

	if(xmlMQTT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlMQTT);
				break;
			}
		}
	}
};

WISE.managers.mqttManager.updateIndex = function(){
	var brokerIndex = 0;
	for(var brokerKey in this.pool.brokers){
		this.pool.brokers[brokerKey].index = ++brokerIndex;

		var messageIndex = 0;
		for(var messageKey in this.pool.brokers[brokerKey].publish.messages){
			this.pool.brokers[brokerKey].publish.messages[messageKey].index = ++messageIndex;
		}

		var topicIndex = 0;
		for(var topicKey in this.pool.brokers[brokerKey].subscribe.topics){
			this.pool.brokers[brokerKey].subscribe.topics[topicKey].index = ++topicIndex;
		}
	}
};
