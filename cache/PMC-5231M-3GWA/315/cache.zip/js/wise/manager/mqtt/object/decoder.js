WISE.managers.mqttManager.decodeXMLObject = function(xmlDoc){
	var $xmlMQTT = $(xmlDoc).find("WISE > NOTE > MQTT");
	if($xmlMQTT.length > 0){
		var $xmlBROKER = $xmlMQTT.find("> BROKER");
		var maxBrokerKey = 0;
		for(var i = 0; i < $xmlBROKER.length; i++){
			var brokerKey = parseInt($($xmlBROKER[i]).attr("idx"), 10) - 1;
			if(brokerKey > maxBrokerKey){maxBrokerKey = brokerKey};

			var broker = this.createBroker({
				"name": $($xmlBROKER[i]).attr("nickname"),
				"description": $($xmlBROKER[i]).attr("desc") || "",

				"initialStatus": $($xmlBROKER[i]).attr("enable") == "1" ? true : false,
				"address": $($xmlBROKER[i]).attr("address"),
				"port": parseInt($($xmlBROKER[i]).attr("port"), 10),
				"authInfo": $($xmlBROKER[i]).attr("username") ? {
					"enable": true,
					"id": $($xmlBROKER[i]).attr("username"),
					"password": {
						"plain": padding("", parseInt($($xmlBROKER[i]).attr("password_len"), 10), "*"),
						"encoded": $($xmlBROKER[i]).attr("password"),
						"length": parseInt($($xmlBROKER[i]).attr("password_len"), 10)
					}
				} : {
					"enable": false
				},
				"will": $($xmlBROKER[i]).attr("will_topic") ? {
					"enable": true,
					"topicName": $($xmlBROKER[i]).attr("will_topic"),
					"payload": $($xmlBROKER[i]).attr("will_message"),
					"qos": parseInt($($xmlBROKER[i]).attr("will_qos"), 10)
				} : {
					"enable": false
				},
				"encryption": $($xmlBROKER[i]).attr("ssl_enable") == "1" ? true : false,
				"clientId": $($xmlBROKER[i]).attr("clientid") || "",
				"keepAliveTimer": parseInt($($xmlBROKER[i]).attr("alive_timer"), 10),
				"publishInterval": parseInt($($xmlBROKER[i]).attr("publish_period"), 10),
				"prefix": $($xmlBROKER[i]).attr("prefix") || ""
			});

			this.setBroker(brokerKey, broker);

			var $xmlP = $($xmlBROKER[i]).find("> PUBLISH > P");
			if($xmlP.length > 0){
				var maxMessageKey = 0;
				for(var j = 0; j < $xmlP.length; j++){
					var messageKey = parseInt($($xmlP[j]).attr("idx"), 10) - 1;
					if(messageKey > maxMessageKey){maxMessageKey = messageKey};

					// Process prefix first
					var usePrefix = $($xmlP[j]).attr("use_prefix");
					if(usePrefix){
						usePrefix = (usePrefix == "1" ? true : false);
					}
					else{// Downward compatibility
						if($($xmlP[j]).attr("topic").startsWith(broker.prefix + "/") == true){
							usePrefix = true;
						}
						else{
							usePrefix = false;
						}
					}

					var topicName = $($xmlP[j]).attr("topic");
					if(usePrefix){
						topicName = topicName.replace(new RegExp("^" + broker.prefix + "/"), "");
					}

					var message = this.createPublishMessage({
						"name": $($xmlP[j]).attr("nickname"),
						"description": $($xmlP[j]).attr("desc") || "",

						"topicName": topicName,
						"usePrefix": usePrefix,
						"type": parseInt($($xmlP[j]).attr("data_type"), 10),
						"payload": $($xmlP[j]).attr("data"),
						"qos": parseInt($($xmlP[j]).attr("qos"), 10),
						"retain": $($xmlP[j]).attr("retain") == "1" ? true : false,
						"autoPublish": {
							"timing": (function(){
								var timing = 0;
								if($($xmlP[j]).attr("pub_gate")){
									timing += 1;
								}
								if($($xmlP[j]).attr("period_pub") == "1"){
									timing += 2;
								}
								return timing;
							})(),
							"threshold": parseFloat($($xmlP[j]).attr("pub_gate") || 1)
						}
					});

					this.setPublishMessage(broker, messageKey, message);
				}

				broker.publish.key = ++maxMessageKey;
			}

			var $xmlS = $($xmlBROKER[i]).find("> SUBSCRIBE > S");
			if($xmlS.length > 0){
				var maxTopicKey = 0;
				for(var j = 0; j < $xmlS.length; j++){
					var topicKey = parseInt($($xmlS[j]).attr("idx"), 10) - 1;
					if(topicKey > maxTopicKey){maxTopicKey = topicKey};

					// Process prefix first
					var usePrefix = $($xmlS[j]).attr("use_prefix");
					if(usePrefix){
						usePrefix = (usePrefix == "1" ? true : false);
					}
					else{// Downward compatibility
						if($($xmlS[j]).attr("topic").startsWith(broker.prefix + "/") == true){
							usePrefix = true;
						}
						else{
							usePrefix = false;
						}
					}

					var topicName = $($xmlS[j]).attr("topic");
					if(usePrefix){
						topicName = topicName.replace(new RegExp("^" + broker.prefix + "/"), "");
					}

					var topic = this.createSubscribeTopic({
						"name": $($xmlS[j]).attr("nickname"),
						"description": $($xmlS[j]).attr("desc") || "",

						"topicName": topicName,
						"usePrefix": usePrefix,
						"qos": parseInt($($xmlS[j]).attr("qos"), 10)
					});

					this.setSubscribeTopic(broker, topicKey, topic);
				}

				broker.subscribe.key = ++maxTopicKey;
			}
		}

		this.pool.key = ++maxBrokerKey;
	}
};
