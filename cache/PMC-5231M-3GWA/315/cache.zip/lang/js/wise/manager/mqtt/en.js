﻿$.extend(true, Lang, {
	"js/wise/manager/mqtt/rule/object.js": {
		"brokerConnectionStatus": "Borker Connection Status",
		"offline": "Offline",
		"online": "Online",
		"mqttBrokerConnectionStatus": "MQTT Borker Connection Status",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"brokerFunctionStatus": "Broker Function Status",
		"mqttBrokerFunctionStatus": "MQTT Broker($broker) Function Status",
		"publishMessage": "Publish Message",
		"publish": "Publish",
		"mqttPublishMessage": "MQTT Publish Message"
	}
});