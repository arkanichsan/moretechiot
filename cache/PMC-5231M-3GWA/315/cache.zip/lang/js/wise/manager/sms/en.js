﻿$.extend(true, Lang, {
	"js/wise/manager/sms/rule/object.js": {
		"smsAlarm": "SMS Alarm",
		"send": "Send"
	}
});