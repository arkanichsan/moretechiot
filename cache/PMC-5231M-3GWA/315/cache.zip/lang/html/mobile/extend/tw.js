﻿$.extend(true, Lang, {
	"pmGlobal": {
		"none": "無設定任何裝置。",
		"V": "電壓",
		"I": "電流",
		"KW": "實功率",
		"kvar": "無效功率",
		"kVA": "視在功率",
		"PF": "功率因數",
		"kWh": "kWh",
		"kvarh": "kvarh",
		"kVah": "kVAh",
		"kWh_day": "本日累計用電量",
		"kWh_month": "本月累計用電量",
		"kWh_year": "本年累計用電量",
		"co2_day": "本日累計排碳量",
		"co2_month": "本月累計排碳量",
		"co2_year": "本年累計排碳量",
		"maxKw_hour": "本小時最高需量",
		"maxKw_day": "本日最高需量",
		"maxKw_month": "本月最高需量",
		"kW_now": "實際需量",
		"kW_predict": "預測需量",
		"aphase": "A相",
		"bphase": "B相",
		"cphase": "C相",
		"sum_average": "總和/平均",
		"loop": "迴路",
		"channel": "通道",
		"sum": "總和",
		"average": "平均",
		"internalRegister": "內部暫存器",
		"enterValue": "請輸入數值：",
		"submeter":"子電錶"
	},
	"pmmsg": {
		"loadingError": "資料讀取錯誤，請再試一次。",
		"getValueError": "資料讀取錯誤!",
		"noSup": "此項目不支援!",
		"noFile": "無記錄檔案。"
	},
	"html/mobile/home/main.htm": {
		"Home": "首頁",
		"PMCName": "名稱",
		"Firmware": "韌體版本",
		"SDSpace": "microSD卡剩餘空間",
		"approxXDays": "約剩$day天",
		"Date": "日期",
		"Time": "時間",
		"ContractCapacity": "契約容量",
		"pmNumber": "電錶數量",
		"ioNumber": "I/O模組數量",
		"XB": "XW-Board",
		"pm": "電錶",
		"io": "I/O模組",
		"PMCInfo": "PMC資訊",
		"ModuleList": "電錶列表",
		"Module": "模組",
		"Interface": "介面",
		"Address": "位址"
	},
	"html/mobile/home/menu.htm": {
		"Menu": "主選單",
		"Home": "首頁",
		"meterInfo": "電錶資訊",
		"ElectricityInfo": "電力資訊",
		"ioinfo": "I/O資訊",
		"eventRecord": "事件記錄",
		"realTimeInfo": "電錶即時資訊",
		"historyTimeInfo": "電錶歷史資訊",
		"custom": "其他資訊",
		"groupInfo": "群組資訊"
	},
	"html/mobile/home/default.htm": {
		//copy WISE default
		"internalRegister": "內部暫存器",
		"no": "編號",
		"channel": "通道",
		"address": "位址",
		"counter": "計數器:",
		"enterValue": "請輸入數值：",
		"valueOfChannel": "$channel數值：",
		"none": "無",
		"diCounterX": "DI計數器$channel",
		"internalRegisterX": "內部暫存器$no",
		"popup": {
			"module": "模組：",
			"channel": "通道：",
			"value": "數值："
		}
	},
	"html/mobile/home/event.htm": {
		"eventRecord": "事件記錄",
		"logNone": "無任何事件記錄。",  
		"time": "時間",
		"type": "類型",
		"content": "內容",
		"result": "結果"
	},
	"html/mobile/home/pm_overview/pm_overview.htm": {
		"prinfo": "電力資訊",
		"Filters": "篩選器",
		"Apply": "確定"
	},
	"html/mobile/home/pm_view/pm_view.htm": {
		"MeterParameterInformation": "電錶參數資訊",
		"realTimeInfo": "電錶即時資訊",
		"Nickname": "名稱",
		"index": "電錶位址",
		"tcpIndex": "編號",
		"ip": "IP位址",
		"portTcp": "連接埠",
		"netId": "NetID",
		"type": "型號",
		"pt": "PT比值",
		"ct": "CT比值",
		"portRtu": "通訊埠",
		"ActualDemand": "分鐘實際需量",
		"ForecastDemand": "分鐘預測需量",
		"ContractCapacity": "契約容量",
		"doInfo": "電錶DO資訊"
	},
	"html/mobile/home/pm_view/custom.htm": {
		"ptRatio": "PT比值",
		"ctRatio": "CT比值",
		"wiringMode": "接線模式",
		"voltageMode": "電壓模式",
		"status": "狀態",
		"setting": "設定",
		"phaseSequence": "相序",
		"refresh": "更新資料",
		"popup":{
			"thisFieldRangeIsBetweenAToB": "此欄位輸入範圍為 $minimum ~ $maximum。",
			"thisFieldRangeIsGreaterEqualX": "此欄位輸入範圍為大於或等於 $minimum。",
			"thisFieldRangeIsLessEqualX": "此欄位輸入範圍為小於或等於 $maximum。",
			"thisFieldOnlyAllowInputInteger": "此欄位限輸入整數。",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "此欄位限輸入整數或浮點數。"
		}
	},
	"html/mobile/home/pm_view/hy_chart.htm": {
		"Inquiry": "查詢",
		"dateRange": "日期範圍",
		"historyTimeInfo": "電錶歷史資訊",
		"item": "項目",
		"date": "日期",
		"time": "時間"
	},
	"html/mobile/home/group_view/group_view.htm":{
		"MainGroup": "主群組",
		"CiGroup": "次群組",
		"GroupInformation": "群組參數資訊",
		"realTimeInfo": "群組即時資訊"
	}
});