WISE.managers.moduleManager.decodeXMLObject = function(xmlDoc){
	var processICPDASModule = function($xmlNode, module){
		var $xmlDI = $xmlNode.find("> DI");
		for(var k = 0; k < $xmlDI.length; k++){

			var channelIndex = parseInt($($xmlDI[k]).attr("idx"), 10);
			module.DI.setting[channelIndex].disable = false;
			module.DI.setting[channelIndex].name = $($xmlDI[k]).attr("nickname") || "";

			if(module.type == "onboard"){
				module.DI.setting[channelIndex].counterType = [0, 2, 1][parseInt($($xmlDI[k]).attr("cnt_type"), 10)];
			}
			else if(module.type == "icpdas"){
				module.DI.setting[channelIndex].counterReset = parseInt($($xmlDI[k]).attr("cnt_clear"), 10);
			}
		}

		var $xmlDO = $xmlNode.find("> DO");
		for(var k = 0; k < $xmlDO.length; k++){
			var channelIndex = parseInt($($xmlDO[k]).attr("idx"), 10);
			module.DO.setting[channelIndex].disable = false;
			module.DO.setting[channelIndex].name = $($xmlDO[k]).attr("nickname") || "";

			if(module.type == "onboard"){
				module.DO.setting[channelIndex].powerOnValue = parseInt($($xmlDO[k]).attr("power_on"), 10);
			}
			else if(module.type == "icpdas"){}

			if(typeof($($xmlDO[k]).attr("pulse_hi")) != "undefined" && typeof($($xmlDO[k]).attr("pulse_lo")) != "undefined"){
				module.DO.setting[channelIndex].advancedFunction = 1;
				module.DO.setting[channelIndex].pulse.high = parseInt($($xmlDO[k]).attr("pulse_hi"), 10);
				module.DO.setting[channelIndex].pulse.low = parseInt($($xmlDO[k]).attr("pulse_lo"), 10);
			}
			else if(typeof($($xmlDO[k]).attr("back_off")) != "undefined"){
				module.DO.setting[channelIndex].advancedFunction = 2;
				module.DO.setting[channelIndex].autoOFF = parseInt($($xmlDO[k]).attr("back_off"), 10);
			}
			else if(typeof($($xmlDO[k]).attr("di_map")) != "undefined"){
				module.DO.setting[channelIndex].advancedFunction = 3;
				module.DO.setting[channelIndex].mappingDI = $($xmlDO[k]).attr("di_map") == "1" ? true : false;
			}
			else{
				module.DO.setting[channelIndex].advancedFunction = 0;
			}
		}

		var $xmlAI = $xmlNode.find("> AI");
		for(var k = 0; k < $xmlAI.length; k++){
			var channelIndex = parseInt($($xmlAI[k]).attr("idx"), 10);
			module.AI.setting[channelIndex].disable = false;
			module.AI.setting[channelIndex].name = $($xmlAI[k]).attr("nickname") || "";

			if(module.type == "onboard"){
				if($($xmlAI[k]).attr("type")){//downward compatibility
					module.AI.setting[channelIndex].type = parseInt($($xmlAI[k]).attr("type"), 10);
				}
			}
			else if(module.type == "icpdas" && module.moduleType != "DL"){
				module.AI.setting[channelIndex].type = parseInt($($xmlAI[k]).attr("type"), 10);
			}

			if(typeof($($xmlAI[k]).attr("deadband")) != "undefined"){
				module.AI.setting[channelIndex].deadband = parseFloat($($xmlAI[k]).attr("deadband"));
			}

			if(typeof($($xmlAI[k]).attr("scale_min")) != "undefined" && typeof($($xmlAI[k]).attr("scale_max")) != "undefined"){
				module.AI.setting[channelIndex].scale.min = parseFloat($($xmlAI[k]).attr("scale_min"));
				module.AI.setting[channelIndex].scale.max = parseFloat($($xmlAI[k]).attr("scale_max"));
				module.AI.setting[channelIndex].scale.unit = $($xmlAI[k]).attr("scale_unit") || "";
			}
		}

		var $xmlAO = $xmlNode.find("> AO");
		for(var k = 0; k < $xmlAO.length; k++){
			var channelIndex = parseInt($($xmlAO[k]).attr("idx"), 10);
			module.AO.setting[channelIndex].disable = false;
			module.AO.setting[channelIndex].name = $($xmlAO[k]).attr("nickname") || "";

			if(module.type == "onboard"){
				if($($xmlAO[k]).attr("type")){//downward compatibility
					module.AO.setting[channelIndex].type = parseInt($($xmlAO[k]).attr("type"), 10);
				}

				module.AO.setting[channelIndex].powerOnValue = parseFloat($($xmlAO[k]).attr("power_on"));
			}
			else if(module.type == "icpdas"){
				module.AO.setting[channelIndex].type = parseInt($($xmlAO[k]).attr("type"), 10);
			}
		}
	};

	var processModbusModule = function($xmlNode, module){
		var processCoilSettings = function($xmlCoil){
			var settings = {
				"startAddress": parseInt($xmlCoil.attr("start_add"), 10),
				"length": parseInt($xmlCoil.attr("len"), 10),
				"name": []
			};

			var $xmlN = $xmlCoil.find("> N");
			for(var i = 0; i < $xmlN.length; i++){
				var dataIndex = parseInt($($xmlN[i]).attr("idx"), 10);
				settings.name[dataIndex] = $($xmlN[i]).attr("nickname") || "";
			}

			return settings;
		};

		var processRegisterSetting = function($xmlRegister){
			var settings = {
				"startAddress": parseInt($xmlRegister.attr("start_add"), 10),
				"length": parseInt($xmlRegister.attr("len"), 10),
				"type": parseInt($xmlRegister.attr("type"), 10),
				"inverse": $xmlRegister.attr("endian") == "1" ? true : false,
				"scaleRatio": parseFloat($xmlRegister.attr("ratio") || 1),
				"offset": parseFloat($xmlRegister.attr("offset") || 0),
				"deadband": parseFloat($xmlRegister.attr("deadband") || 0),
				"name": [],
				"unit": []
			};

			if(settings.type == 2){
				settings.hexMin = $xmlRegister.attr("hex_min");
				settings.hexMax = $xmlRegister.attr("hex_max");
				settings.realMin = parseFloat($xmlRegister.attr("real_min"));
				settings.realMax = parseFloat($xmlRegister.attr("real_max"));
			}
			else{
				settings.hexMin = settings.hexMax = "0000";
				settings.realMin = settings.realMax = 0;
			}

			var $xmlN = $xmlRegister.find("> N");
			for(var i = 0; i < $xmlN.length; i++){
				var dataIndex = parseInt($($xmlN[i]).attr("idx"), 10);
				settings.name[dataIndex] = $($xmlN[i]).attr("nickname") || "";
				settings.unit[dataIndex] = $($xmlN[i]).attr("unit") || "";
			}

			return settings;
		};

		var $xmlCI = $xmlNode.find("> CI");
		for(var k = 0; k < $xmlCI.length; k++){
			WISE.managers.moduleManager.modbusModule.addBlock(module, "CI", processCoilSettings($($xmlCI[k])));
		}

		var $xmlCO = $xmlNode.find("> CO");
		for(var k = 0; k < $xmlCO.length; k++){
			WISE.managers.moduleManager.modbusModule.addBlock(module, "CO", processCoilSettings($($xmlCO[k])));
		}

		var $xmlRI = $xmlNode.find("> RI");
		for(var k = 0; k < $xmlRI.length; k++){
			WISE.managers.moduleManager.modbusModule.addBlock(module, "RI", processRegisterSetting($($xmlRI[k])));
		}

		var $xmlRO = $xmlNode.find("> RO");
		for(var k = 0; k < $xmlRO.length; k++){
			WISE.managers.moduleManager.modbusModule.addBlock(module, "RO", processRegisterSetting($($xmlRO[k])));
		}
	};

	var $xmlXBOARD = $(xmlDoc).find("WISE > XBOARD");
	if($xmlXBOARD.length > 0){
		var protocol = {
			"W": "xw",
			"V": "xv"
		}[$xmlXBOARD.attr("type")];

		this.pool.interfaces.onboard[0].protocol = protocol;

		var module = this.icpdasModule.createModule({
			"modelName": $xmlXBOARD.attr("name"),
			"name": $xmlXBOARD.attr("nickname"),
			"description": $xmlXBOARD.attr("desc") || "",
			"uid": $xmlXBOARD.attr("uid"),
			"permission":{
				"userLevel": parseInt($xmlXBOARD.attr("level") || 1, 10)
			}
		}, "onboard");

		if(module != null){
			module.AI.singleEnded = parseInt($xmlXBOARD.attr("single_end") || 0, 10);
			if(module.AI.singleEnded == 1){
				module.AI.amount *= 2;
			}

			//set all channel are disable, when xml appear the channel setting, set disable to false.
			var typeArray = ["DI", "DO", "AI", "AO"];
			for(var typeArrayIndex = 0; typeArrayIndex < typeArray.length; typeArrayIndex++){
				var channelType = typeArray[typeArrayIndex];

				for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
					module[channelType].setting[channelIndex].disable = true;
				}
			}

			processICPDASModule($xmlXBOARD, module);

			this.pool.interfaces.onboard[0][protocol].modules[0] = module;
		}

		this.pool.interfaces.onboard[0].modules = this.pool.interfaces.onboard[0][protocol].modules;
	}

	var $xmlCOM = $(xmlDoc).find("WISE > COM");
	for(var i = 0; i < $xmlCOM.length; i++){
		var source = $($xmlCOM[i]).attr("idx");

		if($($xmlCOM[i]).attr("type") == "1"){//dcon
			this.pool.interfaces.comport[source].baudrate = parseInt($($xmlCOM[i]).attr("baud"), 10);
			this.pool.interfaces.comport[source].parity = {"N": 0, "O": 1, "E": 2}[$($xmlCOM[i]).attr("parity")];
			this.pool.interfaces.comport[source].stopbits = parseInt($($xmlCOM[i]).attr("stopbit"), 10);

			this.pool.interfaces.comport[source].protocol = "dcon";
			this.pool.interfaces.comport[source].dcon.timeout = parseInt($($xmlCOM[i]).attr("timeout"), 10);
			this.pool.interfaces.comport[source].dcon.checksum = parseInt($($xmlCOM[i]).attr("checksum"), 10);

			var $xmlMODULE = $($xmlCOM[i]).find("> MODULE");
			for(var j = 0; j < $xmlMODULE.length; j++){
				var moduleIndex = parseInt($($xmlMODULE[j]).attr("idx"), 10) - 1;
				var module = this.icpdasModule.createModule({
					"modelName": $($xmlMODULE[j]).attr("name"),
					"name": $($xmlMODULE[j]).attr("nickname"),
					"description": $($xmlMODULE[j]).attr("desc") || "",
					"scanInterval": $($xmlMODULE[j]).attr("update_delay"),
					"retryInterval": $($xmlMODULE[j]).attr("retry"),
					"temperatureUnit": $($xmlMODULE[j]).attr("fahrenheit") || 0,
					"address": $($xmlMODULE[j]).attr("address"),
					"uid": $($xmlMODULE[j]).attr("uid"),
					"permission":{
						"userLevel": parseInt($($xmlMODULE[j]).attr("level") || 1, 10)
					}
				}, "icpdas");
				
				if(module != null){
					module.AI.singleEnded = parseInt($($xmlMODULE[j]).attr("single_end") || 0, 10);
					if(module.AI.singleEnded == 1){
						module.AI.amount *= 2;
					}

					//set all channel are disable, when xml appear the channel setting, set disable to false.
					var typeArray = ["DI", "DO", "AI", "AO"];
					for(var typeArrayIndex = 0; typeArrayIndex < typeArray.length; typeArrayIndex++){
						var channelType = typeArray[typeArrayIndex];

						for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
							module[channelType].setting[channelIndex].disable = true;
						}
					}

					processICPDASModule($($xmlMODULE[j]), module);

					this.pool.interfaces.comport[source].dcon.modules[moduleIndex] = module;
				}
			}

			this.pool.interfaces.comport[source].modules = this.pool.interfaces.comport[source].dcon.modules;
		}
		else if($($xmlCOM[i]).attr("type") == "2"){//modbusRTU
			this.pool.interfaces.comport[source].baudrate = parseInt($($xmlCOM[i]).attr("baud"), 10);
			this.pool.interfaces.comport[source].parity = {"N": 0, "O": 1, "E": 2}[$($xmlCOM[i]).attr("parity")];
			this.pool.interfaces.comport[source].stopbits = parseInt($($xmlCOM[i]).attr("stopbit"), 10);

			this.pool.interfaces.comport[source].protocol = "modbusRTU";
			this.pool.interfaces.comport[source].modbusRTU.silentInterval = parseInt($($xmlCOM[i]).attr("silent"), 10);

			var $xmlMODULE = $($xmlCOM[i]).find("> MODULE");
			for(var j = 0; j < $xmlMODULE.length; j++){
				var moduleIndex = parseInt($($xmlMODULE[j]).attr("idx"), 10) - 1;

				if($($xmlMODULE[j]).attr("name")){//M7K
					var module = this.icpdasModule.createModule({
						"modelName": $($xmlMODULE[j]).attr("name"),
						"name": $($xmlMODULE[j]).attr("nickname"),
						"description": $($xmlMODULE[j]).attr("desc") || "",
						"scanInterval": $($xmlMODULE[j]).attr("update_delay"),
						"pollingTimeout": $($xmlMODULE[j]).attr("timeout"),
						"retryInterval": $($xmlMODULE[j]).attr("retry"),
						"temperatureUnit": $($xmlMODULE[j]).attr("fahrenheit") || 0,
						"address": $($xmlMODULE[j]).attr("address"),
						"uid": $($xmlMODULE[j]).attr("uid"),
						"permission":{
							"userLevel": parseInt($($xmlMODULE[j]).attr("level") || 1, 10)
						}
					}, "icpdas");

					if(module != null){
						module.AI.singleEnded = parseInt($($xmlMODULE[j]).attr("single_end") || 0, 10);
						if(module.AI.singleEnded == 1){
							module.AI.amount *= 2;
						}

						//set all channel are disable, when xml appear the channel setting, set disable to false.
						var typeArray = ["DI", "DO", "AI", "AO"];
						for(var typeArrayIndex = 0; typeArrayIndex < typeArray.length; typeArrayIndex++){
							var channelType = typeArray[typeArrayIndex];

							for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
								module[channelType].setting[channelIndex].disable = true;
							}
						}

						processICPDASModule($($xmlMODULE[j]).find("> M7000"), module);

						this.pool.interfaces.comport[source].modbusRTU.modules[moduleIndex] = module;
					}
				}
				else{
					var module = this.modbusModule.createModule({
						"type": "rtu",
						"protocol": "modbusRTU",
						"name": $($xmlMODULE[j]).attr("nickname"),
						"description": $($xmlMODULE[j]).attr("desc") || "",
						"scanInterval": $($xmlMODULE[j]).attr("update_delay"),
						"pollingTimeout": $($xmlMODULE[j]).attr("timeout"),
						"retryInterval": $($xmlMODULE[j]).attr("retry"),
						"modbusRTU": {
							"address": $($xmlMODULE[j]).attr("address")
						},
						"uid": $($xmlMODULE[j]).attr("uid"),
						"permission":{
							"userLevel": parseInt($xmlXBOARD.attr("level") || 1, 10)
						}
					}, "rtu");

					processModbusModule($($xmlMODULE[j]), module);

					this.pool.interfaces.comport[source].modbusRTU.modules[moduleIndex] = module;
				}
			}

			this.pool.interfaces.comport[source].modules = this.pool.interfaces.comport[source].modbusRTU.modules;
		}
		else if($($xmlCOM[i]).attr("type") == "3"){//comport232 hmi
			this.pool.interfaces.comport[source].baudrate = parseInt($($xmlCOM[i]).attr("baud"), 10);
			this.pool.interfaces.comport[source].parity = {"N": 0, "O": 1, "E": 2}[$($xmlCOM[i]).attr("parity")];
			this.pool.interfaces.comport[source].stopbits = parseInt($($xmlCOM[i]).attr("stopbit"), 10);

			this.pool.interfaces.comport[source].protocol = "hmi";
		}
		else if($($xmlCOM[i]).attr("type") == "4"){//comport485 hmi
			this.pool.interfaces.comport[source].baudrate = parseInt($($xmlCOM[i]).attr("baud"), 10);
			this.pool.interfaces.comport[source].parity = {"N": 0, "O": 1, "E": 2}[$($xmlCOM[i]).attr("parity")];
			this.pool.interfaces.comport[source].stopbits = parseInt($($xmlCOM[i]).attr("stopbit"), 10);

			this.pool.interfaces.comport[source].protocol = "hmi";
		}
	}

	var $xmlTCP = $(xmlDoc).find("WISE > TCP");
	for(var i = 0; i < $xmlTCP.length; i++){
		var source = 0;
		this.pool.interfaces.network[source].protocol = "modbusTCP";

		var $xmlMODULE = $($xmlTCP[i]).find("> MODULE");
		for(var j = 0; j < $xmlMODULE.length; j++){
			var moduleIndex = parseInt($($xmlMODULE[j]).attr("idx"), 10) - 1;
			var module = this.modbusModule.createModule({
				"type": "tcp",
				"protocol": "modbusTCP",
				"name": $($xmlMODULE[j]).attr("nickname"),
				"description": $($xmlMODULE[j]).attr("desc") || "",
				"scanInterval": $($xmlMODULE[j]).attr("update_delay"),
				"pollingTimeout": $($xmlMODULE[j]).attr("timeout"),
				"retryInterval": $($xmlMODULE[j]).attr("retry"),
				"modbusTCP": {
					"ip": ipToInteger($($xmlMODULE[j]).attr("ip")),
					"port": parseInt($($xmlMODULE[j]).attr("port"), 10),
					"netID": parseInt($($xmlMODULE[j]).attr("netid"), 10)
				},
				"uid": $($xmlMODULE[j]).attr("uid"),
				"permission":{
					"userLevel": parseInt($xmlXBOARD.attr("level") || 1, 10)
				}
			}, "tcp");

			processModbusModule($($xmlMODULE[j]), module);

			this.pool.interfaces.network[source].modbusTCP.modules[moduleIndex] = module;
		}

		this.pool.interfaces.network[source].modules = this.pool.interfaces.network[source].modbusTCP.modules;
	}

	this.generateModulesUID();
	this.updateModulesKey();
};
