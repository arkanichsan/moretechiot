﻿$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"popup": {
			"areYouSureYouWantToLogout": "Are you sure you want to logout?",
			"idleTooLong": "Your login session has expired. For security reasons you will be logged out automatically. Please login again."
		}
	}
});