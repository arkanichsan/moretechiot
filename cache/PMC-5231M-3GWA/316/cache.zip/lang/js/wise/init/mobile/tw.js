﻿$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"popup": {
			"areYouSureYouWantToLogout": "您確定要登出嗎？",
			"idleTooLong": "您閒置過久，為了安全起見系統已將您登出，請重新登入即可。"
		}
	}
});