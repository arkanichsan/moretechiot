WISE.managers.mqttManager.encodeXMLObject = function(xmlDoc){
	var processVariableToJSONString = function(variable){
		var moduleProcessor = WISE.managers.mqttManager.encodeXMLObject.processModuleVariableToJSONString;

		var registerProcessor = function(registerInfo, variable){
			try{
				return '{' + 
					'"msg_type":"CHANNEL_UPDATE",' +
					'"ch_type":"IR",' +
					'"ch_addr":' + (registerInfo.registerIndex + 1) + ',' +
					'"nickname":"' + (WISE.registerInfo(registerInfo.registerIndex).match(/\((.*)\)/)[1] || "") + '",' +
					'"value":' + variable +
				'}';
			}
			catch(error){
				return '{' + 
					'"msg_type": "INTERNAL_REGISTER_NOT_EXIST"' +
				'}';
			}
		};

		var systemInformationProcessor = function(systemInfo, variable){
			try{
				var desc = {
					"Ty": "DATE_YEAR",
					"TM": "DATE_MONTH",
					"Td": "DATE_DAY",
					"Th": "TIME_HOUR",
					"Tm": "TIME_MINUTE",
					"Ts": "TIME_SECOND",
					"Ss": "SIGNAL_STRENGTH_DBM",
					"Sp": "SIGNAL_STRENGTH_PERCENT"
				}[systemInfo.item];

				return '{' + 
					'"msg_type":"SYSTEM_INFORMATION_UPDATE",' +
					'"info_item":"' + desc + '",' +
					'"value":' + variable +
				'}';
			}
			catch(error){
				return '{' + 
					'"msg_type": "SYSTEM_INFORMATION_NOT_EXIST"' +
				'}';
			}
		};

		var json = null;
		var regex = new RegExp("\\$(X|C(\\d+)D(\\d+))(\\D+\\d+)|\\$(T(\\d+)|C(\\d+)M(\\d+))(\\D+\\d+)|\\$(I(\\d+))|\\$(S(T[yMdhms]|S[sp]))" + (typeof(WISE.getVariable.extendRegex) == "string" ? "|(" + WISE.buildVariableEditor.extendRegex + ")": ""));
		var result = regex.exec(variable);

		if(result){
			for(var i = 0; i < result.length; i++){
				if(typeof(result[i]) == "undefined"){
					result[i] = "";
				}
			}

			if(result[1].charAt(0) == "X"){//xwboard
				json = moduleProcessor({
					"sourceType": "onboard",
					"sourceIndex": 0,
					"moduleIndex": 0
				}, result[4], variable);
			}
			else if(result[1].charAt(0) == "C"){//dcon
				json = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[2], 10),
					"moduleIndex": parseInt(result[3], 10) - 1
				}, result[4], variable);
			}
			else if(result[5].charAt(0) == "T"){//modbus tcp
				json = moduleProcessor({
					"sourceType": "network",
					"sourceIndex": 0,
					"moduleIndex": parseInt(result[6], 10) - 1
				}, result[9], variable);
			}
			else if(result[5].charAt(0) == "C"){//modbus rtu
				json = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[7], 10),
					"moduleIndex": parseInt(result[8], 10) - 1
				}, result[9], variable);
			}
			else if(result[10].charAt(0) == "I"){//ir
				json = registerProcessor({
					"registerIndex": parseInt(result[11], 10) - 1,
					"moduleKey": null
				}, variable);
			}
			else if(result[12].charAt(0) == "S"){//system
				json = systemInformationProcessor({
					"item": result[13]
				}, variable);
			}
			else{
				if(typeof(WISE.managers.mqttManager.encodeXMLObject.processExtendVariableToJSONString) == "function"){
					json = WISE.managers.mqttManager.encodeXMLObject.processExtendVariableToJSONString(result.slice(14));
				}
			}
		}

		return json;
	};

	var xmlMQTT = xmlDoc.createElement("MQTT");
	var brokerCounter = 0;

	for(var brokerKey in this.pool.brokers){
		var broker = this.pool.brokers[brokerKey];
		var xmlBROKER = xmlDoc.createElement("BROKER");

		xmlBROKER.setAttribute("idx", broker.index);
		xmlBROKER.setAttribute("address", broker.address);
		xmlBROKER.setAttribute("port", broker.port);

		if(broker.authInfo.enable == true){
			xmlBROKER.setAttribute("username", broker.authInfo.id);
			if(broker.authInfo.password.plain == "" || broker.authInfo.password.plain != padding("", broker.authInfo.password.length, "*")){//setup new password
				xmlBROKER.setAttribute("password", broker.authInfo.password.plain);
				xmlBROKER.setAttribute("password_len", broker.authInfo.password.plain.length);
			}
			else{
				xmlBROKER.setAttribute("password", broker.authInfo.password.encoded);
				xmlBROKER.setAttribute("password_len", broker.authInfo.password.length);
			}
		}

		if(broker.will.enable == true){
			xmlBROKER.setAttribute("will_topic", broker.will.topicName);
			xmlBROKER.setAttribute("will_message", broker.will.payload);
			xmlBROKER.setAttribute("will_qos", broker.will.qos);
		}

		xmlBROKER.setAttribute("ssl_enable", broker.encryption == true ? "1" : "0");
		if(broker.clientId != ""){
			xmlBROKER.setAttribute("clientid", broker.clientId);
		}
		xmlBROKER.setAttribute("alive_timer", broker.keepAliveTimer);
		xmlBROKER.setAttribute("publish_period", broker.publishInterval);
		xmlBROKER.setAttribute("prefix", broker.prefix);

		xmlBROKER.setAttribute("enable", broker.initialStatus == true ? "1" : "0");

		xmlBROKER.setAttribute("nickname", broker.name);
		if(broker.description != ""){
			xmlBROKER.setAttribute("desc", broker.description);
		}

		//publish message
		var xmlPUBLISH = xmlDoc.createElement("PUBLISH");
		var messageCounter = 0;

		for(var messageKey in broker.publish.messages){
			var message = broker.publish.messages[messageKey];
			var xmlP = xmlDoc.createElement("P");

			xmlP.setAttribute("idx", message.index);

			if(message.usePrefix == true){
				xmlP.setAttribute("topic", broker.prefix != "" ? broker.prefix + "/" + message.topicName : message.topicName);
			}
			else{
				xmlP.setAttribute("topic", message.topicName);
			}

			xmlP.setAttribute("use_prefix", message.usePrefix == true ? "1" : "0");
			xmlP.setAttribute("data_type", message.type);

			if(message.type == 0){
				if(message.json == true){
					xmlP.setAttribute("data", processVariableToJSONString(message.payload));//in json format
					xmlP.setAttribute("use_json", "1");
					xmlP.setAttribute("ch_var", message.payload);
				}
				else{
					xmlP.setAttribute("data", message.payload);
					xmlP.setAttribute("use_json", "0");
				}
			}
			else{
				xmlP.setAttribute("data", message.payload);
			}

			xmlP.setAttribute("qos", message.qos);
			xmlP.setAttribute("retain", message.retain == true ? "1" : "0");

			if(message.autoPublish.timing & 1){
				xmlP.setAttribute("pub_gate", message.autoPublish.threshold);
			}
			if(message.autoPublish.timing & 2){
				xmlP.setAttribute("period_pub", "1");
			}
			else{
				xmlP.setAttribute("period_pub", "0");
			}

			xmlP.setAttribute("nickname", message.name);
			if(message.description != ""){
				xmlP.setAttribute("desc", message.description);
			}

			xmlPUBLISH.appendChild(xmlP);
			messageCounter++;
		}

		xmlPUBLISH.setAttribute("topic_num", messageCounter);
		xmlBROKER.appendChild(xmlPUBLISH);

		//subscribe topic
		var xmlSUBSCRIBE = xmlDoc.createElement("SUBSCRIBE");
		var topicCounter = 0;

		for(var topicKey in broker.subscribe.topics){
			var topic = broker.subscribe.topics[topicKey];
			var xmlS = xmlDoc.createElement("S");

			xmlS.setAttribute("idx", topic.index);

			if(topic.usePrefix == true){
				xmlS.setAttribute("topic", broker.prefix != "" ? broker.prefix + "/" + topic.topicName : topic.topicName);
			}
			else{
				xmlS.setAttribute("topic", topic.topicName);
			}

			xmlS.setAttribute("use_prefix", topic.usePrefix == true ? "1" : "0");
			xmlS.setAttribute("qos", topic.qos);

			xmlS.setAttribute("nickname", topic.name);
			if(topic.description != ""){
				xmlS.setAttribute("desc", topic.description);
			}

			xmlSUBSCRIBE.appendChild(xmlS);
			topicCounter++;
		}

		xmlSUBSCRIBE.setAttribute("topic_num", topicCounter);
		xmlBROKER.appendChild(xmlSUBSCRIBE);

		xmlMQTT.appendChild(xmlBROKER);
		brokerCounter++;
	}

	xmlMQTT.setAttribute("num", brokerCounter);

	if(xmlMQTT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlMQTT);
				break;
			}
		}
	}
};

WISE.managers.mqttManager.encodeXMLObject.processModuleVariableToJSONString = function(moduleInfo, channelVariable, variable){
	try{
		var regex = /(\D+)(\d+)/;
		var result = regex.exec(channelVariable);

		if(result){
			for(var i = 0; i < result.length; i++){
				if(typeof(result[i]) == "undefined"){
					result[i] = "";
				}
			}

			moduleInfo.channelType = result[1].toUpperCase();
			moduleInfo.channel = parseInt(result[2].toUpperCase(), 10);
		}

		var module = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas" || module.type == "onboard"){
			var protocol = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

			if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
				var channelIndexInfo = WISE.managers.moduleManager.icpdasModule.channelAddressToIndex(module, moduleInfo.channelType, moduleInfo.channel);
				moduleInfo.channelType = channelIndexInfo[0];
				moduleInfo.channel = channelIndexInfo[1];
			}
			else{//I7K, XW-Board
				if(moduleInfo.channelType == "CI"){
					moduleInfo.channelType = "DIC";
				}
			}
		}

		var sourceTypeName = {
			"onboard": "0",
			"comport": "1",
			"network": "2"
		}[moduleInfo.sourceType];

		var channelTypeName = {
			"DI": "DI",
			"DIC": "DI_COUNTER",
			"DO": "DO",
			"DOC": "DO_COUNTER",
			"AI": "AI",
			"AO": "AO",
			"CI": "DISCRETE_INPUT",
			"CO": "COIL_OUTPUT",
			"RI": "INPUT_REGISTERL",
			"RO": "HOLDING_REGISTER",
			"IR": "IR"//WISE-7000
		}[moduleInfo.channelType];

		return '{' + 
			'"msg_type":"CHANNEL_UPDATE",' +
			'"if_type":' + sourceTypeName + ',' +
			(moduleInfo.sourceType == "comport" ? '"com_port":' + moduleInfo.sourceIndex + ',' : '') +
			(moduleInfo.sourceType != "onboard" ? '"module_no":' + (moduleInfo.moduleIndex + 1) + ',' : '') +
			'"ch_type":"' + channelTypeName + '",' +
			'"ch_addr":' + (moduleInfo.channelType == "IR" ? (moduleInfo.channel + 1) : moduleInfo.channel) + ',' +
			'"nickname":"' + (moduleInfo.channelType != "IR" ? WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, moduleInfo.channelType, moduleInfo.channel).name : "") + '",' +
			'"value":' + variable +
		'}';
	}
	catch(error){
		return '{' + 
			'"msg_type": "MODULE_NOT_EXIST"' +
		'}';
	}
};

WISE.managers.mqttManager.updateIndex = function(){
	var brokerIndex = 0;
	for(var brokerKey in this.pool.brokers){
		this.pool.brokers[brokerKey].index = ++brokerIndex;

		var messageIndex = 0;
		for(var messageKey in this.pool.brokers[brokerKey].publish.messages){
			this.pool.brokers[brokerKey].publish.messages[messageKey].index = ++messageIndex;
		}

		var topicIndex = 0;
		for(var topicKey in this.pool.brokers[brokerKey].subscribe.topics){
			this.pool.brokers[brokerKey].subscribe.topics[topicKey].index = ++topicIndex;
		}
	}
};
