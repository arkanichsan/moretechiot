﻿function TableInit(){
	moduleManager = WISE.managers.moduleManager;
	RegisterInfo = WISE.managers.registerManager;
	PUEInfo = WISE.managers.pueManager;
	TableMaxLength = WISE.managers.moduleManager.modbusTableMaxLength;
	typeArray = ["DO", "DI", "AI", "AO"];
	typeCount={};
	TableTitle = ["<#Lang['?'].ParameterName>", "<#Lang['?'].ModbusAddress>", "<#Lang['?'].Length>", "<#Lang['?'].DataType>", "<#Lang['?'].Range>"];
	ModbusAddress = {"DO": 0,"DI": 100000, "AI": 300000, "AO": 400000};
	AddressBit = {"DO": 1,"DI": 1, "AI": 2, "AO": 2};
	ModbusDataType = {"DO": "Byte","DI": "Byte", "AI": "Float", "AO": "Float"};
	ModbusRange = {"DO": "0=OFF, 1=ON","DI": "0=OFF, 1=ON", "AI": "Floating Point", "AO": "Floating Point"};
	TypeTitle = {
								"DO" : "Coils Output, Unit : Coil(8 Bits)",
								"DI" : "Discrete Input, Unit : Coil(8 Bits)", 
								"AI" : "Input Register, Unit : Register(16 Bits)", 
								"AO" : "Holding Register, Unit : Register(16 Bits)" 
							};
	SA = 0;
	AddAddress = 0;
	DataInfo = {
						"PM":["<#Lang['?'].no>","<#Lang['?'].port>","<#Lang['?'].address>","<#Lang['?'].typeID>"],
						"IO":["<#Lang['?'].no>","<#Lang['?'].port>","<#Lang['?'].address>","<#Lang['?'].typeID>"],
						"Board":[" <#Lang['?'].typeID>","DI","DO","AI","AO"],
						"RTU":["<#Lang['?'].no>","<#Lang['?'].port>","<#Lang['?'].address>"]
					};
	padLeft_num=6;
	//PhaseType={1:[], 3 : ["Phase A","Phase B","Phase C","Total/Average"]};
	RTUtypeArray = ["CO" , "CI" , "RI" , "RO"];
}

//sourceType:onboard/comport/network   com:1/2/3   	modules:0~15(modules no-1)  TableObj:showTable
function GetModbusTable(sourceType, com, modules, TableObj){
	TableInit();
	SelectSourceType = sourceType;
	SelectCom = com;
	Selectmodules = modules;
	
	if(sourceType == "comport"){
		 SelectInfo = moduleManager.pool.interfaces.comport[com].modules[modules];
		 SA = moduleManager.pool.interfaces.comport[com].modbusTableStartAddress + (modules*TableMaxLength);
	}
	else if(sourceType == "network"){
		SelectInfo = moduleManager.pool.interfaces.network[com].modules[modules];
		SA = moduleManager.pool.interfaces.network[com].modbusTableStartAddress + (modules*TableMaxLength);
	}
	
	else if(sourceType == "onboard"){
		SelectInfo = moduleManager.pool.interfaces.onboard[com].modules[modules];
		SA = moduleManager.pool.interfaces.onboard[com].modbusTableStartAddress + (modules*TableMaxLength);
	}
	
	DICounterModule = WISE.managers.moduleManager.icpdasModule.isDICounterModule(SelectInfo);// no DI but AI have DI Conter
	DICounter32Bits=WISE.managers.moduleManager.icpdasModule.is32BitsDICounterModule(SelectInfo);//7080、7084、7088 Length is 2
	for(var type in typeArray)
	{
	if(typeof(SelectInfo.powerMeter) != "undefined")//PM
		typeCount[typeArray[type]] = SelectInfo.powerMeter.io[typeArray[type]].length;
	else//IO
		if(SelectInfo.type == "rtu"||SelectInfo.type == "tcp")
			typeCount[typeArray[type]] = SelectInfo[RTUtypeArray[type]].remoteAddress.length ;
		else
			typeCount[typeArray[type]] = SelectInfo[typeArray[type]].amount;
	}

	if(typeof(SelectInfo.powerMeter) != "undefined")
		InserPMTable(TableObj);
	else if(SelectInfo.type == "rtu"||SelectInfo.type == "tcp")
		InserRTUTable(TableObj);
	else	
		InserIOTable(TableObj);//IO、Board
}

//select_item = 0:System ; 1:IR ; 2:PUE
function GetOtherModbusTable(select_item,TableObj){
	TableInit();
	switch (select_item){
		case "0":InserSystemTable(TableObj);break;
		case "1":InserRegisterTable(TableObj);break;
		case "2":InserPUETable(TableObj);break;
	}
}

//model information
function InserDataInfoTable(DataType){
	var str = ''
	str +='<div><table border = "1px" width = "100%">';
	switch (DataType)
	{
		case "PM":
			//str += '<tr><td colspan="'+(SelectInfo.powerMeter.pt.length+SelectInfo.powerMeter.ct.length+4)+'" bgcolor="#BDBDBD" align="center" style="font-size: 20px;word-break:break-all;">'+SelectInfo.name+'</td></tr>';
			str += '<tr><td colspan="4" bgcolor="#BDBDBD" align="center" style="font-size: 20px;word-break:break-all;">'+SelectInfo.name+'</td></tr>';
			str += '<tr>';
			
			for(var i in DataInfo[DataType])
				switch (i)
				{
					case "0":case "2":str += '<td style="width: 10%;">'+DataInfo[DataType][i]+'</td>';break;
					case "1":
						if(SelectInfo.type != "tcp")
							str += '<td>'+DataInfo[DataType][i]+'</td>';
						else
							str += '<td><#Lang['?'].ipAndPort></td>';
						break;
					default:
						str += '<td>'+DataInfo[DataType][i]+'</td>';
				}
			str += '</tr><tr>';
			str += '<td>' + (Selectmodules+1) + '</td>';
			if(SelectSourceType=="network")
			{
				str += '<td>'+integerToIP(SelectInfo.modbusTCP.ip) + ':' + SelectInfo.modbusTCP.port + '</td>';
				str += '<td>' + SelectInfo.modbusTCP.netID + '</td>';
			}
			else
			{
				str += '<td>COM' + SelectCom + '</td>';
				str += '<td>' + SelectInfo.modbusRTU.address + '</td>';
			}
			str += '<td>' + SelectInfo.powerMeter.modelName + '</td>';
			str += '</tr>';
		break;
		case "IO":	
			if(SelectInfo.type == "onboard")//XW-Board and XV-Board
				{
					if(SelectInfo.name != "")
						str += '<tr><td colspan="5" bgcolor="#BDBDBD" align="center" style="font-size: 20px;">'+SelectInfo.name+'</td></tr>';
					else
						str += '<tr><td colspan="5" bgcolor="#BDBDBD" align="center" style="font-size: 20px;">'+SelectInfo.displayModelName+'</td></tr>';
					str += '<tr>';
					for(var i in DataInfo["Board"])
						str += '<td>'+DataInfo["Board"][i]+'</td>';
					str += '</tr>';
					str += '<tr>';
					str += '<td>'+SelectInfo.displayModelName+'</td>';
					str += '<td style="width:10%;">' + SelectInfo.DI.amount + '</td>';
					str += '<td style="width:10%;">' + SelectInfo.DO.amount + '</td>';
					str += '<td style="width:10%;">' + SelectInfo.AI.amount + '</td>';
					str += '<td style="width:10%;">' + SelectInfo.AO.amount + '</td>';
					str += '</tr>';
				}
				else
				{
					if(SelectInfo.name != "")
						str += '<tr><td colspan="4" bgcolor="#BDBDBD" align="center" style="font-size: 20px;">'+SelectInfo.name+'</td></tr>';
					else
						str += '<tr><td colspan="4" bgcolor="#BDBDBD" align="center" style="font-size: 20px;">'+SelectInfo.displayModelName+'</td></tr>';
					str += '<tr>';
					for(var i in DataInfo[DataType])
						switch (i)
						{
							case "1":
								if(SelectInfo.type != "tcp")
									str += '<td>'+DataInfo[DataType][i]+'</td>';
								else
									str += '<td><#Lang['?'].ipAndPort></td>';
								break;
							default:
								str += '<td>'+DataInfo[DataType][i]+'</td>';
						}
					str += '</tr>';
					str += '<tr>';
					str += '<td>'+(Selectmodules+1)+'</td>';
					str += '<td>COM' + SelectCom + '</td>';
					str += '<td>' + SelectInfo.address + '</td>';
					str += '<td>' + SelectInfo.displayModelName + '</td>';
					str += '</tr>';
				}
		break;	
		case "RTU":
			str += '<tr><td colspan="3" bgcolor="#BDBDBD" align="center" style="font-size: 20px;">'+SelectInfo.name+'</td></tr>';
			str += '<tr>';
			for(var i in DataInfo[DataType])
						switch (i)
						{
							case "1":
								if(SelectInfo.type != "tcp")
									str += '<td>'+DataInfo[DataType][i]+'</td>';
								else
									str += '<td><#Lang['?'].ipAndPort></td>';
								break;
							default:
								str += '<td>'+DataInfo[DataType][i]+'</td>';
						}
			str += '</tr>';
			str += '<tr>';
			str += '<td>'+(Selectmodules+1)+'</td>';
			if(SelectInfo.type=="tcp")
			{
				str += '<td>'+integerToIP(SelectInfo.modbusTCP.ip) + ':' + SelectInfo.modbusTCP.port + '</td>';
				str += '<td>' + SelectInfo.modbusTCP.netID + '</td>';
			}
			else
			{
				str += '<td>COM' + SelectCom + '</td>';
				str += '<td>' + SelectInfo.modbusRTU.address + '</td>';
			}
			str += '</tr>';
		break;
	}
	str +='</table></div>';
	str += '<div><br /></div>'
	return str;
}

//table title
function InserTableTitle(TypeTitle){
	var str = '';
	str +='<table border = "1px" width = "100%">';
	str += '<tr><td colspan = "5" bgcolor="#BDBDBD">'+ TypeTitle +'</td></tr>';
	str += '<tr>';
	for( var title in TableTitle)
	{
		switch (title)
		{
			case "0":case "4":str += '<td bgcolor = "#F2F2F2" style="width: 30%;">' + TableTitle[title] + '</td>';break;
			case "1":str += '<td bgcolor = "#F2F2F2" style="width: 18%;">' + TableTitle[title] + '</td>';break;
			case "2":str += '<td bgcolor = "#F2F2F2" style="width: 10%;">' + TableTitle[title] + '</td>';break;
			case "3":str += '<td bgcolor = "#F2F2F2" style="width: 12%;">' + TableTitle[title] + '</td>';break;
		}
	}
	str += '</tr>';
	return str;
}



function padLeft(str,length){
    if(str.length >= length)
        return str;
    else
        return padLeft("0" +str,length);
}
