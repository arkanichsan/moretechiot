//PMTable
function PMinit(){
	PMInfo = ["<#Lang['?'].PowerMeterType>","Sub Name","Mode Type","<#Lang['?'].FirmwareVersion>","<#Lang['?'].NetID>","<#Lang['?'].ErrorCode>","IP1","IP2","IP3","IP4","<#Lang['?'].port>",""];
							//"<#Lang['?'].address> / <#Lang['?'].netID>",
							//"<#Lang['?'].pollingTimeout>",
							//"<#Lang['?'].retryInterval>",
							//"<#Lang['?'].scanRate>",
	PMFloatingPoint=["","Wiring Type","","1~ 255","-1=Initializing<br />0=Failed<br />1=Success","0~ 255","0~ 255","0~ 255","0~ 255","1~65535",""];
	StatisticsName = {
									"MCD" : "15/30/60 <#Lang['?'].minsActualDemand>",
									"MPD" : "15/30/60 <#Lang['?'].minsForecastDemand>",
									"MDH" : "<#Lang['?'].MaxDemandHourly>",
									"MDD" : "<#Lang['?'].MaxDemandDaily>",
									"MDM" : "<#Lang['?'].MaxDemandMonthly>",
									"DTE" : "<#Lang['?'].DailyAccumulatedElectricity>",
									"MTE" :"<#Lang['?'].MonthlyAccumulatedElectricity>" ,
									"YTE" : "<#Lang['?'].YearlyAccumulatedElectricity>"
							};
	RTUDataType = ["Int16","UInt16","Float","Int32","UInt32","Float"];
	RTURange = ["-32768~32767 "," 0~65535",,"-2147483648 ~2147483647" ,"0~4294967295","Floating Point"];
	PhaseType={1:[], 3 : ["Phase A","Phase B","Phase C","Total/Average"]};
	meterValueOption = {
									"V" : "V",
									"I" : "I",
									"KW" : "kW",
									"KVAR" : "kvar",
									"KVA" : "kVA",
									"PF" : "PF",
									"KWH" :"kWh" ,
									"KVARH" : "kvarh",
									"KVAH" : "kVAh"
							};
	//PMType = SelectInfo.powerMeter.modelName.split("-")[1].split("[")[0];
	PhaseType[1]=[];
	if(SelectInfo.powerMeter.phase == 1)
		for(var i = 1 ; i <=SelectInfo.powerMeter.loop ; i++)
			PhaseType[1].push("CT "+i);
}
function InserPMTable(TableObj){
	PMinit();
	var html_str ='';
	var exAddress = 1;
	AddAddress = 0;
	html_str += InserDataInfoTable("PM");
	//PMFloatingPoint.splice(0, 0, PMType);
	PMFloatingPoint.splice(0, 0, "");
	//add pt and ct Floating Point
	for(var i in SelectInfo.powerMeter.pt)
	{
		PMInfo.splice((PMInfo.length), 0, "<#Lang['?'].pt>"+(parseInt(i)+1));
		PMFloatingPoint.splice((PMFloatingPoint.length), 0, "0.01~655.35");
	}
	for(var i in SelectInfo.powerMeter.ct)
	{
		PMInfo.splice((PMInfo.length), 0, "<#Lang['?'].ct>"+(parseInt(i)+1));
		PMFloatingPoint.splice((PMFloatingPoint.length), 0, "1~65535");
	}
		
	html_str +='<div>';
	var customizedDataArray={};
	var customizedDataLength;
	if(SelectInfo.powerMeter.customizedData.length!=0)
	{
		for(var i= 0 ; i < SelectInfo.powerMeter.customizedData.length; i++ )
			customizedDataArray[i] = [SelectInfo.powerMeter.customizedData[i].ruleName,
											//SelectInfo.powerMeter.format[SelectInfo.powerMeter.customizedData[i].format].dataModel,
											//SelectInfo.powerMeter.format[SelectInfo.powerMeter.customizedData[i].format].type,
											SelectInfo.powerMeter.format[SelectInfo.powerMeter.customizedData[i].format].local.dataModel,
											SelectInfo.powerMeter.format[SelectInfo.powerMeter.customizedData[i].format].local.type,
											
											SelectInfo.powerMeter.customizedData[i].name,
											SelectInfo.powerMeter.customizedData[i].channelIndex,
											SelectInfo.powerMeter.customizedData[i].itemName
											];
											
											
	}
	var HaveTitle = false;
	for(var type in typeArray)
	{
		HaveTitle = false;
		if(typeArray[type] == "AI" )
		{
			html_str += InserTableTitle(TypeTitle[typeArray[type]]);
			//meterValue
			for(var i = 0 ; i < SelectInfo.powerMeter.loop ; i++)
			{
				var isSinglePhase =false
				if(typeof(SelectInfo.powerMeter.channel[i].isSinglePhase) != "undefined")
					isSinglePhase = SelectInfo.powerMeter.channel[i].isSinglePhase;
				var CT_loop_Count = 0;
				if(SelectInfo.powerMeter.phase == 3 && SelectInfo.powerMeter.loop > 1)
				{
					var loop_name = "";
					if(SelectSourceType == "comport")
						loop_name = get_cb_loop_name(moduleManager.pool.interfaces.comport[SelectCom].modules[Selectmodules]);
					else if(SelectSourceType == "network")
						loop_name = get_cb_loop_name(moduleManager.pool.interfaces.network[SelectCom].modules[Selectmodules]);
					html_str += '<tr><td colspan = "5" bgcolor="#A4A4A4">'+ loop_name[i] +'</td></tr>';
					
				}
				for(var j = 0 ; j < SelectInfo.powerMeter.channel[i].length ; j++)
				{
					if(SelectInfo.powerMeter.phase == 1)
						if(SelectInfo.powerMeter.channel[i].name=="")
							html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">'+ PhaseType[SelectInfo.powerMeter.phase][i] +'</td></tr>';
						else
							html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">'+ PhaseType[SelectInfo.powerMeter.phase][i] + '(' + SelectInfo.powerMeter.channel[i].name + ')' + '</td></tr>';
					else
					{
						if(isSinglePhase)
						{
							if(CT_loop_Count < 3)
							{
								if(SelectInfo.powerMeter.channel[i][j].name=="")
									html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">CT' + (i*3+j+1) +'</td></tr>';
								
								else
									html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">CT' + (i*3+j+1)  + '(' + SelectInfo.powerMeter.channel[i][j].name + ')' + '</td></tr>';
								CT_loop_Count++;
							}
							else
							{
								html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">Total/Average</td></tr>';
							}
						}
						else
						{
							if(SelectInfo.powerMeter.channel[i][j].name=="")
								html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">'+ PhaseType[SelectInfo.powerMeter.phase][j] +'</td></tr>';
							else
								html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">'+ PhaseType[SelectInfo.powerMeter.phase][j] + '(' + SelectInfo.powerMeter.channel[i][j].name + ')' + '</td></tr>';
						}
					}
					meterValueLength = SelectInfo.powerMeter.channel[i][j].meterValue.length;
					
					for(var v = 0 ; v < SelectInfo.powerMeter.channel[i][j].meterValue.length;v++)
					{
						if(typeof(SelectInfo.powerMeter.channel[i][j].meterValue[v])=="undefined")
							AddAddress += AddressBit[typeArray[type]];
						else
						{
							var AddressLength = meterValueAddaddress(i, j, v);
							html_str += '<tr>';
							html_str += '<td>' + meterValueOption[SelectInfo.powerMeter.channel[i][j].meterValue[v].itemID]+'</td>';
							html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
							//html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
							html_str += '<td>' + AddressLength + '</td>';
							if(AddressLength == 4)
								html_str += '<td>Double</td>';
							else
								html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
							html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
							html_str += '</tr>';
							AddAddress += AddressLength;
						}
					}
					if(meterValueLength<9)
					{
						AddAddress = AddAddress + (9-meterValueLength) *2; 
					}
				}
			}
			
			//statisticsValue
			for(var i = 0 ; i < SelectInfo.powerMeter.loop ; i++)
			{
				var isSinglePhase =false
				if(typeof(SelectInfo.powerMeter.channel[i].isSinglePhase) != "undefined")
					isSinglePhase = SelectInfo.powerMeter.channel[i].isSinglePhase;
				var CT_loop_Count = 0;
				if(SelectInfo.powerMeter.phase == 3 && SelectInfo.powerMeter.loop > 1)
				{
					var loop_name = "";
					if(SelectSourceType == "comport")
						loop_name = get_cb_loop_name(moduleManager.pool.interfaces.comport[SelectCom].modules[Selectmodules]);
					else if(SelectSourceType == "network")
						loop_name = get_cb_loop_name(moduleManager.pool.interfaces.network[SelectCom].modules[Selectmodules]);
					html_str += '<tr><td colspan = "5" bgcolor="#A4A4A4">'+ loop_name[i] +'</td></tr>';
				}
				for(var j = 0 ; j < SelectInfo.powerMeter.channel[i].length ; j++)
					{
						if(SelectInfo.powerMeter.channel[i][j].statisticsValue.length !=0)
						{
							if(SelectInfo.powerMeter.phase == 1)
								if(SelectInfo.powerMeter.channel[i].name=="")
									html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">'+ PhaseType[SelectInfo.powerMeter.phase][i] +'</td></tr>';
								else
									html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">'+ PhaseType[SelectInfo.powerMeter.phase][i] + '(' + SelectInfo.powerMeter.channel[i].name + ')' + '</td></tr>';
							else
							{
								if(isSinglePhase)
								{
									if(CT_loop_Count < 3)
									{
										if(SelectInfo.powerMeter.channel[i][j].name=="")
											html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">CT' + (i*3+j+1) +'</td></tr>';
										
										else
											html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">CT' + (i*3+j+1)  + '(' + SelectInfo.powerMeter.channel[i][j].name + ')' + '</td></tr>';
										CT_loop_Count++;
									}
									else
									{
										html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">Total/Average</td></tr>';
									}
								}
								else
								{
									if(SelectInfo.powerMeter.channel[i][j].name=="")
										html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9">'+ PhaseType[SelectInfo.powerMeter.phase][j] +'</td></tr>';
									else
										html_str += '<tr><td colspan = "5" bgcolor="#CDC9C9"  style="word-break:break-all;">'+ PhaseType[SelectInfo.powerMeter.phase][j] + '(' + SelectInfo.powerMeter.channel[i][j].name + ')' + '</td></tr>';
								}
							}
							for(var v = 0 ; v < SelectInfo.powerMeter.channel[i][j].statisticsValue.length ; v++)
							{
								if(typeof(SelectInfo.powerMeter.channel[i][j].statisticsValue[v])=="undefined")
									AddAddress += AddressBit[typeArray[type]];
								else
								{
									var AddressLength = statisticsValueAddaddress(i, j, v);
									html_str += '<tr>';
									html_str += '<td>' + StatisticsName[SelectInfo.powerMeter.channel[i][j].statisticsValue[v].itemID] + '</td>';
									html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
									//html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
									html_str += '<td>' + AddressLength + '</td>';
									if(AddressLength == 4)
										html_str += '<td>Double</td>';
									else
										html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
									html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
									html_str += '</tr>';
									AddAddress += AddressLength;
								}
							}
						}
					}
			}
			//otherInfo
			for(var i = 0; i < typeCount[typeArray[type]]; i++)
			{
				
				if(!HaveTitle)
				{
					html_str += '<tr><td colspan = "5" bgcolor="#BDBDBD"><#Lang['?'].otherinfo></td></tr>';
					HaveTitle = true;
				}
				html_str += '<tr>';
				if(SelectInfo.powerMeter.io[typeArray[type]][i].name != "")
					html_str += '<td>' + typeArray[type] + '  Ch.' + i +'('+ SelectInfo.powerMeter.io[typeArray[type]][i].name +')'+ '</td>';
				else
					html_str += '<td>' + typeArray[type] + '  Ch.' + i + '</td>';
				//html_str += '<td>' + padLeft((SA + i * AddressBit[typeArray[type]] + ModbusAddress[typeArray[type]]).toString(), 5) + '</td>';
				html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
				html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
				html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
				html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
				html_str += '</tr>';
				AddAddress += AddressBit[typeArray[type]];
			}
			var checkcustomizedRI=0;
			for(var i in customizedDataArray)
			{
				if(customizedDataArray[i][1] == "RI")
				{
					if(!HaveTitle)
					{
						html_str += '<tr><td colspan = "5" bgcolor="#BDBDBD"><#Lang['?'].otherinfo></td></tr>';
						HaveTitle = true;
					}
					html_str += '<tr>';
					
					if(SelectInfo.powerMeter.phase == 3 &&SelectInfo.powerMeter.loop>1)
					{
						if(customizedDataArray[i][3] == "")
							html_str += '<td>' + customizedDataArray[i][0] + ' ' + customizedDataArray[i][5] +'</td>';
						else
							html_str += '<td>' + customizedDataArray[i][0] +' ' + customizedDataArray[i][5] +'('+ customizedDataArray[i][3] +')' + '</td>';
					}
					else
					{
						if(customizedDataArray[i][3] == "")
							html_str += '<td>' + customizedDataArray[i][0] +'</td>';
						else
							html_str += '<td>' + customizedDataArray[i][0] +'('+ customizedDataArray[i][3] +')' + '</td>';
					}
					html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
					if(customizedDataArray[i][2] >= 2)
						customizedDataLength = 2;
					else
						customizedDataLength= 1;
					html_str += '<td>' + customizedDataLength.toString() + '</td>';
					html_str += '<td>' +RTUDataType[customizedDataArray[i][2]] + '</td>';
					html_str += '<td>' + RTURange[customizedDataArray[i][2]] + '</td>';
					html_str += '</tr>'
					AddAddress += customizedDataLength;
				}
			}
			
			
			//PMInfo
			var pm_information_start_address ="";
			if(SelectSourceType=="comport")
				pm_information_start_address = WISE.managers.moduleManager.pool.interfaces.comport[SelectCom].moduleInfoModbusTableStartAddress;
			else if(SelectSourceType=="network")
				pm_information_start_address = WISE.managers.moduleManager.pool.interfaces.network[SelectCom].moduleInfoModbusTableStartAddress;
			var pm_information_Max_length = WISE.managers.moduleManager.moduleInfoModbusTableMaxLength;
			AddAddress = 0;
			html_str += '<tr><td colspan = "5" bgcolor="#BDBDBD"><#Lang['?'].meterInfo></td></tr>';
			for(var i = 0 ; i < PMInfo.length ; i++)
			{
				if(SelectInfo.type == "rtu" &&  i > 5 && i < 11)//rtu no ip and port information, but must keep memory space
				{
					AddAddress += 1;
					continue;
				}
				if(i == 11||i==1||i==2)//Reserved
				{
					AddAddress += 1;
					continue;
				}
				html_str += '<tr>';
				html_str += '<td>' + PMInfo[i] + '</td>';
				html_str += '<td>'+padLeft((pm_information_start_address + (pm_information_Max_length*Selectmodules) + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num)+'</td>';
				
				if(i < 10)
				{
					exAddress=1;
					html_str += '<td>1</td>';
					html_str += '<td>Int16</td>';
				}
				else if(i == 10)
				{
					exAddress=1;
					html_str += '<td>1</td>';
					html_str += '<td>UInt16</td>';
				}
				else//pt ct						
				{
					exAddress=2;
					html_str += '<td>2</td>';
					html_str += '<td>Float</td>';
				}
				html_str += '<td>'+ PMFloatingPoint[i] + '</td>';
				html_str += '</tr>';
				AddAddress += exAddress;
			}	
		}
		else//AO、DI、DO
		{
			if(typeArray[type] == "DO")
			{
				if(typeCount[typeArray[type]] > 0 )
				{
					if(!HaveTitle)
						html_str += InserTableTitle(TypeTitle[typeArray[type]]);
					HaveTitle = true;
					for(var i = 0; i < typeCount[typeArray[type]]; i++)
					{
						html_str += '<tr>';
						if(SelectInfo.powerMeter.io[typeArray[type]][i].name != "")
							html_str += '<td>' + typeArray[type] + '  Ch.' + i +'('+ SelectInfo.powerMeter.io[typeArray[type]][i].name +')'+ '</td>';
						else
							html_str += '<td>' + typeArray[type] + '  Ch.' + i + '</td>';
						//html_str += '<td>' + padLeft((SA + i * AddressBit[typeArray[type]] + ModbusAddress[typeArray[type]]).toString(), 5) + '</td>';
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
						html_str += '</tr>';
						AddAddress += AddressBit[typeArray[type]];
					}
				}
				for(var i in customizedDataArray)
				{
					if(customizedDataArray[i][1] == "CO")
					{
						if(!HaveTitle)
							html_str += InserTableTitle(TypeTitle[typeArray[type]]);
						html_str += '<tr>';
						if(customizedDataArray[i][3] == "")
							html_str += '<td>' + customizedDataArray[i][0] +' ' + customizedDataArray[i][4] + '</td>';
						else
							html_str += '<td>' + customizedDataArray[i][0] +' ' + customizedDataArray[i][4] +'('+ customizedDataArray[i][3] +')' + '</td>';
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						if(customizedDataArray[i][2] >= 2)
							customizedDataLength = 2;
						else
							customizedDataLength= 1;
						html_str += '<td>' + customizedDataLength.toString() + '</td>';
						if(typeof(customizedDataArray[i][2]) != "undefined"){
							html_str += '<td>' +RTUDataType[customizedDataArray[i][2]] + '</td>';
							html_str += '<td>' + RTURange[customizedDataArray[i][2]] + '</td>';
						}
						else{
							html_str += '<td>Byte</td>';
							html_str += '<td>0~1</td>';
						}
						
						html_str += '</tr>'
						AddAddress += customizedDataLength;
					}
				}
			}
			if(typeArray[type] == "DI")
			{
				if(typeCount[typeArray[type]] > 0 )
				{
					if(!HaveTitle)
						html_str += InserTableTitle(TypeTitle[typeArray[type]]);
					HaveTitle = true;
					for(var i = 0; i < typeCount[typeArray[type]]; i++)
					{
						html_str += '<tr>';
						if(SelectInfo.powerMeter.io[typeArray[type]][i].name != "")
							html_str += '<td>' + typeArray[type] + '  Ch.' + i +'('+ SelectInfo.powerMeter.io[typeArray[type]][i].name +')'+ '</td>';
						else
							html_str += '<td>' + typeArray[type] + '  Ch.' + i + '</td>';
						//html_str += '<td>' + padLeft((SA + i * AddressBit[typeArray[type]] + ModbusAddress[typeArray[type]]).toString(), 5) + '</td>';
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
						html_str += '</tr>';
						AddAddress += AddressBit[typeArray[type]];
					}
				}
				for(var i in customizedDataArray)
				{
					if(customizedDataArray[i][1] == "CI")
					{
						if(!HaveTitle)
						html_str += InserTableTitle(TypeTitle[typeArray[type]]);
						html_str += '<tr>';
						if(customizedDataArray[i][3] == "")
							html_str += '<td>' + customizedDataArray[i][0] + ' ' + customizedDataArray[i][4] +'</td>';
						else
							html_str += '<td>' + customizedDataArray[i][0] +' ' + customizedDataArray[i][4] +'('+ customizedDataArray[i][3] +')' + '</td>';
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						if(customizedDataArray[i][2] >= 2)
							customizedDataLength = 2;
						else
							customizedDataLength= 1;
						html_str += '<td>' + customizedDataLength.toString() + '</td>';
						if(typeof(customizedDataArray[i][2]) != "undefined"){
							html_str += '<td>' +RTUDataType[customizedDataArray[i][2]] + '</td>';
							html_str += '<td>' + RTURange[customizedDataArray[i][2]] + '</td>';
						}
						else{
							html_str += '<td>Byte</td>';
							html_str += '<td>0~1</td>';
						}
						html_str += '</tr>'
						AddAddress += customizedDataLength;
					}
				}
			}
			if(typeArray[type] == "AO")
			{
				if(typeCount[typeArray[type]] > 0 )
				{
					if(!HaveTitle)
						html_str += InserTableTitle(TypeTitle[typeArray[type]]);
					HaveTitle = true;
					for(var i = 0; i < typeCount[typeArray[type]]; i++)
					{
						html_str += '<tr>';
						if(SelectInfo.powerMeter.io[typeArray[type]][i].name != "")
							html_str += '<td>' + typeArray[type] + '  Ch.' + i +'('+ SelectInfo.powerMeter.io[typeArray[type]][i].name +')'+ '</td>';
						else
							html_str += '<td>' + typeArray[type] + '  Ch.' + i + '</td>';
						//html_str += '<td>' + padLeft((SA + i * AddressBit[typeArray[type]] + ModbusAddress[typeArray[type]]).toString(), 5) + '</td>';
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
						html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
						html_str += '</tr>';
						AddAddress += AddressBit[typeArray[type]];
					}
				}
				for(var i in customizedDataArray)
				{
					if(customizedDataArray[i][1] == "RO")
					{
						if(!HaveTitle)
							html_str += InserTableTitle(TypeTitle[typeArray[type]]);
						HaveTitle = true;
						
						html_str += '<tr>';
						if(SelectInfo.powerMeter.phase == 3 &&SelectInfo.powerMeter.loop>1)						
						{
							if(customizedDataArray[i][3] == "")
								html_str += '<td>' + customizedDataArray[i][0] + ' ' + customizedDataArray[i][5] +'</td>';
							else
								html_str += '<td>' + customizedDataArray[i][0] + ' ' + customizedDataArray[i][5] +'('+ customizedDataArray[i][3] +')' + '</td>';
						}
						else
						{
							if(customizedDataArray[i][3] == "")
								html_str += '<td>' + customizedDataArray[i][0] + '</td>';
							else
								html_str += '<td>' + customizedDataArray[i][0] + '('+ customizedDataArray[i][3] +')' + '</td>';
						}
						
						html_str += '<td>' + padLeft((SA + AddAddress + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
						if(customizedDataArray[i][2] >= 2)
							customizedDataLength = 2;
						else
							customizedDataLength= 1;
						html_str += '<td>' + customizedDataLength.toString() + '</td>';
						if(customizedDataArray[i][0].match("Harmonic") != null)
						{
							html_str += '<td>' +RTUDataType[customizedDataArray[i][2]] + '</td>';
							//if(SelectInfo.powerMeter.phase==1)
								//html_str += '<td>0: Disable <br />1: Loop ' + (customizedDataArray[i][4]*3+1) +'<br /> 2: Loop '+(customizedDataArray[i][4]*3+2)+'<br /> 3: Loop '+ (customizedDataArray[i][4]*3+3) +'</td>';
							//else
								html_str += '<td>0: Disable <br />1: Phase A/CT'+(customizedDataArray[i][4]*3+1)+'<br /> 2: Phase B/CT'+(customizedDataArray[i][4]*3+2)+'<br /> 3: Phase C/CT'+(customizedDataArray[i][4]*3+3)+'</td>';
						}
						else
						{
							html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
							html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
						}
						html_str += '</tr>'
						AddAddress += customizedDataLength;
					}
				}
			}
		}
		html_str += '</table>'
		html_str += '<div><br /> </div>';
		AddAddress = 0;
	}
	html_str += '</div>';
	TableObj.html(html_str);
}
function meterValueAddaddress(i, j, v)
{
	var format_type = SelectInfo.powerMeter.format[SelectInfo.powerMeter.channel[i][j].meterValue[v].format].local.type;
	if(format_type<=2)
		return 1;
	else if(format_type >= 3&&format_type <= 5)
		return 2;
	else if(format_type > 5)
		return 4;
}
function statisticsValueAddaddress(i, j, v)
{
	var format_type = SelectInfo.powerMeter.format[SelectInfo.powerMeter.channel[i][j].statisticsValue[v].format].local.type;
	if(format_type<=2)
		return 1;
	else if(format_type >= 3&&format_type <= 5)
		return 2;
	else if(format_type > 5)
		return 4;
}