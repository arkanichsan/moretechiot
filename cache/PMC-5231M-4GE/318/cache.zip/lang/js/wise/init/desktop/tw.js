$.extend(true, Lang, {
	"js/wise/init/desktop.js": {
		"passwordIncorrect": "密碼錯誤。",
		"reachMaximumNumberOfLoginUser": "系統登入人數已滿。",
		"loginSuccessfully": "登入成功。",
		"instantMessage": "即時訊息",
		"approxXDays": "約剩$day天",
		"noSDCard": "未偵測到microSD卡。",
		"ftpUploadFailed": "遠端FTP上傳失敗。",
		"initModuleFailed": "初始化模組$moduleName($address)失敗。",
		"tip": {
			"thisFieldRangeIsBetweenAToB": "此欄位輸入範圍為 $minimum ~ $maximum。",
			"thisFieldRangeIsGreaterEqualX": "此欄位輸入範圍為大於或等於 $minimum。",
			"thisFieldRangeIsLessEqualX": "此欄位輸入範圍為小於或等於 $maximum。",
			"thisFieldOnlyAllowInputInteger": "此欄位限輸入整數。",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "此欄位限輸入整數或浮點數。",
			"thisFieldOnlyAllowInputHEX": "此欄位限輸入16進位數值。",
			"thisFieldNotAllowInputThisChar": "此欄位不允許輸入此字元。",
			"thisFieldContainsTooManyChar": "此欄位包含過多的字元。"
		},
		"popup": {
			"exitEditModeFirst": "請先退出編輯模式。<br>提示：[工具] -> [回專案清單]",
			"areYouSureYouWantToClearAllSetting": "您確定要清除所有設定？",
			"areYouSureYouWantToLoadSetting": "您確定要讀取設定檔？所有尚未儲存的設定在載入設定檔後將會消失。",
			"areYouSureYouWantToSaveSetting": "您確定要寫入設定檔嗎？",
			"areYouSureYouWantToLogout": "您確定要登出嗎？"
		},
		"vpn":{
			"VPNConnecting":"VPN連結中，請稍候。",
			"VPNError":"與VPN伺服器連結發生異常狀況，請確認VPN設定是否有誤。"
		}
	}
});