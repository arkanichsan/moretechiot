$.extend(true, Lang, {
	"js/wise/extend/init/base.js": {
		"V": "V",
		"I": "I",
		"kW": "kW",
		"kvar": "kvar",
		"kVA": "kVA",
		"PF": "PF",
		"actualDemand": "Actual Demand",
		"forecastDemand": "Forecast Demand",
		"hourlyMaximumDemand": "Hourly Maximum Demand",
		"dailyMaximumDemand": "Daily Maximum Demand",
		"monthlyMaximumDemand": "Monthly Maximum Demand",
		"dailyAccumElectricity": "Daily Accumulated Electricity",
		"monthlyAccumElectricity": "Monthly Accumulated Electricity",
		"yearlyAccumElectricity": "Yearly Accumulated Electricity",
		"wiringType": {
			"0": "None",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT",
			"6": "3P3W2CT(HW)",
			"7": "3P3W3CT(HW)",
			"8": "3P4W3CT(HW)"
		},
		"wiringMode": {
			"0": "Automatic",
			"1": "1P2W",
			"2": "1P3W",
			"3": "3P3W2CT",
			"4": "3P3W3CT",
			"5": "3P4W3CT"
		},
		"voltageMode": {
			"0": "Automatic",
			"1": "Line-to-Neutral",
			"2": "Line-to-Line"
		},
		"phaseSequence": {
			"0": "Negative",
			"1": "Positive"
		}
	}
});