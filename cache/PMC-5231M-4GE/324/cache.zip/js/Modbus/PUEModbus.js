function InserPUETable(TableObj){
	var html_str = '';
	var PUEHasValue =false;
	for(var i in PUEInfo.pool.pues)
		PUEHasValue =true;

	if(PUEHasValue)
	{
		html_str +='<div>';
		html_str +='<table border = "1px" width = "100%">';
		html_str += '<tr><td colspan = "5" bgcolor="#BDBDBD">'+ TypeTitle["AI"] +'</td></tr>';
		html_str += '<tr>';
		for( var title in TableTitle)
			html_str += '<td bgcolor = "#F2F2F2">' + TableTitle[title] + '</td>';
		html_str += '</tr>';
		for(var i in PUEInfo.pool.pues)
		{
			html_str += '<tr>';
			html_str += '<td style="word-break:break-all;">' + PUEInfo.pool.pues[i].name + '</td>';
			html_str += '<td>' + padLeft((300 + i * AddressBit["AI"] + ModbusAddress["AI"]).toString(), padLeft_num) + '</td>';
			html_str += '<td>' + AddressBit["AI"] + '</td>';
			html_str += '<td>' + ModbusDataType["AI"] + '</td>';
			html_str += '<td>' + ModbusRange["AI"] + '</td>';
			html_str += '</tr>';
		}
		html_str += '</table>';	
		html_str += '</div>';
		TableObj.html(html_str);
	}
	else
	{
		html_str += '<div id="OverviewNomoduleDiv" style="position: relative; border: 2px dashed rgb(182, 186, 192); border-radius: 5px; background-color: rgb(242, 242, 242);">';
		html_str += '<div class="OverviewNomodule" style="font-size: 120%;padding: 70px 0;text-align: center;color: #2A2A2A;"><#Lang["?"].noinfo></div></div>';
		TableObj.html(html_str);
	}
}