$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"register": "Internal Register"
	}
});