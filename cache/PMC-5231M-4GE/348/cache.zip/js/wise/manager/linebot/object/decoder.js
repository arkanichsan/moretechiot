WISE.managers.lineBotManager.decodeXMLObject = function(xmlDoc){
	var maxKey = 0;

	var $xmlMESSAGE = $(xmlDoc).find("WISE > NOTE > LINE_BOT > MESSAGE");
	if($xmlMESSAGE.length > 0){
		maxKey = 0;

		var $xmlM = $xmlMESSAGE.find("> M");
		for(var i = 0; i < $xmlM.length; i++){
			var key = parseInt($($xmlM[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var message = this.createMessage({
				"name": $($xmlM[i]).attr("nickname"),
				"description": $($xmlM[i]).attr("desc") || "",
				"content": $($xmlM[i]).text()
			});

			this.setMessage(key, message);
		}

		this.pool.messageKey = ++maxKey;
	}
};