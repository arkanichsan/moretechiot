$.extend(true, Lang, {
	"js/wise/init/desktop.js": {
		"passwordIncorrect": "密码错误。",
		"reachMaximumNumberOfLoginUser": "系统登录人数已满。",
		"loginSuccessfully": "登录成功。",
		"instantMessage": "即时消息",
		"approxXDays": "约剩$day天",
		"noSDCard": "未侦测到microSD卡。",
		"ftpUploadFailed": "远程FTP上传失败。",
		"initModuleFailed": "初始化模块$moduleName($address)失败。",
		"tip": {
			"thisFieldRangeIsBetweenAToB": "此字段输入范围为 $minimum ~ $maximum。",
			"thisFieldRangeIsGreaterEqualX": "此字段输入范围为大于或等于 $minimum。",
			"thisFieldRangeIsLessEqualX": "此字段输入范围为小于或等于 $maximum。",
			"thisFieldOnlyAllowInputInteger": "此字段限输入整数。",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "此字段限输入整数或浮点数。",
			"thisFieldOnlyAllowInputHEX": "此字段限输入16进位数值。",
			"thisFieldNotAllowInputThisChar": "此字段不允许输入此字符。",
			"thisFieldContainsTooManyChar": "此字段包含过多的字符。"
		},
		"popup": {
			"exitEditModeFirst": "请先退出编辑模式。<br>提示：[工具] -> [回项目清单]",
			"areYouSureYouWantToClearAllSetting": "您确定要清除所有设置？",
			"areYouSureYouWantToLoadSetting": "您确定要读取配置文件？所有尚未储存的设置在加载配置文件后将会消失。",
			"areYouSureYouWantToSaveSetting": "您确定要写入配置文件吗？",
			"areYouSureYouWantToLogout": "您确定要注销吗？"
		},
		"vpn":{
			"VPNConnecting":"VPN连结中，请稍候。",
			"VPNError":"与VPN伺服器连结发生异常状况，请确认VPN设置是否有误。"
		}
	}
});