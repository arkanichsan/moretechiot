$.extend(true, Lang, {
	"js/wise/manager/logger/rule/object.js": {
		"ftpUploadStatus": "FTP上传状态",
		"uploadFailedContinuingXHours": "上传失败持续 $hours 小时",
		"dataLogger": "数据记录器",
		"stop": "停止",
		"start": "启动",
		"oneTimeLog": "单次记录"
	}
});