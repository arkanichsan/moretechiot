WISE.managers.bluemixManager = (function(){
	return new function() {
		this.pool = {
			//"index": 0,
			//"name": "",
			//"description": "",
			//"reference": [],

			"enable": false,
			"organizationID": "",
			"deviceType": "",
			"deviceID": "",
			"deviceAuthenticationToken": "",
			"keepAliveTimer": 60,
			"publishInterval": 5,

			"publish": {
				"messages": {},
				"key": 0
			},
			"subscribe": {
				"commands": {},
				"commandKey": 0,
				"variables": {},
				"variableKey": 0
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		//this.maxPublishMessageAmount = 12;
		//this.maxSubscribeCommandAmount = 12;
		//this.maxSubscribeVariableAmount = 12;

		//Publish Topic
		this.createPublishMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"eventID": "",
				"type": 0,//0: channel, 1: user-defined
				"payload": "",
				"json": true,//payload in json format(only type==0)
				"autoPublish": {
					"timing": 0,//bit0(1): when chagne, bit1(2): fixed interval,
					"threshold": 1
				}
			}, settings);
			
			return message;
		};

		this.addPublishMessage = function(message){
			var retKey = this.pool.publish.key;
			this.pool.publish.messages[this.pool.publish.key++] = message;
			return retKey;
		};

		this.removePublishMessage = function(key){
			delete this.pool.publish.messages[key];
		};

		this.getPublishMessage = function(key){
			if(typeof(this.pool.publish.messages[key]) != "undefined"){
				return this.pool.publish.messages[key];
			}
			else{
				return null;
			}
		};

		this.setPublishMessage = function(key, message){
			this.pool.publish.messages[key] = message;
		};

		this.getPublishMessages = function(){
			return this.pool.publish.messages;
		};

		//receive
		this.createSubscribeCommand = function(settings){
			var command = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"key": ""
			}, settings);
			
			return command;
		};

		this.addSubscribeCommand = function(command){
			var retKey = this.pool.subscribe.commandKey;
			this.pool.subscribe.commands[this.pool.subscribe.commandKey++] = command;
			return retKey;
		};

		this.removeSubscribeCommand = function(key){
			delete this.pool.subscribe.commands[key];
		};

		this.getSubscribeCommand = function(key){
			if(typeof(this.pool.subscribe.commands[key]) != "undefined"){
				return this.pool.subscribe.commands[key];
			}
			else{
				return null;
			}
		};

		this.setSubscribeCommand = function(key, command){
			this.pool.subscribe.commands[key] = command;
		};

		this.getSubscribeCommands = function(){
			return this.pool.subscribe.commands;
		};

		this.createSubscribeVariable = function(settings){
			var variable = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"key": ""
			}, settings);
			
			return variable;
		};

		this.addSubscribeVariable = function(variable){
			var retKey = this.pool.subscribe.variableKey;
			this.pool.subscribe.variables[this.pool.subscribe.variableKey++] = variable;
			return retKey;
		};

		this.removeSubscribeVariable = function(key){
			delete this.pool.subscribe.variables[key];
		};

		this.getSubscribeVariable = function(key){
			if(typeof(this.pool.subscribe.variables[key]) != "undefined"){
				return this.pool.subscribe.variables[key];
			}
			else{
				return null;
			}
		};

		this.setSubscribeVariable = function(key, variable){
			this.pool.subscribe.variables[key] = variable;
		};

		this.getSubscribeVariables = function(){
			return this.pool.subscribe.variables;
		};
	};
})();
