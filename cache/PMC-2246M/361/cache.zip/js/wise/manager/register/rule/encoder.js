WISE.managers.registerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "register"){
			xmlDoc.setAttribute("l_obj", "IR");
			xmlDoc.setAttribute("l_idx", ruleObject.rule.registerIndex + 1);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);
			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "register"){
			xmlDoc.setAttribute("l_obj", "IR");
			xmlDoc.setAttribute("l_idx", ruleObject.rule.registerIndex + 1);
			xmlDoc.setAttribute("op", {0: "0", 1: "3", 10: "1", 11: "4", 20: "2", 21: "5", 30: "6", 31: "8", 40: "7", 41: "9"}[ruleObject.rule.operate * 10 + ruleObject.rule.frequency]);

			processCompareModule(xmlDoc, ruleObject);
		}
	}
};
