function IOinit(){
	DICounterModule = WISE.managers.moduleManager.icpdasModule.isDICounterModule(SelectInfo);
	DICounter32Bits=WISE.managers.moduleManager.icpdasModule.is32BitsDICounterModule(SelectInfo);
}
function InserIOTable(TableObj){
	IOinit();
	var html_str ='';
	html_str += InserDataInfoTable("IO");
	html_str +='<div>';
	for(var type in typeArray)
		if(typeCount[typeArray[type]] >0 || (typeArray[type] == "AI" && (DICounterModule || DICounter32Bits))||(typeArray[type] == "AI" &&  typeCount["DI"] != 0))
		{
			//html_str +='<table border = "1px" width = "100%">';
			if(typeArray[type] == "DI" && DICounterModule && DICounter32Bits)//7080.7084, no DI but AI have DI Conter
				continue;
			html_str += InserTableTitle(TypeTitle[typeArray[type]]);
			for(var i = 0; i < typeCount[typeArray[type]]; i++)
			{
				html_str += '<tr>';
				if(typeArray[type] == "DO" && SelectInfo.mainType == "7088")//7088 DO Parameter Name is PWM Output Ch.X
					if(SelectInfo[typeArray[type]].setting[i].name !="")
						html_str += '<td  style="word-break:break-all;">PWM Output Ch.' + i +'('+ SelectInfo[typeArray[type]].setting[i].name + ')' + '</td>';
					else
						html_str += '<td>PWM Output Ch.' + i +'</td>';
				else
					if(SelectInfo[typeArray[type]].setting[i].name !="")
						html_str += '<td  style="word-break:break-all;">' + typeArray[type] + '  Ch.' + i +'('+ SelectInfo[typeArray[type]].setting[i].name + ')' + '</td>';
					else
						html_str += '<td>' + typeArray[type] + '  Ch.' + i +'</td>';
				html_str += '<td>' + padLeft((SA + i * AddressBit[typeArray[type]] + ModbusAddress[typeArray[type]]).toString(), padLeft_num) + '</td>';
				html_str += '<td>' + AddressBit[typeArray[type]] + '</td>';
				html_str += '<td>' + ModbusDataType[typeArray[type]] + '</td>';
				html_str += '<td>' + ModbusRange[typeArray[type]] + '</td>';
				html_str += '</tr>';
			}
			if(typeArray[type] == "AI" )
			{
				for( var j = 0;j < typeCount["DI"]; j++)
				{
					html_str += '<tr>';
					if(SelectInfo.DI.setting[j].name!="")
						html_str += '<td  style="word-break:break-all;">DI Counter' + j + '('+ SelectInfo.DI.setting[j].name + ')'+'</td>';
					else
						html_str += '<td>DI Counter' + j +'</td>';
					if(DICounter32Bits||SelectInfo.moduleType == "XVBoard")//7080、7084、7088 Length is 2
					{
						html_str += '<td>' + padLeft((SA + (i*2)+(j*2)+ ModbusAddress[typeArray[type]]).toString(),padLeft_num) + '</td>';
						html_str += '<td>2</td>';
						html_str += '<td>UInt32</td>';
						html_str += '<td>0~4294967295</td>';
						html_str += '</tr>';
					}
					else
					{
						html_str += '<td>' + padLeft((SA + (i*2)+j + ModbusAddress[typeArray[type]]).toString(),padLeft_num) + '</td>';
						html_str += '<td>1</td>';
						html_str += '<td>UInt16</td>';
						html_str += '<td>0~65535</td>';
						html_str += '</tr>';
					}
				}
			}
			html_str += '</table>';
			html_str += '<div><br /></div>';
		}
	html_str += '</div>';
	TableObj.html(html_str);
}