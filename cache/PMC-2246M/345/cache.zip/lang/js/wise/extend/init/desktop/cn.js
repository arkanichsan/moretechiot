$.extend(true, Lang, {
	"js/wise/extend/init/desktop.js": {
		"pulseOutput": "脉冲输出",
		"powerMeter": "电测模块",
		"channel": "通道",
		"info": "信息",
		"ch": "通道",
		"item": "项目",
		"no": "编号",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息",
		"pue": "能源使用效率",
		"all": "全部"
	}
});