$.extend(true, Lang, {
	"js/wise/manager/timer/rule/object.js": {
		"timer": "Timer",
		"notTimeout": "Not timeout",
		"timeout": "Timeout",
		"stop": "Stop",
		"reset": "Reset",
		"start": "Start",
		"pause": "Pause",
		"resume": "Resume"
	},
	"js/wise/manager/timer/rule/encoder.js": {
		"someoneTimerUseAlreadyRemovedRegister": "This Timer is using the value of a disabled Internal Register to be the length of the period time."
	}
});