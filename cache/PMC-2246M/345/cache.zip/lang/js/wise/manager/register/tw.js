$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"register": "內部暫存器",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息"
	}
});