WISE.managers.messengerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "message"){
			xmlDoc.setAttribute("l_obj", "FB_MESSENGER");
			xmlDoc.setAttribute("l_idx", this.pool.messages[ruleObject.rule.messageKey].index);
			xmlDoc.setAttribute("op", "1");
		}
	}
};
