﻿$.extend(true, Lang, {
	"js/wise/manager/system/rule/object.js": {
		"sdCardStatus": "SD卡狀態",
		"abnormal": "異常",
		"signalStrength": "行動網路訊號強度",
		"rebootSystem": "重新啟動系統"
	}
});