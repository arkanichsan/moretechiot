WISE.managers.loggerManager.encodeXMLObject = function(xmlDoc){
	var loggerManager = this;
	var emailManager = WISE.managers.emailManager;
	var processCSVHeader = function(csvHeader, timeStamp, format){
		if(csvHeader == 0){return "";}

		if(typeof(format) == "undefined"){//module
			format = loggerManager.pool._format;
		}

		//prepend and append time/mode to format string, use @n% to prevent replace recursive in english(ex. MM ->Mont(h) -> MontHour)
		timeStamp = timeStamp.replace(/(yyyyy|yyyy|yyy|yy|y)/g, "@1%");
		timeStamp = timeStamp.replace(/(MMMM|MMM|MM|M)/g, "@2%");
		timeStamp = timeStamp.replace(/(dddd|ddd|dd|d)/g, "@3%");
		timeStamp = timeStamp.replace(/(HH|hh|H|h)/g, "@4%");
		timeStamp = timeStamp.replace(/(mm|m)/g, "@5%");
		timeStamp = timeStamp.replace(/(ss|s)/g, "@6%");

		timeStamp = timeStamp.replace(/@1%/g, "<#Lang['?'].year>");
		timeStamp = timeStamp.replace(/@2%/g, "<#Lang['?'].month>");
		timeStamp = timeStamp.replace(/@3%/g, "<#Lang['?'].day>");
		timeStamp = timeStamp.replace(/@4%/g, "<#Lang['?'].hour>");
		timeStamp = timeStamp.replace(/@5%/g, "<#Lang['?'].minute>");
		timeStamp = timeStamp.replace(/@6%/g, "<#Lang['?'].second>");

		format = timeStamp + "," + format + ",<#Lang['?'].mode>";

		var moduleProcessor = function(moduleInfo, channelVariable){
			var paddingName = function(name){
				if(typeof(name) != "undefined" && name != ""){
					return "(" + module.name + ")"
				}
				else{
					return "";
				}
			};

			try{
				var moduleManager = WISE.managers.moduleManager;
				var interfaceName = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name;
				var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];
				var moduleName = (function(sourceType, sourceIndex, moduleIndex){
					var moduleManager = WISE.managers.moduleManager;
					var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
					var name = "";

					if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "onboard"){
						name = module.displayModelName + paddingName(module.name);
					}
					else if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "comport485"){
						if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "dcon"){
							name = module.displayModelName + paddingName(module.name);
						}
						else if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusRTU"){
							if(module.type == "icpdas"){//M7K
								name = module.displayModelName + paddingName(module.name);
							}
							else{
								name = module.name;
							}
						}
					}
					else if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "network"){
						if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusTCP"){
							if(module.type == "icpdas"){//M7K
								name = module.displayModelName + paddingName(module.name);
							}
							else{
								name = module.name;
							}
						}
					}

					return name;
				})(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex);

				var regex = /(\D+)(\d+)/;
				var result = regex.exec(channelVariable);

				if(result){
					for(var i = 0; i < result.length; i++){
						if(typeof(result[i]) == "undefined"){
							result[i] = "";
						}
					}

					moduleInfo.channelType = result[1].toUpperCase();
					moduleInfo.channel = parseInt(result[2].toUpperCase(), 10);
				}

				if(module.type == "icpdas" || module.type == "onboard"){
					var protocol = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

					if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
						var channelIndexInfo = WISE.managers.moduleManager.icpdasModule.channelAddressToIndex(module, moduleInfo.channelType, moduleInfo.channel);
						moduleInfo.channelType = channelIndexInfo[0];
						moduleInfo.channel = channelIndexInfo[1];
					}
					else{//I7K, XW-Board
						if(moduleInfo.channelType == "CI"){
							moduleInfo.channelType = "DIC";
						}
					}
				}

				var channelTypeName = {
					"DI": "DI$channel",
					"DIC": "<#Lang['?'].diCounterX>",
					"DO": "DO$channel",
					"DOC": "<#Lang['?'].doCounterX>",
					"AI": "AI$channel",
					"AO": "AO$channel",
					"CI": "Discrete Input $channel",
					"CO": "Coil Output $channel",
					"RI": "Input Register $channel",
					"RO": "Holding Register $channel",
					"IR": "<#Lang['?'].internalRegisterX>"//remote IR
				}[moduleInfo.channelType];

				var channelInfo = WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, moduleInfo.channelType, moduleInfo.channel);

				if(csvHeader == 1){//channel
					var channelName = channelInfo.channelName;
					if(channelName.match(/^\d+$/)){
						return moduleName + " " + channelTypeName.replace("$channel", channelName);
					}
					else{//customized channel name, like DL
						return moduleName + " " + channelName;
					}
				}
				else if(csvHeader == 2){//name
					return channelInfo.name;
				}
				else{//channel + name
					var channelName = channelInfo.channelName;
					if(channelName.match(/^\d+$/)){
						return moduleName + " " + channelTypeName.replace("$channel", channelInfo);
					}
					else{//customized channel name, like DL
						return moduleName + " " + channelInfo;
					}
				}
			}
			catch(error){
				return null;
			}
		};

		var registerProcessor = function(registerInfo){
			try{
				var registerInfo = WISE.registerInfo(registerInfo.registerIndex);
				if(csvHeader == 1){//channel
					var regex = /\((.*)\)/g;
					return "<#Lang['?'].internalRegisterX>".replace("$channel", registerInfo.replace(regex, ""));
				}
				else if(csvHeader == 2){//name
					var regex = /\((.*)\)/g;
					var resultArray = regex.exec(registerInfo);
					return resultArray != null ? resultArray[1] : "";
				}
				else{//channel + name
					return "<#Lang['?'].internalRegisterX>".replace("$channel", registerInfo);
				}
			}
			catch(error){
				return null;
			}
		};

		var systemInformationProcessor = function(systemInfo){
			try{
				var desc = {
					"Ty": "<#Lang['js/wise/core/desktop.js'].dateYear>",
					"TM": "<#Lang['js/wise/core/desktop.js'].dateMonth>",
					"Td": "<#Lang['js/wise/core/desktop.js'].dateDay>",
					"Th": "<#Lang['js/wise/core/desktop.js'].timeHour>",
					"Tm": "<#Lang['js/wise/core/desktop.js'].timeMinute>",
					"Ts": "<#Lang['js/wise/core/desktop.js'].timeSecond>",
					"TU": "<#Lang['js/wise/core/desktop.js'].timestamp>",
					"Ss": "<#Lang['js/wise/core/desktop.js'].signalStrengthDBM>",
					"Sp": "<#Lang['js/wise/core/desktop.js'].signalStrengthPercent>"
				}[systemInfo.item];

				if(csvHeader == 1){//channel
					return desc;
				}
				else if(csvHeader == 2){//name
					return "";
				}
				else{//channel + name
					return desc + "";
				}
			}
			catch(error){
				return null;
			}
		};

		var undefinedToEmptyString = function(objectArray){
			if(!objectArray){return objectArray;}

			for(var i = 0; i < objectArray.length; i++){
				if(typeof(objectArray[i]) == "undefined"){
					objectArray[i] = "";
				}
			}

			return objectArray;
		};

		var retString = "", index = 0;
		var regex = new RegExp("\\$(X|C(\\d+)D(\\d+))(\\D+\\d+)|\\$(T(\\d+)|C(\\d+)M(\\d+))(\\D+\\d+)|\\$(I(\\d+))|\\$(S(T[yMdhmsU]|S[sp]))", "g");
		var result = undefinedToEmptyString(regex.exec(format));

		while(result != null) {
			var replaceString = null;
			if(result[1].charAt(0) == "X"){//xwboard
				replaceString = moduleProcessor({
					"sourceType": "onboard",
					"sourceIndex": 0,
					"moduleIndex": 0
				}, result[4]);
			}
			else if(result[1].charAt(0) == "C"){//dcon
				replaceString = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[2], 10),
					"moduleIndex": parseInt(result[3], 10) - 1
				}, result[4]);
			}
			else if(result[5].charAt(0) == "T"){//modbus tcp
				replaceString = moduleProcessor({
					"sourceType": "network",
					"sourceIndex": 0,
					"moduleIndex": parseInt(result[6], 10) - 1
				}, result[9]);
			}
			else if(result[5].charAt(0) == "C"){//modbus rtu
				replaceString = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[7], 10),
					"moduleIndex": parseInt(result[8], 10) - 1
				}, result[9]);
			}
			else if(result[10].charAt(0) == "I"){//ir
				replaceString = registerProcessor({
					"registerIndex": parseInt(result[11], 10) - 1,
					"moduleKey": null
				});
			}
			else if(result[12].charAt(0) == "S"){//system
				replaceString = systemInformationProcessor({
					"item": result[13]
				});
			}

			if(replaceString != null){
				retString += format.substring(index, result.index) + replaceString;
				index = regex.lastIndex;
			}

			result = undefinedToEmptyString(regex.exec(format));
		}

		retString += format.substring(index);

		return retString;
	};

	var processFTPAttribute = function(ftpServers){
		var ftpAttribute = "";
		for(var i = 0; i < ftpServers.length; i++){
			if(typeof(loggerManager.pool.ftp.servers[ftpServers[i]]) == "undefined"){continue;}

			ftpAttribute += loggerManager.pool.ftp.servers[ftpServers[i]].index + ",";
		}
		return ftpAttribute.substr(0, ftpAttribute.length - 1);
	};

	var xmlDATALOG = xmlDoc.createElement("DATALOG");

	//data logger(module)
	if(this.pool.dataLogger.module.enable == true){
		var xmlALL_LOG = xmlDoc.createElement("ALL_LOG");

		xmlALL_LOG.setAttribute("name", this.pool.dataLogger.module.fileName);
		xmlALL_LOG.setAttribute("sample_rate", this.pool.dataLogger.module.sampleRate);
		xmlALL_LOG.setAttribute("time_format", this.pool.dataLogger.module.timeStamp);
		xmlALL_LOG.setAttribute("header_type", this.pool.dataLogger.module.csvHeader);
		xmlALL_LOG.setAttribute("header_str", processCSVHeader(this.pool.dataLogger.module.csvHeader, this.pool.dataLogger.module.timeStamp));
		xmlALL_LOG.setAttribute("upload_period", this.pool.dataLogger.module.filePeriod);
		xmlALL_LOG.setAttribute("bom", this.pool.dataLogger.module.useBOM == true ? "1" : "0");
		xmlALL_LOG.setAttribute("ftp", processFTPAttribute(this.pool.dataLogger.module.ftpServers));

		if(typeof(emailManager.pool.emails[this.pool.dataLogger.module.emailKey]) != "undefined"){
			xmlALL_LOG.setAttribute("email", emailManager.pool.emails[this.pool.dataLogger.module.emailKey].index);
		}

		xmlALL_LOG.setAttribute("cloud", this.pool.dataLogger.module.cloud == true ? "1" : "0");

		xmlDATALOG.appendChild(xmlALL_LOG);
	}

	//data logger(customized)
	var xmlCUSTOM_LOG = xmlDoc.createElement("CUSTOM_LOG");
	var counter = 0;
	for(var key in this.pool.dataLogger.customized.logs){
		var log = this.pool.dataLogger.customized.logs[key];
		var xmlC = xmlDoc.createElement("C");

		xmlC.setAttribute("idx", log.index);
		xmlC.setAttribute("name", log.fileName);
		xmlC.setAttribute("content", log.format);
		xmlC.setAttribute("sample_rate", log.sampleRate);
		xmlC.setAttribute("time_format", log.timeStamp);
		xmlC.setAttribute("header_type", log.csvHeader);
		xmlC.setAttribute("header_str", processCSVHeader(log.csvHeader, log.timeStamp, log.format));
		xmlC.setAttribute("upload_period", log.filePeriod);
		xmlC.setAttribute("bom", log.useBOM == true ? "1" : "0");
		xmlC.setAttribute("ftp", processFTPAttribute(log.ftpServers));

		if(typeof(emailManager.pool.emails[log.emailKey]) != "undefined"){
			xmlC.setAttribute("email", emailManager.pool.emails[log.emailKey].index);
		}

		xmlC.setAttribute("nickname", log.name);
		if(log.description != ""){
			xmlC.setAttribute("desc", log.description);
		}

		xmlCUSTOM_LOG.appendChild(xmlC);
		counter++;
	}

	if(counter > 0){
		xmlCUSTOM_LOG.setAttribute("num", counter);
		xmlDATALOG.appendChild(xmlCUSTOM_LOG);
	}

	//data logger(mqtt)
	var mqttManager = WISE.managers.mqttManager;
	if(typeof(mqttManager) != "undefined"){
		var brokerFlag = false;
		var brokers = mqttManager.getBrokers();
		for(var brokerKey in brokers){
			brokerFlag = true;
			break;
		}

		if(this.pool.dataLogger.mqtt.enable == true && brokerFlag == true){
			var xmlMQTT_LOG = xmlDoc.createElement("MQTT_LOG");

			xmlMQTT_LOG.setAttribute("time_format", this.pool.dataLogger.mqtt.timeStamp);
			xmlMQTT_LOG.setAttribute("upload_period", this.pool.dataLogger.mqtt.filePeriod);
			xmlMQTT_LOG.setAttribute("bom", this.pool.dataLogger.mqtt.useBOM == true ? "1" : "0");
			xmlMQTT_LOG.setAttribute("ftp", processFTPAttribute(this.pool.dataLogger.mqtt.ftpServers));

			if(typeof(emailManager.pool.emails[this.pool.dataLogger.mqtt.emailKey]) != "undefined"){
				xmlMQTT_LOG.setAttribute("email", emailManager.pool.emails[this.pool.dataLogger.mqtt.emailKey].index);
			}

			xmlDATALOG.appendChild(xmlMQTT_LOG);
		}
	}

	//event logger
	var xmlEVENTLOG = xmlDoc.createElement("EVENT_LOG");
	xmlEVENTLOG.setAttribute("upload_period", this.pool.eventLogger.uploadFrequency);
	if(this.pool.eventLogger.uploadFrequency > 0){
		xmlEVENTLOG.setAttribute("upload_hour", this.pool.eventLogger.uploadTiming.hour);
		xmlEVENTLOG.setAttribute("upload_minute", this.pool.eventLogger.uploadTiming.minute);

		if(this.pool.eventLogger.uploadFrequency > 1){
			xmlEVENTLOG.setAttribute("upload_day", this.pool.eventLogger.uploadTiming.day);
		}
	}

	xmlEVENTLOG.setAttribute("ftp", processFTPAttribute(this.pool.eventLogger.ftpServers));
	xmlDATALOG.appendChild(xmlEVENTLOG);

	//ftp server
	var xmlFTP = xmlDoc.createElement("FTP");
	var counter = 0;
	for(var key in this.pool.ftp.servers){
		var server = this.pool.ftp.servers[key];

		var xmlF = xmlDoc.createElement("F");
		xmlF.setAttribute("idx", server.index);
		xmlF.setAttribute("url", server.address);
		xmlF.setAttribute("port", server.port);
		xmlF.setAttribute("account", server.account);

		if(server.password.plain == "" || server.password.plain != padding("", server.password.length, "*")){//setup new password
			xmlF.setAttribute("password", server.password.plain);
			xmlF.setAttribute("password_len", server.password.plain.length);
		}
		else{
			xmlF.setAttribute("password", server.password.encoded);
			xmlF.setAttribute("password_len", server.password.length);
		}

		xmlF.setAttribute("path", server.path);

		xmlF.setAttribute("nickname", server.name);
		if(server.description != ""){
			xmlF.setAttribute("desc", server.description);
		}

		xmlFTP.appendChild(xmlF);
		counter++;
	}

	if(counter > 0){
		xmlFTP.setAttribute("num", counter);
		xmlDATALOG.appendChild(xmlFTP);
	}

	for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
		if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
			xmlDoc.documentElement.childNodes[i].appendChild(xmlDATALOG);
			break;
		}
	}
};

WISE.managers.loggerManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.dataLogger.customized.logs){
		this.pool.dataLogger.customized.logs[key].index = ++index;
	}

	index = 0;
	for(var key in this.pool.ftp.servers){
		this.pool.ftp.servers[key].index = ++index;
	}
};