WISE.managers.lineBotManager.decodeXMLObject = function(xmlDoc){
	var maxKey = 0;
    var $xmlLINE_BOT = $(xmlDoc).find("WISE > NOTE > LINE_BOT");

    if($xmlLINE_BOT.length > 0){
		// Message
		var $xmlMESSAGE = $xmlLINE_BOT.find("> MESSAGE");
		if($xmlMESSAGE.length > 0){
			maxKey = 0;

			var $xmlM = $xmlMESSAGE.find("> M");
			for(var i = 0; i < $xmlM.length; i++){
				var key = parseInt($($xmlM[i]).attr("idx"), 10) - 1;
				if(key > maxKey){maxKey = key};

				var message = this.createMessage({
					"name": $($xmlM[i]).attr("nickname"),
					"description": $($xmlM[i]).attr("desc") || "",
					"content": $($xmlM[i]).text()
				});

				this.setMessage(key, message);
			}

			this.pool.messageKey = ++maxKey;
		}

    	// FTP Server
	    var $xmlSENDBOX = $xmlLINE_BOT.find("> SENDBOX");
	    if($xmlSENDBOX.length > 0){
	        var systemManager = WISE.managers.systemManager;

			systemManager.pool.ftpServer.lineBot = {
	            "enable": true,
	            "content": $xmlSENDBOX.text()
			}
	    }

		// IP Camera
		var $xmlCAMERA = $xmlLINE_BOT.find("> CAMERA");
		if($xmlCAMERA.length > 0){
			var moduleManager = WISE.managers.moduleManager;

			var $xmlC = $xmlCAMERA.find("> C");
			for(var i = 0; i < $xmlC.length; i++){
				var moduleIndex = parseInt($($xmlC[i]).attr("camera_idx") - 1);

				var $xmlMSG = $($xmlC[i]).find("> MSG");
				moduleManager.pool.interfaces.camera[0].modules[moduleIndex].lineBot = {
					"enable": true,
					"content": $xmlMSG.text()
				};
			}
		}

    	// CGI Server
		var $xmlCGI_SERVER = $xmlLINE_BOT.find("> CGI_SERVER");
	    if($xmlCGI_SERVER.length > 0){
	        var cgiManager = WISE.managers.cgiManager;

	        var $xmlC = $xmlCGI_SERVER.find("> C");
	        for(var i = 0; i < $xmlC.length; i++){
	            var index = parseInt($($xmlC[i]).attr("idx") - 1);

				var $xmlMSG = $($xmlC[i]).find("> MSG");
	            cgiManager.pool.send.servers[index].lineBot = {
	                "enable": true,
	                "content": $xmlMSG.text()
	            };
	        }
	    }
	}
};