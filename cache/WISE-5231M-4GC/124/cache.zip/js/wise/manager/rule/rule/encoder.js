WISE.managers.ruleManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "ruleStatus"){
			xmlDoc.setAttribute("l_obj", "RULE");
			xmlDoc.setAttribute("l_idx", this.pool.rules[ruleObject.rule.ruleKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "ruleStatus"){
			xmlDoc.setAttribute("l_obj", "RULE");
			xmlDoc.setAttribute("l_idx", this.pool.rules[ruleObject.rule.ruleKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
}

WISE.managers.ruleManager.check = function(){
	if(!this.checkRules()){
		return {
			"hash": "#home/rules",
			"message": "<#Lang['?'].someoneRulesAreError>"
		};
	}

	return null;
};
