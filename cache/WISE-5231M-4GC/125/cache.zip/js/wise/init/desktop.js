function init(){
	//wideScreenMode = getCookie("wideScreenMode") == "true" ? true : false;
	wideScreenMode = screen.width > 1400 ? true : false;
	$("#container").css("width", wideScreenMode == true ? wideScreenContainerWidth + "px" : normalContainerWidth + "px");
	$("#foot").html(copyRight);

	$("#loadingLoader, #loginContainer, #loadingContainer, #loginRunTimeDownContainer").remove();
	$("#container").show();

	$("#topControlBarContainer").css({"display": "", "top": $("#topControlBarContainer").outerHeight(true) * -1}).animate({
		top: 0
	});

	//ajax global setup
	$.ajaxSetup({
		cache: true,
		beforeSend: function(jqXHR, settings){
			if(typeof(debugMode) != "undefined" && debugMode == true){/*check debug mode command*/
				if(/^<\?xml /.test(settings.data) == true){
					settings.data = "!" + (typeof(settings.data) != "undefined" ? settings.data : "");
				}
			}
		},
		success: function(data, textStatus, jqXHR){
			if(this.dataType == "xml"){
				serverNoResponse = false;

				if($(data).children().attr("reply") == "kick" && $(data).children().attr("key") == WISE.getUser().key){
					if(typeof(aliveChecker) != "undefined"){//avoid receive kick when first to load rule file failed, because aliveChecker is not ready to go
						aliveChecker.stopAliveTimer();
						aliveChecker.stopIdleTimer();

						disableHash(true);
						$("#idleMessage").show(0, function(){
							$("#idleLoginPassword").focus();
						});
					}

					this.error(jqXHR, "keyerror", "Key Error");
					return;
				}
			}

			if(typeof(this.done) == "function"){
				this.done(data, textStatus, jqXHR);
			}
		},
		done: function(){},
		error: function(jqXHR, textStatus, errorThrown){
			if(jqXHR.status == 500 || (jqXHR.status == 0 && (textStatus == "timeout" || textStatus == "error"))){
				if(typeof(serverNoResponse) == "undefined" || serverNoResponse == false){
					//$(".fixedDiv").hide();//hide all popup message
					insertMessage(LangLogin.runtimeServerNoResponse[WISE.language], 1);
					popupErrorWindow(LangLogin.runtimeServerNoResponse[WISE.language]);
				}

				serverNoResponse = true;
				//return;
			}
			else if(jqXHR.status == 404){
				popupErrorWindow(LangLogin.fileNotFound[WISE.language]);
			}

			if(typeof(this.fail) == "function"){
				this.fail(jqXHR, textStatus, errorThrown);
			}
		},
		fail: function(){}
	});

	/*WISE name*/
	updateWISEName = function(name){//is global
		$("#wiseNamePrevious").text(name);
		$("#wiseNameText").trigger("blur", [false]);
	};

	$("#wiseNamePrevious").text(WISE.$.name);
	$("#wiseNameText").hover(
		function(){
			if(!$(this).hasClass("active")){
				$(this).addClass("hover");
				$("#wiseNameLabel").show();
			}
		},
		function(){
			if(!$(this).hasClass("active")){
				$(this).removeClass("hover");
				$("#wiseNameLabel").hide();
			}
		}
	).bind("click", function(){
		if(!$(this).hasClass("active")){
			$(this).css({"textAlign": "left"}).addClass("active").select().animate({
				"width": "180px"
			}, "fast");
			$("#wiseNameSaveButton, #wiseNameLabel").show();
		}
	}).bind("blur", function(event, save, duration){
		if(save != true){
			$(this).val($("#wiseNamePrevious").text());
		}
		else{
			if($(this).val() == ""){
				$(this).val(WISE.$.modelName);
			}

			var wiseName = $(this).val();
			WISE.$.name = wiseName;
			$("#wiseNamePrevious").text(wiseName);
		}

		$(this).animate({
			"width": $("#wiseNamePrevious").innerWidth() + "px"
		}, typeof(duration) == "undefined" ? "fast" : duration);
		$(this).removeClass("active hover");
		$("#wiseNameSaveButton, #wiseNameLabel").hide();
	}).bind("keydown", function(event){
		if(event.which == 13){//ENTER
			$(this).trigger("blur", [true]);
		}
		else if(event.which == 27){//ESC
			$(this).trigger("blur", [false]);
		}
	}).trigger("blur", [false, 0]);

	$("#wiseNameSaveButton").bind("mousedown", function(event){
		$("#wiseNameText").trigger("blur", [true]);
	});

	WISE.bind("afterParse", function(){
		updateWISEName(WISE.$.name);
	}, "updateWISEName");

	if(WISE.getUser().character == "guest"){
		$("#wiseNameText").attr("disabled", true).css("cursor", "auto");
	}

	$("#topControlBar div").hover(
		function(){
			$(this).addClass("hover");
		},
		function(){
			$(this).removeClass("hover");
		}
	);

	$("#topControlBarNew").bind("click", function(){
		var confirmClearAllSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToClearAllSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!clear");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmClearAllSetting();
				//}
			});
		}
		else{
			confirmClearAllSetting();
		}
	});

	$("#topControlBarLoad").bind("click", function(){
		var confirmLoadSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLoadSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!load");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmLoadSetting();
				//}
			});
		}
		else{
			confirmLoadSetting();
		}
	});

	$("#topControlBarSave").bind("click", function(){
		var confirmSaveSetting = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToSaveSetting>", function(result){
				if(result == false){return;}

				redirectTo("#home!save");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmSaveSetting();
				//}
			});
		}
		else{
			confirmSaveSetting();
		}
	});

	$("#topControlBarLogout").bind("click", function(){
		var confirmLogout = function(){
			popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLogout>", function(result){
				if(result == false){return;}

				redirectTo("#home!logout");
			});
		};

		if(typeof(is_editing) != "undefined" && is_editing == true){
			popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
				//if(result == true){
				//	confirmLogout();
				//}
			});
		}
		else{
			confirmLogout();
		}
	});

	$("#logo, #logoTiny").bind("click", function(event){
		if(event.ctrlKey == true && event.altKey == true){
			redirectTo("#debug");
		}
		else{
			redirectTo("#home/main");
			$("#navigation li").removeClass("active");
		}
	});

	$("#infoBarBatteryStatus").hover(
		function(){
			$(this).find(".iconsRule, #infoBarBatteryStatusText").addClass("hover");
		},
		function(){
			$(this).find(".iconsRule, #infoBarBatteryStatusText").removeClass("hover");
		}
	);

	$("#infoBarSDFreeSpace").hover(
		function(){
			$(this).find(".iconsRule, #infoBarSDFreeSpaceText").addClass("hover");
		},
		function(){
			$(this).find(".iconsRule, #infoBarSDFreeSpaceText").removeClass("hover");
		}
	);

	$("#infoBarMessage").bind("click", function(event){
		$(document).unbind("click.infoBar");

		if($(this).hasClass("active")){
			$(this).removeClass("active");
			$("#infoBarDetailMessage").hide();
		}
		else{
			$(this).addClass("active").trigger("mouseenter");

			if($.browser.msie && parseInt($.browser.version, 10) <= 8){//IE8 fixed
				$("#infoBarDetailMessage").show();
			}
			else{
				$("#infoBarDetailMessage").fadeIn("fast");
			}

			$(document).bind("click.infoBar", function(event){
				$(document).unbind("click.infoBar");
				$("#infoBarMessage").triggerHandler("click");
				$("#infoBarMessage").trigger("mouseleave");
			});
		}

		event.stopPropagation();
	}).hover(
		function(){
			$(this).find(".iconsRule, .infoBarMessageText").addClass("hover");
		},
		function(){
			if($(this).hasClass("active")){return;}

			$(this).find(".iconsRule, .infoBarMessageText").removeClass("hover");
		}
	).disableSelection();

	$("#infoBarDetailMessage").bind("click", function(event){
		event.stopPropagation();
	});

	/*insert login message to status bar*/
	insertMessage("<#Lang['?'].loginSuccessfully>", 0, 0);
	insertMessage("<#Lang['?'].instantMessage>", 0, 2);

	/*browser compatibility process*/
	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$("#topControlBar, #infoBarDetailMessageTitleDummy1Content, #infoBarDetailMessageTitleDummy2Content, #infoBarDetailMessageContent").unwrap();
	}

	if($.browser.mozilla || $.browser.opera) {
		$("body").css("overflowY", "scroll");
	}
	else{
		$("html").css("overflowY", "scroll");
	}
	//$("html").css("overflowY", "scroll");

	if($.browser.webkit){//since chrome version 39, chinese line-height not same with english.
		$("body").css("lineHeight", "1.15");
	}

	if(WISE.getUser().character == "user"){
		$("#topControlBar > #topControlBarNew").hide();
	}
	else if(WISE.getUser().character == "guest"){
		$("#topControlBar > *:not(#topControlBarLogout)").hide();
	}

	/*AccessPermission Comment Command*/
/*
	addCommentCommand("AccessPermission", function(args){
		for(var i = 0; i < args.length; i++){
			if(WISE.getUser().character == args[i]){
				return true;
			}
		}

		redirectTo("#home", true);
		return false;
	});
*/

	/*idle check*/
	$("#idleLoginPassword").keypress(function(event){
		if(event.which == 13){
			$("#idleLoginButton").click();
		}
	});

	$("#idleLoginButton").bind("click", function(){
		var disableInput = function(disable){
			if(disable == false){
				$("#idleLoginLoader").css("visibility", "hidden");
				$("#idleLoginPassword, #idleLoginButton").attr("disabled", false);
			}
			else{
				$("#idleLoginLoader").css("visibility", "visible");
				$("#idleLoginPassword, #idleLoginButton").attr("disabled", true);
			}
		};

		var xmlDoc = $.parseXML("<LOGIN/>");
		xmlDoc.documentElement.setAttribute("pw", $("#idleLoginPassword").val());

		if(WISE.getUser().character == "user"){
			xmlDoc.documentElement.setAttribute("idx", WISE.getUser().userIndex + 1);
		}

		$("#idleLoginStatus").empty();
		disableInput(true);

		$.ajax({ 
			//url: "./dll/xml/login.xml",
			url: "./dll/wise.dll",
			type: "POST",
			data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
			contentType: "text/xml",
			processData: false,
			cache: false,
			dataType: "xml",
			done: function(xmlDoc){
				var $xmlLOGIN = $(xmlDoc).find("LOGIN");
				var reply = $xmlLOGIN.attr("reply");

				if(reply == "admin" || reply == "deputy" || reply == "guest"){
					if(reply == "deputy"){reply = "user";}

					if(reply == WISE.getUser().character){
						WISE.setUser(reply, $xmlLOGIN.attr("key"), {
							"idleTime": $xmlLOGIN.attr("keepalive"),
							"userIndex": parseInt($xmlLOGIN.attr("idx") || 0, 10) - 1,
							"permission": $xmlLOGIN.attr("function")
						});
						aliveChecker.startAliveTimer();
						aliveChecker.startIdleTimer();

						$("#idleLoginPassword").val("");
						$("#idleLoginStatus").empty();

						if(WISE.getUser().character == "user" || WISE.getUser().character == "guest"){//reload rule file, maybe it change by admin
							WISE.loadRuleFile({
								error: function(){
									WISE.resetWISE();
									updateWISEName(WISE.$.name);
								},
								complete: function(){
									disableInput(false);
									disableHash(false);
									$("#idleMessage").hide();

									redirectTo("#home/main");
								}
							});
						}
						else{
							disableInput(false);
							disableHash(false);
							$("#idleMessage").hide();

							if(typeof(afterLoginMenu) == "function"){afterLoginMenu();}
							if(typeof(afterLoginContent) == "function"){afterLoginContent();}
						}
					}
					else{
						var xmlDoc = $.parseXML("<LOGOUT/>");

						xmlDoc.documentElement.setAttribute("key", $xmlLOGIN.attr("key"));

						$.ajax({ 
							url: "./dll/wise.dll",
							type: "POST",
							data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
							contentType: "text/xml",
							processData: false,
							cache: false,
							dataType: "xml"
						});

						$("#idleLoginPassword").val("");
						$("#idleLoginStatus").text("<#Lang['?'].passwordIncorrect>");
						disableInput(false);
					}
				}
				else if(reply == "occupied" || reply == "full"){
					$("#idleLoginStatus").text("<#Lang['?'].reachMaximumNumberOfLoginUser>");
					disableInput(false);
				}
				else{
					$("#idleLoginPassword").val("");
					$("#idleLoginStatus").text("<#Lang['?'].passwordIncorrect>");
					disableInput(false);
				}
			}
		});
	});

	aliveChecker = WISE.createAliveChecker({
		"process": function($xmlALIVE){
			var freeSpace = parseFloat($xmlALIVE.attr("microsd"));
			if(!isNaN(freeSpace)){
				if(freeSpace >= 0){
					$("#infoBarSDFreeSpaceText").text(toFixed(freeSpace, 1) + "MB" + ($xmlALIVE.attr("log_day") ? "(" + "<#Lang['?'].approxXDays>".replace("$day", toFixed(parseFloat($xmlALIVE.attr("log_day")), 0)) + ")" : ""));
				}
				else{
					$("#infoBarSDFreeSpaceText").text("<#Lang['?'].noSDCard>");
					insertMessage("<#Lang['?'].noSDCard>")
				}
			}

			if($xmlALIVE.attr("ftp") == "0"){
				insertMessage("<#Lang['?'].ftpUploadFailed>")
			}

			$xmlM7000 = $xmlALIVE.find("> M7000");
			for(var i = 0; i < $xmlM7000.length; i++){
				if($($xmlM7000[i]).attr("init") == "-1"){
					insertMessage("<#Lang['?'].initModuleFailed>".replace("$moduleName", $($xmlM7000[i]).attr("name")).replace("$address", $($xmlM7000[i]).attr("address")), 1);
				}
			}

			$("#infoBarBatteryStatus .iconsRule").removeClass("batteryOK batteryFailed");
			if($xmlALIVE.attr("battery") == "1"){
				$("#infoBarBatteryStatusText").text("<#Lang['?'].ok>");
				$("#infoBarBatteryStatus .iconsRule").addClass("batteryOK");
			}
			else{
				$("#infoBarBatteryStatusText").text("<#Lang['?'].dead>");
				$("#infoBarBatteryStatus .iconsRule").addClass("batteryFailed");
			}
		},
		"timeout": function(){
			//show password input filed
			disableHash(true);
			$("#idleMessage").show(0, function(){
				$("#idleLoginPassword").focus();
			});
		}
	});

	$("*[tip]").livequery(
		function(){
			$(this).hover(
				function(){
					var that = this;
					$(this).attr(
						"pid",
						setTimeout(function(){
							$(that).showTip({"tip": $(that).attr("tip"), "position": $(that).attr("tip_position") ? $(that).attr("tip_position") : "top", "color": $(that).attr("tip_color") ? $(that).attr("tip_color") : "black"});
						}, 100)
					);
				},
				function(){
					clearTimeout($(this).attr("pid"));
					$(this).hideTip();
				}
			)
		},
		function(){
			clearTimeout($(this).attr("pid"));
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$("input[limit], input[range]").livequery(
		function(){
			$(this).unbind(".validation");

			$(this).bind("focus.validation", function(event){
				$(this).attr("valued", $(this).val());
				$(this).attr("valuep", $(this).val());
			});

			$(this).bind("keyup.validation", function(event){
				if(typeof($(this).attr("range")) != "undefined"){
					if($(this).attr("validation")){return;}

					if($(this).val() != "" && $(this).attr("valuep") != $(this).val()){
						var range = $(this).triggerHandler("getRange");
						var message = null;

						if(range.min != null && range.max != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsBetweenAToB>".replace("$minimum", range.min).replace("$maximum", range.max);
						}
						else if(range.min != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsGreaterEqualX>".replace("$minimum", range.min);
						}
						else if(range.max != null){
							message = "<#Lang['?'].tip.thisFieldRangeIsLessEqualX>".replace("$maximum", range.max);
						}

						var value = Number($(this).val());
						if(isNaN(value)){value = 0;}
						if((range.min != null && value < range.min) || (range.max != null && value > range.max)){
							$(this).showTip({"tip": message, "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeyup").bind("blur.validationKeyup", function(){
								$(this).hideTip();
							});
						}
						else{
							$(this).hideTip();
						}
					}

					$(this).attr("valuep", $(this).val());
				}
			});

			$(this).bind("keypress.validation", function(event){
				if(event.which == 0 || event.which == 8 || event.which == 13){return;}//skip enter(13), backspace(8) and special key link F1..etc

				if($(this).attr("limit") == "int"){
					if(!(/[\d+-]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputInteger>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if($(this).attr("limit") == "float"){
					if(!(/[\d+-.Ee]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputIntegerOrFloatingPoint>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if($(this).attr("limit") == "hex"){
					if(!(/[0-9A-Fa-f]/.test(String.fromCharCode(event.which)))){
						$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldOnlyAllowInputHEX>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
							$(this).hideTip();
						}).attr("validation", "failed");
						event.preventDefault();
					}
					else{
						$(this).hideTip().removeAttr("validation");
					}
				}
				else if(typeof($(this).attr("limit")) != "undefined"){
					var limit = $(this).attr("limit");
					var from = limit.indexOf("["), to = limit.lastIndexOf("]");

					if(from != -1 && to != -1){
						var regex = new RegExp("[" + $(this).attr("limit").substring(from + 1, to) + "]", "g");

						if(!(regex.test(String.fromCharCode(event.which)))){
							$(this).showTip({"tip": "<#Lang['?'].tip.thisFieldNotAllowInputThisChar>", "position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"), "color": "red"}).unbind("blur.validationKeypress").bind("blur.validationKeypress", function(){
								$(this).hideTip();
							}).attr("validation", "failed");
							event.preventDefault();
						}
						else{
							$(this).hideTip().removeAttr("validation");
						}
					}
				}
			});

			$(this).bind("correctRange.validation", function(){
				if($(this).attr("limit") == "int" || $(this).attr("limit") == "float"){
					if($(this).val() == "" || isNaN($(this).val()) || !isFinite($(this).val())){//not number or is infinite
						if(typeof($(this).attr("default")) != "undefined"){
							$(this).val($(this).attr("default"));
						}
						else if(!isNaN($(this).attr("valued"))){
							$(this).val($(this).attr("valued"));
						}
						else{
							$(this).val("0");
						}
					}
					else{//no error, just format the number
						$(this).val(Number($(this).val()));
					}

					//maybe value not match the type
					if($(this).attr("limit") == "int"){
						$(this).val(parseInt($(this).val(), 10));
					}
					else if($(this).attr("limit") == "float"){
						$(this).val(parseFloat($(this).val()));
					}
				}
				else if($(this).attr("limit") == "hex"){
					if(!(/[0-9A-Fa-f]/g.test($(this).val()))){
						$(this).val(typeof($(this).attr("default")) != "undefined" ? $(this).attr("default") : "0");
					}
					else{//no error, just padding zero
						var maxLength = Number($(this).attr("maxlength"));
						if(!isNaN(maxLength)){
							var zeroArray = new Array(maxLength);
							for(var i = 0; i < zeroArray.length; i++){
								zeroArray[i] = "0";
							}
							$(this).val(zeroArray.join("").substring(0, maxLength - $(this).val().length) + $(this).val().toUpperCase());
						}
					}
				}
				else if(typeof($(this).attr("limit")) != "undefined"){
					var limit = $(this).attr("limit");
					var from = limit.indexOf("["), to = limit.lastIndexOf("]");

					if(from != -1 && to != -1){
						var notSign = "^";
						if($(this).attr("limit").charAt(from + 1) == "^"){
							notSign = "";
							from++;
						}

						var regex = new RegExp("[" + notSign + $(this).attr("limit").substring(from + 1, to) + "]", "g");
						var value = $(this).val().replace(regex, "");

						$(this).val(value == "" && typeof($(this).attr("default")) != "undefined" ? $(this).attr("default") : value);
					}
				}
			});

			$(this).bind("getRange.validation", function(){
				if(typeof($(this).attr("range")) != "undefined"){
					var min = null, max = null;
					var splitArray = $(this).attr("range").replace(/ /g, "").split("~");

					if(splitArray.length == 2){
						if(splitArray[0] != "" && !isNaN(min)){
							min = Number(splitArray[0]);
						}
						if(splitArray[1] != "" && !isNaN(max)){
							max = Number(splitArray[1]);
						}

						if(min != null && max != null && min > max){
							var temp = min;
							min = max;
							max = temp;
						}
					}

					return {"min": min, "max": max};
				}
			});

			$(this).bind("correctRange.validation", function(event){
				if(typeof($(this).attr("range")) != "undefined"){
					var range = $(this).triggerHandler("getRange");
					var value = Number($(this).val());
					if(isNaN(value)){value = 0;}

					if(range.min != null && value < range.min){
						$(this).val(range.min);
					}
					else if(range.max != null && value > range.max){
						$(this).val(range.max);
					}
					else{
						//$(this).val(value);
					}
				}
			});

			$(this).bindFirst("blur.validation", function(){
				if($(this).attr("require") == "false" && $(this).val() == ""){return;}

				$(this).triggerHandler("correctRange");
			});
		},
		function(){
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$("input[length], textarea[length]").livequery(
		function(){
			$(this).unbind(".length");

			$(this).bindFirst("keyup.length", function(){
				if($(this).attr("validation")){return;}

				var length = parseInt($(this).attr("length"), 10);
				if(isNaN(length)){return;}

				if(wordCount($(this).val()) > length){
					$(this).showTip({
						"tip": "<#Lang['?'].tip.thisFieldContainsTooManyChar>",
						"position": ($(this).attr("tip_position") ? $(this).attr("tip_position") : "right"),
						"color": "red"
					}).unbind("blur.length").bindFirst("blur.length", function(){
						var length = parseInt($(this).attr("length"), 10);
						if(isNaN(length)){return;}

						$(this).val($(this).val().substr(0, wordCut($(this).val(), parseInt($(this).attr("length"), 10))));
						$(this).hideTip();
					});
				}
				else{
					$(this).hideTip();
				}
			});
		},
		function(){
			$("#" + $(this).attr("tip_id")).remove();
		}
	);

	$.fn.checkInput = function(autoCorrect){
		return this.each(function(){
			if($(this).attr("limit") || $(this).attr("range")){
				$(this).triggerHandler("blur");
			}
			return $(this);
		});
	};

	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$(window).bind('scroll', {"originalTop": $('#infoBar').offset().top - 30}, function(event){
		    var $infoBar = $('#infoBar');
		    if($(window).scrollTop() > $infoBar.offset().top - 30){
				$infoBar.css({"position": "fixed", "left": "50%", "top": "30px", "bottom": "auto", "right": "auto", "marginLeft": ($("#container").width() / 2 - $infoBar.width()) + "px"});
				//$("#topBar").show().css({"top": (-1 * $("#topBar").outerHeight(true)) + "px", "opacity": 0}).animate({"top": 0, "opacity": 1});
				//has problem
				$("#topBarLogo").css({"marginLeft": ($("#container").width() / 2 * -1) + "px"});
				$("#topBar").fadeIn("fast");
		    }
			else{
				if($(window).scrollTop() <= event.data.originalTop){
					$infoBar.css({"position": "", "left": "", "top": "", "bottom": "", "right": "", "marginLeft": ""});
					//$("#topBar").animate({"top": (-1 * $("#topBar").outerHeight(true)) + "px", "opacity": 0}, function(){
					//	$(this).hide();
					//});
					//has problem
					$("#topBar").fadeOut("fast");
				}
			}
		});
	}

	$.ajax({
		url: "html/desktop" + "/" + currentLevel[0] + "/" + "menu.htm" + "?" + cacheString,
		type: "GET",
		dataType: "html",
		success: function(htmlString){
			if(processCommentCommand(htmlString) == false){return;}

			$("#topMenu").html(processLanguage(htmlString, this.url.split("?")[0]));
			processNavigationItem($("#navigation li"));

			/*Hash init*/
			$.history.init(function(hash) {
				if(hash != "" && previousHash.replace(/\+.+?\//g, "/") == hash.replace(/\+.+?\//g, "/")){
					//no change, nothing to do
				}
				else if(hashDisable == true || (typeof(is_editing) != "undefined" && is_editing == true)){//is_editing is defined in hmi.htm
					if(hash != redirectHash){//prevent loop redirect
						redirectHash = previousHash;
						redirectTo("#" + previousHash);
					}

					if(typeof(is_editing) != "undefined" && is_editing == true){//for HMI
						popupAlarmWindow("<#Lang['?'].popup.exitEditModeFirst>", function(result){
							//correctionTitle();//inside hmi.htm
						});
					}
				}
				else{
					hashHandler(hash == "" ? "home" : hash);
				}

				previousHash = hash;
			}, {"unescape": true});
		}
	});
}

/*
	insertMode = undefined or 0(normal insert)
	insertMode = 1(only insert to content)
	insertMode = 2(only insert to title)
*/
function insertMessage(message, level, insertMode){
	level = {0: "informationBalloon", 1: "exclamationSign"}[level || 0];

	if(insertMode != 1){
		$("#infoBarMessageWidth").html(message);
		$("#infoBarMessageIcon").attr("class", "iconsRule " + level + (function(){
			if($("#infoBarMessage").hasClass("active")){
				return " hover";
			}

			return "";
		})());

		if($("#infoBarMessageWidth").innerWidth() + 1 > parseInt($(".infoBarMessageText").css("maxWidth"), 10)){
			$(".infoBarMessageText").css({"textOverflow": "ellipsis"});
		}
		else{
			$(".infoBarMessageText").css({"textOverflow": ""});
		}

		$(".infoBarMessageText").html(message).stop().animate({
			"width": ($("#infoBarMessageWidth").innerWidth() + 1) + "px"
		}, "fast");
	}

	if(insertMode != 2){
		var date = new Date();
		var $row = $("<tr></tr>").append(
			$("<td></td>").text(padding(date.getHours(), 2) + ":" + padding(date.getMinutes(), 2) + ":" + padding(date.getSeconds(), 2))
		).append(
			$("<td></td>").css({"paddingTop": "2px", "paddingBottom": "2px", "lineHeight": "19px"}).append(
				$("<span></span>").attr("class", "iconsRule hover " + level).css("float", "left")
			).append(message)
		);

		var $firstRow = $("#infoBarDetailMessageTable tr:first");

		if($firstRow.hasClass("even")){
			$row.addClass("odd");
		}
		else{
			$row.addClass("even");
		}

		$row.prependTo("#infoBarDetailMessageTable");
		$("#infoBarDetailMessageTable tr:gt(9)").remove();
	}
}

function toggleWidth(){
	if(wideScreenMode == false){
		var containerWidth = wideScreenContainerWidth;
		$("#container").animate({"width": containerWidth + "px"})
		$("#right").animate({"width": ($("#right").width() + (wideScreenContainerWidth - normalContainerWidth)) + "px"})
		wideScreenMode = true;
	}
	else{
		var containerWidth = normalContainerWidth;
		$("#container").animate({"width": containerWidth + "px"})
		$("#right").animate({"width": ($("#right").width() - (wideScreenContainerWidth - normalContainerWidth)) + "px"})
		wideScreenMode = false;
	}
	setCookie("wideScreenMode", wideScreenMode);

	if($.browser.msie && parseInt($.browser.version, 10) <= 8){
	}
	else{
		$('#infoBar').animate({"marginLeft": (containerWidth / 2 - $('#infoBar').width()) + "px"});
		$("#topBarLogo").animate({"marginLeft": (containerWidth / 2 * -1) + "px"});
	}
}

//function guideline(){
//	$.guideLine("#navigation_list li[location='#home/system']", {"eventType": "click", "spotLight": {"reset": true, "innerDimension": true, "text":"test1234567890"}})
//	.guideLine("#navigation_2nd li[location='#home/system/interface']", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#remoteIOTab div.comport_2", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#comport_2 select.protocol", {
//		"eventType": "change",
//		"handler": function(){
//			if($(this).val() == "modbusRTU"){
//				return true;
//			}
//			else{
//				return false;
//			}
//		},
//		"spotLight": {"text":"test1234567890"}
//	})
//	.guideLine("#saveButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#popupOKButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#navigation_list li[location='#home/module']", {"eventType": "click", "spotLight": {"innerDimension": true, "text":"test1234567890"}})
//	.guideLine("#navigation_2nd li[location='#home/module/powermeter']", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#remoteIOTab div.comport_2", {"eventType": "click", "delay": true, "spotLight": {"text":"test1234567890"}})
//	.guideLine("#modbusRTUShowAllModuleButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("body>ul.ui-autocomplete:first>li:last", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#modbusRTUModuleListHandler div.icon.add", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#saveButton", {"eventType": "click", "spotLight": {"text":"test1234567890"}})
//	.guideLine("#popupOKButton", {
//		"eventType": "click",
//		"handler": function(){
//			$.spotLight("hide");
//		},
//		"spotLight": {"text":"test1234567890"}
//	})
//	.guideLine.start({
//		"spotLight": {
//			"close": function(){
//				$("#rightContent").unbind("resize.guideLine");
//				$.guideLine.stop();
//			}
//		}
//	});
//
//	$("#rightContent").resize(function(event){
//		$(window).resize();
//		event.stopPropagation();
//	});
//}

function showDownloadNotify(callback){
	if(getCookie("downloadNotify") != null){
		if(typeof(callback) == "function"){
			callback();
		}

		return;
	}

	disableHash(true);
	$("[id^=downloadNotify]").remove();
	$("html, body").scrollTop(0);

	// Create element
	$.each(["Top", "Bottom", "Right", "Left"], function(index, value){
		$("<div></div>").css({
			"position": "absolute",
			"opacity": 0.3,
			"backgroundColor": "#000",
			"zIndex": "1100"
		}).attr("id", "downloadNotify" + value).appendTo("body");
	});

	$("<div></div>").css({
		"position": "absolute",
		"zIndex": "1101",
		"border": "3px solid #666666",
		"boxSizing": "border-box"
	}).attr("id", "downloadNotifyBorder").appendTo("body");

	$("<div></div>").attr({"class": "spotLight", "id": "downloadNotifyTip"}).append(
		$("<div></div>").attr("class", "textLayer").css({
			"fontSize": "15px",
			"padding": "10px",
			"boxShadow": "rgba(0, 0, 0, 0.298039) 0px 1px 2px 2px"
		}).append(
			$("<div></div>").attr("class", "text").text("<#Lang['?'].tip.clickDownloadAfterCompleteAllSetting>")
		).append(
			$("<div></div>").css({
				"margin": "9px 0 3px 0",
				"textAlign": "center"
			}).append(
				$("<span></span>").attr("class", "spotLightButton").css({
					"position": "relative",
					"padding": "2px 8px"
				}).text("<#Lang['?'].close>").bind("click", function(){
					setCookie("downloadNotify", true, 525600);
					disableHash(false);
					$("[id^=downloadNotify]").remove();
					$(window).unbind("resize.downloadNotify");

					if(typeof(callback) == "function"){
						callback();
					}
				}).bind("mousedown", function(){
					$(this).css("top", "1px");
				}).bind("mouseup mouseleave", function(){
					$(this).css("top", "0px");
				})
			)
		).append(
			$("<div></div>").css("marginLeft", "94px").attr("class", "spotLightIcon bottom")
		)
	).appendTo("body");

	// Init position
	$("#downloadNotifyTop").css({
		"top": 0,
		"left": 0,
		"width": "100%",
		"height": $("html, body").scrollTop() + "px"
	});

	$("#downloadNotifyBottom").css({
		"top": $("html, body").scrollTop() + $(window).height() + "px",
		"left": 0,
		"width": "100%",
		"height": Math.max($(window).height(), $("body").height()) - ($("html, body").scrollTop() + $(window).height()) + "px"
	});

	$("#downloadNotifyLeft").css({
		"top": $("html, body").scrollTop() + "px",
		"left": 0,
		"width": 0,
		"height": $(window).height() + "px"
	});

	$("#downloadNotifyRight").css({
		"top": $("html, body").scrollTop() + "px",
		"left": $(window).width() + "px",
		"width": 0,
		"height": $(window).height() + "px"
	});

	$("#downloadNotifyBorder").css({
		"top": $("html, body").scrollTop() + "px",
		"left": 0,
		"width": $(window).width() + "px",
		"height": $(window).height() + "px",
    	"borderRadius": "3px"
	});

	// Adjust position
	var adjustDownloadNotify = function(resize){
		var $target = $("#topControlBarSave");
		var top = $target.offset().top,
			left = $target.offset().left,
			width = $target.innerWidth(),
			height = $target.innerHeight();

		$.when(
			$("#downloadNotifyTop").stop().animate({
				"top": 0,
				"left": 0,
				"width": "100%",
				"height": top + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyBottom").stop().animate({
				"top": top + height + "px",
				"left": 0,
				"width": "100%",
				"height": Math.max($(window).height(), $("body").height()) - (top + height) + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyLeft").stop().animate({
				"top": top + "px",
				"left": 0,
				"width": left + "px",
				"height": height + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyRight").stop().animate({
				"top": top + "px",
				"left": left + width + "px",
				"width": $(window).width() - (left + width) + "px",
				"height": height + "px"
			}, !resize ? 600 : 0),
			$("#downloadNotifyBorder").stop().animate({
				"top": (top - 3) + "px",
				"left": (left - 3) + "px",
				"width": (width + 6) + "px",
				"height": (height + 6) + "px"
			}, !resize ? 600 : 0)
		).then(function(){
			$("#downloadNotifyTip").css({
				"top": (top + height) + "px",
				"left": ((left + (width - $("#downloadNotifyTip").outerWidth()) / 2) - 100) + "px"
			}).fadeIn(!resize ? 400 : 0);
		});
	};
	
	adjustDownloadNotify(false);

	$(window).unbind("resize.downloadNotify").bind("resize.downloadNotify", function(){
		adjustDownloadNotify(true);
	});
}

function startBreathingDownloadButton(){
	$("#topControlBarSave").attr({
		"tip_color": "yellow",
		"tip": "<#Lang['?'].tip.settingNotDownloadToController>"
	}).css({
		"backgroundColor": "rgba(246, 206, 124, 0)",
		"color": "rgba(246, 206, 124, 0)",
		"boxShadow": "0px 0px 10px 3px",
		"borderRadius": "30%"
	}).find("div").show().find("img").css({
		"animationName": "exclame",
    	"animationDuration": "500ms"
	});

	window.onbeforeunload = function() {
	    return "<#Lang['?'].tip.settingNotDownloadToController>";
	};

	breathingDownloadButton();
}

function breathingDownloadButton(){
	$("#topControlBarSave").animate({
		"backgroundColor": "rgba(246, 206, 124, 1)",
		"color": "rgba(246, 206, 124, 1)",
	}, 1500, "swing").animate({
		"backgroundColor": "rgba(246, 206, 124, 0.5)",
		"color": "rgba(246, 206, 124, 0.5)",
	}, 1500, "swing", breathingDownloadButton);
}

function stopBreathingDownloadButton(){
	$("#topControlBarSave").stop(true).attr({
		"tip": "<#Lang['html/desktop/frame.htm'].saveRule>",
		"tip_color": "black"
	}).css({
		"backgroundColor": "",
		"color": "",
		"boxShadow": "",
		"borderRadius": ""
	}).find("div").hide();

	window.onbeforeunload = null;
}

function stickyControlButton(handlerID, listID){
	var $handler = $("#" + handlerID);
	var $list = $("#" + listID);
	var $stickyBar = $handler.find(".stickyBar");

	if($list.is(":visible") != true){return}

	if($(window).height() + $(window).scrollTop() > $list.offset().top && $(window).height() + $(window).scrollTop() < $handler.offset().top + 45){
		if(!$stickyBar.hasClass("flow")){
			$stickyBar.addClass("flow");

			if($stickyBar.attr("from") == "top"){
				$stickyBar.stop().css("bottom", "-56px").animate({
					"bottom": "-16px"
				}, "fast");
			}
		}
	}
	else{
		if($(window).height() + $(window).scrollTop() < $handler.offset().top + 45){
			$stickyBar.attr("from", "top");
			if($stickyBar.hasClass("flow") && !$stickyBar.attr("run")){
				$stickyBar.stop().attr("run", true).animate({
					"bottom": "-56px"
				}, "fast", function(){
					$(this).removeClass("flow").removeAttr("run");
				});
			}
		}
		else{
			$stickyBar.attr("from", "bottom");
			$stickyBar.stop().removeClass("flow").css("bottom", "");
		}
	}
}


/*
parameter[0] == 0 => Internal Register
parameter[0] == 1 => I/O Module, need pass sourceType, sourceIndex, moduleIndex at parameter[1], parameter[2] and parameter[3]
parameter[0] == 2 => Customized Channel Status Page, need pass statusPageKey at parameter[1]
*/
function generateStatus(parameter, timer, callbackFunction){
	var typeNamePool = {
		"DI": "DI$channel",
		"DIC": "<#Lang['?'].diCounterX>",
		"DO": "DO$channel",
		"DOC": "<#Lang['?'].doCounterX>",
		"AI": "AI$channel",
		"AO": "AO$channel",
		"CI": "Discrete Input $channel",
		"CO": "Coil Output $channel",
		"RI": "Input Register $channel",
		"RO": "Holding Register $channel",
		"IR": "<#Lang['?'].internalRegisterX>"
	};

	timer.stop();
	$("#statusBlockContainer").empty();

	if(parameter[0] == "0"){
		var registerManager = WISE.managers.registerManager;
		var registerExist = false;

		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registers.length; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}

			registerExist = true;
			break;
		}

		if(registerExist == false){
			redirectTo("#home/status", true);
		}
		else{
			createRegisterStatus();
			updateStatus = updateMoudleStatus;
		}
	}
	else if(parameter[0] == "1"){
		var moduleManager = WISE.managers.moduleManager;
		var sourceType = parameter[1];
		var sourceIndex = parseInt(parameter[2], 10);
		var moduleIndex = parseInt(parameter[3], 10);

		try{
			var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
		}
		catch(error){
			var module = null;
		}
		finally{
			if(module == null){
				redirectTo("#home/status", true);
			}
			else{
				createModuleStatus();
				updateStatus = updateMoudleStatus;
			}
		}
	}
	else if(parameter[0] == "2"){
		var statusManager = WISE.managers.statusManager;
		var statusPageKey = parseInt(parameter[1], 10);

		try{
			var statusPage = statusManager.pool.statusPages[statusPageKey];
		}
		catch(error){
			var statusPage = null;
		}
		finally{
			if(statusPage == null){
				redirectTo("#home/status", true);
			}
			else{
				var registerManager = WISE.managers.registerManager;
				var moduleManager = WISE.managers.moduleManager;

				createCustomizeStatus();
				updateStatus = updateCustomizeStatus;
			}
		}
	}

	if($("#statusBlockContainer").children().length == 0){
		$("<div></div>").addClass("statusNone").css({
			"padding": "40px 0"
		}).html("<#Lang['?'].none>").appendTo($("#statusBlockContainer"));
	}

	timer.process = function(timer){
		updateStatus(timer);
	};
	timer.start();

	function createRegisterStatus(){
		var $blockIRContainer = $("<div></div>").attr("id", "statusBlockIRContainer");

		for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registerManager.maxAmount; registerIndex++){
			if(typeof(registers[registerIndex]) == "undefined"){continue;}

			var setting = {
				"name": typeof(registers[registerIndex]) == "undefined" ? "-" : registers[registerIndex].name,
				"title": "<#Lang['?'].no>" + (registerIndex + 1),
				"type": "IR",
				"registerIndex": registerIndex
			};

			$blockIRContainer.append(createBlock(setting).attr("id", "statusBlock_IR_" + registerIndex));
		}

		$("#statusBlockContainer").append(
			$("<div></div>").attr("class", "title").html("<#Lang['?'].internalRegister>")
		).append(
			$blockIRContainer
		).append(
			$("<div></div>").attr("class", "br")
		);
	}

	function createModuleStatus(){
		if(module.type == "icpdas" || module.type == "onboard"){
			for(var i = 0, typeArray = ["DI", "DO", "AI", "AO"]; i < typeArray.length; i++){
				var $blockContainer = $("<div></div>").attr("id", "status" + typeArray[i] + "BlockContainer");

				for(var j = 0; j < module[typeArray[i]].amount; j++){
					if(module[typeArray[i]].setting[j].disable == true){continue;}

					var setting = {
						"name": module[typeArray[i]].setting[j].name,
						"title": (module.moduleType != "DL" || typeArray[i] != "AI" ? "<#Lang['?'].channel>" : "") + module[typeArray[i]].setting[j].channelName,
						"type": typeArray[i],
						"sourceType": sourceType,
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex
					};

					if(typeArray[i] == "AI"){
						setting.unit = moduleManager.icpdasModule.getAIRange(module, j).unit;
					}
					else if(typeArray[i] == "AO"){
						setting.unit = moduleManager.icpdasModule.getAORange(module.AO.setting[j].type).unit;
					}

					var protocol = moduleManager.pool.interfaces[sourceType][sourceIndex].protocol;
					if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
 						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, typeArray[i], j);

						setting.channelType = channelAddressInfo[0];
						setting.channelAddress = channelAddressInfo[1];
						setting.channelIndex = j;//for DI Counter to calculate the address
						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + channelAddressInfo[0] + "_" + channelAddressInfo[1]));
					}
					else{
						setting.channelType = typeArray[i];
						setting.channelIndex = j;
						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + typeArray[i] + "_" + j));
					}
				}

				if($blockContainer.children().length > 0){
					$("#statusBlockContainer").append(
						$("<div></div>").attr("class", "title").html(typeArray[i])
					).append(
						$blockContainer
					).append(
						$("<div></div>").attr("class", "br")
					);
				}
			}

			if(module.moduleType == "WISE"){
				var $blockContainer = $("<div></div>").attr("id", "statusBlockIRContainer");

				for(var i = 0; i < module.IR.amount; i++){
					var setting = {
						"name": module.IR.setting[i].name,
						"title": "<#Lang['?'].no>" + (i + 1),
						"type": "RO",
						"sourceType": sourceType,
						"sourceIndex": sourceIndex,
						"moduleIndex": moduleIndex
					};

					var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, "IR", i);

					setting.channelType = channelAddressInfo[0];
					setting.channelAddress = channelAddressInfo[1];

					var $block = createBlock(setting).attr("id", "statusBlock_" + channelAddressInfo[0] + "_" + channelAddressInfo[1]);
					$blockContainer.append($block);
				}

				$("#statusBlockContainer").append(
					$("<div></div>").attr("class", "title").html("<#Lang['?'].internalRegister>")
				).append(
					$blockContainer
				).append(
					$("<div></div>").attr("class", "br")
				);
			}
		}
		else if(module.type == "rtu" || module.type == "tcp"){
			for(var i = 0, typeArray = ["CI", "CO", "RI", "RO"]; i < typeArray.length; i++){
				if(module[typeArray[i]].blockArray.length > 0){
					var $blockContainer = $("<div></div>").attr("id", "status" + typeArray[i] + "BlockContainer");

					for(var address in module[typeArray[i]].remoteAddress){
						var setting = {
							"name": module[typeArray[i]].remoteAddress[address].name,
							"title": "<#Lang['?'].address>" + address,
							"type": typeArray[i],
							"sourceType": sourceType,
							"sourceIndex": sourceIndex,
							"moduleIndex": moduleIndex,
							"channelAddress": address
						};

						if(typeArray[i] == "RI" || typeArray[i] == "RO"){
							setting.unit = module[typeArray[i]].remoteAddress[address].unit;
						}

						$blockContainer.append(createBlock(setting).attr("id", "statusBlock_" + typeArray[i] + "_" + address));
					}

					$("#statusBlockContainer").append(
						$("<div></div>").attr("class", "title").html(typeNamePool[typeArray[i]].replace("$channel", ""))
					).append(
						$blockContainer
					).append(
						$("<div></div>").attr("class", "br")
					);
				}
			}
		}

		//create polling time
		if(module.type != "onboard"){
			$("#statusBlockContainer .title:first").before(
				$("<div></div>").attr({
					"class": "statusPollingTimeWrapper",
					"id": "statusPollingTimeWrapper",
					"tip": "<#Lang['?'].pollingTime>",
					"tip_position": "left"
				}).append(
					$("<span></span>").attr("class", "iconsTimer").css({
						"verticalAlign": "middle"
					})
				).append(
					$("<span></span>").attr({
						"class": "statusPollingTime",
						"id": "statusPollingTime"
					}).css({
						"verticalAlign": "middle"
					})
				).hover(function(){
					$(this).addClass("hover").find(".iconsTimer").addClass("hover");
				}, function(){
					$(this).removeClass("hover").find(".iconsTimer").removeClass("hover");
				})
			);
		}
	}

	function createCustomizeStatus(){
		for(var i = 0; i < statusPage.group.length; i++){
			var group = statusPage.group[i];

			var $blockContainer = $("<div></div>");
			for(var j = 0; j < group.block.length; j++){
				var block = group.block[j];
				var setting = $.extend(true, {}, block);

				if(block.type == "IR"){
					if(block.moduleKey == null){
						var register = registerManager.pool.registers[block.registerIndex];
						setting.name = register.name;
						setting.title = typeNamePool[block.type].replace("$channel", block.registerIndex + 1);
					}
					else{
						var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
						var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

						setting.name = module.IR.setting[block.registerIndex].name;
						setting.title = typeNamePool[block.type].replace("$channel", block.registerIndex + 1);

						setting.sourceType = moduleInfo.sourceType;
						setting.sourceIndex = moduleInfo.sourceIndex;
						setting.moduleIndex = moduleInfo.moduleIndex;

						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, "IR", block.registerIndex);
						setting.channelType = channelAddressInfo[0];
						setting.channelAddress = channelAddressInfo[1];
					}
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
					var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

					if(block.type == "DI" || block.type == "DIC" || block.type == "DO" || block.type == "DOC" || block.type == "AI" || block.type == "AO"){
						var channelInfo = WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, block.type, block.channelIndex);

						var channelName = channelInfo.channelName;
						if(channelName.match(/^\d+$/)){
							setting.title = typeNamePool[block.type].replace("$channel", channelName);
						}
						else{//customized channel name, like DL
							setting.title = channelName;
						}

						setting.name = channelInfo.name;

						if(block.type == "AI"){
							setting.unit = moduleManager.icpdasModule.getAIRange(module, block.channelIndex).unit;
						}
						else if(block.type == "AO"){
							setting.unit = moduleManager.icpdasModule.getAORange(module.AO.setting[block.channelIndex].type).unit;
						}

						var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
						if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
	 						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, block.type, block.channelIndex);

							setting.channelType = channelAddressInfo[0];
							setting.channelAddress = channelAddressInfo[1];
							setting.channelIndex = j;//for DI Counter to calculate the address
						}
					}
					else{
						setting.title = typeNamePool[block.type].replace("$channel", block.channelAddress);
						setting.name = module[block.type].remoteAddress[block.channelAddress].name;

						if(block.type == "RI" || block.type == "RO"){
							setting.unit = module[block.type].remoteAddress[block.channelAddress].unit;
						}
					}

					setting.sourceType = moduleInfo.sourceType;
					setting.sourceIndex = moduleInfo.sourceIndex;
					setting.moduleIndex = moduleInfo.moduleIndex;
				}


				createBlock(setting, "customize").attr("id", "statusBlock_" + i + "_" + j).appendTo($blockContainer);
			}

			$("#statusBlockContainer").append(
				$("<div></div>").attr("class", "title").html(group.title)
			).append(
				$blockContainer
			).append(
				$("<div></div>").attr("class", "br")
			);
		}
	}

	function createBlock(setting, blockType){
		var $button = $("<div></div>").attr("class", "statusBlockButton")/*.disableSelection()*/;

		if(setting.type == "DI" || setting.type == "DO" || setting.type == "CI" || setting.type == "CO"){
			$button.append(
				$("<div></div>").attr("class", "statusBlockLightContainer").append(
					(function(){
						if(setting.type == "DO"){
							var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];

							if(module.mainType == "7088"){
								return $("<span></span>").css("fontSize", "120%").html("PWM&nbsp;");
							}
						}
					})()
				).append(
					$("<span></span>").attr("class", (function(){
						var className = "statusBlockText";
						if(setting.type == "DI"){
							var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];

							if(moduleManager.icpdasModule.isDICounterModule(module)){
								className += " isDICounterModule";
							}

							if(module.moduleType == "XWBoard"){
								className += " isXWBoard";
							}
						}

						return className;
					})()).text("-")
				).append(
					$("<div></div>").attr("class", (function(){
						var className = "statusBlockLight UNKNOWN";
						if(setting.type == "DI"){
							var module = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex];

							if(moduleManager.icpdasModule.isDICounterModule(module)){
								className += " isDICounterModule";
							}
						}

						return className;
					})()).html("&nbsp;")
				)
			);

			if(setting.type == "DI" || setting.type == "CI" || (WISE.getUser().character == "user" && WISE.permissionCheck(6) == false) || WISE.getUser().character == "guest"){
				$button.addClass("unEditable");
			}
			else{//DO, CO and user is admin
				$button.bind("click", {"block": setting}, function(event){
					if($(this).hasClass("disable")){return;}

					$("#statusBlockContainer .statusBlockButton").not(".unEditable").addClass("disable");
					timer.stop();//stop refresh

					var block = event.data.block;
					var moduleType = processModuleType(block);

					var xmlDoc = $.parseXML("<SET/>");
					xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
					xmlDoc.documentElement.setAttribute("type", moduleType);
					xmlDoc.documentElement.setAttribute("ch", block.channelType || block.type);
					xmlDoc.documentElement.setAttribute("chn", typeof(block.channelAddress) != "undefined" ? block.channelAddress : block.channelIndex);
					if(moduleType != "XBOARD"){
						if(moduleType != "CAMERA"){
							xmlDoc.documentElement.setAttribute("com", block.sourceIndex);
						}

						xmlDoc.documentElement.setAttribute("module", block.moduleIndex + 1);
					}
					xmlDoc.documentElement.appendChild(xmlDoc.createTextNode($button.find(".statusBlockText").text() == "ON" ? 0 : 1));

					WISE.startAjax("content", {
						url: "./dll/wise.dll",
						type: "POST",
						data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
						contentType: "text/xml",
						processData: false,
						cache: false,
						dataType: "xml",
						done: function(xmlDoc){
							$("#statusBlockContainer .statusBlockButton").not(".unEditable").removeClass("disable");
							timer.start();
						}
					});
				}).bind("mousedown", function(){
					$(this).css("backgroundColor", "#FFF")
				}).bind("mouseup mouseleave", function(){
					$(this).css("backgroundColor", "#ECECEC")
				});
			}
		}
		else if(setting.type == "DIC" || setting.type == "DOC" || setting.type == "AI" || setting.type == "AO" || setting.type == "RI" || setting.type == "RO" || setting.type == "IR"){
			$button.append(
				$("<nobr></nobr>").attr("class", "statusBlockValueShowDiv").append(
					$("<span></span>").attr("class", "statusBlockEmptyText").html("&nbsp;")
				).append(
					$("<span></span>").attr("class", "statusBlockText").html("-")
				).append(
					$("<div></div>").attr("class", "statusBlockUnitContainer").append(
						$("<div></div>").attr("class", "statusBlockUnitWrap").append(
							$("<div></div>").attr("class", "statusBlockUnit").append(
								$("<nobr></nobr>").html(setting.unit)
							)
						).append(
							$("<span></span>").attr("class", "statusBlockEmptyText").html("&nbsp;")
						)
					)
				)
			).append(
				$("<div></div>").attr("class", "statusBlockValueEditorDiv").css("display", "none").append(
					$("<input type='text'/>").attr("class", "statusBlockInputField").bind("keydown", {"block": setting}, function(event){
						if(event.which == 13 || event.which == 27){//ENTER or ESC
							var $button = $(this).parents(".statusBlockButton:first");
							var block = event.data.block;

							$button.find(".statusBlockValueShowDiv").css("visibility", "visible")/*.find(".statusBlockText").text($(this).val())*/;
							$button.find(".statusBlockValueEditorDiv").css("display", "none");
							$button.removeClass("editing");

							$("#opacityCover").unbind("click");
							opacityCover("hide", $button.parents(".statusBlock:first"));

							if(event.which == 13){//ENTER
								$("#statusBlockContainer .statusBlockButton").not(".unEditable").addClass("disable");

								var xmlDoc = $.parseXML("<SET/>");
								xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

								if(setting.type == "IR" && typeof(setting.moduleIndex) == "undefined"){
									xmlDoc.documentElement.setAttribute("type", "IR");
									xmlDoc.documentElement.setAttribute("module", block.registerIndex + 1);
								}
								else{
									xmlDoc.documentElement.setAttribute("type", processModuleType(block));
									xmlDoc.documentElement.setAttribute("com", block.sourceIndex);
									xmlDoc.documentElement.setAttribute("module", block.moduleIndex + 1);
									xmlDoc.documentElement.setAttribute("ch", block.channelType || block.type);
									xmlDoc.documentElement.setAttribute("chn", typeof(block.channelAddress) != "undefined" ? block.channelAddress : block.channelIndex);
								}
								xmlDoc.documentElement.appendChild(xmlDoc.createTextNode($(this).val()));

								WISE.startAjax("content", { 
									url: "./dll/wise.dll",
									type: "POST",
									data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
									contentType: "text/xml",
									processData: false,
									cache: false,
									dataType: "xml",
									done: function(xmlDoc){
										$("#statusBlockContainer .statusBlockButton").not(".unEditable").removeClass("disable");
										timer.start();
									}
								});
							}
							else{//ESC
								timer.start();
							}

							$(this).blur();
							//$(this).disableSelection();
						}
					}).val("0")
				)
			);

			if(setting.type == "DIC" || setting.type == "DOC" || setting.type == "AI" || setting.type == "RI" || (WISE.getUser().character == "user" && WISE.permissionCheck(6) == false) || WISE.getUser().character == "guest"){
				$button.addClass("unEditable");
			}
			else{//AO, RO and user is admin
				$button.bind("click", function(){
					if($(this).hasClass("disable")){return;}

					if(!$(this).hasClass("editing")){
						timer.stop();//stop refresh

						//$(this).enableSelection();
						$(this).addClass("editing");
						$(this).find(".statusBlockValueShowDiv").css("visibility", "hidden");
						$(this).find(".statusBlockValueEditorDiv").css("display", "block");
						$(this).find(".statusBlockValueEditorDiv input.statusBlockInputField").select().mouseup(function(){
					        $(this).unbind("mouseup");
					        return false;
					    });

						opacityCover("show", $(this).parents(".statusBlock:first"));
						$("#opacityCover").unbind("click").bind("click", function(){
							$(this).unbind("click");
							opacityCover("hide", $(".statusBlock"));

							var $button = $(".statusBlockButton.editing");
							$button.find(".statusBlockValueShowDiv").css("visibility", "visible");
							$button.find(".statusBlockValueEditorDiv").css("display", "none");
							//$button.disableSelection();
							$button.removeClass("editing");

							timer.start();
						});
					}
				}).bind("mousedown", function(){
					if(!$(this).hasClass("editing")){
						$(this).css("backgroundColor", "#FFF")
					}
				}).bind("mouseup mouseleave", function(){
					if(!$(this).hasClass("editing")){
						$(this).css("backgroundColor", "#ECECEC")
					}
				});
			}
		}

		if(typeof(blockType) != "undefined" && blockType == "customize"){
			var $statusBlock = $("<div></div>").attr("class", "statusBlock").append(
				$("<div></div>").attr("class", "statusBlockInnerDiv").append(
					$("<div></div>").attr("class", "statusBlockTitle").html((typeof(setting.name) == "undefined" || setting.name == "") ? "-" : setting.name)
				).append(
					$("<div></div>").attr("class", "statusBlockContent").append(
						$button
					)
				).append(
					$("<div></div>").attr("class", "statusBlockModuleInfoWrapper").append(
						(function(setting){
							if(setting.type == "IR"){
								if(typeof(setting.moduleIndex) == "undefined"){
									return $("<div></div>").attr("class", "statusBlockModuleInfo").append(
										$("<div></div>").attr("class", "statusBlockDescription").html(setting.title)
									);
								}
								else{
									return $("<div></div>").attr("class", "statusBlockModuleInfo").append(
										$("<div></div>").attr("class", "statusBlockDescription").html(moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].name)
									).append(
										$("<div></div>").attr("class", "statusBlockDescription").html(WISE.moduleInfo(setting.sourceType, setting.sourceIndex, setting.moduleIndex))
									).append(
										$("<div></div>").attr("class", "statusBlockDescription").html(setting.title)
									);
								}
							}
							else{
								return $("<div></div>").attr("class", "statusBlockModuleInfo").append(
									$("<div></div>").attr("class", "statusBlockDescription").html(moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].name)
								).append(
									$("<div></div>").attr("class", "statusBlockDescription").html(WISE.moduleInfo(setting.sourceType, setting.sourceIndex, setting.moduleIndex))
								).append(
									$("<div></div>").attr("class", "statusBlockDescription").html(setting.title)
								);
							}
						})(setting)
					)
				)
			).hover(
				function(){
					var $blockModuleInfoWrapper = $(this).find(".statusBlockModuleInfoWrapper");

					if(typeof($blockModuleInfoWrapper.data("top")) == "undefined"){
						var top = (($blockModuleInfoWrapper.innerHeight() + 1) * -1);
						$blockModuleInfoWrapper.css("top", top + "px");
						$blockModuleInfoWrapper.data("top", top);
					}

					$blockModuleInfoWrapper.show("slide", {"direction": "down"}, "fast", function(){
						$(this).bind("mouseenter", function(){
							$(this).parent().mouseout();
							$(this).unbind("mouseenter");
						})
					});
				},
				function(){
					$(this).find(".statusBlockModuleInfoWrapper").stop(true, true).hide();
				}
			);


			if(setting.type == "DIC"){
				$statusBlock.addClass("isDICounter");
			}
		}
		else{
			var $statusBlock = $("<div></div>").attr("class", "statusBlock").append(
				$("<div></div>").attr("class", "statusBlockInnerDiv").append(
					$("<div></div>").attr("class", "statusBlockTitle").html(setting.title)
				).append(
					$("<div></div>").attr("class", "statusBlockContent").append(
						$("<div></div>").attr("class", "statusBlockName").html((typeof(setting.name) == "undefined" || setting.name == "") ? "-" : setting.name)
					).append(
						$button
					)
				)
			);
		}

		if(blockType != "customize" && ((setting.type == "DI" && !moduleManager.icpdasModule.isNoDICounterModule(module)) || (setting.type == "DO" && moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex].modules[setting.moduleIndex].moduleType == "WISE"))){
			$statusBlock.find(".statusBlockContent").append(
				$("<div></div>").attr("class", "statusBlockCounter").html("<#Lang['?'].counter>&nbsp;").append(
					$("<span></span>").attr("id", (function(){
						var interfaces = moduleManager.pool.interfaces[setting.sourceType][setting.sourceIndex];
						var protocol = interfaces.protocol;
						var module = interfaces.modules[setting.moduleIndex];

						if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
							var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, setting.type + "C", setting.channelIndex);
							return "statusCounter_" + channelAddressInfo[0] + "_" + channelAddressInfo[1];
						}
						else{
							return "statusCounter_DI_" + setting.channelIndex;
						}
					})()).text("-")
				)
			)
		}

		return $statusBlock;
	}

	function updateValue($textFiled, value){
		if(!$textFiled.attr("textColor")){
			$textFiled.attr("textColor", $textFiled.css("color"));
		}

		var previousValue = $textFiled.text();
		
		if(previousValue != value && previousValue != "-" && previousValue != ""){
			$textFiled.stop().css("color", "#FF0000").animate({"color": $textFiled.attr("textColor")}, 2000, "easeInExpo");
		}

		$textFiled.text(value);
	}

	function updateMoudleStatus(timer){
		$("#contentLoader").show();

		var xmlDoc = $.parseXML("<STATUS/>");

		xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

		if(parameter[0] == "0"){//IR
			xmlDoc.documentElement.setAttribute("type", "IR");
		}
		else{
			var moduleType = processModuleType({
				"sourceType": sourceType,
				"sourceIndex": sourceIndex,
				"moduleIndex": moduleIndex
			});

			xmlDoc.documentElement.setAttribute("type", moduleType);

			if(moduleType != "XBOARD"){
				if(moduleType != "CAMERA"){
					xmlDoc.documentElement.setAttribute("com", sourceIndex);
				}

				xmlDoc.documentElement.setAttribute("module", moduleIndex + 1);
			}
		}

		timer.addAjax(
			WISE.startAjax("content", { 
				url: "./dll/wise.dll",
				//url: "./dll/xml/status5.xml",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				done: function(xmlDoc){
					var $xmlSTATUS = $(xmlDoc).find("STATUS");

					if($xmlSTATUS.attr("online") && typeof(callbackFunction) == "function"){
						callbackFunction($xmlSTATUS.attr("online"));
					}

					var pollingTime = parseInt($xmlSTATUS.attr("polling_time"), 10);
					if(!isNaN(pollingTime)){
						$("#statusPollingTime").html(formatPollingTime(pollingTime).join(""));
						$("#statusPollingTimeWrapper").show();
					}

					var $xmlElement = $xmlSTATUS.children();
					for(var i = 0; i < $xmlElement.length; i++){
						var tagName = $xmlElement[i].tagName;

						if(tagName == "DI" || tagName == "DO" || tagName == "CI" || tagName == "CO"){
							var $statusBlockText = $("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockText:not(.isDICounterModule)");

							if(tagName == "DI" && $statusBlockText.hasClass("isXWBoard")){
								var statusString = $($xmlElement[i]).text() == "0" ? "ON" : "OFF";
							}
							else{
								var statusString = $($xmlElement[i]).text() == "0" ? "OFF" : "ON";
							}

							updateValue($statusBlockText, statusString);
							$("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockLight:not(.isDICounterModule)").removeClass("ON OFF UNKNOWN").addClass(statusString);

							if(tagName == "DI" && typeof($($xmlElement[i]).attr("cnt")) != "undefined"){
								//$("#statusBlock_DI_" + $($xmlElement[i]).attr("idx") + " .statusBlockCounter > span").html($($xmlElement[i]).attr("cnt"));
								updateValue($("#statusCounter_DI_" + $($xmlElement[i]).attr("idx")), $($xmlElement[i]).attr("cnt"));
							}
						}
						else if(tagName == "AO" || tagName == "RO"){
							updateValue($("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockText"), $($xmlElement[i]).text());
							$("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockInputField").val($($xmlElement[i]).text());

						}
						else if(tagName == "IR"){
							updateValue($("#statusBlock_" + tagName + "_" + (parseInt($($xmlElement[i]).attr("idx"), 10) - 1) + " .statusBlockText"), $($xmlElement[i]).text());
							$("#statusBlock_" + tagName + "_" + (parseInt($($xmlElement[i]).attr("idx"), 10) - 1) + " .statusBlockInputField").val($($xmlElement[i]).text());
						}
						else{//AI, RI
							updateValue($("#statusBlock_" + tagName + "_" + $($xmlElement[i]).attr("idx") + " .statusBlockText"), $($xmlElement[i]).text());
						}

						if(tagName == "RI" || tagName == "RO"){//for M7K DI Counter
							updateValue($("#statusCounter_" + tagName + "_" + $($xmlElement[i]).attr("idx")), $($xmlElement[i]).text());
						}
					}
				},
				complete: function(){
					$("#contentLoader").hide();
					timer.next();
				}
			})
		);
	}

	function updateCustomizeStatus(timer, statusType){
		$("#contentLoader").show();

		var xmlDoc = $.parseXML("<STATUS/>");

		xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);
		xmlDoc.documentElement.setAttribute("type", "CUSTOM");
		xmlDoc.documentElement.setAttribute("module", statusPageKey + 1);

		timer.addAjax(
			WISE.startAjax("content", { 
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				done: function(xmlDoc){
					var $xmlG = $(xmlDoc).find("STATUS > G");

					for(var i = 0; i < $xmlG.length; i++){
						var groupKey = parseInt($($xmlG[i]).attr("idx"), 10) - 1;
						var $xmlB = $($xmlG[i]).find("> B");

						for(var j = 0; j < $xmlB.length; j++){
							var type = $($xmlB[j]).attr("type");
							var blockIndex = parseInt($($xmlB[j]).attr("idx"), 10) - 1;

							if(type == "DI" || type == "DO" || type == "CI" || type == "CO"){
								var $statusBlock = $("#statusBlock_" + groupKey + "_" + blockIndex);
								var $statusBlockText = $statusBlock.find(".statusBlockText");
								var statusString = $($xmlB[j]).text() == "0" ? "OFF" : "ON";

								if(type == "DI"){
									if($statusBlock.hasClass("isDICounter")){
										updateValue($statusBlockText, $($xmlB[j]).attr("cnt"));
										continue;
									}
									else{
										if($statusBlockText.hasClass("isXWBoard")){
											statusString = $($xmlB[j]).text() == "0" ? "ON" : "OFF";
										}
									}
								}

								updateValue($statusBlockText, statusString);
								$statusBlock.find(".statusBlockLight").removeClass("ON OFF UNKNOWN").addClass(statusString);
								continue;
							}
							else if(type == "AO" || type == "RO" || type == "IR"){
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockText"), $($xmlB[j]).text());
								$("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockInputField").val($($xmlB[j]).text());
								continue;
							}
							else{//AI, RI
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockText"), $($xmlB[j]).text());
								continue;
							}

							if((type == "CI" || type == "CO") && $($xmlB[j]).attr("cnt")){//for M7K DI Counter
								updateValue($("#statusBlock_" + groupKey + "_" + blockIndex + " .statusBlockCounter"), $($xmlB[j]).attr("cnt"));
								continue;
							}
						}
					}
				},
				complete: function(){
					$("#contentLoader").hide();
					timer.next();
				}
			})
		);
	}

	function processModuleType(moduleInfo){
		var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas"){
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

			if(protocol == "dcon"){//M7K
				return "DCON";
			}
			else if(protocol == "modbusRTU"){
				return "RTU";
			}
			else if(protocol == "modbusTCP"){
				return "TCP";
			}
			else if(protocol == "httpCGI"){
				return "CAMERA";
			}
		}
		else if(module.type == "onboard"){return "XBOARD";}
		else if(module.type == "rtu"){return "RTU";}
		else if(module.type == "tcp"){return "TCP";}
	};

	function opacityCover(display, $target){
		if(display == "show"){
			if(typeof($target) != "undefined"){
				$target.css("zIndex", "10");
			}
			$("#opacityCover").css("display", "block");
			$("#right").css("position", "static");//for IE6 and IE7
		}
		else{
			if(typeof($target) != "undefined"){
				$target.css("zIndex", "");
			}
			$("#opacityCover").css("display", "none");
			$("#right").css("position", "relative");//for IE6 and IE7
		}
	}
};

// Picture viewer
function isImage(name){
	return (/\.(gif|jpg|jpeg|png)$/i).test(name);
}

function isVideo(name){
	return (/\.(mp4)$/i).test(name);
}

function showImageWindow(path, fileArray, fileArrayIndex){
	var loadImage = function(imageIndex){
		$("#imageViewer").attr("status", "loading");
		$("#imageViewerTitle").text("<#Lang['?'].loading>");
		$("#imageViewerLoader").show();

		if(isImage(fileArray[imageIndex].name)){
			createImage().css({"width": "", "height": ""}).attr({
				"imageIndex": imageIndex,
				"src": path + "/" + fileArray[imageIndex].name/* + "?_=" + Math.random()*/
			}).appendTo("#imageViewerImage");
		}
		else if(isVideo(fileArray[imageIndex].name)){
			createVideo(path + "/" + fileArray[imageIndex].name/* + "?_=" + Math.random()*/).css({"width": "", "height": ""}).attr({
				"imageIndex": imageIndex
			}).appendTo("#imageViewerImage");
		}
	};

	var createVideo = function(src){
		return $("<video></video>").attr("controls", true).append(
			$("<source></source>").attr({
				"src": src,
				"type": "video/mp4"
			})
		).bind("loadedmetadata", onLoad);
	};

	var createImage = function(){
		return $("<img/>").bind("load", onLoad);
	};

	var onLoad = function(){
		var imageIndex = parseInt($(this).attr("imageIndex"), 10);
		$("#imageViewerTitle").text(fileArray[imageIndex].name);
		$("#imageViewerLoader").hide();

		var containerMinWidth = parseInt($("#imageViewerImageContainer").css("minWidth"), 10);
		var containerMinHeight = parseInt($("#imageViewerImageContainer").css("minHeight"), 10);
		var imageWidth = this.width || this.videoWidth, imageHeight = this.height || this.videoHeight;

		if(imageWidth > $(window).width() - 100){//according width to scale height
			imageWidth = $(window).width() - 100;
			imageHeight = imageWidth * (this.height || this.videoHeight) / (this.width || this.videoWidth);
		}

		if(imageHeight > $(window).height() - 100){//if the height still over screen, change according height to scale width
			imageHeight = $(window).height() - 100;
			imageWidth = imageHeight * (this.width || this.videoWidth) / (this.height || this.videoHeight);
		}

		imageWidth = Math.round(imageWidth);
		imageHeight = Math.round(imageHeight);

		$(this).css({
			"width": imageWidth + "px",
			"height": imageHeight + "px"
		}).parent().removeAttr("id").css({
			"left": (imageWidth < containerMinWidth ? containerMinWidth / 2 - imageWidth / 2 : 0) + "px",
			"top": (imageHeight < containerMinHeight ? containerMinHeight / 2 - imageHeight / 2 : 0) + "px",
			"opacity": "1"
		}).siblings("div.imageViewerImage").attr("id", "imageViewerImage").animate({
			"opacity": 0
		}, "slow", function(){
			$(this).empty();

			$(this).css({
				"zIndex": "1",
				"left": "9999px",
			}).siblings("div.imageViewerImage").css({
				"zIndex": "2"
			});

			$("#imageViewer").removeAttr("status");
		});

		$("#imageViewerImageContainer").animate({
			"width": Math.max(imageWidth, containerMinWidth) + "px",
			"height": Math.max(imageHeight, containerMinHeight) + "px"
		}, "slow");

		//update navigation button
		$("#imageViewerPreviousButton, #imageViewerNextButton").unbind("click");

		var nextImageIndex;
		for(var i = imageIndex + 1; i < fileArray.length; i++){
			if(isImage(fileArray[i].name) || isVideo(fileArray[i].name)){
				nextImageIndex = i;
				break;
			}
		}

		if(typeof(nextImageIndex) != "undefined"){//next image exist
			$("#imageViewerNextButton").bind("click", {"imageIndex": nextImageIndex}, function(event){
				if($("#imageViewer").attr("status") != "loading"){
					loadImage(event.data.imageIndex);
				}
			}).fadeIn("slow");
		}
		else{
			$("#imageViewerNextButton").fadeOut("slow");
		}

		var previousImageIndex;
		for(var i = imageIndex - 1; i >= 0; i--){
			if(isImage(fileArray[i].name) || isVideo(fileArray[i].name)){
				previousImageIndex = i;
				break;
			}
		}

		if(typeof(previousImageIndex) != "undefined"){//next image exist
			$("#imageViewerPreviousButton").bind("click", {"imageIndex": previousImageIndex}, function(event){
				if($("#imageViewer").attr("status") != "loading"){
					loadImage(event.data.imageIndex);
				}
			}).fadeIn("slow");
		}
		else{
			$("#imageViewerPreviousButton").fadeOut("slow");
		}
	};

	$("#opacityCoverMessage > .fixedDivContentWrap").empty().append(
		$("<table></table>").attr({"cellSpacing": "0", "cellPadding": "0", "border": "0", "width": "100%", "height":"100%"}).append(
			$("<tr></tr>").append(
				$("<td></td>").attr({"align": "center", "valign": "middle"}).css({"padding": "10px"}).append(
					$("<div></div>").attr("id", "imageViewer").append(
						$("<div></div>").attr("id", "imageViewerHeader").append(
							$("<span></span>").attr("class", "icon3 Remove").css({
								"position": "absolute",
								"right": "5px",
								"top": "50%",
								"marginTop": "-9px",
								"cursor": "pointer"
							}).hover(
								function(){
									$(this).addClass("hover");
								},
								function(){
									$(this).removeClass("hover");
								}
							).bind("click", function(){
								$("#opacityCoverMessage > .fixedDivContentWrap").empty();//prevent img onload fire
								$("#opacityCoverMessage").hide();
							})
						).append(
							$("<span></span>").attr("id", "imageViewerTitle")
						)
					).append(
						$("<div></div>").attr("id", "imageViewerBody").append(
							$("<div></div>").attr("id", "imageViewerImageContainer").append(
								$("<div></div>").attr({
									"class": "imageViewerImage",
									"id": "imageViewerImage"
								})
							).append(
								$("<div></div>").attr({
									"class": "imageViewerImage"
								})
							).append(
								$("<div></div>").attr("id", "imageViewerLoader").append(
									$("<img/>").attr("src", "./image/desktop/loader2.gif").css("float", "left")
								)
							).append(
								$("<div></div>").attr({
									"id": "imageViewerNextButton",
									"class": "imageViewerNavigationButton"
								}).append(
									$("<span></span>").attr("class", "imageViewerIcons next")
								).hover(
									function(){
										$(this).addClass("hover");
									},
									function(){
										$(this).removeClass("hover");
									}
								)
							).append(
								$("<div></div>").attr({
									"id": "imageViewerPreviousButton",
									"class": "imageViewerNavigationButton"
								}).append(
									$("<span></span>").attr("class", "imageViewerIcons previous")
								).hover(
									function(){
										$(this).addClass("hover");
									},
									function(){
										$(this).removeClass("hover");
									}
								)
							)
						)
					)
				)
			)
		)
	);

	$("#opacityCoverMessage").show();
	loadImage(fileArrayIndex);
}