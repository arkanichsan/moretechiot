function ipToInteger(ip){
	var ipArray = ip.split('.');
	return ((((((+ipArray[0]) * 256) + (+ipArray[1])) * 256) + (+ipArray[2])) * 256) + (+ipArray[3]);
}

function integerToIP(integer) {
	var ip = integer % 256;
	for (var i = 3; i > 0; i--) { 
		integer = Math.floor(integer / 256);
		ip = (integer % 256) + '.' + ip;
	}

	return ip;
}

function padding(number, length, paddingChar){
	paddingChar = typeof(paddingChar) == "undefined" ? "0" : paddingChar;

    var str = "" + number;
    while (str.length < length) {
        str = paddingChar + str;
    }
   
    return str;
}

function toFixed(number, decimal){
	var length = Math.pow(10, typeof(decimal) != "undefined" ? decimal : 2);
	return (Math.round(number * length) / length);
}

function ruleColor(message, lv){
	//return $("<span></span>").attr("class", "ruleColorLV" + lv).html(message).wrap("<span></span>").parent().html();
	return "<span class='ruleColorLV" + lv + "'>" + message + "</span>";
};

function randomKey(length, chars){
	chars = chars || "ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var randomString = "";
	for (var i = 0; i < length; i++) {
		randomString += chars.charAt(Math.floor(Math.random() * chars.length));
	}

	return randomString;
}

function xmlToString(node, prettyPrint){
	var processPredefinedEntities = function(xmlString){
		return xmlString.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
	};

	var traverse = function(node, level){
		if(node.nodeType == 3){
			if(typeof(node.text) != "undefined"){
				return processPredefinedEntities(node.text);
			}
			else{
				return processPredefinedEntities(node.textContent);
			}
		}
		else{
			var indentation = "";
			if(prettyPrint == true){
				for(var i = 0; i < level; i++){
					indentation += "  ";
				}
			}

			var xmlString = (prettyPrint ? indentation : "") + "<" + node.tagName;
			if(node.attributes){
				for(var i = 0; i < node.attributes.length; i++){
					xmlString += " " + node.attributes[i].name + "=\"" + processPredefinedEntities(node.attributes[i].value) + "\"";
				}
			}

			if(node.hasChildNodes()){
				level++;

				var onlyTextNodeExist = true;
				var childString = "";

				for(var i = 0; i < node.childNodes.length; i++){
					if(node.childNodes[i].nodeType != 3){onlyTextNodeExist = false;}

					childString += traverse(node.childNodes[i], level);
				}

				if(childString.length != 0){
					xmlString += ">";

					if(onlyTextNodeExist == true){
						xmlString += childString + "</" + node.tagName + ">" + (prettyPrint ? "\r\n" : "");
					}
					else{
						xmlString += (prettyPrint ? "\r\n" : "") + childString + (prettyPrint ? indentation : "") + "</" + node.tagName + ">" + (prettyPrint ? "\r\n" : "");
					}
				}
				else{
					xmlString += "/>" + (prettyPrint ? "\r\n" : "");
				}
			}
			else{
				xmlString += "/>" + (prettyPrint ? "\r\n" : "");
				//xmlString += "></" + node.tagName + ">" + (prettyPrint ? "\r\n" : "");
			}

			return xmlString;
		}
	};

	return traverse(node, 0);
};
