WISE.managers.statusManager.encodeXMLObject = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;

	var xmlSTATUS = xmlDoc.createElement("STATUS");

	for(var key in this.pool.statusPages){
		var statusPage = this.pool.statusPages[key];
		var xmlS = xmlDoc.createElement("S");

		xmlS.setAttribute("idx", statusPage.index);
		xmlS.setAttribute("nickname", statusPage.name);

		if(statusPage.description != ""){
			xmlS.setAttribute("desc", statusPage.description);
		}

		for(var i = 0; i < statusPage.group.length; i++){
			var group = statusPage.group[i];
			var xmlGROUP = xmlDoc.createElement("GROUP");
			xmlGROUP.setAttribute("idx", i + 1);
			xmlGROUP.setAttribute("nickname", group.title);

			for(var j = 0; j < group.block.length; j++){
				var block = group.block[j];
				var xmlBLOCK = xmlDoc.createElement("BLOCK");
				xmlBLOCK.setAttribute("idx", j + 1);

				if(block.type == "IR"){
					if(block.moduleKey == null){
						xmlBLOCK.setAttribute("b_obj", "IR");
						xmlBLOCK.setAttribute("b_idx", block.registerIndex + 1);
					}
					else{
						var moduleInfo = processModuleInfo(xmlBLOCK, "b", block.moduleKey);
						var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", block.registerIndex);
						xmlBLOCK.setAttribute("b_ch", channelAddressInfo[0]);
						xmlBLOCK.setAttribute("b_chn", channelAddressInfo[1]);
					}
				}
				else{
					var moduleInfo = processModuleInfo(xmlBLOCK, "b", block.moduleKey);
					var moduleManager = WISE.managers.moduleManager;
					var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
					var module = moduleInfo.module;

					if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
						var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, block.type, block.channelIndex);
						xmlBLOCK.setAttribute("b_ch", channelAddressInfo[0]);
						xmlBLOCK.setAttribute("b_chn", channelAddressInfo[1]);
					}
					else{
						if(block.type == "DIC"){
							xmlBLOCK.setAttribute("b_ch", "DI");
							xmlBLOCK.setAttribute("b_cnt", "1");
						}
						else{
							xmlBLOCK.setAttribute("b_ch", block.type);
						}

						xmlBLOCK.setAttribute("b_chn", typeof(block.channelIndex) != "undefined" ? block.channelIndex : block.channelAddress);
					}
				}

				xmlGROUP.appendChild(xmlBLOCK);
			}

			xmlS.appendChild(xmlGROUP);
		}

		xmlSTATUS.appendChild(xmlS);
	}

	if(xmlSTATUS.childNodes.length > 0){
		xmlDoc.documentElement.appendChild(xmlSTATUS);
	}
};

WISE.managers.statusManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.statusPages){
		this.pool.statusPages[key].index = ++index;
	}
};