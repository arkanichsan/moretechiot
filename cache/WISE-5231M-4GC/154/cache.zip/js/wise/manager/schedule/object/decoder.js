WISE.managers.scheduleManager.decodeXMLObject = function(xmlDoc){
	var $xmlSCHEDULE = $(xmlDoc).find("WISE > NOTE > SCHEDULE");
	if($xmlSCHEDULE.length > 0){
		var $xmlS = $xmlSCHEDULE.find("> S");
		var maxKey = 0;
		for(var i = 0; i < $xmlS.length; i++){
			var key = parseInt($($xmlS[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var schedule = this.createSchedule({
				"name": $($xmlS[i]).attr("nickname"),
				"description": $($xmlS[i]).attr("desc"),
				"initialStatus": parseInt($($xmlS[i]).attr("status"), 10),
				"mode": parseInt($($xmlS[i]).attr("type"), 10)
			});

			if(schedule.mode == 0){
				var $xmlDATE = $($xmlS[i]).find("> DATE");
				schedule.date.startDate.year = parseInt($xmlDATE.attr("year"), 10);
				schedule.date.startDate.month = parseInt($xmlDATE.attr("month"), 10);
				schedule.date.duration = parseInt($xmlDATE.attr("duration"), 10);

				schedule.date.skipDateArray = [];
				var skipArray = $($xmlS[i]).find("> SKIP").text().split(",");
				for(var j = 0; j < skipArray.length; j++){
					schedule.date.skipDateArray.push(parseInt(skipArray[j], 10));
				}
			}
			else if(schedule.mode == 1){
				var week = $($xmlS[i]).attr("week");
				for(var j = 0; j < week.length; j++){
					var index = parseInt(week.charAt(j), 10);
					if(index == 7){index = 0;}//sunday is zero
					schedule.date.repeatDayArray[index] = true;
				}

				var $xmlSKIP = $($xmlS[i]).find("> SKIP");
				if($xmlSKIP.length > 0){
					var skipArray = $xmlSKIP.text().split(",");

					for(var j = 0; j < skipArray.length; j++){
						schedule.date.exceptionDateArray.push(skipArray[j].split("/"));
					}
				}
			}

			schedule.timeArray = [];
			var $xmlTIME = $($xmlS[i]).find("> TIME");
			for(var j = 0; j < $xmlTIME.length; j++){
				schedule.timeArray[parseInt($($xmlTIME[j]).attr("idx"), 10)] = [parseInt($($xmlTIME[j]).attr("h1"), 10), parseInt($($xmlTIME[j]).attr("m1"), 10), parseInt($($xmlTIME[j]).attr("s1"), 10), parseInt($($xmlTIME[j]).attr("h2"), 10), parseInt($($xmlTIME[j]).attr("m2"), 10), parseInt($($xmlTIME[j]).attr("s2"), 10)];
			}

			//clear undefined element
			for(var j = 0; j < schedule.timeArray.length;){
				if(typeof(schedule.timeArray[j]) == "undefined"){
					schedule.timeArray.splice(j, 1);
				}
				else{
					j++;
				}
			}

			this.setSchedule(key, schedule);
		}

		this.pool.key = ++maxKey;
	}
};