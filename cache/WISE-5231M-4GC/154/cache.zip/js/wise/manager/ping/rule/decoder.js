WISE.managers.pingManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "PING"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.ping);
			ruleObject.rule.pingKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
	}

	return ruleObject;
};