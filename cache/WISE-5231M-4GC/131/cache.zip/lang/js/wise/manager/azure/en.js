$.extend(true, Lang, {
	"js/wise/manager/azure/rule/object.js": {
		"connectionStatus": "Connection Status",
		"offline": "Offline",
		"online": "Online",
		"azureConnectionStatus": "Microsoft Azure Connection Status",
		"subscribeMessage": "Subscribe Message",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message",
		"functionStatus": "Function Status",
		"azureFunctionStatus": "Microsoft Azure Function Status",
		"publishMessage": "Publish Message",
		"publish": "Publish",
		"resetVariable": "Reset Variable",
		"reset": "Reset"
	}
});