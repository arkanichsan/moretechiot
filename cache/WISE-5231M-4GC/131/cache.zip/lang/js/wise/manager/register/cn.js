$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"internalRegister": "内部缓存器",
		"local": "本机",
		"remote": "远程",
		"bit": "位元",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息"
	}
});