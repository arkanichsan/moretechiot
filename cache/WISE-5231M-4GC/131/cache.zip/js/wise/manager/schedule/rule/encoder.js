WISE.managers.scheduleManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "schedule"){
			xmlDoc.setAttribute("l_obj", "SCHEDULE");
			xmlDoc.setAttribute("l_idx", this.pool.schedules[ruleObject.rule.scheduleKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "schedule"){
			xmlDoc.setAttribute("l_obj", "SCHEDULE");
			xmlDoc.setAttribute("l_idx", this.pool.schedules[ruleObject.rule.scheduleKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
};