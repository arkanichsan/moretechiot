WISE.managers.lineBotManager = (function(){
	return new function() {
		this.pool = {
			messages: {},
			messageKey: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxMessageAmount = 12;

		this.createMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"content": ""
			}, settings);

			return message;
		};

		this.addMessage = function(message){
			var retKey = this.pool.messageKey;
			this.pool.messages[this.pool.messageKey++] = message;
			return retKey;
		};

		this.removeMessage = function(key){
			delete this.pool.messages[key];
		};

		this.getMessage = function(key){
			if(typeof(this.pool.messages[key]) != "undefined"){
				return this.pool.messages[key];
			}
			else{
				return null;
			}
		};

		this.setMessage = function(key, message){
			this.pool.messages[key] = message;
		};

		this.getMessages = function(){
			return this.pool.messages;
		};
	};
})();
