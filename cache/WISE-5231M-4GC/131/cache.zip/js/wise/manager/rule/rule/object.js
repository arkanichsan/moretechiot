WISE.managers.ruleManager.pool.conditions = {
	"ruleStatus": {
		"name": "<#Lang['?'].ruleStatus>",
		"fileName": "crule",
		"rule":{
			"ruleKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.ruleKey == null){
				return false;
			}

			var ruleManager = WISE.managers.ruleManager;

			if(typeof(ruleManager.pool.rules[this.rule.ruleKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){

			var ruleManager = WISE.managers.ruleManager;
			var rule = ruleManager.pool.rules[this.rule.ruleKey];
			var valueString = ["<#Lang.global.disable>", "<#Lang.global.enable>"];

			return this.name + "(" + rule.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.ruleKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.ruleManager.pool.actions = {
	"ruleStatus": {
		"name": "<#Lang['?'].ruleStatus>",
		"fileName": "arule",
		"rule":{
			"ruleKey": null,
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			if(this.rule.ruleKey == null){
				return false;
			}

			var ruleManager = WISE.managers.ruleManager;

			if(typeof(ruleManager.pool.rules[this.rule.ruleKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var ruleManager = WISE.managers.ruleManager;
			var rule = ruleManager.pool.rules[this.rule.ruleKey];
			var valueString = ["<#Lang.global.disable>", "<#Lang.global.enable>"];

			return this.name + "(" + rule.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.ruleKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.ruleManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['ruleStatus']['key'] = [];
	this.pool.actions['ruleStatus']['key'] = [];

	for(var key in this.pool.rules){
		this.pool.conditions['ruleStatus']['key'].push(parseInt(key, 10));
		this.pool.actions['ruleStatus']['key'].push(parseInt(key, 10));
	}
};
