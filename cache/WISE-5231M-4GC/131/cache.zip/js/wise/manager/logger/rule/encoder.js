WISE.managers.loggerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
/*
		if(ruleObject.ruleObjectKey == "ftp"){
			xmlDoc.setAttribute("l_obj", "FTP");
			xmlDoc.setAttribute("op", {1: "0", 3: "1", 6: "2", 12: "3", 24: "4"}[ruleObject.rule.value]);
		}
*/
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "log"){
			xmlDoc.setAttribute("l_obj", "LOG");
			xmlDoc.setAttribute("l_idx", ruleObject.rule.logType == "module" ? "0" : this.pool.dataLogger.customized.logs[ruleObject.rule.logKey].index);
			xmlDoc.setAttribute("op", "1");
		}
	}
};

WISE.managers.loggerManager.beforeEncodeRuleFile = function(){
	var format = "", csvIndex = 0;

	var moduleManager = WISE.managers.moduleManager;
	for(var sourceTypeIndex = 0, sourceTypeArray = ["onboard", "comport", "network"]; sourceTypeIndex < sourceTypeArray.length; sourceTypeIndex++){
		var sourceType = sourceTypeArray[sourceTypeIndex];

		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces[sourceType].length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces[sourceType][sourceIndex]) == "undefined"){continue;}

			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces[sourceType][sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];
				module._csvHeader = "";// let moduleManager to use
				module._csvIndex = csvIndex;

				if(typeof(module.extendedModule) != "undefined"){continue;}

				if(module.type == "onboard" || module.type == "icpdas"){
					for(var channelTypeIndex = 0, channelTypeArray = ["DI", "DO", "AI", "AO"]; channelTypeIndex < channelTypeArray.length; channelTypeIndex++){
						var channelType = channelTypeArray[channelTypeIndex];

						if(channelType == "DI" && moduleManager.icpdasModule.isDICounterModule(module)){
						}
						else{
							for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
								if(module[channelType].setting[channelIndex].disable == true){continue;}

								format += WISE.getVariable(sourceType, sourceIndex, moduleIndex, channelType, channelIndex) + ",";
								module._csvHeader += channelType + channelIndex + ",";
								csvIndex++;
							}
						}

						//DI, DO Counter
						if(channelType == "DI"){
							if(module.type == "onboard"){
								for(var channelIndex = 0; channelIndex < module.DI.amount; channelIndex++){
									if(module.DI.setting[channelIndex].disable == true){continue;}

									if(module.DI.setting[channelIndex].counterType > 0){
										format += WISE.getVariable(sourceType, sourceIndex, moduleIndex, "DIC", channelIndex) + ",";
										module._csvHeader += "DIC" + channelIndex + ",";
										csvIndex++;
									}
								}
							}
							else{
								if(!moduleManager.icpdasModule.isNoDICounterModule(module)){
									for(var channelIndex = 0; channelIndex < module.DI.amount; channelIndex++){
										if(module.DI.setting[channelIndex].disable == true){continue;}

										format += WISE.getVariable(sourceType, sourceIndex, moduleIndex, "DIC", channelIndex) + ",";
										module._csvHeader += "DIC" + channelIndex + ",";
										csvIndex++;
									}
								}
							}
						}
						else if(channelType == "DO"){
							if(module.moduleType == "WISE"){
								for(var channelIndex = 0; channelIndex < module.DO.amount; channelIndex++){
									if(module.DO.setting[channelIndex].disable == true){continue;}

									format += WISE.getVariable(sourceType, sourceIndex, moduleIndex, "DOC", channelIndex) + ",";
									module._csvHeader += "DOC" + channelIndex + ",";
									csvIndex++;
								}
							}
						}
					}
				}
				else if(module.type == "rtu" || module.type == "tcp"){
					for(var channelTypeIndex = 0, channelTypeArray = ["CI", "CO", "RI", "RO"]; channelTypeIndex < channelTypeArray.length; channelTypeIndex++){
						var channelType = channelTypeArray[channelTypeIndex];

						if(module[channelType].blockArray.length > 0){
							for(var channelAddress in module[channelType].remoteAddress){
								format += WISE.getVariable(sourceType, sourceIndex, moduleIndex, channelType, channelAddress) + ",";
								module._csvHeader += channelType + channelAddress + ",";
								csvIndex++;
							}
						}
					}
				}

				if(module.moduleType == "WISE"){
					for(var i = 0; i < 48; i++){
						format += WISE.getVariable("register", module.key, i) + ",";
						module._csvHeader += "IR" + (i + 1) + ",";
						csvIndex++;
					}
				}

				module._csvHeader = module._csvHeader.substr(0, module._csvHeader.length - 1);
			}
		}
	}

	var registerManager = WISE.managers.registerManager;
	registerManager.pool._csvHeader = "";// let registerManager to use
	registerManager.pool._csvIndex = csvIndex;

	for(var registerIndex = 0, registers = registerManager.pool.registers; registerIndex < registers.length; registerIndex++){
		if(typeof(registers[registerIndex]) == "undefined"){continue;}

		format += WISE.getVariable("register", null, registerIndex) + ",";
		registerManager.pool._csvHeader += "IR" + (registerIndex + 1) + ",";
		csvIndex++;
	}

	registerManager.pool._csvHeader = registerManager.pool._csvHeader.substr(0, registerManager.pool._csvHeader.length - 1);

	format = format.substr(0, format.length - 1);
	this.pool._format = format;// let encodeXMLObject to use
};