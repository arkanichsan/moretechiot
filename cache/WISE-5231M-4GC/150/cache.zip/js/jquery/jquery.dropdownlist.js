(function($) {
	$.fn.dropDownList = function(settings, extraParam1){
		if(typeof(settings) == "string"){
			var $dropDownListContainer = $(this).parents(".dropDownListContainer:first");
			var $dropDownListSelector = $dropDownListContainer.children(".dropDownListSelector");

			if(settings == "val"){
				if(typeof(extraParam1) != "undefined"){
					var $li = $(this).find("li[val='" + extraParam1 + "']");
					if($li.length > 0){
						$dropDownListSelector.attr("val", extraParam1).text($li.text());
					}

					return $(this);
				}
				else{
					return $dropDownListSelector.attr("val");
				}
			}
			else if(settings == "label"){
				return $dropDownListSelector.text();
			}
			else if(settings == "click"){
				$(this).triggerHandler("bindClick", [$(this).find("li[val='" + $dropDownListSelector.attr("val") + "']")]);
				return $(this);
			}
			else if(settings == "disabled"){
				if(extraParam1 == false){
					$dropDownListContainer.removeClass("disabled");
				}
				else{
					$dropDownListContainer.addClass("disabled");
				}

				return $(this);
			}
		}
		else{
			settings = $.extend(true, {
				"click": function(){},
				"tip": null,
				"val" : null
			}, settings);

			return this.each(function(){
				if($(this).hasClass("dropDownListContainer")){return $(this);}

				var defaultLabel, defaultVal, defaultFound = 0;

				$(this).find("li").bind("mouseenter click", function(event){
					event.stopPropagation();

					if($(this).attr("disabled")){return;}

					$(this).siblings("li.hover").removeClass("hover").children("ul").hide();
					$(this).find("ul").hide();
					$(this).find("li.hover").removeClass("hover");

					$(this).children("ul").show().css("left", ($(this).parent().width() - 3) + "px");
					$(this).addClass("hover");
				}).bind("click", function(event){
					event.stopPropagation();

					if($(this).children("ul").length == 0 && !$(this).attr("disabled")){//leaf li node
						var $dropDownListSelector = $(this).parents(".dropDownListContainer:first").children(".dropDownListSelector");
						$dropDownListSelector.text($(this).text());

						if($(this).attr("val") == undefined){
							$dropDownListSelector.removeAttr("val");
						}
						else{
							$dropDownListSelector.attr("val", $(this).attr("val"));
						}

						settings.click(this);
						$(document).triggerHandler("click");
					}
				}).each(function(index){
					if($(this).children("ul").length == 0){
						if(defaultFound <= 1){
							defaultLabel = $(this).text();
							defaultVal = $(this).attr("val");
							defaultFound = 2;
						}

						if(defaultFound <= 2 && settings.tip != null){
							defaultLabel = settings.tip;
							defaultVal = null;
							defaultFound = 3;
						}

						if(defaultFound <= 3 && settings.val != null && $(this).attr("val") == settings.val){
							defaultLabel = $(this).text();
							defaultVal = $(this).attr("val");
							defaultFound = 4;
						}
					}
					else{
						$(this).addClass("hasChildren").parent().children().css("paddingRight", "20px");
						$(this).append(
							$("<div></div>").addClass("dropDownListBackgroundImage toRight").css({"position": "absolute", "top": "50%", "right": "5px", "marginTop": "-5px"})
						);
					}
				});

				var $container = $("<div></div>").addClass("dropDownListContainer").append(
					$("<div></div>").addClass("dropDownListSelector").html(defaultFound == 0 ? settings.tip || "&nbsp;" : defaultLabel).attr("val", defaultVal)
				).append(
					$("<div></div>").addClass("dropDownListButton").html("&nbsp;").append(
						$("<div></div>").addClass("dropDownListBackgroundImage toDown").css({"position": "absolute", "top": "50%", "right": "5px", "marginTop": "-5px"})
					)
				).append(
					$("<div></div>").addClass("dropDownListWrapper").append(
						$("<div></div>").addClass("dropDownList")
					)
				).bind("click", function(event){
					if($(this).hasClass("disabled")){return;}

					event.stopPropagation();

					var $dropDownList = $(this).find(".dropDownList");

					if(!$(this).hasClass("dropDownListActive")){
						$(document).click();

						$(this).addClass("dropDownListActive");
						$dropDownList.find(".hover").removeClass("hover");
						$dropDownList.find("li ul").hide();
						$dropDownList.show();

						$(document).bind("click.dropDownList", {"dropDownList": $dropDownList, "dropDownListContainer": $(this)}, function(event){
							event.data.dropDownList.hide();
							event.data.dropDownListContainer.removeClass("dropDownListActive");
							$(document).unbind("click.dropDownList");
						});
					}
					else{
						$(document).click();
					}
				}).hover(
					function(){
						$(this).addClass("hover");
					},
					function(){
						$(this).removeClass("hover");
					}
				).insertBefore($(this)).disableSelection();

				$(this).appendTo($container.find(".dropDownList"));
				$(this).css("minWidth", ($container.width() - 2) + "px");
				$(this).bind("bindClick", function(event, li){
					settings.click(li[0]);
				});

				return $(this);
			});
		}
	};
})(jQuery);