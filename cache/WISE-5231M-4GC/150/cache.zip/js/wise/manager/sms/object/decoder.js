WISE.managers.smsManager.decodeXMLObject = function(xmlDoc){
	var $xmlSMS = $(xmlDoc).find("WISE > NOTE > SMS");
	if($xmlSMS.length > 0){
		this.pool.pinCode = (function(pin, pinLength){
			return {
				plain: padding("", pinLength, "*"),
				encoded: pin,
				length: pinLength
			};
		})($xmlSMS.attr("pin"), parseInt($xmlSMS.attr("pin_len"), 10));

		var $xmlADMIN = $xmlSMS.find("> ADMIN");
		if($xmlADMIN.length > 0){
			this.pool.smsCommands.enable = true;
			this.pool.smsCommands.allowAccessPhone.enable = $xmlADMIN.attr("skip_check") != "1" ? true : false;

			var $xmlA = $xmlSMS.find("> ADMIN > A");
			for(var i = 0; i < $xmlA.length; i++){
				this.pool.smsCommands.allowAccessPhone.numbers.push($($xmlA[i]).text());
			}

			var $xmlQ = $xmlSMS.find("> QUICK_CMD > Q");
			for(var i = 0; i < $xmlQ.length; i++){
				this.pool.smsCommands.quickCommands.push({
					"customizeCommand": $($xmlQ[i]).attr("cmd"),
					"originalCommand": $($xmlQ[i]).attr("type") + ":" + $($xmlQ[i]).text()
				});
			}
		}
		else{
			this.pool.smsCommands.enable = false;
		}

		var $xmlS = $xmlSMS.find("> S");
		var maxKey = 0;
		for(var i = 0; i < $xmlS.length; i++){
			var key = parseInt($($xmlS[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var smsAlarm = this.createSMSAlarm({
				"name": $($xmlS[i]).attr("nickname"),
				"description": $($xmlS[i]).attr("desc"),
				"unicode": $($xmlS[i]).attr("unicode") == "8" ? true : false,
				"message": $($xmlS[i]).find("> MSG:first").text(),
				"phoneNumbers": (function($xmlS){
					var phoneNumbers = [];
					var $xmlNUM = $xmlS.find("> NUM");
					for(var i = 0; i < $xmlNUM.length; i++){
						phoneNumbers.push($($xmlNUM[i]).text());
					}
					return phoneNumbers;
				})($($xmlS[i]))
			});

			this.setSMSAlarm(key, smsAlarm);
		}

		this.pool.key = ++maxKey;
	}
};