WISE.managers.messengerManager.encodeXMLObject = function(xmlDoc){
    if(this.pool.enable == true){
        var xmlFB_MESSENGER = xmlDoc.createElement("FB_MESSENGER");
        //xmlFB_MESSENGER.setAttribute("token", this.pool.token);

        // Page
        for(var key in this.pool.pages){
            var page = this.pool.pages[key];
            xmlFB_MESSENGER.setAttribute("token", page.token);
			break;
        }

        // Message
        var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

        for(var key in this.pool.messages){
            var message = this.pool.messages[key];
            var xmlM = xmlDoc.createElement("M");

            xmlM.setAttribute("idx", message.index);
            xmlM.setAttribute("nickname", message.name);

            if(message.description != ""){
                xmlM.setAttribute("desc", message.description);
            }

            xmlM.appendChild(xmlDoc.createTextNode(message.content));

            xmlMESSAGE.appendChild(xmlM);
        }

        if(xmlMESSAGE.childNodes.length > 0){
            xmlFB_MESSENGER.appendChild(xmlMESSAGE);
        }

        // FTP Server
        var xmlSENDBOX = null;
        var systemManager = WISE.managers.systemManager;
		var server = systemManager.pool.ftpServer;

        try{
            if(server.messenger.enable == true){
				xmlSENDBOX = xmlDoc.createElement("SENDBOX");
    			xmlSENDBOX.appendChild(xmlDoc.createTextNode(server.messenger.content));
            }
        }
        catch(error){}

        // IP Camera
        var xmlCAMERA = xmlDoc.createElement("CAMERA");
        var counter = 0;

        var moduleManager = WISE.managers.moduleManager;
        for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
            if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

            for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
                if(typeof(modules[moduleIndex]) == "undefined"){continue;}

                try{
                    if(modules[moduleIndex].messenger.enable == true){
                		var xmlC = xmlDoc.createElement("C");
                        xmlC.setAttribute("camera_idx", moduleIndex + 1);
                        xmlC.setAttribute("idx", ++counter);

            			var xmlMSG = xmlDoc.createElement("MSG");
            			xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].messenger.content));
                   		xmlC.appendChild(xmlMSG);

                    	xmlCAMERA.appendChild(xmlC);
                    }
                }
                catch(error){}
            }
        }

        // CGI Server
        var xmlCGI_SERVER = xmlDoc.createElement("CGI_SERVER");
        var cgiManager = WISE.managers.cgiManager;

        for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
            if(typeof(servers[sourceIndex]) == "undefined"){continue;}

            try{
                if(servers[sourceIndex].messenger.enable == true){
            		var xmlC = xmlDoc.createElement("C");
                    xmlC.setAttribute("idx", servers[sourceIndex].index);

        			var xmlMSG = xmlDoc.createElement("MSG");
        			xmlMSG.appendChild(xmlDoc.createTextNode(servers[sourceIndex].messenger.content));
               		xmlC.appendChild(xmlMSG);

	                xmlCGI_SERVER.appendChild(xmlC);
                }
            }
            catch(error){}
        }

        // LINK
        var xmlLINK = xmlDoc.createElement("LINK");

        if(xmlSENDBOX != null){
            xmlLINK.appendChild(xmlSENDBOX);
        }

        if(xmlCAMERA.childNodes.length > 0){
            xmlLINK.appendChild(xmlCAMERA);
        }

        if(xmlCGI_SERVER.childNodes.length > 0){
            xmlLINK.appendChild(xmlCGI_SERVER);
        }

        if(xmlSENDBOX != null || xmlCAMERA.childNodes.length > 0 || xmlCGI_SERVER.childNodes.length > 0){
            xmlFB_MESSENGER.appendChild(xmlLINK);
        }

        // 
        if(xmlFB_MESSENGER.childNodes.length > 0){
            for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
                if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
                    xmlDoc.documentElement.childNodes[i].appendChild(xmlFB_MESSENGER);
                    break;
                }
            }
        } 
    }
};

WISE.managers.messengerManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.pages){
		this.pool.pages[key].index = ++index;
	}
    
    index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};