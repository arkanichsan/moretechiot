$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"internalRegister": "内部缓存器",
		"local": "本机",
		"remote": "远程",
		"bit": "位元"
	}
});