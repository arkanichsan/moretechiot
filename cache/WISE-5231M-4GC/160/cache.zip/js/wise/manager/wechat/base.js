WISE.managers.weChatManager = (function(){
	return new function() {
		this.pool = {
            enable: false,
            corpId: "",
            applications: {},
            applicationKey: 0,
			messages: {},
			messageKey: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};

		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
        this.maxApplicationAmount = 12;
		this.maxMessageAmount = 12;

        this.createApplication = function(settings){
			var application = $.extend(true, {
				"index": 0,
				"agentId": "",
				"secret": ""
			}, settings);

			return application;
		};

		this.addApplication = function(application){
			var retKey = this.pool.applicationKey;
			this.pool.applications[this.pool.applicationKey++] = application;
			return retKey;
		};

		this.removeApplication = function(key){
			delete this.pool.applications[key];
		};

		this.getApplication = function(key){
			if(typeof(this.pool.applications[key]) != "undefined"){
				return this.pool.applications[key];
			}
			else{
				return null;
			}
		};

		this.setApplication = function(key, application){
			this.pool.applications[key] = application;
		};

		this.getApplications = function(){
			return this.pool.applications;
		};
        
        this.createMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"applications": [],
				"content": ""
			}, settings);

			return message;
		};

		this.addMessage = function(message){
			var retKey = this.pool.messageKey;
			this.pool.messages[this.pool.messageKey++] = message;
			return retKey;
		};

		this.removeMessage = function(key){
			delete this.pool.messages[key];
		};

		this.getMessage = function(key){
			if(typeof(this.pool.messages[key]) != "undefined"){
				return this.pool.messages[key];
			}
			else{
				return null;
			}
		};

		this.setMessage = function(key, message){
			this.pool.messages[key] = message;
		};

		this.getMessages = function(){
			return this.pool.messages;
		};
	};
})();
