$.extend(true, Lang, {
	"js/wise/manager/ping/rule/object.js": {
		"failed": "失敗"
	}
});