WISE.managers.moduleManager = (function(){
	return new function() {
		this.pool = {
			"interfaces": {
				"onboard": [],
				"comport": [],
				"network": []
			},

			"modulesKey": {}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.totalIOModuleAmount = 48;//normal I/O module amount
		this.totalExtendedModuleAmount = 0;//like power meter...etc

		this.comportModuleMaxAddress = 128;
		this.modbusTableMaxLength = 500;//How many modbus table space is allocated for each module.

		this.createInterface = function(type, name, modbusTableStartAddress, maxModuleAmount){
			if(type == "onboard"){
				return {
					"type": type,//onboard, comport232, comport485, network
					"name": name,
					"modbusTableStartAddress": modbusTableStartAddress,
					"protocol": null,//xw, xv
					"modules": [],
					"xw":{
						"modules": []
					},
					"xv":{
						"modules": []
					}
				};
			}
			else if(type == "comport232"){
				return {
					"type": type,
					"name": name,
					"protocol": null,//null, hmi
					"baudrate": 9600,
					"parity": 0,
					"stopbits": 1,
					"modules": [],
					"hmi": {}
				};
			}
			else if(type == "comport485"){
				return {
					"type": type,
					"name": name,
					"modbusTableStartAddress": modbusTableStartAddress,
					"protocol": null,//null, dcon, modbusRTU, hmi
					"baudrate": 9600,
					"parity": 0,//0:none, 1:odd, 2:even
					"stopbits": 1,
					"modules": [],
					"maxModuleAmount": maxModuleAmount,
					"dcon": {
						"timeout": 1000,
						"checksum": 0,
						"modules": []
					},
					"modbusRTU": {
						//"silentInterval": 48,
						"silentInterval": 200,
						"modules": []
					},
					"hmi": {}
				};
			}
			else if(type == "network"){
				return {
					"type": type,
					"name": name,
					"modbusTableStartAddress": modbusTableStartAddress,
					"protocol": /*null*/"modbusTCP",//let lan always enable
					"modules": [],
					"maxModuleAmount": maxModuleAmount,
					"modbusTCP": {
						"modules": []
					}
				};
			}
		};

		this.icpdasModule = {
			"unit": {
				0:"°C",
				1:"°F",
				2:"mV",
				3:"V",
				4:"mA",
				5:"A",

				/*for DL*/
				6:"%",
				7:"ppm",

				/*for unknow*/
				9999:""
			},

			"aiTypeInfomation": {/* typeCode:[prefix, min, max, unit(0:°C, 1:°F, 2:mV, 3:V, 4:mA, 5:A, 6:%, 7:°C, 8:°F(6 ~ 8 for DL)), HEX min, HEX max] */
				//Voltage
				/* 00 */  0: ["",  -15,  15, 2],
				/* 01 */  1: ["",  -50,  50, 2],
				/* 02 */  2: ["", -100, 100, 2],
				/* 0C */ 12: ["", -150, 150, 2],
				/* 03 */  3: ["", -500, 500, 2],//7018Z
				/* 0B */ 11: ["", -500, 500, 2],//7017,7019
				/* 04 */  4: ["",   -1,   1, 3],//7018Z
				/* 0A */ 10: ["",   -1,   1, 3],//7017,7019
				/* 05 */  5: ["", -2.5, 2.5, 3],
				/* 09 */  9: ["",   -5,   5, 3],
				/* 08 */  8: ["",  -10,  10, 3],
				/* 1C */ 28: ["",  -50,  50, 3],
				/* 1B */ 27: ["", -150, 150, 3],

				//Current
				/* 1A */ 26: ["",    0,  20, 4],
				/* 07 */  7: ["",    4,  20, 4],
				/* 06 */  6: ["",  -20,  20, 4],
				/* 0D */ 13: ["",  -20,  20, 4],

				//Thermocouple
				/* 0E */ 14: ["T/C Type J",           -210,  760, 0],
				/* 0F */ 15: ["T/C Type K",           -270, 1372, 0],
				/* 10 */ 16: ["T/C Type T",           -270,  400, 0],
				/* 11 */ 17: ["T/C Type E",           -270, 1000, 0],
				/* 12 */ 18: ["T/C Type R",              0, 1768, 0],
				/* 13 */ 19: ["T/C Type S",              0, 1768, 0],
				/* 14 */ 20: ["T/C Type B",              0, 1820, 0],
				/* 15 */ 21: ["T/C Type N",           -270, 1300, 0],
				/* 16 */ 22: ["T/C Type C",              0, 2320, 0],
				/* 17 */ 23: ["T/C Type L",           -200,  800, 0],
				/* 18 */ 24: ["T/C Type M",           -200,  100, 0],
				/* 19 */ 25: ["T/C Type L(DIN43710)", -200,  900, 0],
                         
				//RTD    
				/* 21 */ 33: ["Pt 100, α= 0.00385",     0, 100, 0],
				/* 22 */ 34: ["Pt 100, α= 0.00385",     0, 200, 0],
				/* 23 */ 35: ["Pt 100, α= 0.00385",     0, 600, 0],
				/* 20 */ 32: ["Pt 100, α= 0.00385",  -100, 100, 0],
				/* 2E */ 46: ["Pt 100, α= 0.00385",  -200, 200, 0],
				/* 80 */128: ["Pt 100, α= 0.00385",  -200, 600, 0],
				/* 24 */ 36: ["Pt 100, α= 0.003916", -100, 100, 0],
				/* 25 */ 37: ["Pt 100, α= 0.003916",    0, 100, 0],
				/* 26 */ 38: ["Pt 100, α= 0.003916",    0, 200, 0],
				/* 27 */ 39: ["Pt 100, α= 0.003916",    0, 600, 0],
				/* 2F */ 47: ["Pt 100, α= 0.003916", -200, 200, 0],
				/* 81 */129: ["Pt 100, α= 0.003916", -200, 600, 0],
				/* 2A */ 42: ["Pt 1000, α= 0.00385", -200, 600, 0],
				/* 83 */131: ["Nickel 100", -60, 180, 0],
				/* 29 */ 41: ["Nickel 120",   0, 100, 0],
				/* 28 */ 40: ["Nickel 120", -80, 100, 0],
				/* 82 */130: ["Cu 50 @ 0 °C",                -5, 150, 0],
				/* 2B */ 43: ["Cu 100 @ 0 °C, α= 0.00421",  -20, 150, 0],
				/* 2C */ 44: ["Cu 100 @ 25 °C, α= 0.00427",   0, 200, 0],
				/* 2D */ 45: ["Cu 1000 @ 0 °C, α= 0.00421", -20, 150, 0],
                         
				//Thermistor
				/* 61 */ 64: ["", -40, 80, 0],
				/* 60 */ 96: ["PreCon Type III 10K@25°C", -30, 240, 1],
				/* 61 */ 97: ["Fenwell Type U 2K@25°C", -50, 150, 0],
				/* 62 */ 98: ["Fenwell Type U 2K@25°C",   0, 150, 0],
				/* 63 */ 99: ["YSI L Mix 100@25°C",   -80, 100, 0],
				/* 64 */100: ["YSI L Mix 300@25°C",   -80, 100, 0],
				/* 65 */101: ["YSI L Mix 1000@25°C",  -70, 100, 0],
				/* 66 */102: ["YSI B Mix 2252@25°C",  -50, 150, 0],
				/* 67 */103: ["YSI B Mix 3000@25°C",  -40, 150, 0],
				/* 68 */104: ["YSI B Mix 5000@25°C",  -40, 150, 0],
				/* 69 */105: ["YSI B Mix 6000@25°C",  -30, 150, 0],
				/* 6A */106: ["YSI B Mix 10000@25°C", -30, 150, 0],
				/* 6B */107: ["YSI H Mix 10000@25°C", -30, 150, 0],
				/* 6C */108: ["YSI H Mix 30000@25°C", -10, 200, 0],

				/*for special modules, ex: DL modules*/
				1003: ["",   0,  100, 6],
				1001: ["",   0,   80, 0],
				1002: ["",   0,  144, 1],
				1000: ["",   0, 9999, 7],
				1004: ["", -10,   50, 0],
				1005: ["",  14,  122, 1],
				1006: ["", -65,   50, 0],
				1007: ["", -85,  122, 1],

				/*unknow for modbus tcp module*/
				9999: ["", -9999,  9999, 9999]
			},

			"aoTypeInfomation": {/* typeCode:[min, max, unit(2:mV, 3:V, 4:mA, 5:A)] */
				//Voltage
				/* 04 */ 4: [  0,  5, 3],//7022
				/* 34 */52: [  0,  5, 3],
				/* 02 */ 2: [  0, 10, 3],//7022
				/* 32 */50: [  0, 10, 3],
				/* 05 */ 5: [ -5,  5, 3],
				/* 35 */53: [ -5,  5, 3],
				/* 03 */ 3: [-10, 10, 3],
				/* 33 */51: [-10, 10, 3],
                            
				//Current   
				/* 00 */ 0: [  0, 20, 4],//7022
				/* 30 */48: [  0, 20, 4],
				/* 01 */ 1: [  4, 20, 4],//7022
				/* 31 */49: [  4, 20, 4],

				/*unknow for modbus tcp module*/
				9999: [  -9999, 9999, 9999]
			},

			"onboardModuleInformation": {
				"XWBoard":{
					"107":{
						"0":[["XW107","XW107i"],[8,8,0,0],[],[],,[]]
					},
					"110":{
						"0":[["XW110i"],[16,0,0,0],[],[],,[]]
					},
					"304":{
						"0":[["XW304"],[4,4,6,1],[9],[53],,[]]
					},
					"310":{
						"0":[["XW310"],[3,3,4,2],[8],[51],,[]],
						"C":[["XW310C"],[3,3,4,2],[26],[48],,[]]
					}
				},
				"XVBoard": {
					"107":{
						"0":[["XV107","XV107A"],[8,8,0,0],[],[],,[]]
					},
					"110":{
						"0":[["XV110"],[16,0,0,0],[],[],,[]]
					},
					"111":{
						"0":[["XV111","XV111A"],[0,16,0,0],[],[],,[]]
					},
					"116":{
						"0":[["XV116"],[5,6,0,0],[],[],,[]]
					},
					"306":{
						"0":[["XV306"],[4,4,4,0],[10,5,9,[8],26,7,6],[],,[]]
					},
					"307":{
						"0":[["XV307"],[4,4,0,2],[],[4,[2],5,3,0,1],,[]]
					},
					"308":{
						"0":[["XV308"],[8,8,8,0],[10,5,9,[8],26,7,6],[],,[]]
					},
					"310":{
						"0":[["XV310"],[4,4,4,2],[10,5,9,[8],26,7,6],[4,[2],5,3,0,1],,[]]
					}
				}
			},

			"remoteModuleInformation": {
/*
	modelName: [],
	protocol: 0,
	channel: {
		DI: {
			amount: 0,
			name: [],
			modbus: {
				model: "CO",
				address: 0,
				counter: {
					data: {
						model: "RI",
						address: 96,
						type: 0
					},
					reset: {
						model: "CO",
						address: 265
					}
				}
			}
		},
		DO: {
			amount: 0,
			name: [],
			modbus: {
				model: "CO",
				address: 0
			}
		},
		AI: {
			amount: 0,
			type: {
				code: [],
				default: 0
			},
			name: [],
			modbus: {
				model: "RI",
				address: 96,
				type: 0
			}
		},
		AO: {
			amount: 0,
			type: {
				code: [],
				default: 0
			},
			name: [],
			modbus: {
				model: "RO",
				address: 96,
				type: 0
			}
		}
	}
*/
				//I-7000
				"I7K": {
					/*
					mainType:{
						subType: [
							[module name, ...],
							[DI amount, DO amount, AI amount, AO amount],
							[useable AI type code(decimal), ...],
							[useable AO type code(decimal), ...],
							Protocol(bit0: DCON, bit1: Modbus RTU),
							[
								[customized DI channel name, ...],
								[customized DO channel name, ...],
								[customized AI channel name, ...],
								[customized AO channel name, ...]
							],
							[
								[
									DI channel Modbus model type(CI/CO/RI/RO),
									DI channel Modbus start address,
									[
										DO channel Modbus model type,
										DO channel Modbus start address
										DO channel Modbus data type(0 ~ 5)
									],
								],
								[
									DO channel Modbus model type,
									DO channel Modbus start address,
									[
										DO channel Modbus model type,
										DO channel Modbus start address
										DO channel Modbus data type
									],
								],
								[
									AI channel Modbus model type,
									AI channel Modbus start address,
									AI channel Modbus data type
								],
								[
									AO channel Modbus model type,
									AO channel Modbus start address,
									AO channel Modbus data type
								],
							],
							Internal Register amount
						]
					}
					*/
					"7005":{
						"0":[["I-7005"],[0,6,8,0],[96,97,98,99,100,101,102,103,104,105,106,107,108],[],1,[]]
					},
					"7011":{
						"0":[["I-7011","I-7011D"],[1,2,1,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22],[],1,[]],
						"1":[["I-7011P","I-7011PD"],[1,2,1,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22,23,24],[],1,[]]
					},
					"7012":{
						"0":[["I-7012","I-7012D","I-7012F","I-7012FD"],[1,2,1,0],[12,11,10,9,8,13],[],1,[]]
					},
					"7013":{
						"0":[["I-7013","I-7013D"],[0,0,1,0],[33,34,35,32,46,128,36,37,38,39,47,129,42,41,40,130],[],1,[]]
					},
					"7014":{
						"0":[["I-7014D"],[1,2,1,0],[12,11,10,9,8,13],[],1,[]]
					},
					"7015":{
						"0":[["I-7015","I-7015P"],[0,0,6,0],[33,34,35,32,46,128,36,37,38,39,47,129,42,131,41,40,130,43,44,45],[],1,[]]
					},
					"7016":{
						"0":[["I-7016","I-7016D"],[1,4,2,1],[0,1,2,3,4,5,6],[50],1,[]],
						"1":[["I-7016P","I-7016PD"],[1,4,1,1],[0,1,2,3,4,5,6],[50],1,[]]
					},
					"7017":{
						"0":[["I-7017","I-7017F","I-7017R"],[0,0,8,0],[12,11,10,9,8,26,7,13],[],1,[]],
						"1":[["I-7017C","I-7017FC","I-7017RC"],[0,0,8,0],[26,7,13],[],1,[]],
						"2":[["I-7017R-A5"],[0,0,8,0],[28,27],[],1,[]],
						"3":[["I-7017Z"],[0,0,10,0],[12,11,10,9,8,26,7,13],[],1,[]]
					},
					"7018":{
						"0":[["I-7018","I-7018BL"],[0,0,8,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22],[],1,[]],
						"1":[["I-7018P"],[0,0,8,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22,23,24],[],1,[]],
						"2":[["I-7018Z"],[0,0,10,0],[0,1,2,3,4,5,26,7,6,14,15,16,17,18,19,20,21,22,23,24,25],[],1,[]],
						"3":[["I-7018R"],[0,0,8,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22,23,24,25],[],1,[]]
					},
					"7019":{
						"0":[["I-7019R"],[0,0,8,0],[0,1,2,12,3,4,5,9,8,26,7,6,14,15,16,17,18,19,20,21,22,23,24,25],[],1,[]]
					},
					"7021":{
						"0":[["I-7021","I-7021P"],[0,0,0,1],[],[50,48,49],1,[]]
					},
					"7022":{
						"0":[["I-7022"],[0,0,0,2],[],[4,2,0,1],1,[]]
					},
					"7024":{
						"0":[["I-7024"],[0,0,0,4],[],[52,50,53,51,48,49],1,[]],
						"1":[["I-7024R"],[5,0,0,4],[],[52,50,53,51,48,49],1,[]]
					},
					"7033":{
						"0":[["I-7033","I-7033D"],[0,0,3,0],[33,34,35,32,46,128,36,37,38,39,47,129,42,41,40,130],[],1,[]]
					},
					"7041":{
						"0":[["I-7041","I-7041D","I-7041P","I-7041PD"],[14,0,0,0],[],[],1,[]]
					},
					"7042":{
						"0":[["I-7042","I-7042D"],[0,13,0,0],[],[],1,[]]
					},
					"7043":{
						"0":[["I-7043","I-7043D"],[0,16,0,0],[],[],1,[]]
					},
					"7044":{
						"0":[["I-7044","I-7044D"],[4,8,0,0],[],[],1,[]]
					},
					"7045":{
						"0":[["I-7045","I-7045D","I-7045-NPN","I-7045D-NPN"],[0,16,0,0],[],[],1,[]]
					},
					"7050":{
						"0":[["I-7050","I-7050D","I-7050A","I-7050AD"],[7,8,0,0],[],[],1,[]]
					},
					"7051":{
						"0":[["I-7051","I-7051D"],[16,0,0,0],[],[],1,[]]
					},
					"7052":{
						"0":[["I-7052","I-7052D"],[8,0,0,0],[],[],1,[]]
					},
					"7053":{
						"0":[["I-7053_FG","I-7053D_FG"],[16,0,0,0],[],[],1,[]]
					},
					"7055":{
						"0":[["I-7055","I-7055D","I-7055-NPN","I-7055D-NPN"],[8,8,0,0],[],[],1,[]]
					},
					"7058":{
						"0":[["I-7058","I-7058D"],[8,0,0,0],[],[],1,[]]
					},
					"7059":{
						"0":[["I-7059","I-7059D"],[8,0,0,0],[],[],1,[]]
					},
					"7060":{
						"0":[["I-7060","I-7060D"],[4,4,0,0],[],[],1,[]]
					},
					"7061":{
						"0":[["I-7061","I-7061D"],[0,12,0,0],[],[],1,[]]
					},
					"7063":{
						"0":[["I-7063","I-7063D","I-7063A","I-7063AD","I-7063B","I-7063BD"],[8,3,0,0],[],[],1,[]]
					},
					"7065":{
						"0":[["I-7065","I-7065D","I-7065A","I-7065AD","I-7065B","I-7065BD"],[4,5,0,0],[],[],1,[]]
					},
					"7066":{
						"0":[["I-7066","I-7066D"],[0,7,0,0],[],[],1,[]]
					},
					"7067":{
						"0":[["I-7067","I-7067D"],[0,7,0,0],[],[],1,[]]
					},
					"7080":{
						"0":[["I-7080","I-7080D","I-7080B","I-7080BD"],[2,2,0,0],[],[],1,[]]
					},
					/*
					"7083":{
						"0":[["I-7083","I-7083D","I-7083B","I-7083BD"],[3,0,0,0],[],[],1,[]]
					},
					*/
					"7088":{
						"0":[["I-7088"],[8,8,0,0],[],[],1,[]]
					}
				},

				//M-7000 module
				"M7K": {
					"7002":{
						"0":[["M-7002"],[5,4,4,0],[12,11,10,9,8,26,7,13],[],2,[],[["CI",32,["RI",96,1],["CO",265]],["CO",0],["RI",0,2],[]]]
					},
					//"7003":{
					//	"0":[["M-7003"],[0,4,8,0],[12,11,10,9,8,26,7,13],[],2,[],[[],["CO",0],["RI",0,2],[]]]
					//},
					"7005":{
						"0":[["M-7005"],[0,6,8,0],[96,97,98,99,100,101,102,103,104,105,106,107,108],[],2,[],[[],["CO",0],["RI",0,2],[]]]
					},
					"7011":{
						"0":[["M-7011"],[1,2,1,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22],[],2,[],[["CI",0,["RI",96,1],["CO",265]],["CO",32],["RI",0,2],[]]],
					},
					"7015":{
						"0":[["M-7015","M-7015P"],[0,0,6,0],[33,34,35,32,46,128,36,37,38,39,47,129,42,131,41,40,130,43,44,45],[],2,[],[[],[],["RI",0,2],[]]]
					},
					"7016":{
						"0":[["M-7016"],[1,4,2,1],[0,1,2,3,4,5,6],[50],2,[],[["CO",0,["RI",96,1],["CO",265]],["CO",32],["RI",0,2],["RO",32,2]]]
					},
					"7017":{
						"0":[["M-7017","M-7017R"],[0,0,8,0],[12,11,10,9,8,26,7,13],[],2,[],[[],[],["RI",0,2],[]]],
						"1":[["M-7017C","M-7017RC"],[0,0,8,0],[26,7,13],[],2,[],[[],[],["RI",0,2],[]]],
						"2":[["M-7017R-A5"],[0,0,8,0],[28,27],[],2,[],[[],[],["RI",0,2],[]]],
						"3":[["M-7017Z"],[0,0,10,0],[12,11,10,9,8,26,7,13],[],2,[],[[],[],["RI",0,2],[]]]
					},
					"7018":{
						"0":[["M-7018"],[0,0,8,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22],[],2,[],[[],[],["RI",0,2],[]]],
						"1":[["M-7018R"],[0,0,8,0],[0,1,2,3,4,5,6,14,15,16,17,18,19,20,21,22,23,24,25],[],2,[],[[],[],["RI",0,2],[]]],
						"2":[["M-7018Z"],[0,0,10,0],[0,1,2,3,4,5,26,7,6,14,15,16,17,18,19,20,21,22,23,24,25],[],2,[],[[],[],["RI",0,2],[]]]
					},
					"7019":{
						"0":[["M-7019R"],[0,0,8,0],[0,1,2,12,3,4,5,9,8,26,7,6,14,15,16,17,18,19,20,21,22,23,24,25],[],2,[],[[],[],["RI",0,2],[]]],
						"1":[["M-7019Z"],[0,0,10,0],[0,1,2,12,3,4,5,9,8,26,7,6,14,15,16,17,18,19,20,21,22,23,24,25],[],2,[],[[],[],["RI",0,2],[]]]
					},
					"7022":{
						"0":[["M-7022"],[0,0,0,2],[],[4,2,0,1],2,[],[[],[],[],["RO",0,2]]]
					},
					"7024":{
						"0":[["M-7024"],[0,0,0,4],[],[52,50,53,51,48,49],2,[],[[],[],[],["RO",0,2]]],
						"1":[["M-7024R"],[5,0,0,4],[],[52,50,53,51,48,49],2,[],[["CO",32,["RO",128,1],["CO",512]],[],[],["RO",0,2]]],
						"2":[["M-7024U"],[4,4,0,4],[],[4,2,5,3,0,1],2,[],[["CI",32,["RI",128,1],["CO",512]],["CO",0],[],["RO",0,2]]]
					},
					"7026":{
						"0":[["M-7026"],[3,3,6,2],[12,11,10,9,8,26,7,13],[4,2,5,3,0,1],2,[],[["CI",32,["RI",128,1],["CO",512]],["CO",0],["RI",0,2],["RO",32,2]]]
					},
					//"7033":{
					//	"0":[["M-7033"],[0,0,3,0],[33,34,35,32,46,128,36,37,38,39,47,129,42,41,40,130],[],2,[],[[],[],["RI",0,2],[]]]
					//},
					"7041":{
						"0":[["M-7041","M-7041P","M-7041-A5"],[14,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7043":{
						"0":[["M-7043"],[0,16,0,0],[],[],2,[],[[],["CO",0],[],[]]]
					},
					"7045":{
						"0":[["M-7045","M-7045-NPN"],[0,16,0,0],[],[],2,[],[[],["CO",0],[],[]]]
					},
					"7050":{
						"0":[["M-7050"],[7,8,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"7051":{
						"0":[["M-7051"],[16,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7052":{
						"0":[["M-7052"],[8,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7053":{
						"0":[["M-7053"],[16,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7055":{
						"0":[["M-7055","M-7055-NPN"],[8,8,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"7058":{
						"0":[["M-7058"],[8,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7059":{
						"0":[["M-7059"],[8,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7060":{
						"0":[["M-7060","M-7060P"],[4,4,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"7061":{
						"0":[["M-7061"],[0,12,0,0],[],[],2,[],[[],["CO",0],[],[]]]
					},
					"7065":{
						"0":[["M-7065","M-7065B"],[4,5,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"7066":{
						"0":[["M-7066P"],[0,7,0,0],[],[],2,[],[[],["CO",0],[],[]]]
					},
					"7067":{
						"0":[["M-7067"],[0,7,0,0],[],[],2,[],[[],["CO",0],[],[]]]
					},
					"7068":{
						"0":[["M-7068"],[8,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7069":{
						"0":[["M-7069"],[8,0,0,0],[],[],2,[],[["CO",32,["RI",0,1],["CO",512]],[],[],[]]]
					},
					"7080":{
						"0":[["M-7080","M-7080B"],[2,2,0,0],[],[],2,[],[["CO",64,["RO",0,4],["CO",132]],["CO",0],[],[]]]//fake DI address
					},
					"7084":{
						"0":[["M-7084"],[8,0,0,0],[],[],2,[],[["CO",64,["RI",0,4],["CO",512]],[],[],[]]]//fake DI address
					},
					"7088":{
						"0":[["M-7088"],[8,8,0,0],[],[],2,[],[["CI",32,["RI",0,4],["CO",265]],["CO",0],[],[]]]
					}
				},

				//tM
				"tM":{
					"0":{
						"9110":[["tM-AD5"],[0,0,5,0],[10,5,9,8],[],2,[],[[],[],["RI",0,2],[]]],//
						"9111":[["tM-AD5C"],[0,0,5,0],[26,7,6],[],2,[],[[],[],["RI",0,2],[]]],//m
						"9120":[["tM-AD8"],[0,0,8,0],[11,10,5,9,8],[],2,[],[[],[],["RI",0,2],[]]],//
						"9121":[["tM-AD8C"],[0,0,8,0],[26,7,6],[],2,[],[[],[],["RI",0,2],[]]],//m
						"9130":[["tM-TH8"],[0,0,8,0],[96,97,98,99,100,101,102,103,104,105,106,107,108],[],2,[],[[],[],["RI",0,2],[]]],//
						"9210":[["tM-P4A4"],[4,4,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],[],[]]],
						"9211":[["tM-P4C4"],[4,4,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],[],[]]],
						"9220":[["tM-C8"],[0,8,0,0],[],[],2,[],[[],["CO",0],[],[]]],
						"9230":[["tM-P8"],[8,0,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],[],[],[]]],
						"9310":[["tM-P3R3"],[3,3,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],[],[]]],
						"9311":[["tM-P3POR3"],[3,3,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],[],[]]],
						"9320":[["tM-R5"],[0,5,0,0],[],[],2,[],[[],["CO",0],[],[]]],
						"9410":[["tM-DA1P1R1"],[1,1,0,1],[],[4,2,0,1],2,[],[["CI",32,["RI",128,1],["CO",512]],["CO",0],[],["RO",32,2]]],
						"9420":[["tM-AD4P2C2"],[2,2,4,0],[10,5,9,8,26,7,6],[],2,[],[["CI",32,["RI",128,1],["CO",512]],["CO",0],["RI",0,2],[]]]
					}
				},

				//LC module
				"LC": {
					"101":{
						"0":[["LC-101"],[1,1,0,0],[],[],2,[],[["CI",31,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"103":{
						"0":[["LC-103"],[1,1,0,0],[],[],2,[],[["CI",0,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"131":{
						"0":[["LC-131"],[1,1,0,0],[],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],[],[]]]
					},
					"221":{
						"0":[["LC-221"],[1,1,0,1],[],[4,2,0,1],2,[],[["CI",32,["RI",128,1],["CO",512]],["CO",0],[],["RO",32,2]]]
					}
				},

				//SC
				"SC": {
					"4104":{
						"0":[["SC-4104-W1"],[1,4,1,0],[64],[],2,[],[["CI",32,["RI",0,1],["CO",512]],["CO",0],["RI",0,2],[]]]//fake DI Counter and DI Counter Reset
					}
				},

				//DL
				"DL":{
					"100":{
						"0":[["DL-100"],[0,0,3,0],[1003,1001,1002],[],3,[[],[],["<#Lang['?'].humidity>","<#Lang['?'].celsiusTemperature>","<#Lang['?'].fahrenheitTemperature>"],[]],[[],[],["RI",0,2],[]]]
					},
					"300":{
						"0":[["DL-302"],[0,1,6,0],[1000,1003,1004,1005,1006,1007],[],2,[[],[],["CO2","<#Lang['?'].humidity>","<#Lang['?'].celsiusTemperature>","<#Lang['?'].fahrenheitTemperature>","<#Lang['?'].celsiusDewPointTemperature>","<#Lang['?'].fahrenheitDewPointTemperature>"],[]],[[],["CO",0],["RI",0,2],[]]]
					}
				},

				//ET
				"ET":{
					"7002":{
						"0":[["ET-7002||(P)ET-7002","ET-7202||(P)ET-7202"],[6,3,3,0],[9999],[],4,[],[["CI",0,["RI",32,4],["CO",34]],["CO",0],["RI",0,2],[]]]
					},
					"7005":{
						"0":[["ET-7005||(P)ET-7005"],[0,4,8,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]]
					},
					"7015":{
						"0":[["ET-7015||(P)ET-7015","ET-7215||(P)ET-7215"],[0,0,7,0],[9999],[],4,[],[[],[],["RI",0,2],[]]]
					},
					"7016":{
						"0":[["ET-7016||(P)ET-7016"],[2,2,2,1],[9999],[9999],4,[],[["CI",0,["RI",32,4],["CO",34]],["CO",0],["RI",0,2],["RO",0,2]]]
					},
					"7017":{
						"0":[["ET-7017||(P)ET-7017","ET-7217||(P)ET-7217"],[0,4,8,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]],
						"1":[["ET-7017-10||(P)ET-7017-10","ET-7217-10||(P)ET-7217-10"],[0,0,10,0],[9999],[],4,[],[[],[],["RI",0,2],[]]]
					},
					"7018":{
						"0":[["ET-7018Z||(P)ET-7018Z"],[0,6,10,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]],
						"1":[["ET-7218Z||(P)ET-7218Z"],[0,3,10,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]]
					},
					"7019":{
						"0":[["ET-7019||(P)ET-7019"],[0,4,8,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]],
						"1":[["ET-7019Z||(P)ET-7019Z"],[0,6,10,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]],
						"2":[["ET-7219Z||(P)ET-7219Z"],[0,3,10,0],[9999],[],4,[],[[],["CO",0],["RI",0,2],[]]]
					},
					"7024":{
						"0":[["ET-7024||(P)ET-7024","ET-7224||(P)ET-7224"],[5,5,0,4],[],[9999],4,[],[["CI",0,["RI",32,4],["CO",34]],["CO",0],[],["RO",0,2]]]
					},
					"7026":{
						"0":[["ET-7026||(P)ET-7026","ET-7226||(P)ET-7226"],[2,2,6,2],[9999],[9999],4,[],[["CI",0,["RI",32,4],["CO",34]],["CO",0],["RI",0,2],["RO",0,2]]]
					},
					"7042":{
						"0":[["ET-7042||(P)ET-7042","ET-7242||(P)ET-7242"],[0,16,0,0],[],[],4,[],[[],["CO",0],[],[]]]
					},
					"7044":{
						"0":[["ET-7044||(P)ET-7044","ET-7244||(P)ET-7244"],[8,8,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7050":{
						"0":[["ET-7050||(P)ET-7050","ET-7250||(P)ET-7250"],[12,6,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7051":{
						"0":[["ET-7051||(P)ET-7051","ET-7251||(P)ET-7251"],[16,0,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],[],[],[]]]
					},
					"7052":{
						"0":[["ET-7052||(P)ET-7052","ET-7252||(P)ET-7252"],[8,8,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7053":{
						"0":[["ET-7053||(P)ET-7053","ET-7253||(P)ET-7253"],[16,0,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],[],[],[]]]
					},
					"7055":{
						"0":[["ET-7055||(P)ET-7055","ET-7255||(P)ET-7255"],[8,8,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7060":{
						"0":[["ET-7060||(P)ET-7060","ET-7260||(P)ET-7260"],[6,6,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7061":{
						"0":[["ET-7261||(P)ET-7261"],[0,11,0,0],[],[],4,[],[[],["CO",0],[],[]]]
					},
					"7065":{
						"0":[["ET-7065||(P)ET-7065"],[6,6,0,0],[],[],4,[],[["CI",0,["RI",16,4],["CO",34]],["CO",0],[],[]]]
					},
					"7066":{
						"0":[["ET-7066||(P)ET-7066"],[0,8,0,0],[],[],4,[],[[],["CO",0],[],[]]]
					},
					"7067":{
						"0":[["ET-7067||(P)ET-7067","ET-7267||(P)ET-7267"],[0,8,0,0],[],[],4,[],[[],["CO",0],[],[]]]
					}
				},

				"WF":{
					"2017":{
						"0":[["WF-2017"],[0,0,8,0],[9999],[],4,[],[[],[],["RI",0,2],[]]]
					},
					"2019":{
						"0":[["WF-2019"],[0,0,10,0],[9999],[],4,[],[[],[],["RI",0,2],[]]]
					},
					"2026":{
						"0":[["WF-2026"],[2,3,5,2],[9999],[9999],4,[],[["CI",0,["RI",50,4],["CO",10]],["CO",0],["RI",0,2],["RO",0,2]]]//fake DI Counter and DI Counter Reset
					},
					"2042":{
						"0":[["WF-2042"],[0,16,0,0],[],[],4,[],[[],["CO",0],[],[]]]
					},
					"2051":{
						"0":[["WF-2051"],[16,0,0,0],[],[],4,[],[["CI",0,["RI",50,4],["CO",10]],[],[],[]]]
					},
					"2055":{
						"0":[["WF-2055"],[8,8,0,0],[],[],4,[],[["CI",0,["RI",50,4],["CO",10]],["CO",0],[],[]]]
					},
					"2060":{
						"0":[["WF-2060"],[8,8,0,0],[],[],4,[],[["CI",0,["RI",50,4],["CO",10]],["CO",0],[],[]]]
					}
				},

				"WISE":{
					"7102":{
						"0":[["WISE-7102"],[6,3,3,0],[9999],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],["RI",20,5],[]],48]
					},
					"7105":{
						"0":[["WISE-7105"],[0,4,8,0],[9999],[],4,[],[[],["CO",20,["RI",80,1],[]],["RI",20,5],[]],48]
					},
					"7115":{
						"0":[["WISE-7115"],[0,0,7,0],[9999],[],4,[],[[],[],["RI",20,5],[]],48]
					},
					"7117":{
						"0":[["WISE-7117"],[0,4,8,0],[9999],[],4,[],[[],["CO",20,["RI",80,1],[]],["RI",20,5],[]],48]
					},
					"7118Z":{
						"0":[["WISE-7118Z"],[0,6,10,0],[9999],[],4,[],[[],["CO",20,["RI",80,1],[]],["RI",20,5],[]],48]
					},
					"7119":{
						"0":[["WISE-7119"],[0,4,8,0],[9999],[],4,[],[[],["CO",20,["RI",80,1],[]],["RI",20,5],[]],48]
					},
					"7126":{
						"0":[["WISE-7126"],[2,2,6,2],[9999],[9999],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],["RI",20,5],["RO",20,5]],48]
					},
					"7142":{
						"0":[["WISE-7142"],[0,16,0,0],[],[],4,[],[[],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7144":{
						"0":[["WISE-7144"],[8,8,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7150":{
						"0":[["WISE-7150"],[12,6,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7151":{
						"0":[["WISE-7151"],[16,0,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],[],[],[]],48]
					},
					"7152":{
						"0":[["WISE-7152"],[8,8,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7153":{
						"0":[["WISE-7153"],[16,0,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],[],[],[]],48]
					},
					"7160":{
						"0":[["WISE-7160"],[6,6,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7167":{
						"0":[["WISE-7167"],[0,8,0,0],[],[],4,[],[[],["CO",20,["RI",80,1],[]],[],[]],48]
					},
					"7255":{
						"0":[["WISE-7255"],[8,8,0,0],[],[],4,[],[["CI",20,["RI",60,1],[]],["CO",20,["RI",80,1],[]],[],[]],48]
					}
				},

				"IR":{
					"210":{
						"0":[["IR-210"],[0,0,0,1],[],[9999],2,[],[[],[],[],["RO",1103,4]]]
					},
					"712":{
						"0":[["IR-712"],[0,0,0,1],[],[9999],2,[],[[],[],[],["RO",1103,4]]],
						"1":[["IR-712A"],[0,0,0,1],[],[9999],2,[],[[],[],[],["RO",1103,4]]],
						"2":[["IR-712-MTCP"],[0,0,0,1],[],[9999],4,[],[[],[],[],["RO",1103,4]]]
					}
				}
			},

			"noDICounterModule": {
				"SC": {
					"4104":{
						"0": true
					}
				},
				"WF":{
					"2026": {
						"0": true
					}
				}
			},

			"noDICounterResetModule": {
				"SC": {
					"4104":{
						"0": true
					}
				},
				"WF":{
					"2026": {
						"0": true
					}
				},
				"WISE":{
					"7102":{
						"0": true
					},
					"7105":{
						"0": true
					},
					"7115":{
						"0": true
					},
					"7117":{
						"0": true
					},
					"7118Z":{
						"0": true
					},
					"7119":{
						"0": true
					},
					"7126":{
						"0": true
					},
					"7142":{
						"0": true
					},
					"7144":{
						"0": true
					},
					"7151":{
						"0": true
					},
					"7152":{
						"0": true
					},
					"7153":{
						"0": true
					},
					"7160":{
						"0": true
					},
					"7167":{
						"0": true
					},
					"7255":{
						"0": true
					}
				}
			},

			"irModuleInformation": {//[command amount, channel amount]
				"210":{
					"0":[36,6],
				},
				"712":{
					"0":[36,2],
					"1":[224,2],
					"2":[512,2]
				}
			},

			"singleEndedModule": {//the module moduleManager can switch single-ended mode
				"XWBoard":{
					"310":{
						"C": true
					}
				},
				"I7K":{
					"7017": {
						"3": true
					}
				},
				"M7K":{
					"7017": {
						"3": true
					}
				},
				"ET":{
					"7017":{
						"1": true
					}
				}
			},

			"singleAITypeModule": {//the module moduleManager type of all AI channel are same.
				"tM":{
					"0": {
						"110": true,
						"111": true,
						"120": true,
						"121": true
					}
				},
				"I7K":{
					"7016": {
						"0": true
					},
					"7017": {
						"0": true,
						"1": true,
						"2": true
					},
					"7018": {
						"0": true,
						"1": true
					},
					"7033": {
						"0": true
					}
				},
				"M7K":{
					"7016": {
						"0": true
					},
					"7017": {
						"0": true,
						"1": true,
						"2": true
					},
					"7018": {
						"0": true,
						"1": true
					},
					"7033": {
						"0": true
					}
				}
			},

			"singleAOTypeModule": {//the module moduleManager type of all AO channel are same.
				"I7K":{
					"7024": {
						"0": true,
						"1": true
					}
				},
				"M7K":{
					"7024": {
						"0": true,
						"1": true
					}
				}
			},

			"singleResetDICounterFlagModule": {//the M7K module only one flag to reset all DI counter, not include I7K, if need to support I7K must change rule encoder and power on reset
				"M7K":{
					"7002": {
						"0": true
					},
					"7011": {
						"0": true
					},
					"7016": {
						"0": true
					},
					"7088": {
						"0": true
					}
				}
			},

			"dioSwitchableModule": {
				"XVBoard":{
					"308":{
						"0": true
					}
				}
			},

			"diCounterModule": {//the DI of below modules can't use in rule
				"I7K":{
					"7080": {
						"0": true
					},
					"7083": {
						"0": true
					}
				},
				"M7K":{
					"7080": {
						"0": true
					},
					"7084": {
						"0": true
					}
				}
			},

			"longDICounterModule": {//the DI counters of below modules are 32-bit wide
				"XVBoard":{
					"107": {
						"0": true
					},
					"110": {
						"0": true
					},
					"116": {
						"0": true
					},
					"306": {
						"0": true
					},
					"307": {
						"0": true
					},
					"308": {
						"0": true
					},
					"310": {
						"0": true
					}
				},
				"I7K":{
					"7080": {
						"0": true
					},
					"7083": {
						"0": true
					},
					"7088": {
						"0": true
					}
				},
				"M7K":{
					"7080": {
						"0": true
					},
					"7084": {
						"0": true
					},
					"7088": {
						"0": true
					}
				},
				"ET":{
					"7002": {
						"0": true
					},
					"7016": {
						"0": true
					},
					"7024": {
						"0": true
					},
					"7026": {
						"0": true
					},
					"7044": {
						"0": true
					},
					"7050": {
						"0": true
					},
					"7051": {
						"0": true
					},
					"7052": {
						"0": true
					},
					"7053": {
						"0": true
					},
					"7055": {
						"0": true
					},
					"7060": {
						"0": true
					},
					"7065": {
						"0": true
					}
				},
				"WF":{
					"2026": {
						"0": true
					},
					"2051": {
						"0": true
					},
					"2055": {
						"0": true
					},
					"2060": {
						"0": true
					},
				}
			},

			"createModule": function(settings, type){
				for(var moduleInformationIndex = 0, moduleInformationArray = ["onboardModuleInformation", "remoteModuleInformation"]; moduleInformationIndex < moduleInformationArray.length; moduleInformationIndex++){
					var moduleInformation = this[moduleInformationArray[moduleInformationIndex]];

					for(var moduleType in moduleInformation){
						for(var mainType in moduleInformation[moduleType]){
							for(var subType in moduleInformation[moduleType][mainType]){
								for(var i = 0; i < moduleInformation[moduleType][mainType][subType][0].length; i++){
									var nameArray = moduleInformation[moduleType][mainType][subType][0][i].split("||");
									if(nameArray[0] == settings.modelName){
										var module = $.extend(true, {
											"type": type,//icpdas(original(old): dcon), onboard
											"name": "",
											"displayModelName": nameArray[1] || nameArray[0],
											"description": "",
											"reference": [],
											"key": randomKey(8),
											"scanInterval": 5,
											"pollingTimeout": 1000,//ms
											"retryInterval": 5,//second
											"temperatureUnit": 0,//0 for °C, 1 for °F
											"permission": {
												"userLevel": 1
											}
										}, settings);

										module.moduleType = moduleType;//I7K, M7K, tM, DL, WISE
										module.mainType = mainType;
										module.subType = subType;
										module.DI = this.initDIChannel(moduleType, moduleInformation[moduleType][mainType][subType][1][0], moduleInformation[moduleType][mainType][subType][5][0]);
										module.DO = this.initDOChannel(moduleType, moduleInformation[moduleType][mainType][subType][1][1], moduleInformation[moduleType][mainType][subType][5][1]);
										module.AI = this.initAIChannel(moduleType, moduleInformation[moduleType][mainType][subType][1][2], moduleInformation[moduleType][mainType][subType][5][2], moduleInformation[moduleType][mainType][subType][2], this.isSingleEndedModule(module));
										module.AO = this.initAOChannel(moduleType, moduleInformation[moduleType][mainType][subType][1][3], moduleInformation[moduleType][mainType][subType][5][3], moduleInformation[moduleType][mainType][subType][3]);
										module.IR = this.initIRChannel(moduleType, moduleInformation[moduleType][mainType][subType][7]);

										//disable DO channel for DIO switchable module
										if(this.isDIOSwitchableModule(module)){
											for(var i = 0; i < module.DO.amount; i++){
												module.DO.setting[i].disable = true;
											}
										}

										//disable AO channel for IR module
										if(module.moduleType == "IR"){
											for(var i = 0; i < module.AO.amount; i++){
												module.AO.setting[i].disable = true;
											}

											module.command = [];
										}

										return module;
									}
								}
							}
						}
					}
				}

				return null;
			},

			"initDIChannel": function(moduleType, amount, channelName){
				var ret = {};

				ret.amount = amount;
				ret.setting = [];

				for(var i = 0; i < amount; i++){
					ret.setting.push({
						"disable": false,
						"channelName": (function(){
							if(typeof(channelName) != "undefined"){
								if(typeof(channelName[i]) != "undefined"){
									return channelName[i];
								}
								else if(typeof(channelName[i % amount]) != "undefined"){
									return channelName[i % amount];
								}
							}

							return i;
						})(),
						"name": "",
						"counterName": "",

						"counterType": moduleType == "XVBoard" ? 2 : 0//0: disable, 1: rising, 2: falling
					});
				}

				return ret;
			},

			"initDOChannel": function(moduleType, amount, channelName){
				var ret = {};

				ret.amount = amount;
				ret.setting = [];

				for(var i = 0; i < amount; i++){
					ret.setting.push({
						"disable": false,
						"channelName": (function(){
							if(typeof(channelName) != "undefined"){
								if(typeof(channelName[i]) != "undefined"){
									return channelName[i];
								}
								else if(typeof(channelName[i % amount]) != "undefined"){
									return channelName[i % amount];
								}
							}

							return i;
						})(),
						"name": "",
						"counterName": "",
						"advancedFunction": 0,//0: Disable, 1:Pulse Output, 2:Auto OFF, 3:DI Mapping
						"mappingDI": false,
						"autoOFF": 1,

						/*for XW-Board*/
						"powerOnValue": 0,//0: OFF, 1:ON
						"pulse":{
							"high": 1,
							"low": 1
						}
					});
				}

				return ret;
			},

			"initAIChannel": function(moduleType, amount, channelName, typeCode, isSingleEnded){
				var findDefaultTypeCode = function(typeCode){
					for(var i = 0; i < typeCode.length; i++){
						if(typeCode[i].constructor === Array){
							return typeCode[i][0];
						}
					}

					return typeCode[0];
				};

				var ret = {};

				ret.amount = amount;
				ret.setting = [];
				ret.singleEnded = 0;

				for(var i = 0, length = isSingleEnded == true ? amount * 2 : amount; i < length; i++){// two times space reserve for single-ended mode
					ret.setting.push({
						"disable": false,
						"channelName": (function(){
							if(typeof(channelName) != "undefined"){
								if(typeof(channelName[i]) != "undefined"){
									return channelName[i];
								}
								else if(typeof(channelName[i % amount]) != "undefined"){
									return channelName[i % amount];
								}
							}

							return i;
						})(),
						"name": "",
						"type": moduleType == "DL" ? typeCode[i % amount] : findDefaultTypeCode(typeCode),
						"scale": {
							"min": 0,
							"max": 0,
							"ratio": 1,
							"offset": 0,
							"unit": ""
						},
						"offset": 0
					});
				}

				return ret;
			},

			"initAOChannel": function(moduleType, amount, channelName, typeCode){
				var findDefaultTypeCode = function(typeCode){
					for(var i = 0; i < typeCode.length; i++){
						if(typeCode[i].constructor === Array){
							return typeCode[i][0];
						}
					}

					return typeCode[0];
				};

				var ret = {};

				ret.amount = amount;
				ret.setting = [];

				for(var i = 0; i < amount; i++){
					ret.setting.push({
						"disable": false,
						"channelName": (function(){
							if(typeof(channelName) != "undefined"){
								if(typeof(channelName[i]) != "undefined"){
									return channelName[i];
								}
								else if(typeof(channelName[i % amount]) != "undefined"){
									return channelName[i % amount];
								}
							}

							return i;
						})(),
						"name": "",
						"type": moduleType == "DL" ? typeCode[i % amount] : findDefaultTypeCode(typeCode),

						/*for XW-Board*/
						"powerOnValue": 0
					});
				}

				return ret;
			},

			"initIRChannel": function(moduleType, amount){
				amount = amount || 0;

				var ret = {};

				ret.amount = amount;
				ret.setting = [];

				for(var i = 0; i < amount; i++){
					ret.setting.push({
						"disable": false,
						"channelName": (function(){
							return i + 1;
						})(),
						"name": ""
					});
				}

				return ret;
			},

			// input:  
			//   object::module, number::aiType, number::temperatureUnit OR
			//   object::module, number::channelIndex
			//
			// output:
			//   [number::rangeMin, number::rangeMax, string::unit]
			"getAIRange": function(module, aiType, temperatureUnit){
				var mode = 1;
				if(typeof(temperatureUnit) == "undefined"){
					mode = 2;
					var channelIndex = aiType, aiType = module.AI.setting[channelIndex].type, temperatureUnit = module.temperatureUnit;
				}

				if(module.moduleType != "DL"){
					if(this.aiTypeInfomation[aiType][3] == 0 || this.aiTypeInfomation[aiType][3] == 1){
						if(this.aiTypeInfomation[aiType][3] != temperatureUnit){
							if(temperatureUnit == 0){
								return {
									"min": Math.round((this.aiTypeInfomation[aiType][1] - 32) * 5 / 9),
									"max": Math.round((this.aiTypeInfomation[aiType][2] - 32) * 5 / 9),
									"unit": this.unit[temperatureUnit]
								};
							}
							else{
								return {
									"min": Math.round(this.aiTypeInfomation[aiType][1] * 9 / 5 + 32),
									"max": Math.round(this.aiTypeInfomation[aiType][2] * 9 / 5 + 32),
									"unit": this.unit[temperatureUnit]
								};
							}
						}
					}
				}

				if(mode == 1){
					return {
						"min": module.modelName == "tM-AD8" && this.aiTypeInfomation[aiType][1] < 0 ? 0 : this.aiTypeInfomation[aiType][1],
						"max": this.aiTypeInfomation[aiType][2],
						"unit": this.unit[this.aiTypeInfomation[aiType][3]]
					};
				}
				else{
					if(module.AI.setting[channelIndex].scale.min != 0 || module.AI.setting[channelIndex].scale.max != 0){//scale
						return {
							"min": module.AI.setting[channelIndex].scale.min/* + module.AI.setting[channelIndex].offset*/,
							"max": module.AI.setting[channelIndex].scale.max/* + module.AI.setting[channelIndex].offset*/,
							"unit": module.AI.setting[channelIndex].scale.unit
						};
					}
					else if(module.AI.setting[channelIndex].scale.ratio != 1 || module.AI.setting[channelIndex].scale.offset != 0){//scale
						return {
							"min": this.aiTypeInfomation[aiType][1] * module.AI.setting[channelIndex].scale.ratio + module.AI.setting[channelIndex].scale.offset/* + module.AI.setting[channelIndex].offset*/,
							"max": this.aiTypeInfomation[aiType][2] * module.AI.setting[channelIndex].scale.ratio + module.AI.setting[channelIndex].scale.offset/* + module.AI.setting[channelIndex].offset*/,
							"unit": module.AI.setting[channelIndex].scale.unit
						};
					}
					else{//no scale
						return {
							"min": (module.modelName == "tM-AD8" && this.aiTypeInfomation[aiType][1] < 0 ? 0 : this.aiTypeInfomation[aiType][1])/* + module.AI.setting[channelIndex].offset*/,
							"max": this.aiTypeInfomation[aiType][2]/* + module.AI.setting[channelIndex].offset*/,
							"unit": this.unit[this.aiTypeInfomation[aiType][3]]
						};
					}
				}
			},

			"getAORange": function(aoType){
				return {
					"min": this.aoTypeInfomation[aoType][0],
					"max": this.aoTypeInfomation[aoType][1],
					"unit": this.unit[this.aoTypeInfomation[aoType][2]]
				};
			},

			"isSingleEndedModule": function(module){
				try{
					if(this.singleEndedModule[module.moduleType][module.mainType][module.subType] == true){
						return true;

					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isSingleAITypeModule": function(module){
				try{
					if(this.singleAITypeModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isSingleAOTypeModule": function(module){
				try{
					if(this.singleAOTypeModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isSingleResetDICounterFlagModule": function(module){
				try{
					if(this.singleResetDICounterFlagModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isDICounterModule": function(module){
				try{
					if(this.diCounterModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"is32BitsDICounterModule": function(module){
				try{
					if(this.longDICounterModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isDIOSwitchableModule": function(module){
				try{
					if(this.dioSwitchableModule[module.moduleType][module.mainType][module.subType] == true){
						return true;
					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isNoDICounterModule": function(module){
				try{
					if(this.noDICounterModule[module.moduleType][module.mainType][module.subType] == true){
						return true;

					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"isNoDICounterResetModule": function(module){
				if(this.isNoDICounterModule(module)){return true;}

				try{
					if(this.noDICounterResetModule[module.moduleType][module.mainType][module.subType] == true){
						return true;

					}
					else{
						return false;
					}
				}
				catch(error){
					return false;
				}
			},

			"checkAIRange": function(module, channelIndex, value){
				var range = this.getAIRange(module, channelIndex);

				if(value < range.min){value = range.min;}
				else if(value > range.max){value = range.max;}

				return value;
			},

			"checkAORange": function(module, channelIndex, value){
				var range = this.getAORange(module.AO.setting[channelIndex].type);

				if(value < range.min){value = range.min;}
				else if(value > range.max){value = range.max;}

				return value;
			},
				
			"getIRCommandAmount": function(module){
				try{
					return this.irModuleInformation[module.mainType][module.subType][0];
				}
				catch(error){
					return null;
				}
			},

			"getIRChannelAmount": function(module){
				try{
					return this.irModuleInformation[module.mainType][module.subType][1];
				}
				catch(error){
					return null;
				}
			},
				
			"toModbusModule": function(module){
				var moduleManager = WISE.managers.moduleManager;
				var tempModule = moduleManager.modbusModule.createModule({}, "rtu");

				//DI
				if(module.DI.amount > 0){
					//if(!moduleManager.icpdasModule.isDICounterModule(module)){
						var channelAddressInfo = this.channelIndexToAddress(module, "DI", 0);
						moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
							"startAddress": channelAddressInfo[1],
							"length": module.DI.amount,
							"name": (function(module){
								var name = [];
								for(var i = 0; i < module.DI.amount; i++){
									if(module.DI.setting[i].disable == true){
										name.push("");
									}
									else{
										name.push(module.DI.setting[i].name);
									}
								}
								return name;
							})(module),
							"cross": channelAddressInfo[3],//for M7K,
							"visible": !moduleManager.icpdasModule.isDICounterModule(module)
						});
					//}

					//DI Counter
					if(!moduleManager.icpdasModule.isNoDICounterModule(module)){
						var channelAddressInfo = this.channelIndexToAddress(module, "DIC", 0);
						moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
							"startAddress": channelAddressInfo[1],
							"length": module.DI.amount,
							"type": channelAddressInfo[2],
							"cross": channelAddressInfo[3]//for M7K
						});
					}

					//DI Counter Reset
					if(!moduleManager.icpdasModule.isNoDICounterResetModule(module)){
						var modbusInfo = WISE.managers.moduleManager.icpdasModule.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][0][3];
						moduleManager.modbusModule.addBlock(tempModule, modbusInfo[0], {
							"startAddress": modbusInfo[1],
							"length": moduleManager.icpdasModule.isSingleResetDICounterFlagModule(module) ? 1 : module.DI.amount,
							"visible": false//for M7K
						});
					}
				}

				//DO
				if(module.DO.amount > 0){
					var channelAddressInfo = this.channelIndexToAddress(module, "DO", 0);
					moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
						"startAddress": channelAddressInfo[1],
						"length": module.DO.amount,
						"name": (function(module){
							var name = [];
							for(var i = 0; i < module.DO.amount; i++){
								if(module.DO.setting[i].disable == true){
									name.push("");
								}
								else{
									name.push(module.DO.setting[i].name);
								}
							}
							return name;
						})(module)
					});

					//DO Counter
					if(module.moduleType == "WISE"){
						moduleManager.modbusModule.addBlock(tempModule, "RI", {
							"startAddress": 80,
							"length": module.DO.amount,
							"type": 1
						});
					}
				}

				var getName = function(channel){
					if(channel.disable == true){
						return "";
					}
					else{
						return channel.name;
					}
				};

				//AI
				for(var i = 0; i < module.AI.amount;){
					var name = [getName(module.AI.setting[i])];
					for(var j = i + 1, length = 1; j < module.AI.amount; j++){//merge same block
						//if(module.AI.setting[j].type != module.AI.setting[i].type){
						//	break;
						//}
						//else{
							name.push(getName(module.AI.setting[j]));
							length++;
						//}
					}

					var channelAddressInfo = this.channelIndexToAddress(module, "AI", i);
					var range = this.getAIRange(module, module.AI.setting[i].type, module.temperatureUnit);

					moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
						"startAddress": channelAddressInfo[1],
						"length": length,
						/*run-time no need to know, use a dummy value replace it*/
						"hexMin": "0000",
						"hexMax": "0000",
						"realMin": range.min,
						"realMax": range.max,
						/********************************************************/
						"type": channelAddressInfo[2],
						"name": name,
						"cross": channelAddressInfo[3]//for M7K
					});

					i += length;
				}

				//AO
				for(var i = 0; i < module.AO.amount;){
					var name = [getName(module.AO.setting[i])];
					for(var j = i + 1, length = 1; j < module.AO.amount; j++){//merge same block
						//if(module.AO.setting[j].type != module.AO.setting[i].type){
						//	break;
						//}
						//else{
							name.push(getName(module.AO.setting[j]));
							length++;
						//}
					}

					var channelAddressInfo = this.channelIndexToAddress(module, "AO", i);
					var range = this.getAORange(module.AO.setting[i].type);

					moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
						"startAddress": channelAddressInfo[1],
						"length": length,
						/*run-time no need to know, use a dummy value replace it*/
						"hexMin": "0000",
						"hexMax": "0000",
						"realMin": range.min,
						"realMax": range.max,
						/********************************************************/
						"type": channelAddressInfo[2],
						"name": name
					});

					i += length;
				}

				//IR
				if(module.moduleType == "WISE"){
					var channelAddressInfo = this.channelIndexToAddress(module, "IR", 0);
					moduleManager.modbusModule.addBlock(tempModule, channelAddressInfo[0], {
						"startAddress": channelAddressInfo[1],
						"length": 48,
						/*run-time no need to know, use a dummy value replace it*/
						"hexMin": "0000",
						"hexMax": "0000",
						"realMin": 0,
						"realMax": 0,
						/********************************************************/
						"type": channelAddressInfo[2]
					});
				}

				return tempModule
			},

			"channelIndexToAddress": function(module, channelType, channelIndex){
				if(channelType == "IR"){
					return ["RO", 40 + channelIndex * 2, 5, false];
				}
				else{
					var modbusInfo = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][{"DI": 0, "DO": 1, "AI": 2, "AO": 3, "DIC": 0, "DOC": 1}[channelType]];

					if(channelType == "DIC" || channelType == "DOC"){modbusInfo = modbusInfo[2];}

					var dataModel = modbusInfo[0], isCross = false;
					if(channelType == "DI" && dataModel == "CO"){dataModel = "CI"; isCross = true;}
					else if(channelType == "AI" && dataModel == "AO"){dataModel = "RI"; isCross = true;}
					else if(channelType == "DIC" && dataModel == "RO"){dataModel = "RI"; isCross = true;}
					else if(channelType == "DOC" && dataModel == "RO"){dataModel = "RI"; isCross = true;}

					return [dataModel, modbusInfo[1] + channelIndex * ((channelType == "AI" || channelType == "AO" || channelType == "DIC" || channelType == "DOC") && modbusInfo[2] > 2 ? 2 : 1), modbusInfo[2], isCross];
				}
			},

			"channelAddressToIndex": function(module, channelType, channelAddress){
				if(typeof(module.channelMappingTable) == "undefined"){
					module.channelMappingTable = {"CI":{}, "CO":{}, "RI":{}, "RO":{}};

					for(var i = 0; i < this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][1][0]; i++){
						var modbusInfo = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][0];
						var dataModel = /*modbusInfo[0]*/"CI", startAddress = modbusInfo[1], length = 1;
						module.channelMappingTable[dataModel][startAddress + length * i] = ["DI", i];

						//DI Counter
						var dataModel = /*modbusInfo[2][0]*/"RI", startAddress = modbusInfo[2][1], length = (modbusInfo[2][2] > 2 ? 2 : 1);
						module.channelMappingTable[dataModel][startAddress + length * i] = ["DIC", i];

						//DI Counter Reset
						if(module.moduleType != "WISE"){
							var dataModel = modbusInfo[3][0], startAddress = modbusInfo[3][1], length = 1;
							module.channelMappingTable[dataModel][startAddress + length * i] = ["DICR", i];
						}
					}

					for(var i = 0; i < this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][1][1]; i++){
						var modbusInfo = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][1];
						var dataModel = modbusInfo[0], startAddress = modbusInfo[1], length = 1;
						module.channelMappingTable[dataModel][startAddress + length * i] = ["DO", i];

						if(module.moduleType == "WISE"){
							//DO Counter
							var dataModel = /*modbusInfo[2][0]*/"RI", startAddress = modbusInfo[2][1], length = (modbusInfo[2][2] > 2 ? 2 : 1);
							module.channelMappingTable[dataModel][startAddress + length * i] = ["DOC", i];

							//DO Counter Reset
							//var dataModel = modbusInfo[3][0], startAddress = modbusInfo[3][1], length = 1;
							//module.channelMappingTable[dataModel][startAddress + length * i] = ["DOCR", i];
						}
					}

					for(var i = 0, aiAmount = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][1][2] * (this.isSingleEndedModule(module) == true ? 2 : 1); i < aiAmount; i++){
						var modbusInfo = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][2];
						var dataModel = /*modbusInfo[0]*/"RI", startAddress = modbusInfo[1], length = (modbusInfo[2] > 2 ? 2 : 1);
						module.channelMappingTable[dataModel][startAddress + length * i] = ["AI", i];
					}

					for(var i = 0; i < this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][1][3]; i++){
						var modbusInfo = this.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][3];
						var dataModel = modbusInfo[0], startAddress = modbusInfo[1], length = (modbusInfo[2] > 2 ? 2 : 1);
						module.channelMappingTable[dataModel][startAddress + length * i] = ["AO", i];
					}

					//IR
					if(module.moduleType == "WISE"){
						for(var i = 0; i < 48; i++){
							var modbusInfo = ["RO", 40, 5];
							var dataModel = modbusInfo[0], startAddress = modbusInfo[1], length = (modbusInfo[2] > 2 ? 2 : 1);
							module.channelMappingTable[dataModel][startAddress + length * i] = ["IR", i];
						}
					}
				}

				return module.channelMappingTable[channelType][channelAddress];
			}
		};

		this.modbusModule = {
			"createModule": function(settings, type){
				var module = $.extend(true, {
					"type": type,//rtu, tcp
					"protocol": "modbusRTU",//modbusRTU, modbusTCP
					"name": "",
					"description": "",
					"reference": [],

					"key": randomKey(8),
					"scanInterval": 5,
					"pollingTimeout": 1000,
					"retryInterval": 5,
					"modbusRTU": {
						"address": 1
					},
					"modbusTCP": {
						"ip": 3232261121,
						"port": 502,
						"netID": 1
					},
					"permission": {
						"userLevel": 1
					}
				}, settings);

				this.initAllBlock(module);

				return module;
			},

			"addBlock": function(module, dataModel, settings){
				var settings = $.extend(true, {
					"disable": false,
					"name": [],

					//no use for coil
					"unit": [],
					"scaleRatio": 1,
					"offset": 0
				}, settings);

				var index = module[dataModel].blockArray.push(settings) - 1;

				for(var i = 0; i < settings.length; i++){//default name and unit
					if(typeof(module[dataModel].blockArray[index].name[i]) == "undefined"){
						module[dataModel].blockArray[index].name[i] = "";
					}

					if(typeof(module[dataModel].blockArray[index].unit[i]) == "undefined"){
						module[dataModel].blockArray[index].unit[i] = "";
					}
				}

				this.updateBlock(module, dataModel);
			},

			"initAllBlock": function(module){
				module.CI = {"blockArray":[], "remoteAddress":{}};
				module.CO = {"blockArray":[], "remoteAddress":{}};
				module.RI = {"blockArray":[], "remoteAddress":{}};
				module.RO = {"blockArray":[], "remoteAddress":{}};
			},

			"removeBlock": function(module, dataModel, blockArrayIndex){
				module[dataModel].blockArray.splice(blockArrayIndex, 1);

				this.updateBlock(module, dataModel);
			},

			"removeAllBlock": function(module){
				this.initAllBlock(module);
			},

			"updateBlock": function(module, dataModel){
				module[dataModel].blockArray.sort(this.sortByStartAddress);
				this.updateRemoteAddress(module, dataModel);
			},

			"updateRemoteAddress": function(module, dataModel){//dataModel can be CI, CO, RI or RO
				var dataModel = dataModel.toUpperCase().split(" ");

				for(var i = 0; i < dataModel.length; i++){
					module[dataModel[i]].remoteAddress = [];

					for(var j = 0, list = module[dataModel[i]].blockArray; j < list.length; j++){
						//if(list[j].disable == true){continue;}

						for(var k = 0; k < list[j].length; k++){
							module[dataModel[i]].remoteAddress[parseInt(list[j].startAddress + (list[j].type >= 3 ? 2 : 1) * k, 10)] = {
								"name": list[j].name[k],
								"unit": list[j].unit[k],
								"blockIndex": j,
								"index": k
							};
						}
					}
				}
			},

			"sortByStartAddress": function(a, b){
				return a.startAddress - b.startAddress;
			},

			"getRegisterRange": function(module, dataModel, channelAddress){
				var processBlockRange = function(block){
					if(block.type == 0){//16-bit Signed Integer
						var min = -32768 * block.scaleRatio + block.offset, max = 32767 * block.scaleRatio + block.offset;
						return {"min": Math.min(min, max), "max": Math.max(min, max), "type": block.scaleRatio == 1 && block.offset == 0 ? "int" : "float"};
					}
					else if(block.type == 1){//16-bit Unsigned Integer
						var min = 0 * block.scaleRatio + block.offset, max = 65535 * block.scaleRatio + block.offset;
						return {"min": Math.min(min, max), "max": Math.max(min, max), "type": block.scaleRatio == 1 && block.offset == 0 ? "int" : "float"};
					}
					else if(block.type == 2){//16-bit HEX
						var min = block.realMin * block.scaleRatio + block.offset, max = block.realMax * block.scaleRatio + block.offset;
						return {"min": Math.min(min, max), "max": Math.max(min, max), "type": "float"};
					}
					else if(block.type == 3){//32-bit Signed Long
						var min = -2147483648 * block.scaleRatio + block.offset, max = 2147483647 * block.scaleRatio + block.offset;
						return {"min": Math.min(min, max), "max": Math.max(min, max), "type": block.scaleRatio == 1 && block.offset == 0 ? "int" : "float"};
					}
					else if(block.type == 4){//32-bit Unsigned Long
						var min = 0 * block.scaleRatio + block.offset, max = 4294967295 * block.scaleRatio + block.offset;
						return {"min": Math.min(min, max), "max": Math.max(min, max), "type": block.scaleRatio == 1 && block.offset == 0 ? "int" : "float"};
					}
					else{//32-bit Floating Point
						//var min = -65535 * block.scaleRatio + block.offset, max = 65535 * block.scaleRatio + block.offset;
						//return {"min": Math.min(min, max), "max": Math.max(min, max), "type": "float"};
						return {"min": Number.NEGATIVE_INFINITY, "max": Number.POSITIVE_INFINITY, "type": "float"};
					}	
				};

				if(typeof(dataModel) == "undefined"){//only one parameter, block
					var block = module;

					return processBlockRange(block);
				}
				else{
					var remoteAddress = module[dataModel].remoteAddress[channelAddress];
					var block = module[dataModel].blockArray[remoteAddress.blockIndex];
					var retObj = processBlockRange(block);
					retObj.unit = remoteAddress.unit

					return retObj;
				}
			},

			"checkRegisterRange": function(module, dataModel, channelAddress, value){
				var range = this.getRegisterRange(module, dataModel, channelAddress);

				if(value < range.min){value = range.min;}
				else if(value > range.max){value = range.max;}

				return value;
			}
		};

		this.getModuleByKey = function(key){
			try{
				return this.pool.modulesKey[key].module;
			}
			catch(error){
				return null;
			}
		};

		this.getModuleInfoByKey = function(key){
			try{
				this.pool.modulesKey[key].module;//try module exist or not

				return this.pool.modulesKey[key];
			}
			catch(error){
				return null;
			}
		};

		this.updateModulesKey = function(modules){
			var moduleManager = WISE.managers.moduleManager;

			this.pool.modulesKey = {};

			for(var sourceTypeIndex = 0, sourceTypeArray = ["onboard", "comport", "network"]; sourceTypeIndex < sourceTypeArray.length; sourceTypeIndex++){
				var sourceType = sourceTypeArray[sourceTypeIndex];

				for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces[sourceType].length; sourceIndex++){
					if(typeof(moduleManager.pool.interfaces[sourceType][sourceIndex]) == "undefined"){continue;}

					for(var moduleIndex = 0, modules = moduleManager.pool.interfaces[sourceType][sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
						if(typeof(modules[moduleIndex]) == "undefined"){continue;}
						//modules[moduleIndex].sourceType = sourceType;
						//modules[moduleIndex].sourceIndex = sourceIndex;

						this.pool.modulesKey[modules[moduleIndex].key] = {
							"sourceType": sourceType,
							"sourceIndex": sourceIndex,
							"moduleIndex": moduleIndex,
							"module": moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex]
						};
					}
				}
			}
		};

		this.generateModulesUID = function(){
			var uidPool = {};
			var uidGenerator = function(module){
				if(typeof(module.uid) == "undefined"){
					var key;
					do{
						key = randomKey(1, "abcdefghiklmnopqrstuvwxyz") + randomKey(3, "abcdefghiklmnopqrstuvwxyz0123456789");
					}
					while(typeof(uidPool[key]) != "undefined");

					module.uid = key;// write uid back to module
					uidPool[module.uid] = true;

					return module.uid;
				}
				else{// uid exist in module, keep it not change(reuse)
					return module.uid;
				}
			};

			// find all exist uid in moudle
			for(var sourceTypeIndex = 0, sourceTypeArray = ["onboard", "comport", "network"]; sourceTypeIndex < sourceTypeArray.length; sourceTypeIndex++){
				var sourceType = sourceTypeArray[sourceTypeIndex];

				for(var sourceIndex = 0; sourceIndex < this.pool.interfaces[sourceType].length; sourceIndex++){
					if(typeof(this.pool.interfaces[sourceType][sourceIndex]) == "undefined"){continue;}

					for(var moduleIndex = 0, modules = this.pool.interfaces[sourceType][sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
						if(typeof(modules[moduleIndex]) == "undefined"){continue;}

						if(typeof(modules[moduleIndex].uid) != "undefined"){
							if(uidPool[modules[moduleIndex].uid] == true){
								delete modules[moduleIndex].uid;
							}
							else{
								uidPool[modules[moduleIndex].uid] = true;
							}
						}
					}
				}
			}

			for(var sourceTypeIndex = 0, sourceTypeArray = ["onboard", "comport", "network"]; sourceTypeIndex < sourceTypeArray.length; sourceTypeIndex++){
				var sourceType = sourceTypeArray[sourceTypeIndex];

				for(var sourceIndex = 0; sourceIndex < this.pool.interfaces[sourceType].length; sourceIndex++){
					if(typeof(this.pool.interfaces[sourceType][sourceIndex]) == "undefined"){continue;}

					for(var moduleIndex = 0, modules = this.pool.interfaces[sourceType][sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
						if(typeof(modules[moduleIndex]) == "undefined"){continue;}

						uidGenerator(modules[moduleIndex]);
					}
				}
			}

		};
	};
})();
