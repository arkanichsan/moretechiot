WISE.managers.activeioManager.encodeXMLObject = function(xmlDoc){
	var processModuleInfo = function(xmlDoc, moduleKey){
		var moduleManager = WISE.managers.moduleManager;
		var moduleInfo = moduleManager.getModuleInfoByKey(moduleKey);
		var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas"){
			if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "dcon"){//M7K
				xmlDoc.setAttribute("l_obj", "DCON");
			}
			else if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "modbusRTU"){
				xmlDoc.setAttribute("l_obj", "RTU");
			}
			else if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "modbusTCP"){
				xmlDoc.setAttribute("l_obj", "TCP");
			}

			xmlDoc.setAttribute("l_com", moduleInfo.sourceIndex);
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
		}
		else if(module.type == "onboard"){
			xmlDoc.setAttribute("l_obj", "XBOARD");
		}
		else if(module.type == "rtu"){
			xmlDoc.setAttribute("l_obj", "RTU");
			xmlDoc.setAttribute("l_com", moduleInfo.sourceIndex);
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
		}
		else if(module.type == "tcp"){
			xmlDoc.setAttribute("l_obj", "TCP");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
		}

		return moduleInfo;
	};

	if(this.pool.table.coil.length == 0 && this.pool.table.register.length == 0){return;}

	var moduleManager = WISE.managers.moduleManager;

	var xmlACTIVE_IO = xmlDoc.createElement("ACTIVE_IO");

	//ACTIVE_IO > TABLE
	var xmlTABLE = xmlDoc.createElement("TABLE");

	//ACTIVE_IO > TABLE > COIL
	var xmlCOIL = xmlDoc.createElement("COIL");
	var coiArray = this.pool.table.coil;
	for(var i = 0; i < coiArray.length; i++){
		var coilBlock = coiArray[i];
		var xmlC = xmlDoc.createElement("C");
		xmlC.setAttribute("idx", i + 1);

		var moduleInfo = processModuleInfo(xmlC, coilBlock.moduleKey);
		var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
		var module = moduleInfo.module;
		if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
			var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, coilBlock.channelType, coilBlock.channel);
			xmlC.setAttribute("l_ch", channelAddressInfo[0]);
			xmlC.setAttribute("l_chn", channelAddressInfo[1]);
		}
		else{
			xmlC.setAttribute("l_ch", coilBlock.channelType);
			xmlC.setAttribute("l_chn", coilBlock.channel);
		}

		xmlCOIL.appendChild(xmlC);
	}
	xmlCOIL.setAttribute("num", i);
	xmlTABLE.appendChild(xmlCOIL);

	//ACTIVE_IO > TABLE > REGISTER
	var xmlREGISTER = xmlDoc.createElement("REGISTER");
	var registerArray = this.pool.table.register;
	var xmlR = null, registerIndex = 0, coilIndex = 0;
	for(var i = 0; i < registerArray.length; i++){
		var registerBlock = registerArray[i];

		if(registerBlock.channelType == "DI" || registerBlock.channelType == "DO" || registerBlock.channelType == "CI" || registerBlock.channelType == "CO"){
			if(xmlR == null || coilIndex > 15){
				xmlR = xmlDoc.createElement("R");
				xmlR.setAttribute("idx", ++registerIndex);
				xmlR.setAttribute("mode", "C");
				coilIndex = 0;
			}

			var xmlC = xmlDoc.createElement("C");
			xmlC.setAttribute("idx", ++coilIndex);

			var moduleInfo = processModuleInfo(xmlC, registerBlock.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;
			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
				var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, registerBlock.channelType, registerBlock.channel);
				xmlC.setAttribute("l_ch", channelAddressInfo[0]);
				xmlC.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlC.setAttribute("l_ch", registerBlock.channelType);
				xmlC.setAttribute("l_chn", registerBlock.channel);
			}

			xmlR.appendChild(xmlC);
		}
		else{
			if(xmlR != null){
				xmlREGISTER.appendChild(xmlR);
			}

			xmlR = xmlDoc.createElement("R");
			xmlR.setAttribute("idx", ++registerIndex);
			xmlR.setAttribute("mode", "R");
			if(typeof(registerBlock.registerIndex) != "undefined"){//IR
				if(registerBlock.moduleKey == null){
					xmlR.setAttribute("l_obj", "IR");
					xmlR.setAttribute("l_idx", registerBlock.registerIndex + 1);
				}
				else{
					var moduleInfo = processModuleInfo(xmlR, registerBlock.moduleKey);
					var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", registerBlock.registerIndex);
					xmlR.setAttribute("l_ch", channelAddressInfo[0]);
					xmlR.setAttribute("l_chn", channelAddressInfo[1]);
				}
			}
			else{
				var moduleInfo = processModuleInfo(xmlR, registerBlock.moduleKey);
				var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
				var module = moduleInfo.module;
				if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
					var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, registerBlock.channelType, registerBlock.channel);
					xmlR.setAttribute("l_ch", channelAddressInfo[0]);
					xmlR.setAttribute("l_chn", channelAddressInfo[1]);
				}
				else{
					xmlR.setAttribute("l_ch", registerBlock.channelType);
					xmlR.setAttribute("l_chn", registerBlock.channel);
				}
			}
			xmlREGISTER.appendChild(xmlR);

			xmlR = null;
		}

		if(xmlR != null){
			xmlREGISTER.appendChild(xmlR);
		}
	}
	xmlREGISTER.setAttribute("num", registerIndex);
	xmlTABLE.appendChild(xmlREGISTER);

	xmlACTIVE_IO.appendChild(xmlTABLE);

	//ACTIVE_IO > RECEIVER
	if(this.pool.slave.enable == true){
		var xmlRECEIVER = xmlDoc.createElement("RECEIVER");
		xmlRECEIVER.setAttribute("url", integerToIP(this.pool.slave.ip));
		xmlRECEIVER.setAttribute("port", this.pool.slave.port);
		xmlRECEIVER.setAttribute("netid", this.pool.slave.netID);
		xmlRECEIVER.setAttribute("timeout", this.pool.slave.timeout);
		xmlRECEIVER.setAttribute("send_mode", this.pool.slave.update.timing);

		if(this.pool.slave.update.timing & 1){
			xmlRECEIVER.setAttribute("send_threshold", this.pool.slave.update.threshold);
		}

		if(this.pool.slave.update.timing & 2){
			xmlRECEIVER.setAttribute("send_period", this.pool.slave.update.interval);
		}

		xmlRECEIVER.setAttribute("coil_address", this.pool.slave.startAddress.coil);
		xmlRECEIVER.setAttribute("register_address", this.pool.slave.startAddress.register);

		xmlACTIVE_IO.appendChild(xmlRECEIVER);
	}

	for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
		if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
			xmlDoc.documentElement.childNodes[i].appendChild(xmlACTIVE_IO);
			break;
		}
	}
};

WISE.managers.activeioManager.check = function(){
	var moduleManager = WISE.managers.moduleManager;
	var registerManager = WISE.managers.registerManager;
	var isExist = function(block){
		if(typeof(block.registerIndex) != "undefined"){//is register
			var brokenFlag = false;

			if(block.moduleKey == null){
				if(typeof(registerManager.pool.registers[block.registerIndex]) == "undefined"){
					brokenFlag = true;
				}
			}
			else{
				if(moduleManager.getModuleByKey(block.moduleKey) == null){
					brokenFlag = true;
				};
			}

			if(brokenFlag == true){
				return false;
			}
		}
		else{
			var brokenFlag = false;
			var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);

			if(moduleInfo != null){
				try{
					var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];
					if(module.type == "onboard" || module.type == "icpdas"){
						var channelType = block.channelType;
						if(channelType == "DIC"){
							channelType = "DI";
						}
						else if(channelType == "DOC"){
							channelType = "DO";
						}

						var channel = module[channelType].setting[block.channel];
						if(!channel || channel.disable == true){
							throw "channelNotFound";
						}
					}
					else if(module.type == "rtu" || module.type == "tcp"){
						if(!module[block.channelType].remoteAddress[block.channel]){
							throw "channelNotFound";
						}
					}
					else{
						throw "channelNotFound";
					}
				}
				catch(error){
					brokenFlag = true;
				}
			}
			else{
				brokenFlag= true;
			}

			if(brokenFlag == true){
				return false;
			}
		}

		return true;
	};

	for(var typeArrayIndex = 0, typeArray = ["coil", "register"]; typeArrayIndex < typeArray.length; typeArrayIndex++){
		var blockArray = this.pool.table[typeArray[typeArrayIndex]];
		for(var i = 0; i < blockArray.length; i++){
			var block = blockArray[i];

			if(isExist(block) == false){
				return {
					"hash": "#home/advanced/activeio",
					"message": "<#Lang['?'].mappingTableContainNotExistChannelOrIR>"
				};
			}
		}
	}

	return null;
};
