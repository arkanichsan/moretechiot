var cssFiles = [
	"css/mobile/default.css",
	"css/mobile/icons.css"
];

var languageFiles = [
	"lang/js/wise/manager/module/" + currentLanguage + ".js",
	"lang/js/wise/manager/logger/" + currentLanguage + ".js",
	"lang/js/wise/manager/register/" + currentLanguage + ".js",
	"lang/js/wise/init/mobile/" + currentLanguage + ".js",

	"lang/html/base/wise/" + currentLanguage + ".js",
	"lang/html/mobile/wise/" + currentLanguage + ".js"
];

var jsFiles = [
	"js/jquery/jquery.ui.min.js",
	"js/jquery/jquery.spinner.js",

	"js/wise/utilities/base.js",
	"js/wise/core/base.js",

	"js/wise/manager/module/base.js",
	"js/wise/manager/module/object/decoder.js",

	"js/wise/manager/logger/base.js",
	"js/wise/manager/logger/object/decoder.js",

	"js/wise/manager/register/base.js",
	"js/wise/manager/register/object/decoder.js",

	"js/wise/manager/status/base.js",//PMC-5151 no use
	"js/wise/manager/status/object/decoder.js",

	"js/wise/popup/base.js",
	"js/wise/popup/mobile.js",
	"js/wise/hash/mobile.js",

	"js/wise/init/mobile.js"
];
