﻿$.extend(true, Lang, {
	"html/mobile/frame.htm": {
		"goToDesktopVersion": "Go to desktop version.",
		"dialog": "Dialog",
		"prompt": "Prompt"
	},
	"html/mobile/home/menu.htm": {
		"menu": "Menu",
		"home": "Home",
		"internalRegister": "Internal Register",
		"customizeStatus": "Channel Status"
	},
	"html/mobile/home/main.htm": {
		"systemInformation": "System Information",
		"nickname": "Nickname",
		"date": "Date",
		"time": "Time",
		"microSDSpace": "microSD Space",
		"approxXDays": "Approx.$day Days",
		"noSDCard": "No microSD card detected.",
		"none": "None",
		"totalNumberOfIOModule": "Total no. of I/O",
		"moduleList": "Module List",
		"ipAndPort": "IP & Port",
		"address": "Address",
		"scanRate": "Scan Rate",
		"pollingTimeout": "Polling Timeout"
	},
	"html/mobile/home/status/default.htm": {
		"internalRegister": "Internal Register",
		"no": "No.",
		"channel": "Ch.",
		"address": "Addr.",
		"counter": "Counter:",
		"enterValue": "Please enter the value:",
		"valueOfChannel": "The value of $channel:",
		"none": "None",
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel",
		"popup": {
			"module": "Module:",
			"channel": "Channel:",
			"value": "Value:"
		}
	},
	"html/mobile/home/status/ir.htm": {
		"none": "None",
		"ch": "Ch.",
		"outputChannel": "Output Channel",
		"availableCommand": "Available Command",
		"transmit": "Transmit",
		"popup": {
			"outputChannelIsEmpty": "No output channel selected, please select at least one channel and then click the 'Transmit' button."
		}
	}
});