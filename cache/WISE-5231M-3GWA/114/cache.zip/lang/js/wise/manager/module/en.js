﻿$.extend(true, Lang, {
	"js/wise/manager/module/base.js": {
		"humidity": "Humidity",
		"celsiusTemperature": "Temperature(°C)",
		"fahrenheitTemperature": "Temperature(°F)",
		"celsiusDewPointTemperature": "Dew Point Temperature(°C)",
		"fahrenheitDewPointTemperature": "Dew Point Temperature(°F)"
	},
	"js/wise/manager/module/rule/object.js": {
		"icpdasModule": "ICP DAS Module",
		"modbusModule": "Modbus Module",
		"diCounter": "DI Counter",
		"doCounter": "DO Counter",
		"onToOFF": "ON to OFF",
		"offToON": "OFF to ON",
		"statusChange": "Status Change",
		"change": "Change",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"reset": "Reset",
		"connectionStatus": "Connection Status",
		"online": "Online",
		"offline": "Offline",
		"pulseOutput": "Pulse Output",
		"infrared": "Infrared",
		"ch": "Ch.",
		"transmitCommand": "Transmit Command"
	}
});
