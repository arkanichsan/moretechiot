﻿$.extend(true, Lang, {
	"js/wise/manager/activeio/object/encoder.js": {
		"mappingTableContainNotExistChannelOrIR": "The Modbus Address Mapping Table contains  channels or Internal Registers that are not existed. Please remove invalid channels or Internal Registers."
	},
	"js/wise/manager/activeio/base.js": {
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel"
	}
});