WISE.managers.moduleManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;
/*
	var processModuleInfo = function(sourceType, sourceIndex, moduleIndex, rule){
		rule.sourceType = sourceType;
		rule.sourceIndex = sourceIndex;
		rule.moduleKey = moduleIndex;
		return rule;
	};
*/

	if($(xmlDoc).attr("l_obj") == "DCON" || $(xmlDoc).attr("l_obj") == "XBOARD"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "DI"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.DI);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "DIC"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.DIC);
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);

				if(ruleObject.rule.operate < 5){
					processCompareModule(xmlDoc, ruleObject);
				}
			}
			if($(xmlDoc).attr("l_ch") == "DO"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.DO);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "AI"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.AI);
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

				processCompareModule(xmlDoc, ruleObject);
			}
			else if($(xmlDoc).attr("l_ch") == "AO"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.AO);
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

				processCompareModule(xmlDoc, ruleObject);
			}
			else if($(xmlDoc).attr("l_ch") == "STATUS"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "DIC"){
				ruleObject = WISE.createRuleObject(this.pool.actions.DIC);
				ruleObject.rule.value = 0;
			}
			else if($(xmlDoc).attr("l_ch") == "DO"){
				ruleObject = WISE.createRuleObject(this.pool.actions.DO);

				var code = {"0": 0, "1": 10, "2": 1, "3": 11, "4": 20}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "AO"){
				ruleObject = WISE.createRuleObject(this.pool.actions.AO);
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				if(ruleObject.rule.operate >= 3){
					ruleObject.rule.operate -= 3;
					ruleObject.rule.frequency = 1;
				}
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);

				processCompareModule(xmlDoc, ruleObject);
			}
		}

		if(ruleObject != null){
			if($(xmlDoc).attr("l_obj") == "DCON"){
				ruleObject.rule.moduleKey = this.pool.interfaces.comport[parseInt($(xmlDoc).attr("l_com"), 10)].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1].key;
			}
			else if($(xmlDoc).attr("l_obj") == "XBOARD"){
				ruleObject.rule.moduleKey = this.pool.interfaces.onboard[0].modules[0].key;
			}

			if($(xmlDoc).attr("l_ch") != "STATUS"){//STATUS doesn't has l_chn attribute
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);
			}
		}
	}
	else if($(xmlDoc).attr("l_obj") == "RTU" || $(xmlDoc).attr("l_obj") == "TCP"){
		var processICPDASModule = function(xmlDoc){
			if($(xmlDoc).attr("l_obj") == "RTU"){
				var module = moduleManager.pool.interfaces.comport[parseInt($(xmlDoc).attr("l_com"), 10)].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
			}
			else if($(xmlDoc).attr("l_obj") == "TCP"){
				var module = moduleManager.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
			}

			var ruleObject = null;

			if(module.type == "icpdas"){//M7K
				var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $(xmlDoc).attr("l_ch"), parseInt($(xmlDoc).attr("l_chn"), 10));

				if(xmlDoc.tagName == "IF"){
					if(channelIndexInfo[0] == "DI"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.DI);
						ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];
					}
					else if(channelIndexInfo[0] == "DIC"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.DIC);
						ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];

						if(ruleObject.rule.operate < 5){
							processCompareModule(xmlDoc, ruleObject);
						}
					}
					else if(channelIndexInfo[0] == "DO"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.DO);
						ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];
					}
					else if(channelIndexInfo[0] == "DOC"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.DOC);
						ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];

						if(ruleObject.rule.operate < 5){
							processCompareModule(xmlDoc, ruleObject);
						}
					}
					else if(channelIndexInfo[0] == "AI"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.AI);
						ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];
						ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

						processCompareModule(xmlDoc, ruleObject);
					}
					else if(channelIndexInfo[0] == "AO"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.conditions.AO);
						ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
						ruleObject.rule.channelIndex = channelIndexInfo[1];
						ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

						processCompareModule(xmlDoc, ruleObject);
					}
					else if(channelIndexInfo[0] == "IR"){//remote IR
						//ruleObject = WISE.managers.registerManager.decodeXMLRule(xmlDoc);

						var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $(xmlDoc).attr("l_ch"), parseInt($(xmlDoc).attr("l_chn"), 10));

						ruleObject = WISE.createRuleObject(WISE.managers.registerManager.pool.conditions.register);
						ruleObject.rule.moduleKey = module.key;	
						ruleObject.rule.registerIndex = channelIndexInfo[1];
						ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);

						processCompareModule(xmlDoc, ruleObject);
					}
				}
				else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
					if(channelIndexInfo[0] == "DICR"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.actions.DIC);
						ruleObject.rule.value = 0;
						ruleObject.rule.channelIndex = channelIndexInfo[1];
					}
					else if(channelIndexInfo[0] == "DO"){
						ruleObject = WISE.createRuleObject(moduleManager.pool.actions.DO);

						var code = {"0": 0, "1": 10, "2": 1, "3": 11, "4": 20}[$(xmlDoc).attr("op")];
						ruleObject.rule.value = Math.floor(code / 10);
						ruleObject.rule.frequency = code % 10;
						ruleObject.rule.channelIndex = channelIndexInfo[1];
						ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
					}
					else if(channelIndexInfo[0] == "AO"){
						if(module.moduleType == "IR"){//IR module
							ruleObject = WISE.createRuleObject(moduleManager.pool.actions.IR);
							ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);

							var value = parseInt($(xmlDoc).attr("r_obj"), 10);
							ruleObject.rule.outputChannel = value >>> 16;
							ruleObject.rule.commandIndex = (value & 0xFFFF) - 1;

							if(ruleObject.rule.operate >= 3){
								ruleObject.rule.operate -= 3;
								ruleObject.rule.frequency = 1;
							}
							ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
						}
						else{
							ruleObject = WISE.createRuleObject(moduleManager.pool.actions.AO);
							ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
							ruleObject.rule.channelIndex = channelIndexInfo[1];
							if(ruleObject.rule.operate >= 3){
								ruleObject.rule.operate -= 3;
								ruleObject.rule.frequency = 1;
							}
							ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);

							processCompareModule(xmlDoc, ruleObject);
						}
					}
					else if(channelIndexInfo[0] == "IR"){//remote IR
						//ruleObject = WISE.managers.registerManager.decodeXMLRule(xmlDoc);

						var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $(xmlDoc).attr("l_ch"), parseInt($(xmlDoc).attr("l_chn"), 10));

						ruleObject = WISE.createRuleObject(WISE.managers.registerManager.pool.actions.register);
						ruleObject.rule.moduleKey = module.key;	
						ruleObject.rule.registerIndex = channelIndexInfo[1];

						var code = {"0": 0, "1": 10, "2": 20, "3": 1, "4": 11, "5": 21, "6": 30, "7": 40, "8": 31, "9": 41}[$(xmlDoc).attr("op")];
						ruleObject.rule.operate = Math.floor(code / 10);
						ruleObject.rule.frequency = code % 10;

						processCompareModule(xmlDoc, ruleObject);
					}
				}
			}

			return ruleObject;//null means NOT M7K
		};
		
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "CI"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.conditions.CI);
					ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
				}
			}
			else if($(xmlDoc).attr("l_ch") == "CO"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.conditions.CO);
					ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
				}
			}
			else if($(xmlDoc).attr("l_ch") == "RI" || $(xmlDoc).attr("l_ch") == "RICB"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.conditions.RI);
					ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
					ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

					processCompareModule(xmlDoc, ruleObject);
				}
			}
			else if($(xmlDoc).attr("l_ch") == "RO" || $(xmlDoc).attr("l_ch") == "ROCB"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.conditions.RO);
					ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
					ruleObject.rule.deadband = parseFloat($(xmlDoc).attr("deadband") || "0");

					processCompareModule(xmlDoc, ruleObject);
				}
			}
			else if($(xmlDoc).attr("l_ch") == "STATUS"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "CO"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.actions.CO);
					ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
					if(ruleObject.rule.value >= 2){
						ruleObject.rule.value -= 2;
						ruleObject.rule.frequency = 1;
					}
					ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
				}
			}
			else if($(xmlDoc).attr("l_ch") == "RO"){
				if((ruleObject = processICPDASModule(xmlDoc)) == null){
					ruleObject = WISE.createRuleObject(this.pool.actions.RO);
					ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
					ruleObject.rule.channelAddress = parseInt($(xmlDoc).attr("l_chn"), 10);
					if(ruleObject.rule.operate >= 3){
						ruleObject.rule.operate -= 3;
						ruleObject.rule.frequency = 1;
					}
					ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);

					processCompareModule(xmlDoc, ruleObject);
				}
			}
		}

		if(ruleObject != null){
			if($(xmlDoc).attr("l_obj") == "RTU"){
				ruleObject.rule.moduleKey = moduleManager.pool.interfaces.comport[parseInt($(xmlDoc).attr("l_com"), 10)].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1].key;
			}
			else if($(xmlDoc).attr("l_obj") == "TCP"){
				ruleObject.rule.moduleKey = moduleManager.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1].key;
			}
		}
	}
	else if($(xmlDoc).attr("l_obj") == "CAMERA"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "GPIO_DI"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.cameraDI);
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "GPIO_DO"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.cameraDO);
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "Event"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.cameraEvent);
				ruleObject.rule.commandIndex = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "STATUS"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "GPIO_DO"){
				ruleObject = WISE.createRuleObject(this.pool.actions.cameraDO);
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);

				var code = {"0": 0, "1": 10, "2": 1, "3": 11, "4": 20}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
//			else if($(xmlDoc).attr("l_ch") == "Event"){
//				ruleObject = WISE.createRuleObject(this.pool.actions.cameraEvent);
//				ruleObject.rule.commandIndex = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
//
//				var code = {"0": 0, "1": 1}[$(xmlDoc).attr("op")];
//				ruleObject.rule.value = Math.floor(code / 10);
//				ruleObject.rule.frequency = code % 10;
//				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
//			}
			else if($(xmlDoc).attr("l_ch") == "Snapshot"){
				ruleObject = WISE.createRuleObject(this.pool.actions.cameraSnapshot);
				ruleObject.rule.commandIndex = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;

				var code = {"0": 0, "1": 1}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "Video"){
				ruleObject = WISE.createRuleObject(this.pool.actions.cameraVideo);
				ruleObject.rule.commandIndex = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;

				var code = {"0": 0, "1": 1}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
		}

		if(ruleObject != null){
			ruleObject.rule.moduleKey = moduleManager.pool.interfaces.camera[0].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1].key;
		}
	}

	return ruleObject;
};

WISE.managers.moduleManager.decodeXMLRule.processCompareModule = function(xmlDoc, ruleObject){//expose for process extended module
	var moduleManager = WISE.managers.moduleManager;
	if($(xmlDoc).attr("r_obj") == "DCON" || $(xmlDoc).attr("r_obj") == "XBOARD" || $(xmlDoc).attr("r_obj") == "RTU" || $(xmlDoc).attr("r_obj") == "TCP"){
		//check the module is extended module, if true, then skip
		var module = null;
		if($(xmlDoc).attr("r_obj") == "XBOARD"){
			module = moduleManager.pool.interfaces.onboard[0].modules[0];
		}
		else if($(xmlDoc).attr("r_obj") == "DCON" || $(xmlDoc).attr("r_obj") == "RTU"){
			module = moduleManager.pool.interfaces.comport[parseInt($(xmlDoc).attr("r_com"), 10)].modules[parseInt($(xmlDoc).attr("r_idx"), 10) - 1];
		}
		else if($(xmlDoc).attr("r_obj") == "TCP"){
			module = moduleManager.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("r_idx"), 10) - 1];
		}

		if(module != null && typeof(module.extendedModule) != "undefined"){
			return;
		}

		if($(xmlDoc).attr("r_ch") == "AI"){
			ruleObject.rule.type = 2;
		}
		else if($(xmlDoc).attr("r_ch") == "AO"){
			ruleObject.rule.type = 3;
		}
		else if($(xmlDoc).attr("r_ch") == "RI"){
			ruleObject.rule.type = 4;
		}
		else if($(xmlDoc).attr("r_ch") == "RO"){
			ruleObject.rule.type = 5;
		}
		else if($(xmlDoc).attr("r_ch") == "DIC"){
			ruleObject.rule.type = 7;
		}
		else if($(xmlDoc).attr("r_ch") == "DOC"){
			ruleObject.rule.type = 8;
		}

		if($(xmlDoc).attr("r_obj") == "XBOARD" || $(xmlDoc).attr("r_obj") == "DCON"){
			ruleObject.rule.value[ruleObject.rule.type].channelIndex = parseInt($(xmlDoc).attr("r_chn"), 10);
		}
		else if($(xmlDoc).attr("r_obj") == "RTU" || $(xmlDoc).attr("r_obj") == "TCP"){
			if(module.type == "icpdas"){//M7K
				var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $(xmlDoc).attr("r_ch"), parseInt($(xmlDoc).attr("r_chn"), 10));

				if(channelIndexInfo[0] == "IR"){
					ruleObject.rule.type = 1;
					ruleObject.rule.value[1].registerIndex = channelIndexInfo[1];
				}
				else if(channelIndexInfo[0] == "AI"){
					ruleObject.rule.type = 2;
					ruleObject.rule.value[2].channelIndex = channelIndexInfo[1];
				}
				else if(channelIndexInfo[0] == "AO"){
					ruleObject.rule.type = 3;
					ruleObject.rule.value[3].channelIndex = channelIndexInfo[1];
				}
				else if(channelIndexInfo[0] == "DIC"){
					ruleObject.rule.type = 7;
					ruleObject.rule.value[7].channelIndex = channelIndexInfo[1];
				}
				else if(channelIndexInfo[0] == "DOC"){
					ruleObject.rule.type = 8;
					ruleObject.rule.value[8].channelIndex = channelIndexInfo[1];
				}
			}
			else{
				ruleObject.rule.value[ruleObject.rule.type].channelAddress = parseInt($(xmlDoc).attr("r_chn"), 10);
			}
		}

		ruleObject.rule.value[ruleObject.rule.type].moduleKey = module.key;
	}
	else if($(xmlDoc).attr("r_obj") == "IR"){
		ruleObject.rule.type = 1;
		ruleObject.rule.value[1].registerIndex = parseInt($(xmlDoc).attr("r_idx"), 10) - 1;
	}
	else if($(xmlDoc).attr("r_obj") == "MQTT"){
		ruleObject.rule.type = 9;
		ruleObject.rule.value[9].brokerKey = parseInt($(xmlDoc).attr("r_idx"), 10) - 1;
		ruleObject.rule.value[9].topicKey = parseInt($(xmlDoc).attr("r_chn"), 10) - 1;
	}
	else if($(xmlDoc).attr("r_obj") == "AZURE"){
		ruleObject.rule.type = 10;
		ruleObject.rule.value[10].variableKey = parseInt($(xmlDoc).attr("r_chn"), 10) - 1;
	}
	else if($(xmlDoc).attr("r_obj") == "BLUEMIX"){
		ruleObject.rule.type = 11;

		if($(xmlDoc).attr("r_idx")){
			ruleObject.rule.value[11].commandKey = parseInt($(xmlDoc).attr("r_idx"), 10) - 1;
		}

		ruleObject.rule.value[11].variableKey = parseInt($(xmlDoc).attr("r_chn"), 10) - 1;
	}
	else if($(xmlDoc).attr("r_obj")){//value
		ruleObject.rule.type = 0;
		ruleObject.rule.value[0].constant = $(xmlDoc).attr("r_obj");
	}
};

WISE.managers.moduleManager.afterDecodeRuleFile = function(){
	this.updateModulesKey();
};