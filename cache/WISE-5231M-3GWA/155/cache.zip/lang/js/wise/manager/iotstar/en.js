$.extend(true, Lang, {
	"js/wise/manager/iotstar/rule/encoder.js": {
		"sendBackChannelIsEmpty": "The number of channels must be greater than or equal to one."
	}
});