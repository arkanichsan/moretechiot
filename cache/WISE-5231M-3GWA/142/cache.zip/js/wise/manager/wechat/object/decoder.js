WISE.managers.weChatManager.decodeXMLObject = function(xmlDoc){
	var maxKey = 0;
    
    var $xmlWECHAT = $(xmlDoc).find("WISE > NOTE > WECHAT");
    
    if($xmlWECHAT.length > 0){
        this.pool.enable = true;
        this.pool.corpId = $($xmlWECHAT).attr("corp_id");

        var $xmlAPPLICATION = $(xmlDoc).find("WISE > NOTE > WECHAT > APPLICATION");
        if($xmlAPPLICATION.length > 0){
            maxKey = 0;

            var $xmlA = $xmlAPPLICATION.find("> A");
            for(var i = 0; i < $xmlA.length; i++){
                var key = parseInt($($xmlA[i]).attr("idx"), 10) - 1;
                if(key > maxKey){maxKey = key};

                var application = this.createApplication({
                    "agentId": $($xmlA[i]).attr("agentid"),
                    "secret": $($xmlA[i]).attr("secret")
                });

                this.setApplication(key, application);
            }

            this.pool.applicationKey = ++maxKey;
        }

        var $xmlMESSAGE = $(xmlDoc).find("WISE > NOTE > WECHAT > MESSAGE");
        if($xmlMESSAGE.length > 0){
            maxKey = 0;

            var $xmlM = $xmlMESSAGE.find("> M");
            for(var i = 0; i < $xmlM.length; i++){
                var key = parseInt($($xmlM[i]).attr("idx"), 10) - 1;
                if(key > maxKey){maxKey = key};

                var message = this.createMessage({
                    "name": $($xmlM[i]).attr("nickname"),
                    "description": $($xmlM[i]).attr("desc") || "",
                    "applications": (function(applications){
                        for(var i = 0; i < applications.length; i++){
                            applications[i]--;
                        }
                        return applications;
                    })($($xmlM[i]).attr("app").split(",")),
                    "content": $($xmlM[i]).text()
                });

                this.setMessage(key, message);
            }

            this.pool.messageKey = ++maxKey;
        }

        var $xmlCAMERA = $(xmlDoc).find("WISE > NOTE > WECHAT > LINK > CAMERA");
        if($xmlCAMERA.length > 0){
            var moduleManager = WISE.managers.moduleManager;

            var $xmlC = $xmlCAMERA.find("> C");
            for(var i = 0; i < $xmlC.length; i++){
                var moduleIndex = parseInt($($xmlC[i]).attr("camera_idx") - 1);

                moduleManager.pool.interfaces.camera[0].modules[moduleIndex].weChat = {
                    "enable": true,
                    "applications": (function(){
                        var applications = $xmlC.attr("app").split(",");
                        for(var i = 0; i < applications.length; i++){
                            applications[i]--;
                        }
                        return applications;
                    })()
                };
            }
        }

        var $xmlCGI_SERVER = $(xmlDoc).find("WISE > NOTE > WECHAT > LINK > CGI_SERVER");
        if($xmlCGI_SERVER.length > 0){
            var cgiManager = WISE.managers.cgiManager;

            var $xmlC = $xmlCGI_SERVER.find("> C");
            for(var i = 0; i < $xmlC.length; i++){
                var index = parseInt($($xmlC[i]).attr("idx") - 1);

                cgiManager.pool.send.servers[index].weChat = {
                    "enable": true,
                    "applications": (function(){
                        var applications = $xmlC.attr("app").split(",");
                        for(var i = 0; i < applications.length; i++){
                            applications[i]--;
                        }
                        return applications;
                    })()
                };
            }
        } 
    }
};