﻿$.extend(true, Lang, {
	"js/wise/manager/cgi/rule/object.js": {
		"cgiCommand": "CGI命令",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"cgiSource": "CGI來源",
		"fromX": "來自$address",
		"send": "傳送"
	}
});