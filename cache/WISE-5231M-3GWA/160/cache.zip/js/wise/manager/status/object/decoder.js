WISE.managers.statusManager.decodeXMLObject = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var $xmlSTATUS = $(xmlDoc).find("WISE > STATUS");
	if($xmlSTATUS.length > 0){
		var $xmlS = $xmlSTATUS.find("> S");
		var maxKey = 0;
		for(var i = 0; i < $xmlS.length; i++){
			var key = parseInt($($xmlS[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var statusPage = this.createStatus({
				"name": $($xmlS[i]).attr("nickname"),
				"description": $($xmlS[i]).attr("desc")
			});
			this.setStatus(key, statusPage);

			var $xmlGROUP = $($xmlS[i]).find("> GROUP");
			for(var j = 0; j < $xmlGROUP.length; j++){
				var groupIndex = statusPage.group.push({}) - 1;
				var group = statusPage.group[groupIndex];
				group.title = $($xmlGROUP[j]).attr("nickname");
				group.block = [];

				var $xmlBLOCK = $($xmlGROUP[j]).find("> BLOCK");

				for(var k = 0; k < $xmlBLOCK.length; k++){
					var block = {};

					if($($xmlBLOCK[k]).attr("b_obj") == "IR"){
						block.type = "IR";
						block.registerIndex = parseInt($($xmlBLOCK[k]).attr("b_idx"), 10) - 1;
					}
					else{
						var module = null, protocol;
						if($($xmlBLOCK[k]).attr("b_obj") == "XBOARD"){
							var interfaces = moduleManager.pool.interfaces.onboard[0];
							protocol = interfaces.protocol;
							module = interfaces.modules[0];
						}
						else if($($xmlBLOCK[k]).attr("b_obj") == "DCON"){
							var interfaces = moduleManager.pool.interfaces.comport[parseInt($($xmlBLOCK[k]).attr("b_com"), 10)];
							protocol = interfaces.protocol;
							module = interfaces.modules[parseInt($($xmlBLOCK[k]).attr("b_idx"), 10) - 1];
						}
						else if($($xmlBLOCK[k]).attr("b_obj") == "RTU"){
							var interfaces = moduleManager.pool.interfaces.comport[parseInt($($xmlBLOCK[k]).attr("b_com"), 10)];
							protocol = interfaces.protocol;
							module = interfaces.modules[parseInt($($xmlBLOCK[k]).attr("b_idx"), 10) - 1];
						}
						else if($($xmlBLOCK[k]).attr("b_obj") == "TCP"){
							var interfaces = moduleManager.pool.interfaces.network[0];
							protocol = interfaces.protocol;
							module = interfaces.modules[parseInt($($xmlBLOCK[k]).attr("b_idx"), 10) - 1];
						}
						else if($($xmlBLOCK[k]).attr("b_obj") == "CAMERA"){
							var interfaces = moduleManager.pool.interfaces.camera[0];
							protocol = interfaces.protocol;
							module = interfaces.modules[parseInt($($xmlBLOCK[k]).attr("b_idx"), 10) - 1];
						}

						block.moduleKey = module.key;
						if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
							var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $($xmlBLOCK[k]).attr("b_ch"), parseInt($($xmlBLOCK[k]).attr("b_chn"), 10));
							block.type = channelIndexInfo[0];

							if(block.type == "IR"){
								block.registerIndex = channelIndexInfo[1];
							}
							else{
								block.channelIndex = channelIndexInfo[1];
							}
						}
						else{
							block.type = $($xmlBLOCK[k]).attr("b_ch");
							if(block.type == "DI" || block.type == "DO" || block.type == "AI" || block.type == "AO"){
								block.channelIndex = parseInt($($xmlBLOCK[k]).attr("b_chn"), 10);

								if($($xmlBLOCK[k]).attr("b_cnt") == "1"){//is counter
									block.type = "DIC";
								}
							}
							else{
								block.channelAddress = parseInt($($xmlBLOCK[k]).attr("b_chn"), 10);
							}
						}
					}

					group.block.push(block);
				}
			}
		}

		this.pool.key = ++maxKey;
	}
};