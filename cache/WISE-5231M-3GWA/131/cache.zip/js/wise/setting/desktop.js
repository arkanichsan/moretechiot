var useRuleHash = ["#home/main", "#home/status", "#home/camera"];

var debugMode = false;

var normalContainerWidth = 960, wideScreenContainerWidth = 1200;

var cssFiles = [
	"css/desktop/default.css",
	"css/desktop/navigation.css",
	"css/desktop/rulesetting.css",
	"css/desktop/popupwindows.css",
	"css/desktop/icons.css",
	"css/desktop/dropdownlist.css",
	"css/desktop/tip.css",
	"css/desktop/spotlight.css",
	"css/desktop/imageviewer.css",
	"css/desktop/jquery.ui.theme.css",
	"css/desktop/jquery.ui.autocomplete.css"
];

var languageFiles = [
	"lang/js/wise/core/base/" + currentLanguage + ".js",
	"lang/js/wise/core/desktop/" + currentLanguage + ".js",
	"lang/js/wise/manager/module/" + currentLanguage + ".js",
	"lang/js/wise/manager/timer/" + currentLanguage + ".js",
	"lang/js/wise/manager/schedule/" + currentLanguage + ".js",
	"lang/js/wise/manager/email/" + currentLanguage + ".js",
	"lang/js/wise/manager/cgi/" + currentLanguage + ".js",//PMC-5151 no use
	"lang/js/wise/manager/sms/" + currentLanguage + ".js",
	"lang/js/wise/manager/logger/" + currentLanguage + ".js",
	"lang/js/wise/manager/system/" + currentLanguage + ".js",
	"lang/js/wise/manager/activeio/" + currentLanguage + ".js",
	"lang/js/wise/manager/snmp/" + currentLanguage + ".js",
	"lang/js/wise/manager/azure/" + currentLanguage + ".js",
	"lang/js/wise/manager/bluemix/" + currentLanguage + ".js",
	"lang/js/wise/manager/mqtt/" + currentLanguage + ".js",
	"lang/js/wise/manager/linenotify/" + currentLanguage + ".js",
	"lang/js/wise/manager/linebot/" + currentLanguage + ".js",
	"lang/js/wise/manager/messenger/" + currentLanguage + ".js",
    "lang/js/wise/manager/wechat/" + currentLanguage + ".js",
    "lang/js/wise/manager/iotstar/" + currentLanguage + ".js",
	"lang/js/wise/manager/register/" + currentLanguage + ".js",
	"lang/js/wise/manager/rule/" + currentLanguage + ".js",
	"lang/js/wise/hash/desktop/" + currentLanguage + ".js",
	"lang/js/wise/init/desktop/" + currentLanguage + ".js",

	"lang/html/base/wise/" + currentLanguage + ".js",
	"lang/html/desktop/wise/" + currentLanguage + ".js"
];

var jsFiles = [
	"js/jquery/jquery.ui.min.js",
	"js/jquery/jquery.ui.sortable.fix.js",
	"js/jquery/jquery.ui.catcomplete.js",
	"js/jquery/jquery.history.js",
	"js/jquery/jquery.sliderow.js",
	"js/jquery/jquery.dropdownlist.js",
	"js/jquery/jquery.livequery.min.js",
	"js/jquery/jquery.bind-first.min.js",
	"js/jquery/jquery.tip.js",
	"js/jquery/jquery.insertatcaret.js",
	//"js/jquery/jquery.ba-resize.min.js",
	//"js/jquery/jquery.spotlight.js",
	//"js/jquery/jquery.guideline.js",
	"js/jquery/jquery.stopall.js",
	"js/jquery/jquery.crSpline.min.js",
	"js/jquery/jquery.download.js",

	"js/wise/utilities/base.js",
	"js/wise/utilities/desktop.js",

	"js/wise/core/base.js",
	"js/wise/core/desktop.js",

	"js/wise/manager/module/base.js",
	"js/wise/manager/module/object/encoder.js",
	"js/wise/manager/module/object/decoder.js",
	"js/wise/manager/module/rule/object.js",
	"js/wise/manager/module/rule/encoder.js",
	"js/wise/manager/module/rule/decoder.js",

	"js/wise/manager/timer/base.js",//PMC-5151 no use
	"js/wise/manager/timer/object/encoder.js",
	"js/wise/manager/timer/object/decoder.js",
	"js/wise/manager/timer/rule/object.js",
	"js/wise/manager/timer/rule/encoder.js",
	"js/wise/manager/timer/rule/decoder.js",

	"js/wise/manager/schedule/base.js",
	"js/wise/manager/schedule/object/encoder.js",
	"js/wise/manager/schedule/object/decoder.js",
	"js/wise/manager/schedule/rule/object.js",
	"js/wise/manager/schedule/rule/encoder.js",
	"js/wise/manager/schedule/rule/decoder.js",

	"js/wise/manager/email/base.js",
	"js/wise/manager/email/object/encoder.js",
	"js/wise/manager/email/object/decoder.js",
	"js/wise/manager/email/rule/object.js",
	"js/wise/manager/email/rule/encoder.js",
	"js/wise/manager/email/rule/decoder.js",

	"js/wise/manager/cgi/base.js",//PMC-5151 no use
	"js/wise/manager/cgi/object/encoder.js",
	"js/wise/manager/cgi/object/decoder.js",
	"js/wise/manager/cgi/rule/object.js",
	"js/wise/manager/cgi/rule/encoder.js",
	"js/wise/manager/cgi/rule/decoder.js",

	"js/wise/manager/sms/base.js",
	"js/wise/manager/sms/object/encoder.js",
	"js/wise/manager/sms/object/decoder.js",
	"js/wise/manager/sms/rule/object.js",
	"js/wise/manager/sms/rule/encoder.js",
	"js/wise/manager/sms/rule/decoder.js",

	"js/wise/manager/logger/base.js",
	"js/wise/manager/logger/object/encoder.js",
	"js/wise/manager/logger/object/decoder.js",
	"js/wise/manager/logger/rule/object.js",
	"js/wise/manager/logger/rule/encoder.js",
	"js/wise/manager/logger/rule/decoder.js",

	"js/wise/manager/status/base.js",//PMC-5151 no use
	"js/wise/manager/status/object/encoder.js",
	"js/wise/manager/status/object/decoder.js",
	"js/wise/manager/status/rule/encoder.js",

	"js/wise/manager/activeio/base.js",//PMC-5151 no use
	"js/wise/manager/activeio/object/encoder.js",
	"js/wise/manager/activeio/object/decoder.js",

	"js/wise/manager/snmp/base.js",
	"js/wise/manager/snmp/object/encoder.js",
	"js/wise/manager/snmp/object/decoder.js",
	"js/wise/manager/snmp/rule/object.js",
	"js/wise/manager/snmp/rule/encoder.js",
	"js/wise/manager/snmp/rule/decoder.js",

	"js/wise/manager/azure/base.js",
	"js/wise/manager/azure/object/encoder.js",
	"js/wise/manager/azure/object/decoder.js",
	"js/wise/manager/azure/rule/object.js",
	"js/wise/manager/azure/rule/encoder.js",
	"js/wise/manager/azure/rule/decoder.js",

	"js/wise/manager/bluemix/base.js",
	"js/wise/manager/bluemix/object/encoder.js",
	"js/wise/manager/bluemix/object/decoder.js",
	"js/wise/manager/bluemix/rule/object.js",
	"js/wise/manager/bluemix/rule/encoder.js",
	"js/wise/manager/bluemix/rule/decoder.js",

	"js/wise/manager/mqtt/base.js",
	"js/wise/manager/mqtt/object/encoder.js",
	"js/wise/manager/mqtt/object/decoder.js",
	"js/wise/manager/mqtt/rule/object.js",
	"js/wise/manager/mqtt/rule/encoder.js",
	"js/wise/manager/mqtt/rule/decoder.js",

	"js/wise/manager/linenotify/base.js",
	"js/wise/manager/linenotify/object/encoder.js",
	"js/wise/manager/linenotify/object/decoder.js",
	"js/wise/manager/linenotify/rule/object.js",
	"js/wise/manager/linenotify/rule/encoder.js",
	"js/wise/manager/linenotify/rule/decoder.js",

	"js/wise/manager/linebot/base.js",
	"js/wise/manager/linebot/object/encoder.js",
	"js/wise/manager/linebot/object/decoder.js",
	"js/wise/manager/linebot/rule/object.js",
	"js/wise/manager/linebot/rule/encoder.js",
	"js/wise/manager/linebot/rule/decoder.js",

	"js/wise/manager/messenger/base.js",
	"js/wise/manager/messenger/object/encoder.js",
	"js/wise/manager/messenger/object/decoder.js",
	"js/wise/manager/messenger/rule/object.js",
	"js/wise/manager/messenger/rule/encoder.js",
	"js/wise/manager/messenger/rule/decoder.js",

    "js/wise/manager/wechat/base.js",
	"js/wise/manager/wechat/object/encoder.js",
	"js/wise/manager/wechat/object/decoder.js",
	"js/wise/manager/wechat/rule/object.js",
	"js/wise/manager/wechat/rule/encoder.js",
	"js/wise/manager/wechat/rule/decoder.js",

    "js/wise/manager/iotstar/base.js",
	"js/wise/manager/iotstar/object/encoder.js",
	"js/wise/manager/iotstar/object/decoder.js",
	"js/wise/manager/iotstar/rule/encoder.js",

	"js/wise/manager/system/base.js",
	"js/wise/manager/system/rule/object.js",
	"js/wise/manager/system/rule/encoder.js",
	"js/wise/manager/system/rule/decoder.js",

	"js/wise/manager/register/base.js",
	"js/wise/manager/register/object/encoder.js",
	"js/wise/manager/register/object/decoder.js",
	"js/wise/manager/register/rule/object.js",
	"js/wise/manager/register/rule/encoder.js",
	"js/wise/manager/register/rule/decoder.js",

	"js/wise/manager/rule/base.js",
	"js/wise/manager/rule/object/encoder.js",
	"js/wise/manager/rule/object/decoder.js",
	"js/wise/manager/rule/rule/object.js",
	"js/wise/manager/rule/rule/encoder.js",
	"js/wise/manager/rule/rule/decoder.js",

	"js/wise/popup/base.js",
	"js/wise/popup/desktop.js",

	"js/wise/hash/desktop.js",

	"js/wise/init/desktop.js"
];
