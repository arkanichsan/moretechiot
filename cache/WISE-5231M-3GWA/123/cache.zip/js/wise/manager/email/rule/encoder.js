WISE.managers.emailManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "email"){
			xmlDoc.setAttribute("l_obj", "EMAIL");
			xmlDoc.setAttribute("l_idx", this.pool.emails[ruleObject.rule.emailKey].index);
			xmlDoc.setAttribute("op", {0: "0", 1: "1"}[ruleObject.rule.value * 10 + ruleObject.rule.frequency]);

			if(ruleObject.rule.delay > 0){
				xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
			}
		}
	}
};
