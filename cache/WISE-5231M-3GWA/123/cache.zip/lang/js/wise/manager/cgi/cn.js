$.extend(true, Lang, {
    "js/wise/manager/cgi/rule/object.js": {
        "cgiCommand": "CGI命令",
        "local": "本机",
        "remote": "远程",
        "internalRegister": "内部缓存器",
        "cgiSource": "CGI来源",
        "fromX": "来自$address",
        "send": "传送"
    }
});