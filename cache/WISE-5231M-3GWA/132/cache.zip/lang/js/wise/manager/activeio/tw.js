$.extend(true, Lang, {
	"js/wise/manager/activeio/object/encoder.js": {
		"mappingTableContainNotExistChannelOrIR": "Modbus位址對應表中有不存在的通道或內部暫存器，請移除它們。"
	},
	"js/wise/manager/activeio/base.js": {
		"diCounterX": "DI計數器$channel",
		"doCounterX": "DO計數器$channel",
		"internalRegisterX": "內部暫存器$channel"
	}
});