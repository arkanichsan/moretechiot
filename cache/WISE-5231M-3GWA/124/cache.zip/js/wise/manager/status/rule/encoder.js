WISE.managers.statusManager.check = function(){//return null means no error
	for(var key in this.pool.statusPages){
		var statusPage = this.pool.statusPages[key];

		for(var i = 0; i < statusPage.group.length; i++){
			var group = statusPage.group[i];

			for(var j = 0; j < group.block.length; j++){
				var block = group.block[j];

				if(block.type == "IR"){
					if(block.moduleKey == null){
						var registerManager = WISE.managers.registerManager;
						if(typeof(registerManager.pool.registers[block.registerIndex]) == "undefined"){
							group.block.splice(j, 1);
							j--;
						}
					}
					else{
						var moduleManager = WISE.managers.moduleManager;
						var module = moduleManager.getModuleByKey(block.moduleKey);
						if(module == null){
							group.block.splice(j, 1);
							j--;
						}
					}
				}
				else{
					var moduleManager = WISE.managers.moduleManager;
					var module = moduleManager.getModuleByKey(block.moduleKey);

					if(module == null){
						group.block.splice(j, 1);
						j--;
					}
					else{
						var type = block.type;
						if(type == "DIC"){
							type = "DI";
						}
						else if(type == "DOC"){
							type = "DO";
						}

						if(
							(
								(module.type == "icpdas" || module.type == "onboard") && (module[type].amount <= block.channelIndex || module[type].setting[block.channelIndex].disable == true)
							) || (
								(module.type == "rtu" || module.type == "tcp") && typeof(module[block.type].remoteAddress[block.channelAddress]) == "undefined"
							)
						){
							group.block.splice(j, 1);
							j--;
						}
					}
				}
			}
		}
	}
};