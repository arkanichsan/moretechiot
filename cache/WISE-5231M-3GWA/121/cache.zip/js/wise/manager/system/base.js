WISE.managers.systemManager = (function(){
	return new function() {
		this.pool = {
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
	};
})();
