WISE.managers.systemManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "sdCard"){
			xmlDoc.setAttribute("l_obj", "MICROSD");
		}
		else if(ruleObject.ruleObjectKey == "signal"){
			xmlDoc.setAttribute("l_obj", "SMS");
			xmlDoc.setAttribute("l_ch", ruleObject.rule.unit == 0 ? "SIGNAL" : "SIGNAL_P");
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "reboot"){
			xmlDoc.setAttribute("l_obj", "REBOOT");
			xmlDoc.setAttribute("op", ruleObject.rule.value);

			if(ruleObject.rule.delay > 0){
				xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
			}
		}
	}
};