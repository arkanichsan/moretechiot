﻿$.extend(true, Lang, {
	"js/wise/manager/activeio/object/encoder.js": {
		"mappingTableContainNotExistChannelOrIR": "Modbus地址对应表中有不存在的信道或内部缓存器，请移除它们。"
	},
	"js/wise/manager/activeio/base.js": {
		"diCounterX": "DI计数器$channel",
		"doCounterX": "DO计数器$channel",
		"internalRegisterX": "内部缓存器$channel"
	}
});