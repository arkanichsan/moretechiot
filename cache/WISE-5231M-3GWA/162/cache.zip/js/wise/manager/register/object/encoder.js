WISE.managers.registerManager.encodeXMLObject = function(xmlDoc){
	var xmlIR = xmlDoc.createElement("IR");
	xmlIR.setAttribute("start_address", "60");

	if(this.pool._csvHeader != ""){
		xmlIR.setAttribute("csv_header", this.pool._csvHeader);
		xmlIR.setAttribute("csv_index", this.pool._csvIndex);
	}

	for(var i = 0, registers = this.pool.registers; i < this.pool.registers.length; i++){
		if(typeof(registers[i]) == "undefined"){continue;}

		var register = registers[i];
		var xmlI = xmlDoc.createElement("I");

		xmlI.setAttribute("idx", i + 1);
		xmlI.setAttribute("value", register.initialValue);
		xmlI.setAttribute("type", register.type);
		xmlI.setAttribute("nickname", register.name);

		if(register.equation.enable == true){
			xmlI.setAttribute("formula", register.equation.expression);
		}

		if(register.description != ""){
			xmlI.setAttribute("desc", register.description);
		}

		for(var j = 0; j < register.bitName.length; j++){
			if(typeof(register.bitName[j]) != "undefined" && register.bitName[j] != ""){
				var xmlB = xmlDoc.createElement("B");
				xmlB.setAttribute("idx", j + 1);
				xmlB.setAttribute("nickname", register.bitName[j]);
				xmlI.appendChild(xmlB);
			}
		}

		xmlIR.appendChild(xmlI);
	}

	if(xmlIR.childNodes.length > 0){
		xmlDoc.documentElement.appendChild(xmlIR);
	}
};

