WISE.managers.emailManager = (function(){
	return new function() {
		this.pool = {
			emails: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 12;

		this.createEmail = function(settings){
			var email = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"smtpServer": {
					"url": "",
					"port": 25
				},
				"authInfo": {
					"id": "",
					"password": {
						"plain": "",
						"encoded": "",
						"length": 0,
					},
					"securityMode": 3// 0:No Security / 1:TLS / 2:SSL / 3: No Check Authentication
				},
				"senderInfo": {
					"name": "",
					"address": ""
				},
				"receiverInfo": {
					"address": []	
				},
				"subject": "",
				"content": ""
			}, settings);

			return email;
		};

		this.addEmail = function(email){
			var retKey = this.pool.key;
			this.pool.emails[this.pool.key++] = email;
			return retKey;
		};

		this.removeEmail = function(key){
			delete this.pool.emails[key];
		};

		this.getEmail = function(key){
			if(typeof(this.pool.emails[key]) != "undefined"){
				return this.pool.emails[key];
			}
			else{
				return null;
			}
		};

		this.setEmail = function(key, email){
			this.pool.emails[key] = email;
		};

		this.getEmails = function(){
			return this.pool.emails;
		};
	};
})();
