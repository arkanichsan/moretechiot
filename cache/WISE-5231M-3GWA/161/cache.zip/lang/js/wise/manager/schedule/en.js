$.extend(true, Lang, {
	"js/wise/manager/schedule/rule/object.js": {
		"schedule": "Schedule",
		"outOfRange": "Out of Range",
		"inRange": "In Range"
	}
});