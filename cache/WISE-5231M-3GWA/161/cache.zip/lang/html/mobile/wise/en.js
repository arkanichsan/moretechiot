$.extend(true, Lang, {
	"html/mobile/frame.htm": {
		"goToDesktopVersion": "Go to desktop version.",
		"dialog": "Dialog",
		"prompt": "Prompt"
	},
	"html/mobile/home/menu.htm": {
		"menu": "Menu",
		"home": "Home",
		"internalRegister": "Internal Register",
		"customizeStatus": "Channel Status"
	},
	"html/mobile/home/main.htm": {
		"systemInformation": "System Information",
		"nickname": "Nickname",
		"date": "Date",
		"time": "Time",
		"microSDSpace": "microSD Space",
		"approxXDays": "Approx.$day Days",
		"noSDCard": "No microSD card detected.",
		"none": "None",
		"totalNumberOfIOModule": "Total no. of I/O",
		"moduleList": "Module List",
		"ipAndPort": "IP & Port",
		"address": "Address",
		"scanRate": "Scan Rate",
		"pollingTimeout": "Polling Timeout"
	}
});