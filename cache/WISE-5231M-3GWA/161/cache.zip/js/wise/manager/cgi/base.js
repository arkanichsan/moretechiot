WISE.managers.cgiManager = (function(){
	return new function() {
		this.pool = {
			send:{
				servers: {},
				key: 0
			},
			receive:{
				variables: {},
				variableKey: 0,

				clients: {},
				clientKey: 0
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxServerAmount = 12;
		this.maxCommandAmount = 12;

		this.maxVariableAmount = 12;
		this.maxClientAmount = 12;

		//send
		this.createServer = function(settings){
			var server = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"commands": {},
				"key": 0,

				"address": "",
				"port": 80,
				"retryTimes": 0,
				"authInfo": {
					"authType": 0,//0: None, 1: Basic, 2: Digest
					"id": "",
					"password": {
						"plain": "",
						"encoded": "",
						"length": 0,
					}
				},
				"ftpServers": []//key
			}, settings);
			
			return server;
		};

		this.addServer = function(server){
			var retKey = this.pool.send.key;
			this.pool.send.servers[this.pool.send.key++] = server;
			return retKey;
		};

		this.removeServer = function(key){
			delete this.pool.send.servers[key];
		};

		this.getServer = function(key){
			if(typeof(this.pool.send.servers[key]) != "undefined"){
				return this.pool.send.servers[key];
			}
			else{
				return null;
			}
		};

		this.setServer = function(key, server){
			this.pool.send.servers[key] = server;
		};

		this.getServers = function(){
			return this.pool.send.servers;
		};

		this.createCommand = function(settings){
			var command = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"method": "GET",// GET or POST
				"command": "",
				"body": "",// for POST
				"saveResponseAsFile": {
					"enable": false,
					"path": "",
					"fileVariable": "",
					"emailKey": null//send back via email
				}
			}, settings);
			
			return command;
		};

		this.addCommand = function(server, command){
			var retKey = server.key;
			server.commands[server.key++] = command;
			return retKey;
		};

		this.removeCommand = function(server, key){
			delete server.commands[key];
		};

		this.getCommand = function(server, key){
			if(typeof(server.commands[key]) != "undefined"){
				return server.commands[key];
			}
			else{
				return null;
			}
		};

		this.setCommand = function(server, key, command){
			server.commands[key] = command;
		};

		this.getCommands = function(server){
			return server.commands;
		};

		//receive
		this.createVariable = function(settings){
			var variable = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"key": ""
			}, settings);
			
			return variable;
		};

		this.addVariable = function(variable){
			var retKey = this.pool.receive.variableKey;
			this.pool.receive.variables[this.pool.receive.variableKey++] = variable;
			return retKey;
		};

		this.removeVariable = function(key){
			delete this.pool.receive.variables[key];
		};

		this.getVariable = function(key){
			if(typeof(this.pool.receive.variables[key]) != "undefined"){
				return this.pool.receive.variables[key];
			}
			else{
				return null;
			}
		};

		this.setVariable = function(key, variable){
			this.pool.receive.variables[key] = variable;
		};

		this.getVariables = function(){
			return this.pool.receive.variables;
		};

		this.createClient = function(settings){
			var client = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"address": ""
			}, settings);
			
			return client;
		};

		this.addClient = function(client){
			var retKey = this.pool.receive.clientKey;
			this.pool.receive.clients[this.pool.receive.clientKey++] = client;
			return retKey;
		};

		this.removeClient = function(key){
			delete this.pool.receive.clients[key];
		};

		this.getClient = function(key){
			if(typeof(this.pool.receive.clients[key]) != "undefined"){
				return this.pool.receive.clients[key];
			}
			else{
				return null;
			}
		};

		this.setClient = function(key, client){
			this.pool.receive.clients[key] = client;
		};

		this.getClients = function(){
			return this.pool.receive.clients;
		};
	};
})();
