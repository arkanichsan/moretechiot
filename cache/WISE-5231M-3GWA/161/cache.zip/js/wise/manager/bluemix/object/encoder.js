WISE.managers.bluemixManager.encodeXMLObject = function(xmlDoc){
	var processVariableToJSONString = function(variable){
		var moduleProcessor = WISE.managers.bluemixManager.encodeXMLObject.processModuleVariableToJSONString;

		var registerProcessor = function(registerInfo, variable){
			try{
				return '{' + 
					'"msg_type":"CHANNEL_UPDATE",' +
					'"ch_type":"IR",' +
					'"ch_addr":' + (registerInfo.registerIndex + 1) + ',' +
					'"nickname":"' + (WISE.registerInfo(registerInfo.registerIndex).match(/\((.*)\)/)[1] || "") + '",' +
					'"value":' + variable +
				'}';
			}
			catch(error){
				return '{' + 
					'"msg_type": "INTERNAL_REGISTER_NOT_EXIST"' +
				'}';
			}
		};

		var systemInformationProcessor = function(systemInfo, variable){
			try{
				var desc = {
					"Ty": "DATE_YEAR",
					"TM": "DATE_MONTH",
					"Td": "DATE_DAY",
					"Th": "TIME_HOUR",
					"Tm": "TIME_MINUTE",
					"Ts": "TIME_SECOND",
					"TU": "UNIX_TIMESTAMP",
					"Ss": "SIGNAL_STRENGTH_DBM",
					"Sp": "SIGNAL_STRENGTH_PERCENT"
				}[systemInfo.item];

				return '{' + 
					'"msg_type":"SYSTEM_INFORMATION_UPDATE",' +
					'"info_item":"' + desc + '",' +
					'"value":' + variable +
				'}';
			}
			catch(error){
				return '{' + 
					'"msg_type": "SYSTEM_INFORMATION_NOT_EXIST"' +
				'}';
			}
		};

		var json = null;
		var regex = new RegExp("\\$(X|C(\\d+)D(\\d+))(\\D+\\d+)|\\$(T(\\d+)|C(\\d+)M(\\d+))(\\D+\\d+)|\\$(I(\\d+))|\\$(S(T[yMdhmsU]|S[sp]))" + (typeof(WISE.getVariable.extendRegex) == "string" ? "|(" + WISE.buildVariableEditor.extendRegex + ")": ""));
		var result = regex.exec(variable);

		if(result){
			for(var i = 0; i < result.length; i++){
				if(typeof(result[i]) == "undefined"){
					result[i] = "";
				}
			}

			if(result[1].charAt(0) == "X"){//xwboard
				json = moduleProcessor({
					"sourceType": "onboard",
					"sourceIndex": 0,
					"moduleIndex": 0
				}, result[4], variable);
			}
			else if(result[1].charAt(0) == "C"){//dcon
				json = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[2], 10),
					"moduleIndex": parseInt(result[3], 10) - 1
				}, result[4], variable);
			}
			else if(result[5].charAt(0) == "T"){//modbus tcp
				json = moduleProcessor({
					"sourceType": "network",
					"sourceIndex": 0,
					"moduleIndex": parseInt(result[6], 10) - 1
				}, result[9], variable);
			}
			else if(result[5].charAt(0) == "C"){//modbus rtu
				json = moduleProcessor({
					"sourceType": "comport",
					"sourceIndex": parseInt(result[7], 10),
					"moduleIndex": parseInt(result[8], 10) - 1
				}, result[9], variable);
			}
			else if(result[10].charAt(0) == "I"){//ir
				json = registerProcessor({
					"registerIndex": parseInt(result[11], 10) - 1,
					"moduleKey": null
				}, variable);
			}
			else if(result[12].charAt(0) == "S"){//system
				json = systemInformationProcessor({
					"item": result[13]
				}, variable);
			}
			else{
				if(typeof(WISE.managers.bluemixManager.encodeXMLObject.processExtendVariableToJSONString) == "function"){
					json = WISE.managers.bluemixManager.encodeXMLObject.processExtendVariableToJSONString(result.slice(14));
				}
			}
		}

		return json;
	};

	if(this.pool.enable == true){
		var xmlBLUEMIX = xmlDoc.createElement("BLUEMIX");

		xmlBLUEMIX.setAttribute("org_id", this.pool.organizationID);
		xmlBLUEMIX.setAttribute("device_type", this.pool.deviceType);
		xmlBLUEMIX.setAttribute("device_id", this.pool.deviceID);
		xmlBLUEMIX.setAttribute("auth_token", this.pool.deviceAuthenticationToken);
		xmlBLUEMIX.setAttribute("alive_timer", this.pool.keepAliveTimer);
		xmlBLUEMIX.setAttribute("publish_period", this.pool.publishInterval);

		var messageCounter = 0;
		var xmlPUBLISH = xmlDoc.createElement("PUBLISH");

		var messages = this.pool.publish.messages;
		for(var messageKey in messages){
			var message = messages[messageKey];

			var xmlP = xmlDoc.createElement("P");
			xmlP.setAttribute("idx", message.index);
			xmlP.setAttribute("nickname", message.name);
			xmlP.setAttribute("event_id", message.eventID);
			xmlP.setAttribute("data_type", message.type);

			if(message.type == 0){
				if(message.json == true){
					xmlP.setAttribute("data", processVariableToJSONString(message.payload));//in json format
					xmlP.setAttribute("use_json", "1");
					xmlP.setAttribute("ch_var", message.payload);
				}
				else{
					xmlP.setAttribute("data", message.payload);
					xmlP.setAttribute("use_json", "0");
				}
			}
			else{
				xmlP.setAttribute("data", message.payload);
			}

			if(message.autoPublish.timing & 1){
				xmlP.setAttribute("pub_gate", message.autoPublish.threshold);
			}
			if(message.autoPublish.timing & 2){
				xmlP.setAttribute("period_pub", "1");
			}
			else{
				xmlP.setAttribute("period_pub", "0");
			}

			if(message.type == 0){
				xmlP.setAttribute("use_json", "1");
			}

			if(message.description != ""){
				xmlP.setAttribute("desc", message.description);
			}

			xmlPUBLISH.appendChild(xmlP);

			messageCounter++;
		}

		xmlPUBLISH.setAttribute("topic_num", messageCounter);
		xmlBLUEMIX.appendChild(xmlPUBLISH);

		var variableAttr = "", commandAttr = "";
		var xmlSUBSCRIBE = xmlDoc.createElement("SUBSCRIBE");

		for(var commandKey in this.pool.subscribe.commands){
			var command = this.pool.subscribe.commands[commandKey];
			commandAttr += command.key + ",";
		}
		commandAttr = commandAttr.substring(0, commandAttr.length - 1);

		if(commandAttr != ""){
			var xmlMESSAGE = xmlDoc.createElement("COMMAND");
			xmlMESSAGE.setAttribute("cmd", commandAttr);
			xmlSUBSCRIBE.appendChild(xmlMESSAGE);
		}

		for(var variableKey in this.pool.subscribe.variables){
			var variable = this.pool.subscribe.variables[variableKey];
			variableAttr += variable.key + ",";
		}
		variableAttr = variableAttr.substring(0, variableAttr.length - 1);

		if(variableAttr != ""){
			var xmlMESSAGE = xmlDoc.createElement("MESSAGE");
			xmlMESSAGE.setAttribute("key", variableAttr);
			xmlSUBSCRIBE.appendChild(xmlMESSAGE);
		}

		xmlBLUEMIX.appendChild(xmlSUBSCRIBE);

		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				var xmlNOTE = xmlDoc.documentElement.childNodes[i];

				var findTag = false;
				for(var j = 0; j < xmlNOTE.childNodes.length; j++){
					if(xmlNOTE.childNodes[j].nodeName == "IOT"){// find IOT tag exist, create by other manager
						xmlNOTE.childNodes[j].appendChild(xmlBLUEMIX);
						findTag = true;
						break;
					}
				}

				if(findTag == false){// not found IOT tag
					var xmlIOT = xmlDoc.createElement("IOT");
					xmlIOT.appendChild(xmlBLUEMIX);
					xmlNOTE.appendChild(xmlIOT);
				}

				break;
			}
		}
	}
};

WISE.managers.bluemixManager.encodeXMLObject.processModuleVariableToJSONString = function(moduleInfo, channelVariable, variable){
	try{
		var regex = /(\D+)(\d+)/;
		var result = regex.exec(channelVariable);

		if(result){
			for(var i = 0; i < result.length; i++){
				if(typeof(result[i]) == "undefined"){
					result[i] = "";
				}
			}

			moduleInfo.channelType = result[1].toUpperCase();
			moduleInfo.channel = parseInt(result[2].toUpperCase(), 10);
		}

		var module = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.type == "icpdas" || module.type == "onboard"){
			var protocol = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

			if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
				var channelIndexInfo = WISE.managers.moduleManager.icpdasModule.channelAddressToIndex(module, moduleInfo.channelType, moduleInfo.channel);
				moduleInfo.channelType = channelIndexInfo[0];
				moduleInfo.channel = channelIndexInfo[1];
			}
			else{//I7K, XW-Board
				if(moduleInfo.channelType == "CI"){
					moduleInfo.channelType = "DIC";
				}
			}
		}

		var sourceTypeName = {
			"onboard": "0",
			"comport": "1",
			"network": "2"
		}[moduleInfo.sourceType];

		var channelTypeName = {
			"DI": "DI",
			"DIC": "DI_COUNTER",
			"DO": "DO",
			"DOC": "DO_COUNTER",
			"AI": "AI",
			"AO": "AO",
			"CI": "DISCRETE_INPUT",
			"CO": "COIL_OUTPUT",
			"RI": "INPUT_REGISTERL",
			"RO": "HOLDING_REGISTER",
			"IR": "IR"//WISE-7000
		}[moduleInfo.channelType];

		return '{' + 
			'"msg_type":"CHANNEL_UPDATE",' +
			'"if_type":' + sourceTypeName + ',' +
			(moduleInfo.sourceType == "comport" ? '"com_port":' + moduleInfo.sourceIndex + ',' : '') +
			(moduleInfo.sourceType != "onboard" ? '"module_no":' + (moduleInfo.moduleIndex + 1) + ',' : '') +
			'"ch_type":"' + channelTypeName + '",' +
			'"ch_addr":' + (moduleInfo.channelType == "IR" ? (moduleInfo.channel + 1) : moduleInfo.channel) + ',' +
			'"nickname":"' + (moduleInfo.channelType != "IR" ? WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, moduleInfo.channelType, moduleInfo.channel).name : "") + '",' +
			'"value":' + variable +
		'}';
	}
	catch(error){
		return '{' + 
			'"msg_type": "MODULE_NOT_EXIST"' +
		'}';
	}
};

WISE.managers.bluemixManager.updateIndex = function(){
	var messageIndex = 0;
	for(var messageKey in this.pool.publish.messages){
		this.pool.publish.messages[messageKey].index = ++messageIndex;
	}

	var commandIndex = 0;
	for(var commandKey in this.pool.subscribe.commands){
		this.pool.subscribe.commands[commandKey].index = ++commandIndex;
	}

	var variableIndex = 0;
	for(var variableKey in this.pool.subscribe.variables){
		this.pool.subscribe.variables[variableKey].index = ++variableIndex;
	}
};
