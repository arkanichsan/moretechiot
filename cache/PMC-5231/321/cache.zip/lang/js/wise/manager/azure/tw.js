$.extend(true, Lang, {
	"js/wise/manager/azure/rule/object.js": {
		"connectionStatus": "連線狀態",
		"offline": "斷線",
		"online": "連線",
		"azureConnectionStatus": "Microsoft Azure連線狀態",
		"subscribeMessage": "接收訊息",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"functionStatus": "功能狀態",
		"azureFunctionStatus": "Microsoft Azure功能狀態",
		"publishMessage": "發佈訊息",
		"publish": "發佈",
		"azurePublishMessage": "Microsoft Azure發佈訊息"
	}
});