WISE.managers.loggerManager.decodeXMLObject = function(xmlDoc){
	var $xmlDATALOG = $(xmlDoc).find("WISE > NOTE > DATALOG");
	if($xmlDATALOG.length > 0){
		var $xmlPOWERLOG = $xmlDATALOG.find("POWERLOG");
		if($xmlPOWERLOG.length > 0){
			this.pool.dataLog.powerMeterLog.enable = true;
			this.pool.dataLog.powerMeterLog.mode = parseInt($xmlPOWERLOG.attr("mode"), 10);
			this.pool.dataLog.powerMeterLog.addHeader = $xmlPOWERLOG.attr("header") == "1" ? true : false;
			this.pool.dataLog.powerMeterLog.report = $xmlPOWERLOG.attr("report") || "";
			this.pool.ftp.upload.dataLog.powerMeterLog.enable = $xmlPOWERLOG.attr("upload") == "1" ? true : false;
			this.pool.cloud.upload.dataLog.powerMeterLog.enable = $xmlPOWERLOG.attr("cloud") == "1" ? true : false;
		}

		var $xmlIOLOG = $xmlDATALOG.find("IOLOG");
		if($xmlIOLOG.length > 0){
			this.pool.dataLog.ioModuleLog.enable = true;
			this.pool.ftp.upload.dataLog.ioModuleLog.enable = $xmlIOLOG.attr("upload") == "1" ? true : false;
			this.pool.cloud.upload.dataLog.ioModuleLog.enable = $xmlIOLOG.attr("cloud") == "1" ? true : false;
		}

		var $xmlUSER_DEFINED = $xmlDATALOG.find("USER_DEFINED");
		if($xmlUSER_DEFINED.length > 0){
			this.pool.dataLog.customizedLog.enable = true;
			this.pool.dataLog.customizedLog.format = $xmlUSER_DEFINED.text();
			this.pool.ftp.upload.dataLog.customizedLog.enable = $xmlUSER_DEFINED.attr("upload") == "1" ? true : false;
		}

		var $xmlLOG_SETTING = $xmlDATALOG.find("LOG_SETTING");
		if($xmlLOG_SETTING.length > 0){
			this.pool.dataLog.rate = parseInt($xmlLOG_SETTING.attr("rate"), 10);
			this.pool.dataLog.fileNameFormat = parseInt($xmlLOG_SETTING.attr("filename_format"), 10);
			this.pool.dataLog.eof = parseInt($xmlLOG_SETTING.attr("eof"), 10);
			this.pool.dataLog.keepTime = parseInt($xmlLOG_SETTING.attr("keep_time"), 10);
			if($xmlLOG_SETTING.attr("upload_period")){
				this.pool.ftp.upload.dataLog.period = parseInt($xmlLOG_SETTING.attr("upload_period"), 10);
			}
		}

		var $xmlEVENTLOG = $xmlDATALOG.find("EVENTLOG");
		if($xmlEVENTLOG.length > 0){
			this.pool.eventLog.keepTime = parseInt($xmlEVENTLOG.attr("keep_time"), 10);
			this.pool.ftp.upload.eventLog.enable = $xmlEVENTLOG.attr("upload") == "1" ? true : false;
			if($xmlEVENTLOG.attr("upload_period")){
				this.pool.ftp.upload.eventLog.period = parseInt($xmlEVENTLOG.attr("upload_period"), 10);
			}
		}

		var $xmlFTP = $xmlDATALOG.find("FTP");
		if($xmlFTP.length > 0){
			this.pool.ftp.enable = true;
			this.pool.ftp.url = $xmlFTP.attr("url");
			this.pool.ftp.port = parseInt($xmlFTP.attr("port"), 10);
			this.pool.ftp.id = $xmlFTP.attr("id");
			this.pool.ftp.url = $xmlFTP.attr("url");
			this.pool.ftp.password = (function(password, passwordLength){
				return {
					plain: padding("", passwordLength, "*"),
					encoded: password,
					length: passwordLength
				};
			})($xmlFTP.attr("password"), parseInt($xmlFTP.attr("password_len"), 10));
			this.pool.ftp.path = $xmlFTP.attr("path") || "";//downward compatibility
		}

		var $xmlCLOUD = $xmlDATALOG.find("CLOUD");
		if($xmlCLOUD.length > 0){
			this.pool.cloud.enable = true;
		}
		
		var $xmlEMAIL = $xmlDATALOG.find("EMAILREPORT");
		if($xmlEMAIL.length > 0 && $xmlEMAIL.attr("email_idx") != -1){
			this.pool.EmailReport.email_idx = parseInt($xmlEMAIL.attr("email_idx"),10) - 1;
			this.pool.EmailReport.Report.type = $xmlEMAIL.attr("type");
			this.pool.EmailReport.Report.language = $xmlEMAIL.attr("language");
			this.pool.EmailReport.ck_zip = $xmlEMAIL.attr("ck_zip");
		}
	}
};
