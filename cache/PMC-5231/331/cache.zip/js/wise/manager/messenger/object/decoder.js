WISE.managers.messengerManager.decodeXMLObject = function(xmlDoc){
	var maxKey = 0;
    var $xmlFB_MESSENGER = $(xmlDoc).find("WISE > NOTE > FB_MESSENGER");
    
    if($xmlFB_MESSENGER.length > 0){
        this.pool.enable = true;

        maxKey = 0;
        var key = 0;
        if(key > maxKey){maxKey = key};

        var page = this.createPage({
            "token": $($xmlFB_MESSENGER).attr("token")
        });

        this.setPage(key, page);
        this.pool.pageKey = ++maxKey;

        var $xmlMESSAGE = $xmlFB_MESSENGER.find("> MESSAGE");
        if($xmlMESSAGE.length > 0){
            maxKey = 0;

            var $xmlM = $xmlMESSAGE.find("> M");
            for(var i = 0; i < $xmlM.length; i++){
                var key = parseInt($($xmlM[i]).attr("idx"), 10) - 1;
                if(key > maxKey){maxKey = key};

                var message = this.createMessage({
                    "name": $($xmlM[i]).attr("nickname"),
                    "description": $($xmlM[i]).attr("desc") || "",
                    "pages": [0],
                    "content": $($xmlM[i]).text()
                });

                this.setMessage(key, message);
            }

            this.pool.messageKey = ++maxKey;
        }
    }
};