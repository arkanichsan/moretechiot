WISE.managers.pueManager.encodeXMLObject = function(xmlDoc){
	var xmlPUE = xmlDoc.createElement("PUE");
	var pueCounter = 0;

	for(var i = 0, pues = this.pool.pues; i < this.pool.pues.length; i++){
		if(typeof(pues[i])  == "undefined"){continue;}

		var pue = pues[i];
		var xmlP = xmlDoc.createElement("P");

		xmlP.setAttribute("idx", i + 1);
		xmlP.setAttribute("nickname", pue.name);

		xmlP.setAttribute("min", pue.chartBoundary.minimum);
		xmlP.setAttribute("max", pue.chartBoundary.maximum);
		xmlP.setAttribute("percent", pue.displayInPercentage == true ? "1" : "0");

		if(pue.description != ""){
			xmlP.setAttribute("desc", pue.description);
		}

		//color
		if(pue.chartMarker.length > 0){
			var xmlMARKER = xmlDoc.createElement("MARKER");
			for(var j = 0; j < pue.chartMarker.length; j++){
				var xmlM = xmlDoc.createElement("M");
				xmlM.setAttribute("name", pue.chartMarker[j].name);
				xmlM.setAttribute("value", pue.chartMarker[j].value);
				//xmlM.setAttribute("color", pue.chartMarker[j].color);
				xmlMARKER.appendChild(xmlM);
			}
			xmlP.appendChild(xmlMARKER);
		}

		var splitArray = pue.range.split("_");
		var itemType = splitArray[0];
		var itemIndex = -1;

		for(var j = 0; j < itemInformation[itemType].length; j++){
			if(itemInformation[itemType][j].tagName == splitArray[1]){
				itemIndex = j;
				break;
			}
		}

		var moduleManager = WISE.managers.moduleManager;
		var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;

		var counter = 0;
		var xmlNUMERATOR = xmlDoc.createElement("NUMERATOR");
		for(var j = 0; j < pue.totalEnergys.length; j++){
			var xmlN = xmlDoc.createElement("N");
			xmlN.setAttribute("idx", j + 1);

			var module = processModuleInfo(xmlN, "l", pue.totalEnergys[j].moduleKey).module;
			var channel = module.powerMeter.channel[pue.totalEnergys[j].loop][pue.totalEnergys[j].phase][itemType][itemIndex];
			var dataModel = module.powerMeter.format[channel.format].dataModel;

			xmlN.setAttribute("l_ch", dataModel);
			xmlN.setAttribute("l_chn", channel.address);
			xmlN.setAttribute("op", pue.totalEnergys[j].operator);
			xmlN.setAttribute("r_obj", "0");
			xmlNUMERATOR.appendChild(xmlN);
			counter++;
		}
		xmlNUMERATOR.setAttribute("num", counter);
		xmlP.appendChild(xmlNUMERATOR);

		var counter = 0;
		var xmlDENOMINATOR = xmlDoc.createElement("DENOMINATOR");
		for(var j = 0; j < pue.itEnergys.length; j++){
			var xmlD = xmlDoc.createElement("D");
			xmlD.setAttribute("idx", j + 1);

			var module = processModuleInfo(xmlD, "l", pue.itEnergys[j].moduleKey).module;
			var channel = module.powerMeter.channel[pue.itEnergys[j].loop][pue.itEnergys[j].phase][itemType][itemIndex];
			var dataModel = module.powerMeter.format[channel.format].dataModel;

			xmlD.setAttribute("l_ch", dataModel);
			xmlD.setAttribute("l_chn", channel.address);
			xmlD.setAttribute("op", pue.itEnergys[j].operator);
			xmlD.setAttribute("r_obj", "0");
			xmlDENOMINATOR.appendChild(xmlD);
			counter++;
		}
		xmlDENOMINATOR.setAttribute("num", counter);
		xmlP.appendChild(xmlDENOMINATOR);

		xmlPUE.appendChild(xmlP);
		pueCounter++;
	}

	xmlPUE.setAttribute("num", pueCounter);
	xmlPUE.setAttribute("default", this.pool.isDefaultPage == true ? "1" : "0");

	//if(xmlPUE.childNodes.length > 0){
		xmlDoc.documentElement.appendChild(xmlPUE);
	//}
};
