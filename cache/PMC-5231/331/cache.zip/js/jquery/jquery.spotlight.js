(function($) {
	$.spotLight = function(option){
		if(option == "hide"){
			$("#spotLightTip div.spotLightClose").triggerHandler("click");
		}
	};

	$.fn.spotLight = function(settings){
		settings = $.extend(true, {
			"text": "",
			"position": "bottom",
			"padding": 0,
			"reset": false,
			"duration": 400,
			"opacity": 0.2,
			"backgroundColor": "#000",
			"border": "3px solid #666666",
			"innerDimension": false,
			"done": function(){},
			"close": function(){}
		}, settings);

		$.each(["Top", "Bottom", "Right", "Left"], function(index, value){
			if($("#spotlight" + value).length == 0){
				$("<div></div>").css({
					"position": "absolute",
					"opacity": settings.opacity,
					"backgroundColor": settings.backgroundColor,
					"zIndex": "1100"
				}).appendTo("body").attr("id", "spotlight" + value);

				settings.reset = true;
			}
			else{
				$("#spotlight" + value).show();
			}

			if($("#spotlight" + value + "Border").length == 0){
				$("<div></div>").css({
					"position": "absolute",
					"zIndex": "1101"
				}).css("border" + value, settings.border).appendTo("body").attr("id", "spotlight" + value + "Border");

				settings.reset = true;
			}
			else{
				$("#spotlight" + value + "Border").show();
			}
		});

		var borderWidth = parseFloat($("#spotlightTopBorder").css("borderTopWidth"));

		if(settings.reset == true){
			$("#spotlightTop").css({
				"top": 0,
				"left": 0,
				"width": "100%",
				"height": $("html, body").scrollTop() + "px"
			});

			$("#spotlightBottom").css({
				"top": $("html, body").scrollTop() + $(window).height() + "px",
				"left": 0,
				"width": "100%",
				"height": Math.max($(window).height(), $("body").height()) - ($("html, body").scrollTop() + $(window).height()) + "px"
			});

			$("#spotlightLeft").css({
				"top": $("html, body").scrollTop() + "px",
				"left": 0,
				"width": 0,
				"height": $(window).height() + "px"
			});

			$("#spotlightRight").css({
				"top": $("html, body").scrollTop() + "px",
				"left": $(window).width() + "px",
				"width": 0,
				"height": $(window).height() + "px"
			});

			$("#spotlightTopBorder").css({
				"top": 0,
				"left": 0,
				"width": "100%"
			});

			$("#spotlightBottomBorder").css({
				"top": $("html, body").scrollTop() + $(window).height() - borderWidth + "px",
				"left": 0,
				"width": "100%"
			});

			$("#spotlightLeftBorder").css({
				"top": $("html, body").scrollTop() + "px",
				"left": 0,
				"height": $(window).height() + "px"
			});

			$("#spotlightRightBorder").css({
				"top": $("html, body").scrollTop() - borderWidth + "px",
				"left": $(window).width() - borderWidth + "px",
				"height": $(window).height() + "px"
			});
		}

		var $target = this.first();

		var showGuideline = function(duration){
			var top = $target.offset().top - settings.padding, left = $target.offset().left - settings.padding, width = (settings.innerDimension == true ? $target.innerWidth() : $target.outerWidth()), height = (settings.innerDimension == true ? $target.innerHeight() : $target.outerHeight());
			if($("#spotLightTip").length == 0){
				var $tip = $("<div></div>").attr({"class": "spotLight", "id": "spotLightTip"}).append(
					$("<div></div>").attr("class", "textLayer").append(
						$("<span></span>").attr("class", "text")
					)/*.append(
						$("<p></p>").attr("align", "right").css("margin", "9px 0 3px 0").append(
							$("<span></span>").attr("class", "spotLightButton").text("Cancel").bind("click", function(){
								$.spotLight("hide");
							})
						)
					)*/.append(
						$("<span></span>").attr("class", "spotLightIcon")
					).append(
						$("<div></div>").css({"position": "absolute", "top": "2px", "right": "1px", "cursor": "pointer"}).attr("class", "spotLightClose").bind("click", function(){
							$.each(["Top", "Bottom", "Right", "Left"], function(index, value){
								$("#spotlight" + value).hide();
								$("#spotlight" + value + "Border").hide();
							});

							$("#spotLightTip").hide();
							$(window).unbind("resize.spotLight");

							settings.close();
						})
					)
				).appendTo("body");
			}
			else{
				var $tip = $("#spotLightTip");
			}

			$tip.find("span.text").html(settings.text);
			$tip.find("span.spotLightIcon").attr("class", "spotLightIcon " + settings.position);

			if(settings.position == "top"){
				$tip.css({
					"top": (top - $tip.outerHeight()) + "px",
					"left": (left + (width - $tip.outerWidth()) / 2) + "px"
				});
			}
			else if(settings.position == "bottom"){
				$tip.css({
					"top": (top + height) + "px",
					"left": (left + (width - $tip.outerWidth()) / 2) + "px"
				});
			}
			else if(settings.position == "right"){
				$tip.css({
					"top": (top + (height - $tip.outerHeight()) / 2) + "px",
					"left": (left + width) + "px"
				});
			}
			else if(settings.position == "left"){
				$tip.css({
					"top": (top + (height - $tip.outerHeight()) / 2) + "px",
					"left": (left - $tip.outerWidth()) + "px"
				});
			}

			$tip.fadeIn(duration);
		};

		var adjustSpotLight = function(duration, callback){
			var top = $target.offset().top - settings.padding, left = $target.offset().left - settings.padding, width = (settings.innerDimension == true ? $target.innerWidth() : $target.outerWidth()) + settings.padding * 2, height = (settings.innerDimension == true ? $target.innerHeight() : $target.outerHeight()) + settings.padding * 2;
			$.when(
				$("#spotlightTop").stop().animate({
					"top": 0,
					"left": 0,
					"width": "100%",
					"height": top + "px"
				}, duration),

				$("#spotlightBottom").stop().animate({
					"top": top + height + "px",
					"left": 0,
					"width": "100%",
					"height": Math.max($(window).height(), $("body").height()) - (top + height) + "px"
				}, duration),

				$("#spotlightLeft").stop().animate({
					"top": top + "px",
					"left": 0,
					"width": left + "px",
					"height": height + "px"
				}, duration),

				$("#spotlightRight").stop().animate({
					"top": top + "px",
					"left": left + width + "px",
					"width": $(window).width() - (left + width) + "px",
					"height": height + "px"
				}, duration),

				//border
				$("#spotlightTopBorder").stop().animate({
					"top": top - borderWidth + "px",
					"left": left + "px",
					"width": width + "px"
				}, duration),

				$("#spotlightBottomBorder").stop().animate({
					"top": top + height + "px",
					"left": left + "px",
					"width": width + "px"
				}, duration),

				$("#spotlightLeftBorder").stop().animate({
					"top": top - borderWidth + "px",
					"left": left - borderWidth + "px",
					"height": height + borderWidth * 2 + "px"
				}, duration),

				$("#spotlightRightBorder").stop().animate({
					"top": top - borderWidth + "px",
					"left": left + width + "px",
					"height": height + borderWidth * 2 + "px"
				}, duration),

				$("html, body").stop().animate({
					scrollTop: top - ($(window).height() / 2 - height / 2)
				}, duration)
			).then(function(){
				showGuideline(duration);

				if(typeof(callback) == "function"){
					callback();
				}
			});
		}

		$("#spotLightTip").hide();
		adjustSpotLight(settings.duration, settings.done);

		$(window).unbind("resize.spotLight").bind("resize.spotLight", function(){
			adjustSpotLight(settings.duration);
		});

		return this;
	};

})(jQuery);
