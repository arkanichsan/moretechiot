$.extend(true, Lang, {
	"js/wise/manager/pue/rule/object.js": {
		"pue": "能源使用效率",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息"
	}
});