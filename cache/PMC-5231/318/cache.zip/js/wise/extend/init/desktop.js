//overwrite
WISE.managers.moduleManager._encodeXMLObject = WISE.managers.moduleManager.encodeXMLObject;
WISE.managers.moduleManager.encodeXMLObject = function(xmlDoc){
	var processPowerMeter = function(xmlDoc, xmlNode, module){
		$(xmlNode).find("> CI, > CO, > RI, > RO").remove();

		xmlNode.setAttribute("meter_group", module.powerMeter.manufacturer);
		xmlNode.setAttribute("meter_name", module.powerMeter.modelName);

		var xmlMETER = xmlDoc.createElement("METER");
		xmlMETER.setAttribute("loop", module.powerMeter.loop);
		xmlMETER.setAttribute("phase", module.powerMeter.phase);

		if(module.powerMeter.isMainPowerMeter){
			xmlMETER.setAttribute("main", "true");
		}

		if(module.powerMeter.switchable == true){
			xmlMETER.setAttribute("log_type", "1");
		}
		else{
			xmlMETER.setAttribute("log_type", module.powerMeter.phase);
		}

		//localAddress
		var localAddress = {"CI": 0, "CO": 0, "RI": 0, "RO": 0}, mappingPool = {"DI": "CI", "DO": "CO", "AI": "RI", "AO": "RO"};
		localAddress.RI += (9 * module.powerMeter.loop * (module.powerMeter.phase == 3 ? 4 : 1) * 2);

		//phase or loop name
		for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
			var xmlLOOP = xmlDoc.createElement("LOOP");
			xmlLOOP.setAttribute("idx", loop);
			if(module.powerMeter.channel[loop].name != ""){
				xmlLOOP.setAttribute("nickname", module.powerMeter.channel[loop].name);
			}

			if(module.powerMeter.channel[loop].isSinglePhase == true){
				xmlLOOP.setAttribute("single", "1");
			}

			for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
				var xmlPHASE = xmlDoc.createElement("PHASE");
				xmlPHASE.setAttribute("idx", phase);

				//meter_value
				var meterValueArray = module.powerMeter.channel[loop][phase].meterValue, bitMeterValue = 0;
				for(var i = meterValueArray.length - 1; i >= 0; i--){
					bitMeterValue = bitMeterValue << 1;
					if(typeof(meterValueArray[i]) == "undefined"){continue;}

					bitMeterValue += 1;
				}
				xmlPHASE.setAttribute("meter_value", bitMeterValue);

				//statistics_add
				if(module.powerMeter.channel[loop][phase].statisticsValue.length > 0){
					xmlPHASE.setAttribute("statistics_add", localAddress.RI);
					localAddress.RI += (8 * 2);
				}

				if(module.powerMeter.channel[loop][phase].name != ""){
					xmlPHASE.setAttribute("nickname", module.powerMeter.channel[loop][phase].name);
				}

				xmlLOOP.appendChild(xmlPHASE);
			}

			xmlMETER.appendChild(xmlLOOP);
		}

		if(module.powerMeter.phase == 1){//move 1-phase powermeter's loop name to phase tag
			var xmlLOOPs = xmlMETER.getElementsByTagName("LOOP");
			for(var i = 0; i < xmlLOOPs.length; i++){
				var name = xmlLOOPs[i].getAttribute("nickname");
				if(name){
					xmlLOOPs[i].firstChild.setAttribute("nickname", name);
					xmlLOOPs[i].removeAttribute("nickname");
				}
			}
		}

		//IO
		var xmlIO = xmlDoc.createElement("IO");
		for(var typeIndex = 0, typeArray = ["DI", "DO", "AI", "AO"]; typeIndex < typeArray.length; typeIndex++){
			var channelType = typeArray[typeIndex];

			var xmlTYPE = xmlDoc.createElement(channelType);
			xmlTYPE.setAttribute("num", module.powerMeter.io[channelType].length);
			xmlTYPE.setAttribute("add", localAddress[mappingPool[channelType]]);//is local address

			for(var i = 0; i < module.powerMeter.io[channelType].length; i ++){
				var channel = module.powerMeter.io[channelType][i];
				var localDataModel = module.powerMeter.format[channel.format].local.dataModel;
				var localType = module.powerMeter.format[channel.format].local.type;

				var xmlCH = xmlDoc.createElement("CH");
				xmlCH.setAttribute("idx", i);

				//Nickname
				if(channel.name != ""){
					xmlCH.setAttribute("nickname", channel.name);
				}

				//Power ON Value
				if((channelType == "DO" || channelType == "AO") && channel.initial != null){
					xmlCH.setAttribute("power_on", channel.initial.value);
				}

				if(channelType == "DO"){
					//advanced function
					if(channel.advancedFunction == 1){
						//xmlCH.setAttribute("pulse_hi", channel.pulse.high);
						//xmlCH.setAttribute("pulse_lo", channel.pulse.low);
					}
					else if(channel.advancedFunction == 2){
						xmlCH.setAttribute("back_off", channel.autoOFF);
					}
					else if(channel.advancedFunction == 3){
						xmlCH.setAttribute("di_map", "1");
					}
				}
				else if(channelType == "AI"){
					if(channel.deadband != 0){
						xmlCH.setAttribute("deadband", channel.deadband);
					}
					if(channel.scale.max != 0 || channel.scale.min != 0){
						xmlCH.setAttribute("scale_max", channel.scale.max);
						xmlCH.setAttribute("scale_min", channel.scale.min);
					}
				}

				xmlTYPE.appendChild(xmlCH);

				localAddress[localDataModel] += ({"0": 1, "1": 1, "2": 2, "3": 2, "4": 2, "5": 2}[localType] || 1);
			}

			xmlIO.appendChild(xmlTYPE);
		}
		xmlMETER.appendChild(xmlIO);

		//CUSTOM_DATA
		var xmlCUSTOMDATA = xmlDoc.createElement("CUSTOM_DATA");
		for(var i = 0; i < module.powerMeter.customizedData.length; i++){
			var channel = module.powerMeter.customizedData[i];
			var localDataModel = module.powerMeter.format[channel.format].local.dataModel;
			var localType = module.powerMeter.format[channel.format].local.type;

			var xmlCD = xmlDoc.createElement("CD");
			xmlCD.setAttribute("idx", i);
			xmlCD.setAttribute("add", localAddress[localDataModel]);//is local address
			xmlCD.setAttribute("add_type", {"CI": "1", "CO": "0", "RI": "3", "RO": "4"}[localDataModel]);

			//type
			if(localDataModel == "RI" || localDataModel == "RO"){
				xmlCD.setAttribute("data_type", localType);
			}

			xmlCD.setAttribute("name", channel.ruleName);

			//Nickname
			if(channel.name != ""){
				xmlCD.setAttribute("nickname", channel.name);
			}

			xmlCUSTOMDATA.appendChild(xmlCD);

			localAddress[localDataModel] += ({"0": 1, "1": 1, "2": 2, "3": 2, "4": 2, "5": 2}[localType] || 1);
		}
		xmlMETER.appendChild(xmlCUSTOMDATA);

		xmlNode.appendChild(xmlMETER);
	};

	xmlDoc = this._encodeXMLObject(xmlDoc);

	var usedPowerMeterList = {
		"modbusRTU": {},
		"modbusTCP": {}
	};

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.comport.length; sourceIndex++){
		if(typeof(this.pool.interfaces.comport[sourceIndex]) == "undefined" || this.pool.interfaces.comport[sourceIndex].protocol == null){continue;}

		if(this.pool.interfaces.comport[sourceIndex].protocol == "modbusRTU"){
			for(var moduleIndex = 0, modules = this.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];
				if(typeof(module.powerMeter) != "undefined"){//is power meter
					var $xmlMODULE = $(xmlDoc).find("WISE > COM[idx='" + sourceIndex + "'] > MODULE[idx='" + (moduleIndex + 1) + "']");

					processPowerMeter(xmlDoc, $xmlMODULE[0], module);

					if(typeof(usedPowerMeterList.modbusRTU[module.powerMeter.manufacturer]) == "undefined"){
						usedPowerMeterList.modbusRTU[module.powerMeter.manufacturer] = {};
					}

					usedPowerMeterList.modbusRTU[module.powerMeter.manufacturer][module.powerMeter.modelName] = true;
				}
			}
		}
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.network.length; sourceIndex++){
		if(typeof(this.pool.interfaces.network[sourceIndex]) == "undefined" || this.pool.interfaces.network[sourceIndex].protocol == null){continue;}

		var xmlTCP = xmlDoc.createElement("TCP");
		if(this.pool.interfaces.network[sourceIndex].protocol == "modbusTCP"){
			for(var moduleIndex = 0, modules = this.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];
				if(typeof(module.powerMeter) != "undefined"){//is power meter
					var $xmlMODULE = $(xmlDoc).find("WISE > TCP > MODULE[idx='" + (moduleIndex + 1) + "']");

					processPowerMeter(xmlDoc, $xmlMODULE[0], module);

					if(typeof(usedPowerMeterList.modbusTCP[module.powerMeter.manufacturer]) == "undefined"){
						usedPowerMeterList.modbusTCP[module.powerMeter.manufacturer] = {};
					}

					usedPowerMeterList.modbusTCP[module.powerMeter.manufacturer][module.powerMeter.modelName] = true;
				}
			}
		}
	}

	//process USED_METER_LIST tag
	var index = 0;
	var xmlUSED_METER_LIST = xmlDoc.createElement("USED_METER_LIST");

	for(var manufacturer in usedPowerMeterList.modbusRTU){
		for(var modelName in usedPowerMeterList.modbusRTU[manufacturer]){
			if(usedPowerMeterList.modbusRTU[manufacturer][modelName] == true){
				var xmlPM = xmlDoc.createElement("PM");
				xmlPM.setAttribute("idx", index++);
				xmlPM.setAttribute("name", modelName);
				xmlPM.setAttribute("group", manufacturer);
				xmlPM.setAttribute("module_type", "RTU");
				xmlUSED_METER_LIST.appendChild(xmlPM);
			}
		}
	}

	for(var manufacturer in usedPowerMeterList.modbusTCP){
		for(var modelName in usedPowerMeterList.modbusTCP[manufacturer]){
			if(usedPowerMeterList.modbusTCP[manufacturer][modelName] == true){
				var xmlPM = xmlDoc.createElement("PM");
				xmlPM.setAttribute("idx", index++);
				xmlPM.setAttribute("name", modelName);
				xmlPM.setAttribute("group", manufacturer);
				xmlPM.setAttribute("module_type", "TCP");
				xmlUSED_METER_LIST.appendChild(xmlPM);
			}
		}
	}

	xmlUSED_METER_LIST.setAttribute("num", index);
	xmlDoc.documentElement.appendChild(xmlUSED_METER_LIST);

	return xmlDoc;
}

for(var itemType in itemInformation){
	for(var i = 0; i < itemInformation[itemType].length; i++){
		WISE.managers.moduleManager.pool.conditions["pm_channel_" + itemType + "_" + i] = {
			"name": itemInformation[itemType][i].name,
			"fileName": "cpm",
			"menuPath": "<#Lang['?'].powerMeter>>" + {"meterValue": "<#Lang.global.basicValue>", "statisticsValue": "<#Lang.global.statisticsValue>"}[itemType],
			"rule":{
				"moduleKey": null,
				"loop": null,
				"phase": null,
				"itemType": itemType,
				"itemIndex": i,
				"operate": 0,
				"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
				"value": {
					0: {
						"constant": 0
					},
					1: {
						"registerIndex": null
					},
					2: {
						"moduleKey": null,
						"channelIndex": 0
					},
					3: {
						"moduleKey": null,
						"channelIndex": 0
					},
					4: {
						"moduleKey": null,
						"channelAddress": null
					},
					5: {
						"moduleKey": null,
						"channelAddress": null
					}
				}
			},
			"check": function(){
				if(this.rule.moduleKey == null){
					return false;
				}
				if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
					return false;
				}
				if(this.rule.type >= 2 && this.rule.type <= 5 && this.rule.value[this.rule.type].moduleKey == null){
					return false;
				}

				var moduleManager = WISE.managers.moduleManager;
				var module = moduleManager.getModuleByKey(this.rule.moduleKey);
				try{
					var item = module.powerMeter.channel[this.rule.loop][this.rule.phase][this.rule.itemType][this.rule.itemIndex];
				}
				catch(error){
					return false;
				}

				if(module == null || typeof(module[module.powerMeter.format[item.format].dataModel].remoteAddress[item.address]) == "undefined"){
					return false;
				}

				if(this.rule.type == 1){
					var registerManager = WISE.managers.registerManager;
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var moduleManager = WISE.managers.moduleManager;
					var compareModuleInfo = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

					if(compareModuleInfo == null){
						return false;
					}
					else{
						if(this.rule.type == 2 && compareModuleInfo.AI.amount <= this.rule.value[2].channelIndex){
							return false;
						}
						else if(this.rule.type == 3 && compareModuleInfo.AO.amount <= this.rule.value[3].channelIndex){
							return false;
						}
						else if(this.rule.type == 4 && typeof(compareModuleInfo.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
							return false;
						}
						else if(this.rule.type == 5 && typeof(compareModuleInfo.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
							return false;
						}
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
					if(this.extendedModule.check(this) == false){
						return false;
					}
				}

				return true;
			},
			"parseToString": function(){
				var moduleManager = WISE.managers.moduleManager;
				var module = moduleManager.getModuleByKey(this.rule.moduleKey);
				var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
				var operateString = ["=", ">", "<", ">=", "<="];

				var text = (module.powerMeter.phase == 3 ? "<#Lang.global.submeterX>" : "<#Lang.global.ctX>").replace("$no", this.rule.loop + 1) + (module.powerMeter.channel[this.rule.loop].name != "" ? "(" + module.powerMeter.channel[this.rule.loop].name + ")" : "") + " ";

				if(module.powerMeter.phase == 3){
					if(module.powerMeter.loop <= 1){text = "";}

					if(this.rule.phase < module.powerMeter.phase){
						var phaseName = module.powerMeter.channel[this.rule.loop][this.rule.phase].name != "" ? "(" + module.powerMeter.channel[this.rule.loop][this.rule.phase].name + ")" : "";

						if(module.powerMeter.channel[this.rule.loop].isSinglePhase == true){
							text += "<#Lang.global.ctX>".replace("$no", this.rule.loop * 3 + this.rule.phase + 1) + phaseName;
						}
						else{
							text += "<#Lang.global.phaseX>".replace("$no", String.fromCharCode(65 + this.rule.phase)) + phaseName;
						}
					}
					else{
						text += "<#Lang.global.totalOrAverage>";
					}
				}

				var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(text + " " + this.name, 1) + " " + operateString[this.rule.operate] + " ";

				if(this.rule.type == 0){
					retString += ruleColor(this.rule.value[0].constant/* + " " + moduleInfo.module.powerMeter.channel[this.rule.loop][this.rule.phase][this.rule.itemType][this.rule.itemIndex].unit*/, 2);
				}
				else if(this.rule.type == 1){
					var registerManager = WISE.managers.registerManager;
					retString += registerManager.pool.conditions.register.name + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var moduleManager = WISE.managers.moduleManager;
					var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

					if(this.rule.type == 2){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
					}
					else if(this.rule.type == 3){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
					}
					else if(this.rule.type == 4){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
					}
					else if(this.rule.type == 5){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
					retString += this.extendedModule.parseToString(this) || "";
				}

				return retString;
			},

			/*init and key will not be copied*/
			"init": function(){
				var moduleManager = WISE.managers.moduleManager;
				var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
				this.rule.moduleKey = this.key[0].moduleKey;

				for(var loop = 0, foundFlag = false; loop < module.powerMeter.channel.length && foundFlag == false; loop++){
					for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
						var item = module.powerMeter.channel[loop][phase][this.rule.itemType][this.rule.itemIndex];
						if(typeof(item) != "undefined"){
							this.rule.loop = loop;
							this.rule.phase = phase;
							foundFlag = true;
							break;
						}
					}
				}

				//this.rule.value[0].constant = moduleManager.modbusModule.checkRegisterRange(module, this.pmRuleType < 9 ? "RI" : "RICB", this.rule.channelAddress, this.rule.value[0].constant);
				this.rule.value[0].constant = 0;
			},
			"key": []
		};
	}
}

WISE.managers.moduleManager.pool.conditions["pm_io_DI"] = {
	"name": "DI",
	"fileName": "cpmdi",
	"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.ioInformation>",
	"rule":{
		"moduleKey": null,
		"channelIndex": 0,
		"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
	},
	"check": function(){
		if(this.rule.moduleKey == null){
			return false;
		}

		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.rule.moduleKey);

		if(module == null || module.powerMeter.io.DI.length <= this.rule.channelIndex){
			return false;
		}

		return true;
	},
	"parseToString": function(){
		var moduleManager = WISE.managers.moduleManager;
		var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
		var valueString = ["OFF", "ON", "<#Lang['js/wise/manager/module/rule/object.js'].onToOFF>", "<#Lang['js/wise/manager/module/rule/object.js'].offToON>", "<#Lang['js/wise/manager/module/rule/object.js'].statusChange>"];

		return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + this.rule.channelIndex + (moduleInfo.module.powerMeter.io.DI[this.rule.channelIndex].name != "" ? "(" + moduleInfo.module.powerMeter.io.DI[this.rule.channelIndex].name + ")" : ""), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
	},

	/*init and key will not be copied*/
	"init": function(){
		this.rule.moduleKey = this.key[0].moduleKey;
	},
	"key": []
};

WISE.managers.moduleManager.pool.conditions["pm_io_AI"] = {
	"name": "AI",
	"fileName": "cpmai",
	"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.ioInformation>",
	"rule":{
		"moduleKey": null,
		"channelIndex": 0,
		"operate": 0,
		"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
		"value": {
			0: {
				"constant": 0
			},
			1: {
				"registerIndex": null
			},
			2: {
				"moduleKey": null,
				"channelIndex": 0
			},
			3: {
				"moduleKey": null,
				"channelIndex": 0
			},
			4: {
				"moduleKey": null,
				"channelAddress": null
			},
			5: {
				"moduleKey": null,
				"channelAddress": null
			}
		}
	},
	"check": function(){
		if(this.rule.moduleKey == null){
			return false;
		}
		if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
			return false;
		}
		if(this.rule.type >= 2 && this.rule.type <= 5 && this.rule.value[this.rule.type].moduleKey == null){
			return false;
		}

		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.rule.moduleKey);

		if(module == null || module.powerMeter.io.AI.length <= this.rule.channelIndex){
			return false;
		}

		if(this.rule.type == 1){
			var registerManager = WISE.managers.registerManager;
			if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
				return false;
			}
		}
		else if(this.rule.type >= 2 && this.rule.type <= 5){
			var moduleManager = WISE.managers.moduleManager;
			var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

			if(compareModule == null){
				return false;
			}
			else{
				if(this.rule.type == 2 && compareModule.AI.amount <= this.rule.value[2].channelIndex){
					return false;
				}
				else if(this.rule.type == 3 && compareModule.AO.amount <= this.rule.value[3].channelIndex){
					return false;
				}
				else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
					return false;
				}
				else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
					return false;
				}
			}
		}

		if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
			if(this.extendedModule.check(this) == false){
				return false;
			}
		}

		return true;
	},
	"parseToString": function(){
		var moduleManager = WISE.managers.moduleManager;
		var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
		var operateString = ["=", ">", "<", ">=", "<="];

		var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + this.rule.channelIndex + (moduleInfo.module.powerMeter.io.AI[this.rule.channelIndex].name != "" ? "(" + moduleInfo.module.powerMeter.io.AI[this.rule.channelIndex].name + ")" : ""), 1) + " " + operateString[this.rule.operate] + " ";

		if(this.rule.type == 0){
			retString += ruleColor(this.rule.value[0].constant/* + " " + moduleManager.dconModule.getAIRange(moduleInfo.module, this.rule.channelIndex).unit*/, 2);
		}
		else if(this.rule.type == 1){
			var registerManager = WISE.managers.registerManager;
			retString += registerManager.pool.conditions.register.name + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
		}
		else if(this.rule.type >= 2 && this.rule.type <= 5){
			var moduleManager = WISE.managers.moduleManager;
			var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

			if(this.rule.type == 2){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
			}
			else if(this.rule.type == 3){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
			}
			else if(this.rule.type == 4){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
			}
			else if(this.rule.type == 5){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
			}
		}

		if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
			retString += this.extendedModule.parseToString(this) || "";
		}

		return retString;
	},

	/*init and key will not be copied*/
	"init": function(){
		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
		this.rule.moduleKey = this.key[0].moduleKey;
		//need overwrite range check//
		//this.rule.value[0].constant = moduleManager.dconModule.checkAIRange(module, this.rule.channelIndex, this.rule.value[0].constant);
	},
	"key": []
};

WISE.managers.moduleManager.pool.actions["pm_io_DO"] = {
	"name": "DO",
	"fileName": "apmdo",
	"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.ioInformation>",
	"rule":{
		"moduleKey": null,
		"channelIndex": 0,
		"value": 0,
		"frequency": 0,
		"delay": 0
	},
	"check": function(){
		if(this.rule.moduleKey == null){
			return false;
		}

		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.rule.moduleKey);

		if(module == null || module.powerMeter.io.DO.length <= this.rule.channelIndex){
			return false;
		}

		return true;
	},
	"parseToString": function(){
		var moduleManager = WISE.managers.moduleManager;
		var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
		var valueString = ["OFF", "ON"];

		return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + this.rule.channelIndex + (moduleInfo.module.powerMeter.io.DO[this.rule.channelIndex].name != "" ? "(" + moduleInfo.module.powerMeter.io.DO[this.rule.channelIndex].name + ")" : ""), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
	},

	/*init and key will not be copied*/
	"init": function(){
		this.rule.moduleKey = this.key[0].moduleKey;
	},
	"key": []
};

WISE.managers.moduleManager.pool.actions["pm_io_AO"] = {
	"name": "AO",
	"fileName": "apmao",
	"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.ioInformation>",
	"rule":{
		"moduleKey": null,
		"channelIndex": 0,
		"operate": 0,
		"type": 0,//0 for a constant, 1 for IR, 2 for AI, 3 for AO
		"value": {
			0: {
				"constant": 0
			},
			1: {
				"registerIndex": null
			},
			2: {
				"moduleKey": null,
				"channelIndex": 0
			},
			3: {
				"moduleKey": null,
				"channelIndex": 0
			},
			4: {
				"moduleKey": null,
				"channelAddress": null
			},
			5: {
				"moduleKey": null,
				"channelAddress": null
			}
		},
		"frequency": 0,
		"delay": 0
	},
	"check": function(){
		if(this.rule.moduleKey == null){
			return false;
		}
		if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
			return false;
		}
		if(this.rule.type >= 2 && this.rule.type <= 5 && this.rule.value[this.rule.type].moduleKey == null){
			return false;
		}

		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.rule.moduleKey);

		if(module == null || module.powerMeter.io.AO.length <= this.rule.channelIndex){
			return false;
		}

		if(this.rule.type == 1){
			var registerManager = WISE.managers.registerManager;
			if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
				return false;
			}
		}
		else if(this.rule.type >= 2 && this.rule.type <= 5){
			var moduleManager = WISE.managers.moduleManager;
			var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

			if(compareModule == null){
				return false;
			}
			else{
				if(this.rule.type == 2 && compareModule.AI.amount <= this.rule.value[2].channelIndex){
					return false;
				}
				else if(this.rule.type == 3 && compareModule.AO.amount <= this.rule.value[3].channelIndex){
					return false;
				}
				else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
					return false;
				}
				else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
					return false;
				}
			}
		}

		if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
			if(this.extendedModule.check(this) == false){
				return false;
			}
		}

		return true;
	},
	"parseToString": function(){
		var moduleManager = WISE.managers.moduleManager;
		var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
		var operateString = ["=", "+=", "-="];

		var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + this.rule.channelIndex + (moduleInfo.module.powerMeter.io.AO[this.rule.channelIndex].name != "" ? "(" + moduleInfo.module.powerMeter.io.AO[this.rule.channelIndex].name + ")" : ""), 1) + " " + operateString[this.rule.operate] + " ";

		if(this.rule.type == 0){
			retString += ruleColor(this.rule.value[0].constant/* + " " + moduleManager.dconModule.getAORange(moduleInfo.module.AO.setting[this.rule.channelIndex].type).unit*/, 2);
		}
		else if(this.rule.type == 1){
			var registerManager = WISE.managers.registerManager;
			retString += registerManager.pool.conditions.register.name + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
		}
		else if(this.rule.type >= 2 && this.rule.type <= 5){
			var moduleManager = WISE.managers.moduleManager;
			var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

			if(this.rule.type == 2){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
			}
			else if(this.rule.type == 3){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
			}
			else if(this.rule.type == 4){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
			}
			else if(this.rule.type == 5){
				retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
			}
		}

		if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
			retString += this.extendedModule.parseToString(this) || "";
		}

		return retString;
	},

	/*init and key will not be copied*/
	"init": function(){
		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
		this.rule.moduleKey = this.key[0].moduleKey;
		//need overwrite range check//
		//this.rule.value[0].constant = moduleManager.dconModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
	},
	"key": []
};

WISE.managers.moduleManager.modbusModule.createPowerMeterModule.createCustomizedDataRuleItem = function(module){//create CI/CO and RI/RO rule item
	for(var dataModelIndex = 0, dataModelArray = ["CI", "CO", "RI", "RO"]; dataModelIndex < dataModelArray.length; dataModelIndex++){
		var dataModel = dataModelArray[dataModelIndex];

		for(var ruleName in module.powerMeter.customizedData[dataModel]){
			if(typeof(WISE.managers.moduleManager.pool.conditions[ruleName]) == "undefined" && (dataModel == "CI" || dataModel == "CO" || dataModel == "RI" || dataModel == "RO")){//condition
				if(dataModel == "CI" || dataModel == "CO"){
					WISE.managers.moduleManager.pool.conditions["pm_customizedData_" + dataModel + "_" + ruleName] = {
						"name": ruleName,
						"fileName": "cpmcoil",
						"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.otherInformation>",
						"dataModel": dataModel,
						"rule":{
							"moduleKey": null,
							"customizedDataIndex": null,
							"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
						},
						"check": function(){
							if(this.rule.moduleKey == null){
								return false;
							}

							var moduleManager = WISE.managers.moduleManager;
							var module = moduleManager.getModuleByKey(this.rule.moduleKey);

							if(module == null || module.powerMeter.customizedData.length <= this.rule.customizedDataIndex){
								return false;
							}

							var channel = module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var dataModel = module.powerMeter.format[channel.format].dataModel;
							if(typeof(module.powerMeter.customizedData[dataModel][this.name][channel.groupName || ""][channel.channelIndex]) == "undefined"){
								return false;
							}

							return true;
						},
						"parseToString": function(){
							var moduleManager = WISE.managers.moduleManager;
							var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
							var valueString = ["OFF", "ON", "<#Lang['js/wise/manager/module/rule/object.js'].onToOFF>", "<#Lang['js/wise/manager/module/rule/object.js'].offToON>", "<#Lang['js/wise/manager/module/rule/object.js'].statusChange>"];

							var channel = moduleInfo.module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var itemName = "";
							var groupCounter = 0;
							var groupPool = moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName];
							for(var groupName in groupPool){
								groupCounter++;
							}
							if(groupCounter > 1 || moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
								itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
							}

							return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
						},

						/*init and key will not be copied*/
						"init": function(){
							var moduleManager = WISE.managers.moduleManager;
							this.rule.moduleKey = this.key[0].moduleKey;

							var module = moduleManager.getModuleByKey(this.rule.moduleKey);
							for(var i = 0; i < module.powerMeter.customizedData.length; i++){
								var channel = module.powerMeter.customizedData[i];
								var dataModel = module.powerMeter.format[channel.format].dataModel;
								if(channel.ruleName == this.name && dataModel == this.dataModel){
									this.rule.customizedDataIndex = i;
									break;
								}
							}

							//this.rule.value[0].constant = moduleManager.dconModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
						},
						"key": []
					};
				}
				else if(dataModel == "RI" || dataModel == "RO"){
					WISE.managers.moduleManager.pool.conditions["pm_customizedData_" + dataModel + "_" + ruleName] = {
						"name": ruleName,
						"fileName": "cpmregister",
						"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.otherInformation>",
						"dataModel": dataModel,
						"rule":{
							"moduleKey": null,
							"customizedDataIndex": null,
							"operate": 0,
							"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
							"value": {
								0: {
									"constant": 0
								},
								1: {
									"registerIndex": null
								},
								2: {
									"moduleKey": null,
									"channelIndex": 0
								},
								3: {
									"moduleKey": null,
									"channelIndex": 0
								},
								4: {
									"moduleKey": null,
									"channelAddress": null
								},
								5: {
									"moduleKey": null,
									"channelAddress": null
								}
							}
						},
						"check": function(){
							if(this.rule.moduleKey == null){
								return false;
							}

							var moduleManager = WISE.managers.moduleManager;
							var module = moduleManager.getModuleByKey(this.rule.moduleKey);

							if(module == null || module.powerMeter.customizedData.length <= this.rule.customizedDataIndex){
								return false;
							}

							var channel = module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var dataModel = module.powerMeter.format[channel.format].dataModel;
							if(typeof(module.powerMeter.customizedData[dataModel][this.name][channel.groupName || ""][channel.channelIndex]) == "undefined"){
								return false;
							}

							if(this.rule.type == 1){
								var registerManager = WISE.managers.registerManager;
								if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
									return false;
								}
							}
							else if(this.rule.type >= 2 && this.rule.type <= 5){
								var moduleManager = WISE.managers.moduleManager;
								var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

								if(compareModule == null){
									return false;
								}
								else{
									if(this.rule.type == 2 && compareModule.AI.amount <= this.rule.value[2].channelIndex){
										return false;
									}
									else if(this.rule.type == 3 && compareModule.AO.amount <= this.rule.value[3].channelIndex){
										return false;
									}
									else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
										return false;
									}
									else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
										return false;
									}
								}
							}

							if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
								if(this.extendedModule.check(this) == false){
									return false;
								}
							}

							return true;
						},
						"parseToString": function(){
							var moduleManager = WISE.managers.moduleManager;
							var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
							var operateString = ["=", ">", "<", ">=", "<="];

							var channel = moduleInfo.module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var itemName = "";
							var groupCounter = 0;
							var groupPool = moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName];
							for(var groupName in groupPool){
								groupCounter++;
							}
							if(groupCounter > 1 || moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
								itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
							}

							var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""), 1) + " " + operateString[this.rule.operate] + " ";

							if(this.rule.type == 0){
								retString += ruleColor(this.rule.value[0].constant/* + " " + moduleManager.dconModule.getAIRange(moduleInfo.module, this.rule.channelIndex).unit*/, 2);
							}
							else if(this.rule.type == 1){
								var registerManager = WISE.managers.registerManager;
								retString += registerManager.pool.conditions.register.name + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
							}
							else if(this.rule.type >= 2 && this.rule.type <= 5){
								var moduleManager = WISE.managers.moduleManager;
								var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

								if(this.rule.type == 2){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
								}
								else if(this.rule.type == 3){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
								}
								else if(this.rule.type == 4){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
								}
								else if(this.rule.type == 5){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
								}
							}

							if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
								retString += this.extendedModule.parseToString(this) || "";
							}

							return retString;
						},

						/*init and key will not be copied*/
						"init": function(){
							var moduleManager = WISE.managers.moduleManager;
							this.rule.moduleKey = this.key[0].moduleKey;

							var module = moduleManager.getModuleByKey(this.rule.moduleKey);
							for(var i = 0; i < module.powerMeter.customizedData.length; i++){
								var channel = module.powerMeter.customizedData[i];
								var dataModel = module.powerMeter.format[channel.format].dataModel;
								if(channel.ruleName == this.name && dataModel == this.dataModel){
									this.rule.customizedDataIndex = i;
									break;
								}
							}

							//this.rule.value[0].constant = moduleManager.dconModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
						},
						"key": []
					};
				}

				$.extend(true, WISE.managers.moduleManager.pool.conditions["pm_customizedData_" + dataModel + "_" + ruleName], extendedRuleObject);

				//insert additional information manual
				$.extend(true, WISE.managers.moduleManager.pool.conditions["pm_customizedData_" + dataModel + "_" + ruleName], {
					"managerKey": "moduleManager",
					"ruleObjectKey": "pm_customizedData_" + dataModel + "_" + ruleName,
					"ruleObjectType": "conditions"
				});
			}

			if(typeof(WISE.managers.moduleManager.pool.actions[ruleName]) == "undefined" && (dataModel == "CO" || dataModel == "RO")){//action
				if(dataModel == "CO"){
					WISE.managers.moduleManager.pool.actions["pm_customizedData_" + dataModel + "_" + ruleName] = {
						"name": ruleName,
						"fileName": "apmcoil",
						"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.otherInformation>",
						"dataModel": dataModel,
						"rule":{
							"moduleKey": null,
							"customizedDataIndex": null,
							"value": 0,
							"frequency": 0,
							"delay": 0
						},
						"check": function(){
							if(this.rule.moduleKey == null){
								return false;
							}

							var moduleManager = WISE.managers.moduleManager;
							var module = moduleManager.getModuleByKey(this.rule.moduleKey);

							if(module == null || module.powerMeter.customizedData.length <= this.rule.customizedDataIndex){
								return false;
							}

							var channel = module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var dataModel = module.powerMeter.format[channel.format].dataModel;
							if(typeof(module.powerMeter.customizedData[dataModel][this.name][channel.groupName || ""][channel.channelIndex]) == "undefined"){
								return false;
							}

							return true;
						},
						"parseToString": function(){
							var moduleManager = WISE.managers.moduleManager;
							var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
							var valueString = ["OFF", "ON", "<#Lang['?'].pulseOutput>"];

							var channel = moduleInfo.module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var itemName = "";
							var groupCounter = 0;
							var groupPool = moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName];
							for(var groupName in groupPool){
								groupCounter++;
							}
							if(groupCounter > 1 || moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
								itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
							}

							return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
						},

						/*init and key will not be copied*/
						"init": function(){
							var moduleManager = WISE.managers.moduleManager;
							this.rule.moduleKey = this.key[0].moduleKey;

							var module = moduleManager.getModuleByKey(this.rule.moduleKey);
							for(var i = 0; i < module.powerMeter.customizedData.length; i++){
								var channel = module.powerMeter.customizedData[i];
								var dataModel = module.powerMeter.format[channel.format].dataModel;
								if(channel.ruleName == this.name && dataModel == this.dataModel){
									this.rule.customizedDataIndex = i;
									break;
								}
							}
						},
						"key": []
					};
				}
				else if(dataModel == "RO"){
					WISE.managers.moduleManager.pool.actions["pm_customizedData_" + dataModel + "_" + ruleName] = {
						"name": ruleName,
						"fileName": "apmregister",
						"menuPath": "<#Lang['?'].powerMeter>><#Lang.global.otherInformation>",
						"dataModel": dataModel,
						"rule":{
							"moduleKey": null,
							"customizedDataIndex": null,
							"operate": 0,
							"type": 0,//0 for a constant, 1 for IR, 2 for AI, 3 for AO
							"value": {
								0: {
									"constant": 0
								},
								1: {
									"registerIndex": null
								},
								2: {
									"moduleKey": null,
									"channelIndex": 0
								},
								3: {
									"moduleKey": null,
									"channelIndex": 0
								},
								4: {
									"moduleKey": null,
									"channelAddress": null
								},
								5: {
									"moduleKey": null,
									"channelAddress": null
								}
							},
							"frequency": 0,
							"delay": 0
						},
						"check": function(){
							if(this.rule.moduleKey == null){
								return false;
							}
							if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
								return false;
							}
							if(this.rule.type >= 2 && this.rule.type <= 5 && this.rule.value[this.rule.type].moduleKey == null){
								return false;
							}

							var moduleManager = WISE.managers.moduleManager;
							var module = moduleManager.getModuleByKey(this.rule.moduleKey);

							if(module == null || module.powerMeter.customizedData.length <= this.rule.customizedDataIndex){
								return false;
							}

							var channel = module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var dataModel = module.powerMeter.format[channel.format].dataModel;
							if(typeof(module.powerMeter.customizedData[dataModel][this.name][channel.groupName || ""][channel.channelIndex]) == "undefined"){
								return false;
							}

							if(this.rule.type == 1){
								var registerManager = WISE.managers.registerManager;
								if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
									return false;
								}
							}
							else if(this.rule.type >= 2 && this.rule.type <= 5){
								var moduleManager = WISE.managers.moduleManager;
								var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

								if(compareModule == null){
									return false;
								}
								else{
									if(this.rule.type == 2 && compareModule.AI.amount <= this.rule.value[2].channelIndex){
										return false;
									}
									else if(this.rule.type == 3 && compareModule.AO.amount <= this.rule.value[3].channelIndex){
										return false;
									}
									else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
										return false;
									}
									else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
										return false;
									}
								}
							}

							if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
								if(this.extendedModule.check(this) == false){
									return false;
								}
							}

							return true;
						},
						"parseToString": function(){
							var moduleManager = WISE.managers.moduleManager;
							var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
							var operateString = ["=", "+=", "-="];

							var channel = moduleInfo.module.powerMeter.customizedData[this.rule.customizedDataIndex];
							var itemName = "";
							var groupCounter = 0;
							var groupPool = moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName];
							for(var groupName in groupPool){
								groupCounter++;
							}
							if(groupCounter > 1 || moduleInfo.module.powerMeter.customizedData[moduleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
								itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
							}

							var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""), 1) + " " + operateString[this.rule.operate] + " ";

							if(this.rule.type == 0){
								retString += ruleColor(this.rule.value[0].constant/* + " " + moduleManager.dconModule.getAORange(moduleInfo.module.AO.setting[this.rule.channelIndex].type).unit*/, 2);
							}
							else if(this.rule.type == 1){
								var registerManager = WISE.managers.registerManager;
								retString += registerManager.pool.conditions.register.name + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
							}
							else if(this.rule.type >= 2 && this.rule.type <= 5){
								var moduleManager = WISE.managers.moduleManager;
								var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

								if(this.rule.type == 2){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
								}
								else if(this.rule.type == 3){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
								}
								else if(this.rule.type == 4){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
								}
								else if(this.rule.type == 5){
									retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
								}
							}

							if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
								retString += this.extendedModule.parseToString(this) || "";
							}

							return retString;
						},

						/*init and key will not be copied*/
						"init": function(){
							var moduleManager = WISE.managers.moduleManager;
							this.rule.moduleKey = this.key[0].moduleKey;

							var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
							for(var i = 0; i < module.powerMeter.customizedData.length; i++){
								var channel = module.powerMeter.customizedData[i];
								var dataModel = module.powerMeter.format[channel.format].dataModel;
								if(channel.ruleName == this.name && dataModel == this.dataModel){
									this.rule.customizedDataIndex = i;
									break;
								}
							}

							//this.rule.value[0].constant = moduleManager.dconModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
						},
						"key": []
					};
				}

				$.extend(true, WISE.managers.moduleManager.pool.actions["pm_customizedData_" + dataModel + "_" + ruleName], extendedRuleObject);

				//insert additional information manual
				$.extend(true, WISE.managers.moduleManager.pool.actions["pm_customizedData_" + dataModel + "_" + ruleName], {
					"managerKey": "moduleManager",
					"ruleObjectKey": "pm_customizedData_" + dataModel + "_" + ruleName,
					"ruleObjectType": "actions"
				});
			}
		}
	}
};

//extend
var extendedRuleObject = {//for power meter...
	"rule":{
		"value": {
			6: {
				"moduleKey": null,
				"type": null,//channel. io, customizedData

				//for channel
				"loop": null,
				"phase": null,
				"itemType": null,
				"itemIndex": null,

				//for io
				"channelType": null,//string: DI, DO, AI, AO
				"channelIndex": null,

				//for customizedData
				"customizedDataIndex": null,

				//for PUE
				"pueIndex": null
			}
		}
	},
	"extendedModule": {
		"check": function(ruleObject){
			if(ruleObject.rule.type == 6){
				if(ruleObject.rule.value[6].type == "channel"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModule = moduleManager.getModuleByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);

					if(compareModule == null){
						return false;
					}
					else{
						try{
							var item = compareModule.powerMeter.channel[ruleObject.rule.value[6].loop][ruleObject.rule.value[6].phase][ruleObject.rule.value[6].itemType][ruleObject.rule.value[6].itemIndex];
						}
						catch(error){
							return false;
						}

						if(typeof(compareModule[compareModule.powerMeter.format[item.format].dataModel].remoteAddress[item.address]) == "undefined"){
							return false;
						}
					}
				}
				else if(ruleObject.rule.value[6].type == "io"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModule = moduleManager.getModuleByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);

					if(compareModule == null){
						return false;
					}
					else{
						if(compareModule.powerMeter.io[ruleObject.rule.value[6].channelType].length <= ruleObject.rule.value[6].channelIndex){
							return false;
						}
					}
				}
				else if(ruleObject.rule.value[6].type == "customizedData"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModule = moduleManager.getModuleByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);

					if(compareModule == null){
						return false;
					}
					else{
						if(compareModule.powerMeter.customizedData.length <= ruleObject.rule.value[6].customizedDataIndex){
							return false;
						}

						var channel = compareModule.powerMeter.customizedData[ruleObject.rule.value[6].customizedDataIndex];
						var dataModel = compareModule.powerMeter.format[channel.format].dataModel;
						if(typeof(compareModule.powerMeter.customizedData[dataModel][channel.ruleName][channel.groupName || ""][channel.channelIndex]) == "undefined"){
							return false;
						}
					}
				}
				else if(ruleObject.rule.value[6].type == "pue"){
					var pueManager = WISE.managers.pueManager;
					if(typeof(pueManager.pool.pues[ruleObject.rule.value[6].pueIndex]) == "undefined"){
						return false;
					}
				}
			}
		},
		"parseToString": function(ruleObject){
			if(ruleObject.rule.type == 6){//for power meter
				if(ruleObject.rule.value[6].type == "channel"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModuleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);
					var module = compareModuleInfo.module;

					var loop = ruleObject.rule.value[6].loop;
					var phase = ruleObject.rule.value[6].phase;

					var text = (module.powerMeter.phase == 3 ? "<#Lang.global.submeterX>" : "<#Lang.global.ctX>").replace("$no", loop + 1) + (module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "") + " ";

					if(module.powerMeter.phase == 3){
						if(module.powerMeter.loop <= 1){text = "";}

						if(phase < module.powerMeter.phase){
							var phaseName = module.powerMeter.channel[loop][phase].name != "" ? "(" + module.powerMeter.channel[loop][phase].name + ")" : "";

							if(module.powerMeter.channel[loop].isSinglePhase == true){
								text += "<#Lang.global.ctX>".replace("$no", loop * 3 + phase + 1) + phaseName;
							}
							else{
								text += "<#Lang.global.phaseX>".replace("$no", String.fromCharCode(65 + phase)) + phaseName;
							}
						}
						else{
							text += "<#Lang.global.totalOrAverage>";
						}
					}

					return moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(text + " " + itemInformation[ruleObject.rule.value[6].itemType][ruleObject.rule.value[6].itemIndex].name, 1);
				}
				else if(ruleObject.rule.value[6].type == "io"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModuleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);
					var module = compareModuleInfo.module;

					return moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(ruleObject.rule.value[6].channelType + ruleObject.rule.value[6].channelIndex + (module.powerMeter.io[ruleObject.rule.value[6].channelType][ruleObject.rule.value[6].channelIndex].name != "" ? "(" + module.powerMeter.io[ruleObject.rule.value[6].channelType][ruleObject.rule.value[6].channelIndex].name + ")" : ""), 1);
				}
				else if(ruleObject.rule.value[6].type == "customizedData"){
					var moduleManager = WISE.managers.moduleManager;
					var compareModuleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.value[ruleObject.rule.type].moduleKey);
					var module = compareModuleInfo.module;

					var channel = module.powerMeter.customizedData[ruleObject.rule.value[6].customizedDataIndex];
					var itemName = "";
					var groupCounter = 0;
					var groupPool = compareModuleInfo.module.powerMeter.customizedData[compareModuleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName];
					for(var groupName in groupPool){
						groupCounter++;
					}
					if(groupCounter > 1 || compareModuleInfo.module.powerMeter.customizedData[compareModuleInfo.module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
						itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
					}

					return moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(module.powerMeter.customizedData[ruleObject.rule.value[6].customizedDataIndex].ruleName + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""), 1);
				}
				else if(ruleObject.rule.value[6].type == "pue"){
					var pueManager = WISE.managers.pueManager;
					var pue = pueManager.pool.pues[ruleObject.rule.value[6].pueIndex];

					return "<#Lang['?'].pue>" + " " + (ruleObject.rule.value[6].pueIndex + 1) + (pue.name != "" ? "(" + pue.name + ")" : "");
				}
			}
		}
	}
};

//copy
$.extend(true, WISE.managers.moduleManager.pool.conditions.AI, extendedRuleObject);
$.extend(true, WISE.managers.moduleManager.pool.conditions.RI, extendedRuleObject);
$.extend(true, WISE.managers.moduleManager.pool.conditions.RO, extendedRuleObject);
$.extend(true, WISE.managers.moduleManager.pool.actions.AO, extendedRuleObject);
$.extend(true, WISE.managers.moduleManager.pool.actions.RO, extendedRuleObject);
$.extend(true, WISE.managers.registerManager.pool.conditions.register, extendedRuleObject);
$.extend(true, WISE.managers.registerManager.pool.actions.register, extendedRuleObject);
$.extend(true, WISE.managers.pueManager.pool.conditions.pue, extendedRuleObject);
$.extend(true, WISE.managers.azureManager.pool.conditions.subscribe, extendedRuleObject);
$.extend(true, WISE.managers.bluemixManager.pool.conditions.subscribe, extendedRuleObject);
$.extend(true, WISE.managers.mqttManager.pool.conditions.topic, extendedRuleObject);
$.extend(true, WISE.managers.systemManager.pool.conditions.signal, extendedRuleObject);

for(var itemType in itemInformation){
	for(var i = 0; i < itemInformation[itemType].length; i++){
		$.extend(true, WISE.managers.moduleManager.pool.conditions["pm_channel_" + itemType + "_" + i], extendedRuleObject);
	}
}

$.extend(true, WISE.managers.moduleManager.pool.conditions.pm_io_AI, extendedRuleObject);
$.extend(true, WISE.managers.moduleManager.pool.actions.pm_io_AO, extendedRuleObject);

//overwrite
WISE.managers.moduleManager.pool.conditions.status._parseToString = WISE.managers.moduleManager.pool.conditions.status.parseToString;
WISE.managers.moduleManager.pool.conditions.status.parseToString = function(){
	var moduleManager = WISE.managers.moduleManager;
	var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
	var valueString = ["<#Lang['js/wise/manager/module/rule/object.js'].offline>", "<#Lang['js/wise/manager/module/rule/object.js'].online>"];

	if(moduleInfo.module.extendedModule == "powerMeter"){
		var retString = this.name + " " + moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(valueString[this.rule.value], 2);
		return retString;
	}
	else{
		return this._parseToString();
	}
};

//overwrite
WISE.managers.moduleManager._updateRuleObject = WISE.managers.moduleManager.updateRuleObject;
WISE.managers.moduleManager.updateRuleObject = function(){
	this._updateRuleObject();

	var moduleManager = WISE.managers.moduleManager;
	var that = this;
	var modbusModuleKeyProcessor = function(module, keyData){
		for(var itemType in itemInformation){
			for(var i = 0; i < itemInformation[itemType].length; i++){
				for(var loop = 0, foundFlag = false; loop < module.powerMeter.channel.length && foundFlag == false; loop++){
					for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
						if(typeof(module.powerMeter.channel[loop][phase][itemType][i]) != "undefined"){
							that.pool.conditions["pm_channel_" + itemType + "_" + i]["key"].push(keyData);
							foundFlag = true;
							break;
						}
					}
				}
			}
		}

		for(var typeIndex = 0, typeArray = ["DI", "DO", "AI", "AO"]; typeIndex < typeArray.length; typeIndex++){
			var type = typeArray[typeIndex];

			if(module.powerMeter.io[type].length > 0){
				if(type == "DI" || type == "AI"){
					that.pool.conditions["pm_io_" + type]["key"].push(keyData);
					continue;
				}
				else{//DO, AO
					that.pool.actions["pm_io_" + type]["key"].push(keyData);
					continue;
				}
			}
		}

		//process customizedData
		for(var condition in WISE.managers.moduleManager.pool.conditions){
			if(condition.match(/^pm_customizedData_(CI|CO|RI|RO)_/)){
				var splitArray = condition.split("_");
				var groupPool = module.powerMeter.customizedData[splitArray[2]][splitArray[3]];

				for(var groupName in groupPool){
					WISE.managers.moduleManager.pool.conditions[condition].key.push(keyData);
					break;
				}
			}
		}

		for(var action in WISE.managers.moduleManager.pool.actions){
			if(action.match(/^pm_customizedData_(CO|RO)_/)){
				var splitArray = action.split("_");
				var groupPool = module.powerMeter.customizedData[splitArray[2]][splitArray[3]];

				for(var groupName in groupPool){
					WISE.managers.moduleManager.pool.actions[action].key.push(keyData);
					break;
				}
			}
		}
	};

	//clear channel
	for(var itemType in itemInformation){
		for(var i = 0; i < itemInformation[itemType].length; i++){
			this.pool.conditions["pm_channel_" + itemType + "_" + i]['key'] = [];
		}
	}

	//clear io
	this.pool.conditions["pm_io_DI"]["key"] = [];
	this.pool.conditions["pm_io_AI"]["key"] = [];
	this.pool.actions["pm_io_DO"]["key"] = [];
	this.pool.actions["pm_io_AO"]["key"] = [];

	//clear customizedData
	for(var condition in WISE.managers.moduleManager.pool.conditions){
		if(condition.match(/^pm_customizedData_(CI|CO|RI|RO)_/)){
			WISE.managers.moduleManager.pool.conditions[condition].key = [];
		}
	}
	for(var action in WISE.managers.moduleManager.pool.actions){
		if(action.match(/^pm_customizedData_(CO|RO)_/)){
			WISE.managers.moduleManager.pool.actions[action].key = [];
		}
	}

	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.comport.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.comport[sourceIndex]) == "undefined" || moduleManager.pool.interfaces.comport[sourceIndex].type != "comport485"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined" || typeof(modules[moduleIndex].powerMeter) == "undefined"){continue;}

			var keyData = {
				"moduleKey": modules[moduleIndex].key
			};

			if(moduleManager.pool.interfaces.comport[sourceIndex].protocol == "modbusRTU"){
				modbusModuleKeyProcessor(modules[moduleIndex], keyData);
			}
		}
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.network.length; sourceIndex++){
		if(typeof(this.pool.interfaces.network[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = this.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined" || typeof(modules[moduleIndex].powerMeter) == "undefined"){continue;}

			var keyData = {
				"moduleKey": modules[moduleIndex].key
			};

			modbusModuleKeyProcessor(modules[moduleIndex], keyData);
		}
	}
};

//overwrite
WISE.managers.moduleManager._encodeXMLRule = WISE.managers.moduleManager.encodeXMLRule;
WISE.managers.moduleManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processModuleInfo = this.encodeXMLRule.processModuleInfo;
	var processCompareModule = this.encodeXMLRule.processCompareModule;
	var processExtendedModuleRule = this.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey.match(/^pm_/)){
			var module = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey).module;

			var splitArray = ruleObject.ruleObjectKey.split("_");
			if(splitArray[1] == "channel"){
				var channel = module.powerMeter.channel[ruleObject.rule.loop][ruleObject.rule.phase][ruleObject.rule.itemType][ruleObject.rule.itemIndex];
				var dataModel = module.powerMeter.format[channel.format].dataModel;

				xmlDoc.setAttribute("l_ch", dataModel);
				xmlDoc.setAttribute("l_chn", channel.address);
			}
			else if(splitArray[1] == "io"){
				var dataModel = splitArray[2];

				xmlDoc.setAttribute("l_ch", dataModel);
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			else if(splitArray[1] == "customizedData"){
				var channel = module.powerMeter.customizedData[ruleObject.rule.customizedDataIndex];
				var dataModel = module.powerMeter.format[channel.format].dataModel;

				xmlDoc.setAttribute("l_ch", dataModel);
				xmlDoc.setAttribute("l_chn", channel.address);
			}

			if(dataModel == "DI" || dataModel == "CI" || dataModel == "CICB" || dataModel == "CO" || dataModel == "COCB"){//Coil
				xmlDoc.setAttribute("op", ruleObject.rule.value);
			}
			else if(dataModel == "AI" || dataModel == "RI" || dataModel == "RICB" || dataModel == "RO" || dataModel == "ROCB"){//Register
				xmlDoc.setAttribute("op", ruleObject.rule.operate);

				processCompareModule(xmlDoc, ruleObject);
				processExtendedModuleRule(xmlDoc, ruleObject);
			}
		}
		else if(ruleObject.ruleObjectKey == "AI" || ruleObject.ruleObjectKey == "RI" || ruleObject.ruleObjectKey == "RO"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey.match(/^pm_/)){
			var module = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey).module;

			var splitArray = ruleObject.ruleObjectKey.split("_");
			if(splitArray[1] == "channel"){}
			else if(splitArray[1] == "io"){
				var dataModel = splitArray[2];
				xmlDoc.setAttribute("l_ch", dataModel);
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			else if(splitArray[1] == "customizedData"){
				var channel = module.powerMeter.customizedData[ruleObject.rule.customizedDataIndex];
				var dataModel = module.powerMeter.format[channel.format].dataModel;

				xmlDoc.setAttribute("l_ch", dataModel);
				xmlDoc.setAttribute("l_chn", channel.address);
			}

			if(dataModel == "DO" || dataModel == "CO" || dataModel == "COCB"){//Coil
				if(ruleObject.rule.frequency == 1){
					xmlDoc.setAttribute("op", ruleObject.rule.value + 2);
				}
				else if(ruleObject.rule.frequency == 0){
					xmlDoc.setAttribute("op", ruleObject.rule.value);
				}

				if(ruleObject.rule.delay > 0){
					xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
				}
			}
			else if(dataModel == "AO" || dataModel == "RO" || dataModel == "ROCB"){//Register
				if(ruleObject.rule.frequency == 1){
					xmlDoc.setAttribute("op", ruleObject.rule.operate + 3);
				}
				else if(ruleObject.rule.frequency == 0){
					xmlDoc.setAttribute("op", ruleObject.rule.operate);
				}

				if(ruleObject.rule.delay > 0){
					xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
				}

				processCompareModule(xmlDoc, ruleObject);
				processExtendedModuleRule(xmlDoc, ruleObject);
			}
		}
		else if(ruleObject.ruleObjectKey == "AO" || ruleObject.ruleObjectKey == "RO"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
};

WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule = function(xmlDoc, ruleObject){
	var processModuleInfo = WISE.managers.moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = WISE.managers.moduleManager.encodeXMLRule.processCompareModule;

	if(ruleObject.rule.type == 6){//Extended Module
		if(ruleObject.rule.value[6].type == "channel"){
			var module = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[6].moduleKey).module;
			var channel = module.powerMeter.channel[ruleObject.rule.value[6].loop][ruleObject.rule.value[6].phase][ruleObject.rule.value[6].itemType][ruleObject.rule.value[6].itemIndex];
			var dataModel = module.powerMeter.format[channel.format].dataModel;

			xmlDoc.setAttribute("r_ch", dataModel);
			xmlDoc.setAttribute("r_chn", channel.address);
		}
		else if(ruleObject.rule.value[6].type == "io"){
			var module = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[6].moduleKey).module;
			xmlDoc.setAttribute("r_ch", ruleObject.rule.value[6].channelType);
			xmlDoc.setAttribute("r_chn", ruleObject.rule.value[6].channelIndex);
		}
		else if(ruleObject.rule.value[6].type == "customizedData"){
			var module = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[6].moduleKey).module;
			var channel = module.powerMeter.customizedData[ruleObject.rule.value[6].customizedDataIndex];
			var dataModel = module.powerMeter.format[channel.format].dataModel;

			xmlDoc.setAttribute("r_ch", dataModel);
			xmlDoc.setAttribute("r_chn", channel.address);
		}
		else if(ruleObject.rule.value[6].type == "pue"){
			var pueManager = WISE.managers.pueManager;

			xmlDoc.setAttribute("r_obj", "PUE");
			xmlDoc.setAttribute("r_idx", ruleObject.rule.value[6].pueIndex + 1);
		}
	}
};

//reference other functions
for(var funcKey in WISE.managers.moduleManager._encodeXMLRule){
	WISE.managers.moduleManager.encodeXMLRule[funcKey] = WISE.managers.moduleManager._encodeXMLRule[funcKey];
}

//overwrite
WISE.managers.moduleManager._decodeXMLRule = WISE.managers.moduleManager.decodeXMLRule;
WISE.managers.moduleManager.decodeXMLRule = function(xmlDoc){
	var processExtendedModuleRule = this.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = null;

	var module = null;
	if($(xmlDoc).attr("l_obj") == "RTU"){
		module = this.pool.interfaces.comport[parseInt($(xmlDoc).attr("l_com"), 10)].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
	}
	else if($(xmlDoc).attr("l_obj") == "TCP"){
		module = this.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("l_idx"), 10) - 1];
	}

	if(module != null && module.extendedModule == "powerMeter" && $(xmlDoc).attr("l_ch") != "STATUS"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "DI" || $(xmlDoc).attr("l_ch") == "AI"){//power meter I/O
				var channel = module.powerMeter.io[$(xmlDoc).attr("l_ch")][parseInt($(xmlDoc).attr("l_chn"), 10)];
				var dataModel = module.powerMeter.format[channel.format].dataModel;
				var channelInfo = module[dataModel].remoteAddress[channel.address];
			}
			else{
				var channelInfo = module[$(xmlDoc).attr("l_ch")].remoteAddress[parseInt($(xmlDoc).attr("l_chn"), 10)];
			}

			if(channelInfo.type == "channel"){
				ruleObject = WISE.createRuleObject(this.pool.conditions["pm_channel_" + channelInfo.itemType + "_" + channelInfo.itemIndex]);
				ruleObject.rule.loop = channelInfo.loop;
				ruleObject.rule.phase = channelInfo.phase;
				ruleObject.rule.itemType = channelInfo.itemType;
				ruleObject.rule.itemIndex = channelInfo.itemIndex;
			}
			else if(channelInfo.type == "io"){
				ruleObject = WISE.createRuleObject(this.pool.conditions["pm_io_" + channelInfo.channelType]);
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);
			}
			else if(channelInfo.type == "customizedData"){
				ruleObject = WISE.createRuleObject(this.pool.conditions["pm_customizedData_" + module.powerMeter.format[module.powerMeter.customizedData[channelInfo.customizedDataIndex].format].dataModel + "_" + module.powerMeter.customizedData[channelInfo.customizedDataIndex].ruleName]);
				ruleObject.rule.customizedDataIndex = channelInfo.customizedDataIndex;
			}

			//parse op
			if($(xmlDoc).attr("l_ch") == "DI" || $(xmlDoc).attr("l_ch") == "CI" || $(xmlDoc).attr("l_ch") == "CICB" || $(xmlDoc).attr("l_ch") == "CO" || $(xmlDoc).attr("l_ch") == "COCB"){//Coil
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "AI" || $(xmlDoc).attr("l_ch") == "RI" || $(xmlDoc).attr("l_ch") == "RICB" || $(xmlDoc).attr("l_ch") == "RO" || $(xmlDoc).attr("l_ch") == "ROCB"){//Register
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
			}

			ruleObject.rule.moduleKey = module.key;
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "DO" || $(xmlDoc).attr("l_ch") == "AO"){//power meter I/O
				var channel = module.powerMeter.io[$(xmlDoc).attr("l_ch")][parseInt($(xmlDoc).attr("l_chn"), 10)];
				var dataModel = module.powerMeter.format[channel.format].dataModel;
				var channelInfo = module[dataModel].remoteAddress[channel.address];
			}
			else{
				var channelInfo = module[$(xmlDoc).attr("l_ch")].remoteAddress[parseInt($(xmlDoc).attr("l_chn"), 10)];
			}

			if(channelInfo.type == "channel"){}
			else if(channelInfo.type == "io"){
				ruleObject = WISE.createRuleObject(this.pool.actions["pm_io_" + channelInfo.channelType]);
				ruleObject.rule.channelIndex = parseInt($(xmlDoc).attr("l_chn"), 10);
			}
			else if(channelInfo.type == "customizedData"){
				ruleObject = WISE.createRuleObject(this.pool.actions["pm_customizedData_" + module.powerMeter.format[module.powerMeter.customizedData[channelInfo.customizedDataIndex].format].dataModel + "_" + module.powerMeter.customizedData[channelInfo.customizedDataIndex].ruleName]);
				ruleObject.rule.customizedDataIndex = channelInfo.customizedDataIndex;
			}

			//parse op
			if($(xmlDoc).attr("l_ch") == "DO" || $(xmlDoc).attr("l_ch") == "CO" || $(xmlDoc).attr("l_ch") == "COCB"){//Coil
				var code = {"0": 0, "1": 10, "2": 1, "3": 11, "4": 20}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "AO" || $(xmlDoc).attr("l_ch") == "RO" || $(xmlDoc).attr("l_ch") == "ROCB"){//Register
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				if(ruleObject.rule.operate >= 3){
					ruleObject.rule.operate -= 3;
					ruleObject.rule.frequency = 1;
				}
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}

			ruleObject.rule.moduleKey = module.key;
		}

		this._decodeXMLRule.processCompareModule(xmlDoc, ruleObject);
	}
	else{
		ruleObject = this._decodeXMLRule(xmlDoc);
	}

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;

	if($(xmlDoc).attr("r_obj") == "RTU" || $(xmlDoc).attr("r_obj") == "TCP"){
		var module = null;
		if($(xmlDoc).attr("r_obj") == "RTU"){
			module = moduleManager.pool.interfaces.comport[parseInt($(xmlDoc).attr("r_com"), 10)].modules[parseInt($(xmlDoc).attr("r_idx"), 10) - 1];
		}
		else if($(xmlDoc).attr("r_obj") == "TCP"){
			module = moduleManager.pool.interfaces.network[0].modules[parseInt($(xmlDoc).attr("r_idx"), 10) - 1];
		}

		if(module != null && module.extendedModule == "powerMeter"){//process extended module
			if($(xmlDoc).attr("r_ch") == "AI" || $(xmlDoc).attr("r_ch") == "AO"){//power meter I/O
				var channel = module.powerMeter.io[$(xmlDoc).attr("r_ch")][parseInt($(xmlDoc).attr("r_chn"), 10)];
				var dataModel = module.powerMeter.format[channel.format].dataModel;
				var channelInfo = module[dataModel].remoteAddress[channel.address];
			}
			else{
				var channelInfo = module[$(xmlDoc).attr("r_ch")].remoteAddress[parseInt($(xmlDoc).attr("r_chn"), 10)];
			}

			if(channelInfo.type == "channel"){
				ruleObject.rule.value[6].moduleKey = module.key;
				ruleObject.rule.value[6].type = "channel";
				ruleObject.rule.value[6].loop = channelInfo.loop;
				ruleObject.rule.value[6].phase = channelInfo.phase;
				ruleObject.rule.value[6].itemType = channelInfo.itemType;
				ruleObject.rule.value[6].itemIndex = channelInfo.itemIndex;
			}
			else if(channelInfo.type == "io"){
				ruleObject.rule.value[6].moduleKey = module.key;
				ruleObject.rule.value[6].type = "io";
				ruleObject.rule.value[6].channelType = $(xmlDoc).attr("r_ch");
				ruleObject.rule.value[6].channelIndex = parseInt($(xmlDoc).attr("r_chn"), 10);
			}
			else if(channelInfo.type == "customizedData"){
				ruleObject.rule.value[6].moduleKey = module.key;
				ruleObject.rule.value[6].type = "customizedData";
				ruleObject.rule.value[6].customizedDataIndex = channelInfo.customizedDataIndex;
			}

			ruleObject.rule.type = 6;
		}
	}
	else if($(xmlDoc).attr("r_obj") == "PUE"){
		ruleObject.rule.value[6].pueIndex = parseInt($(xmlDoc).attr("r_idx"), 10) - 1;
		ruleObject.rule.value[6].type = "pue";
		ruleObject.rule.type = 6;
	}
};

//reference other functions
for(var funcKey in WISE.managers.moduleManager._decodeXMLRule){
	WISE.managers.moduleManager.decodeXMLRule[funcKey] = WISE.managers.moduleManager._decodeXMLRule[funcKey];
}

//overwrite
WISE.managers.registerManager._encodeXMLRule = WISE.managers.registerManager.encodeXMLRule;
WISE.managers.registerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "register"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "register"){
			if(ruleObject.rule.type == 6){//PM
				processExtendedModuleRule(xmlDoc, ruleObject);
			}
		}
	}
};

//overwrite
WISE.managers.registerManager._decodeXMLRule = WISE.managers.registerManager.decodeXMLRule;
WISE.managers.registerManager.decodeXMLRule = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = this._decodeXMLRule(xmlDoc);

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

//overwrite
WISE.managers.azureManager._encodeXMLRule = WISE.managers.azureManager.encodeXMLRule;
WISE.managers.azureManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "subscribe"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
};

//overwrite
WISE.managers.azureManager._decodeXMLRule = WISE.managers.azureManager.decodeXMLRule;
WISE.managers.azureManager.decodeXMLRule = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = this._decodeXMLRule(xmlDoc);

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

//overwrite
WISE.managers.bluemixManager._encodeXMLRule = WISE.managers.bluemixManager.encodeXMLRule;
WISE.managers.bluemixManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "subscribe"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
};

//overwrite
WISE.managers.bluemixManager._decodeXMLRule = WISE.managers.bluemixManager.decodeXMLRule;
WISE.managers.bluemixManager.decodeXMLRule = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = this._decodeXMLRule(xmlDoc);

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

//overwrite
WISE.managers.mqttManager._encodeXMLRule = WISE.managers.mqttManager.encodeXMLRule;
WISE.managers.mqttManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "topic"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
};

//overwrite
WISE.managers.mqttManager._decodeXMLRule = WISE.managers.mqttManager.decodeXMLRule;
WISE.managers.mqttManager.decodeXMLRule = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = this._decodeXMLRule(xmlDoc);

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

//overwrite
WISE.managers.mqttManager._getTopicName = WISE.managers.mqttManager.getTopicName;
WISE.managers.mqttManager.getTopicName = function(sourceType, sourceIndex, moduleIndex, channelType, channel){
	var topicName = this._getTopicName(sourceType, sourceIndex, moduleIndex, channelType, channel);

	if(topicName != ""){
		return topicName;
	}

	if(sourceType != "register"){
		if(sourceType == "customized"){//PUE
			var variable = "";

			variable += "pue";

			if(typeof(sourceIndex) == "undefined"){
				return variable;
			}
			else{
				variable += "/" + (sourceIndex + 1);

				return variable;
			}
		}
		else{
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

			if(module.extendedModule == "powerMeter"){
				var stringProcessor = function(string){
					return string.toLowerCase().replace(/ /g, "_").replace(/\//g, "-");
				};

				var variable = "";

				if(sourceType == "comport"){
					variable += "com" + sourceIndex;
				}
				else if(sourceType == "network"){
					variable += "lan";
				}

				variable += "/" + "no" + (moduleIndex + 1);

				if(typeof(channelType) == "undefined"){
					return variable;
				}
				else{
					var splitArray = channelType.split("_");

					if(splitArray[0] == "channel"){
						var loop = parseInt(splitArray[1], 10);
						var phase = parseInt(splitArray[2], 10);

						if(module.powerMeter.phase == 3){
							if(module.powerMeter.loop > 1){
								variable += "/" + "submeter$no".replace("$no", loop + 1);
							}

							if(phase < module.powerMeter.phase){
								if(module.powerMeter.channel[loop].isSinglePhase == true){
									variable += "/" + "ct$no".replace("$no", loop * 3 + phase + 1);
								}
								else{
									variable += "/" + "phase_$no".replace("$no", String.fromCharCode(97 + phase));
								}
							}
							else{
								variable += "/" + "total_avg";
							}
						}
						else{
							variable += "/" + "ct$no".replace("$no", loop + 1);
						}
					}
					else if(splitArray[0] == "io"){
						variable += "/" + splitArray[1].toLowerCase();
					}
					else if(splitArray[0] == "customizedData"){
						variable += "/" + stringProcessor(splitArray[2]);
					}

					if(typeof(channel) == "undefined"){
						return variable;
					}
					else{
						if(splitArray[0] == "channel"){
							var valueInfo = channel.split("_");
							var item = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueInfo[0]][parseInt(valueInfo[1], 10)];

							variable += "/" + {
								"V": "v",
								"I": "i",
								"KW": "kw",
								"KVAR": "kvar",
								"KVA": "kva",
								"PF": "pf",
								"KWH": "kwh",
								"KVARH": "kvarh",
								"KVAH": "kvah",
								"MCD": "actual_demand",
								"MPD": "forecast_demand",
								"MDH": "hourly_maximum_demand",
								"MDD": "daily_maximum_demand",
								"MDM": "monthly_maximum_demand",
								"DTE": "daily_accumulated_electricity",
								"MTE": "monthly_accumulated_electricity",
								"YTE": "yearly_accumulated_electricity",
							}[item.itemID];
						}
						else if(splitArray[0] == "io"){
							variable += "/" + channel;
						}
						else if(splitArray[0] == "customizedData"){
							var channel = module.powerMeter.customizedData[parseInt(channel, 10)];

							var groupCounter = 0;
							var groupPool = module.powerMeter.customizedData[module.powerMeter.format[channel.format].dataModel][channel.ruleName];
							for(var groupName in groupPool){
								groupCounter++;
							}

							if(groupCounter > 1 || groupPool[channel.groupName || ""].length > 1){
								if(channel.groupName){
									variable += "/" + stringProcessor(channel.groupName);
								}

								variable += "/" + stringProcessor(channel.itemName || (channel.channelIndex + 1).toString());
							}
						}
					}

					return variable;
				}
			}
		}
	}

	return "";
};

//overwrite
WISE.managers.azureManager.encodeXMLObject._processModuleVariableToJSONString = WISE.managers.azureManager.encodeXMLObject.processModuleVariableToJSONString;
WISE.managers.azureManager.encodeXMLObject.processModuleVariableToJSONString = function(moduleInfo, channelVariable, variable){
	try{
		var module = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.extendedModule == "powerMeter"){
			var stringProcessor = function(string){
				return string.toUpperCase().replace(/ /g, "_");
			};

			var channelInfo = WISE.getVariable.decodeExtendedModuleChannelVariable(module, channelVariable);
			var channelType = channelInfo.channelType;
			var channel = channelInfo.channel;

			var jsonChannelType = "", jsonChannelAddress = "", jsonName = "";
			var splitArray = channelType.split("_");

			if(splitArray[0] == "channel"){
				// Process jsonChannelType
				var loop = parseInt(splitArray[1], 10);
				var phase = parseInt(splitArray[2], 10);

				if(module.powerMeter.phase == 3){
					if(module.powerMeter.loop > 1){
						jsonChannelType += "SUBMETER$no".replace("$no", loop + 1) + "/";
					}

					if(phase < module.powerMeter.phase){
						if(module.powerMeter.channel[loop].isSinglePhase == true){
							jsonChannelType += "CT$no".replace("$no", loop * 3 + phase + 1);
						}
						else{
							jsonChannelType += "PHASE_$no".replace("$no", String.fromCharCode(97 + phase));
						}
					}
					else{
						jsonChannelType += "TOTAL_AVG";
					}
				}
				else{
					jsonChannelType += "CT$no".replace("$no", loop + 1);
				}

				// Process jsonChannelAddress
				var valueInfo = channel.split("_");
				var item = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueInfo[0]][parseInt(valueInfo[1], 10)];

				jsonChannelAddress += {
					"V": "V",
					"I": "I",
					"KW": "KW",
					"KVAR": "KVAR",
					"KVA": "KVA",
					"PF": "PF",
					"KWH": "KWH",
					"KVARH": "KVARH",
					"KVAH": "KVAH",
					"MCD": "ACTUAL_DEMAND",
					"MPD": "FORECAST_DEMAND",
					"MDH": "MAXIMUM_DEMAND_HOURLY",
					"MDD": "MAXIMUM_DEMAND_DAILY",
					"MDM": "MAXIMUM_DEMAND_MONTHLY",
					"DTE": "ACCUMULATED_ELECTRICITY_DAILY",
					"MTE": "ACCUMULATED_ELECTRICITY_MONTHLY",
					"YTE": "ACCUMULATED_ELECTRICITY_YEARLY",
				}[item.itemID];

				// Process jsonName
				jsonName = module.powerMeter.channel[loop][phase].name;
			}
			else if(splitArray[0] == "io"){
				// Process jsonChannelType
				jsonChannelType += splitArray[1].toLowerCase();

				// Process jsonChannelAddress
				jsonChannelAddress += channel;

				// Process jsonName
				jsonName = module.powerMeter.io[splitArray[1]][parseInt(channel, 10)].name;
			}
			else if(splitArray[0] == "customizedData"){
				// Process jsonChannelType
				jsonChannelType += stringProcessor(splitArray[2]);

				// Process jsonChannelAddress
				var channel = module.powerMeter.customizedData[parseInt(channel, 10)];

				var groupCounter = 0;
				var groupPool = module.powerMeter.customizedData[module.powerMeter.format[channel.format].dataModel][channel.ruleName];
				for(var groupName in groupPool){
					groupCounter++;
				}

				if(groupCounter > 1 || groupPool[channel.groupName || ""].length > 1){
					if(channel.groupName){
						jsonChannelAddress += stringProcessor(channel.groupName) + "_";
					}

					jsonChannelAddress += stringProcessor(channel.itemName || (channel.channelIndex + 1).toString());
				}

				// Process jsonName
				jsonName = channel.name;
			}

			var sourceTypeName = {
				"onboard": "0",
				"comport": "1",
				"network": "2"
			}[moduleInfo.sourceType];

			return '{' + 
				'"msg_type":"CHANNEL_UPDATE",' +
				'"if_type":' + sourceTypeName + ',' +
				(moduleInfo.sourceType == "comport" ? '"com_port":' + moduleInfo.sourceIndex + ',' : '') +
				(moduleInfo.sourceType != "onboard" ? '"module_no":' + (moduleInfo.moduleIndex + 1) + ',' : '') +
				'"ch_type":"' + jsonChannelType + '",' +
				'"ch_addr":"' + jsonChannelAddress + '",' +
				'"nickname":"' + jsonName + '",' +
				'"value":' + variable +
			'}';
		}
		else{
			return WISE.managers.azureManager.encodeXMLObject._processModuleVariableToJSONString(moduleInfo, channelVariable, variable);
		}
	}
	catch(error){
		return '{' + 
			'"msg_type": "MODULE_NOT_EXIST"' +
		'}';
	}
};

WISE.managers.bluemixManager.encodeXMLObject._processModuleVariableToJSONString = WISE.managers.bluemixManager.encodeXMLObject.processModuleVariableToJSONString;
WISE.managers.bluemixManager.encodeXMLObject.processModuleVariableToJSONString = function(moduleInfo, channelVariable, variable){
	try{
		var module = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

		if(module.extendedModule == "powerMeter"){
			var stringProcessor = function(string){
				return string.toUpperCase().replace(/ /g, "_");
			};

			var channelInfo = WISE.getVariable.decodeExtendedModuleChannelVariable(module, channelVariable);
			var channelType = channelInfo.channelType;
			var channel = channelInfo.channel;

			var jsonChannelType = "", jsonChannelAddress = "", jsonName = "";
			var splitArray = channelType.split("_");

			if(splitArray[0] == "channel"){
				// Process jsonChannelType
				var loop = parseInt(splitArray[1], 10);
				var phase = parseInt(splitArray[2], 10);

				if(module.powerMeter.phase == 3){
					if(module.powerMeter.loop > 1){
						jsonChannelType += "SUBMETER$no".replace("$no", loop + 1) + "/";
					}

					if(phase < module.powerMeter.phase){
						if(module.powerMeter.channel[loop].isSinglePhase == true){
							jsonChannelType += "CT$no".replace("$no", loop * 3 + phase + 1);
						}
						else{
							jsonChannelType += "PHASE_$no".replace("$no", String.fromCharCode(97 + phase));
						}
					}
					else{
						jsonChannelType += "TOTAL_AVG";
					}
				}
				else{
					jsonChannelType += "CT$no".replace("$no", loop + 1);
				}

				// Process jsonChannelAddress
				var valueInfo = channel.split("_");
				var item = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueInfo[0]][parseInt(valueInfo[1], 10)];

				jsonChannelAddress += {
					"V": "V",
					"I": "I",
					"KW": "KW",
					"KVAR": "KVAR",
					"KVA": "KVA",
					"PF": "PF",
					"KWH": "KWH",
					"KVARH": "KVARH",
					"KVAH": "KVAH",
					"MCD": "ACTUAL_DEMAND",
					"MPD": "FORECAST_DEMAND",
					"MDH": "MAXIMUM_DEMAND_HOURLY",
					"MDD": "MAXIMUM_DEMAND_DAILY",
					"MDM": "MAXIMUM_DEMAND_MONTHLY",
					"DTE": "ACCUMULATED_ELECTRICITY_DAILY",
					"MTE": "ACCUMULATED_ELECTRICITY_MONTHLY",
					"YTE": "ACCUMULATED_ELECTRICITY_YEARLY",
				}[item.itemID];

				// Process jsonName
				jsonName = module.powerMeter.channel[loop][phase].name;
			}
			else if(splitArray[0] == "io"){
				// Process jsonChannelType
				jsonChannelType += splitArray[1].toLowerCase();

				// Process jsonChannelAddress
				jsonChannelAddress += channel;

				// Process jsonName
				jsonName = module.powerMeter.io[splitArray[1]][parseInt(channel, 10)].name;
			}
			else if(splitArray[0] == "customizedData"){
				// Process jsonChannelType
				jsonChannelType += stringProcessor(splitArray[2]);

				// Process jsonChannelAddress
				var channel = module.powerMeter.customizedData[parseInt(channel, 10)];

				var groupCounter = 0;
				var groupPool = module.powerMeter.customizedData[module.powerMeter.format[channel.format].dataModel][channel.ruleName];
				for(var groupName in groupPool){
					groupCounter++;
				}

				if(groupCounter > 1 || groupPool[channel.groupName || ""].length > 1){
					if(channel.groupName){
						jsonChannelAddress += stringProcessor(channel.groupName) + "_";
					}

					jsonChannelAddress += stringProcessor(channel.itemName || (channel.channelIndex + 1).toString());
				}

				// Process jsonName
				jsonName = channel.name;
			}

			var sourceTypeName = {
				"onboard": "0",
				"comport": "1",
				"network": "2"
			}[moduleInfo.sourceType];

			return '{' + 
				'"msg_type":"CHANNEL_UPDATE",' +
				'"if_type":' + sourceTypeName + ',' +
				(moduleInfo.sourceType == "comport" ? '"com_port":' + moduleInfo.sourceIndex + ',' : '') +
				(moduleInfo.sourceType != "onboard" ? '"module_no":' + (moduleInfo.moduleIndex + 1) + ',' : '') +
				'"ch_type":"' + jsonChannelType + '",' +
				'"ch_addr":"' + jsonChannelAddress + '",' +
				'"nickname":"' + jsonName + '",' +
				'"value":' + variable +
			'}';
		}
		else{
			return WISE.managers.bluemixManager.encodeXMLObject._processModuleVariableToJSONString(moduleInfo, channelVariable, variable);
		}
	}
	catch(error){
		return '{' + 
			'"msg_type": "MODULE_NOT_EXIST"' +
		'}';
	}
};

//new function
WISE.managers.azureManager.encodeXMLObject.processExtendVariableToJSONString = 
WISE.managers.bluemixManager.encodeXMLObject.processExtendVariableToJSONString = function(result){
	if(result[1]){
		var pueManager = WISE.managers.pueManager;
		var pueIndex = parseInt(result[1], 10) - 1;
		var pue = pueManager.pool.pues[pueIndex];

		return '{' + 
			'"msg_type":"PUE_UPDATE",' +
			'"no":' + (pueIndex + 1) + ',' +
			'"nickname":"' + pue.name + '",' +
			'"value":' + result[0] +
		'}';
	}
};

//overwrite
WISE.managers.systemManager._encodeXMLRule = WISE.managers.systemManager.encodeXMLRule;
WISE.managers.systemManager.encodeXMLRule = function(xmlDoc, ruleObject){
	this._encodeXMLRule(xmlDoc, ruleObject);

	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "signal"){
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
};

//overwrite
WISE.managers.systemManager._decodeXMLRule = WISE.managers.systemManager.decodeXMLRule;
WISE.managers.systemManager.decodeXMLRule = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processExtendedModuleRule = WISE.managers.moduleManager.decodeXMLRule.processExtendedModuleRule;

	var ruleObject = this._decodeXMLRule(xmlDoc);

	if(ruleObject != null){
		processExtendedModuleRule(xmlDoc, ruleObject);
	}

	return ruleObject;
};

WISE.buildPowerMeterModuleSelector = function($sourceSelector, $moduleSelector, $channelSelector, key, settings){
	if(typeof($sourceSelector) == "string"){
		$sourceSelector = $("#" + $sourceSelector);
	}
	if(typeof($moduleSelector) == "string"){
		$moduleSelector = $("#" + $moduleSelector);
	}
	if(typeof($channelSelector) == "string"){
		$channelSelector = $("#" + $channelSelector);
	}

	$sourceSelector = $($sourceSelector);
	$moduleSelector = $($moduleSelector);
	$channelSelector = $($channelSelector);

	if($sourceSelector.length <= 0){$sourceSelector = null}
	if($channelSelector.length <= 0){$channelSelector = null}

	var moduleManager = WISE.managers.moduleManager;

	var interfaces = {};
	for(var i = 0; i < key.length; i++){
		var moduleInfo = WISE.managers.moduleManager.getModuleInfoByKey(key[i].moduleKey);

		if(typeof(interfaces[moduleInfo.sourceType]) == "undefined"){
			interfaces[moduleInfo.sourceType] = [];
		}
		if(typeof(interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex]) == "undefined"){
			interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex] = {
				"moduleIndexArray": [],
				"name": moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name
			};
		}

		interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].moduleIndexArray.push(moduleInfo.moduleIndex);
	}

	var createModuleSelect = function(){
		$moduleSelector.empty();

		if($sourceSelector != null){
			var moduleSource = $sourceSelector.val().split("_");
			var sourceType = moduleSource[0];
			var sourceIndex = parseInt(moduleSource[1], 10);

			for(var i = 0, moduleIndexArray = interfaces[sourceType][sourceIndex].moduleIndexArray; i < moduleIndexArray.length; i++){
				var moduleInfo = WISE.powerMeterModuleInfo(sourceType, sourceIndex, moduleIndexArray[i]);
				$("<option></option>").attr("value", moduleIndexArray[i]).text(settings.moduleNameOnly == true ? moduleInfo.name : moduleInfo).appendTo($moduleSelector);
			}
		}
		else{
			for(var i = 0, sourceArray = ["onboard", "comport", "network"]; i < sourceArray.length; i++){
				if(typeof(interfaces[sourceArray[i]]) == "undefined"){continue;}
				for(var j = 0; j < interfaces[sourceArray[i]].length; j++){
					if(typeof(interfaces[sourceArray[i]][j]) == "undefined"){continue;}
					for(var k = 0, moduleIndexArray = interfaces[sourceArray[i]][j].moduleIndexArray; k < moduleIndexArray.length; k++){//
						var moduleInfo = WISE.powerMeterModuleInfo(sourceArray[i], j, moduleIndexArray[k]);
						$("<option></option>").attr("value", sourceArray[i] + "_" + j + "_" + moduleIndexArray[k]).text(settings.moduleNameOnly == true ? moduleInfo.name : moduleInfo).appendTo($moduleSelector);
					}
				}
			}
		}
	};

	var createChannelSelect = function(){
		$channelSelector.empty();

		if($sourceSelector != null){
			if($sourceSelector.val() == null){return;}

			var moduleSource = $sourceSelector.val().split("_");
			var sourceType = moduleSource[0];
			var sourceIndex = parseInt(moduleSource[1], 10);
			var moduleIndex = parseInt($moduleSelector.val(), 10);
		}
		else{
			if($moduleSelector.val() == null){return;}

			var moduleSource = $moduleSelector.val().split("_");
			var sourceType = moduleSource[0];
			var sourceIndex = parseInt(moduleSource[1], 10);
			var moduleIndex = parseInt(moduleSource[2], 10);
		}

		var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

		if(typeof(module.powerMeter) != "undefined"){
			if(settings.type == "channel"){
				if(module.powerMeter.phase == 1){
					for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
						var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";

						if((typeof(settings.itemType) == "undefined" || typeof(settings.itemIndex) == "undefined") || typeof(module.powerMeter.channel[loop][0][settings.itemType][settings.itemIndex]) != "undefined"){
							var text = "<#Lang.global.ctX>".replace("$no", loop + 1) + loopName;
							$("<option></option>").attr("value", loop + "_0_" + settings.itemType + "_" + settings.itemIndex).html(text).appendTo($channelSelector);
						}
					}
				}
				else{
					for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
						if(module.powerMeter.loop > 1){
							var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";
							$channelSelector.append($("<option></option>").attr("disabled", true).text("<#Lang.global.submeterX>".replace("$no", loop + 1) + loopName));
						}

						for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
							if((typeof(settings.itemType) == "undefined" || typeof(settings.itemIndex) == "undefined") || typeof(module.powerMeter.channel[loop][phase][settings.itemType][settings.itemIndex]) != "undefined"){
								var text = module.powerMeter.loop > 1 ? "&nbsp;" : "";
	
								if(phase < module.powerMeter.phase){
									var phaseName = module.powerMeter.channel[loop][phase].name != "" ? "(" + module.powerMeter.channel[loop][phase].name + ")" : "";

									if(module.powerMeter.channel[loop].isSinglePhase == true){
										text += "<#Lang.global.ctX>".replace("$no", loop * 3 + phase + 1) + phaseName;
									}
									else{
										text += "<#Lang.global.phaseX>".replace("$no", String.fromCharCode(65 + phase)) + phaseName;
									}
								}
								else{
									text += "<#Lang.global.totalOrAverage>";
								}

								$("<option></option>").attr("value", loop + "_" + phase + "_" + settings.itemType + "_" + settings.itemIndex).html(text).appendTo($channelSelector);
							}
						}
					}
				}

				$channelSelector.find("option:not(:disabled):first").attr("selected", true);//select first not disabled option
			}
			else if(settings.type == "io"){
				for(var i = 0; i < module.powerMeter.io[settings.channelType].length; i++){
					$("<option></option>").attr("value", settings.channelType + "_" + i).text(i + (module.powerMeter.io[settings.channelType][i].name != "" ? "(" + module.powerMeter.io[settings.channelType][i].name + ")" : "")).appendTo($channelSelector);
				}
			}
			else if(settings.type == "customizedData"){
				var groupPool = module.powerMeter.customizedData[settings.channelType][settings.ruleName];
				for(var groupName in groupPool){
					var indent = "";
					if(groupName != ""){
						$channelSelector.append($("<option></option>").attr("disabled", true).text(groupName));
						indent = "&nbsp;";
					}

					for(var i = 0, mappingArray = groupPool[groupName]; i < mappingArray.length; i++){
						$("<option></option>").attr("value", mappingArray[i]).html(indent + (module.powerMeter.customizedData[mappingArray[i]].itemName || i + 1) + (module.powerMeter.customizedData[mappingArray[i]].name != "" ? "(" + module.powerMeter.customizedData[mappingArray[i]].name + ")" : "")).appendTo($channelSelector);
					}
				}
			}
		}
	};

	if($sourceSelector != null){
		$sourceSelector.empty();
		for(var i = 0, sourceArray = ["onboard", "comport", "network"]; i < sourceArray.length; i++){
			if(typeof(interfaces[sourceArray[i]]) == "undefined"){continue;}
			for(var j = 0; j < interfaces[sourceArray[i]].length; j++){
				if(typeof(interfaces[sourceArray[i]][j]) == "undefined"){continue;}
				$("<option></option>").attr("value", sourceArray[i] + "_" + j).text(interfaces[sourceArray[i]][j].name).appendTo($sourceSelector);
			}
		}

		$sourceSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
			createModuleSelect();

			if($channelSelector != null){
				$moduleSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
					createChannelSelect();

					$channelSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
						if(typeof(settings.onChange) == "function"){
							settings.onChange($sourceSelector, $moduleSelector, $channelSelector);
						}
					}).triggerHandler("change");
				}).triggerHandler("change");
			}
			else{
				$moduleSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
					if(typeof(settings.onChange) == "function"){
						settings.onChange($sourceSelector, $moduleSelector);
					}
				}).triggerHandler("change");
			}
		}).triggerHandler("change");
	}
	else{
		createModuleSelect();

		if($channelSelector != null){
			$moduleSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
				createChannelSelect();

				$channelSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
					if(typeof(settings.onChange) == "function"){
						settings.onChange($moduleSelector, $channelSelector);
					}
				}).triggerHandler("change");
			}).triggerHandler("change");
		}
		else{
			$moduleSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(){
				if(typeof(settings.onChange) == "function"){
					settings.onChange($moduleSelector);
				}
			}).triggerHandler("change");
		}
	}
};

WISE.createCompareValue.processExtendedCompareDropDownListValue = function(settings){
	if(settings.rule.value[6].type == "channel"){
		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleInfoByKey(settings.rule.value[6].moduleKey).module;

		return "_channel_" + settings.rule.value[6].itemType + "_" + settings.rule.value[6].itemIndex;
	}
	else if(settings.rule.value[6].type == "io"){
		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleInfoByKey(settings.rule.value[6].moduleKey).module;

		return "_io_" + settings.rule.value[6].channelType;
	}
	else if(settings.rule.value[6].type == "customizedData"){
		var moduleManager = WISE.managers.moduleManager;
		var module = moduleManager.getModuleInfoByKey(settings.rule.value[6].moduleKey).module;

		var channel = module.powerMeter.customizedData[settings.rule.value[6].customizedDataIndex];
		var dataModel = module.powerMeter.format[channel.format].dataModel;
		return "_customizedData_" + dataModel + "_" + channel.ruleName;
	}
	else if(settings.rule.value[6].type == "pue"){
		return "_pue";
	}
};

WISE.createCompareValue.processExtendedCompareDropDownListClick = function(li, settings){
	var moduleManager = WISE.managers.moduleManager;
	var splitArray = $(li).attr("val").split("_");
	var type = parseInt(splitArray[0], 10);

	if(splitArray[1] == "channel"){
		WISE.buildPowerMeterModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions["pm_channel_" + splitArray[2] + "_" + splitArray[3]].key, {
			"type": "channel",
			"itemType": splitArray[2],
			"itemIndex": parseInt(splitArray[3], 10)
		});

		if(settings.rule.value[type].moduleKey != null){
			var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
			if(moduleInfo != null){
				$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
				$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
				$("#" + settings.channel).val(settings.rule.value[type].loop + "_" + settings.rule.value[type].phase + "_" + settings.rule.value[type].itemType + "_" + settings.rule.value[type].itemIndex);
			}
		}

		$("#" + settings.compareChannelPrefix).html("<#Lang['?'].channel>").parent().show();
		$("#" + settings.moduleHandler).show();
	}
	else if(splitArray[1] == "io"){
		if(splitArray[2] == "AI"){
			WISE.buildPowerMeterModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions["pm_io_AI"].key, {
				"type": "io",
				"channelType": splitArray[2]
			});
		}
		else if(splitArray[2] == "AO"){
			WISE.buildPowerMeterModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.actions["pm_io_AO"].key, {
				"type": "io",
				"channelType": splitArray[2]
			});
		}

		if(settings.rule.value[type].moduleKey != null){
			var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
			if(moduleInfo != null){
				$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
				$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
				$("#" + settings.channel).val(settings.rule.value[type].channelType + "_" + settings.rule.value[type].channelIndex);
			}
		}

		$("#" + settings.compareChannelPrefix).html("<#Lang['?'].channel>").parent().show();
		$("#" + settings.moduleHandler).show();
	}
	else if(splitArray[1] == "customizedData"){
		WISE.buildPowerMeterModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions["pm_customizedData_" + splitArray[2] + "_" + splitArray[3]].key, {
			"type": "customizedData",
			"channelType": splitArray[2],
			"ruleName": splitArray[3],
			"onChange": function($sourceSelector, $moduleSelector, $channelSelector){
				if($channelSelector.find("option").length == 1){
					$channelSelector.parent().hide();
				}
				else{
					$channelSelector.parent().show();
				}
			}
		});

		if(settings.rule.value[type].moduleKey != null){
			var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
			if(moduleInfo != null){
				$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
				$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
				$("#" + settings.channel).val(settings.rule.value[type].customizedDataIndex);
			}
		}

		$("#" + settings.compareChannelPrefix).html("<#Lang['?'].item>");
		$("#" + settings.moduleHandler).show();
	}
	else if(splitArray[1] == "pue"){
		var pueManager = WISE.managers.pueManager;
		var pues = pueManager.pool.pues;
		var $select = $("<select></select>");

		for(var i = 0, key = pueManager.pool.conditions.pue.key; i < key.length; i++){
			var $option = $("<option></option>").attr("value", key[i]).text((i + 1) + (pues[key[i]].name != "" ? "(" + pues[key[i]].name + ")" : ""));

			if(key[i] == settings.rule.value[type].pueIndex){
				$option.attr("selected", true);
			}

			$select.append($option);
		}

		$('#' + settings.customizedAreaHandler).empty().html("<#Lang['?'].no>&nbsp;").append($select).show();
	}
};

WISE.createCompareValue.createExtendedCompareValue = function(settings){
	var moduleManager = WISE.managers.moduleManager;
	var $ul = $("#" + settings.type);

	//PM
	var $pmUL = $("<ul></ul>");

	var $meterValueUL = $("<ul></ul>");//meter value
	for(var i = 0; i < itemInformation.meterValue.length; i++){
		if(moduleManager.pool.conditions["pm_channel_meterValue_" + i].key.length > 0){
			$meterValueUL.append(
				$("<li></li>").attr("val", "6_channel_meterValue_" + i).append(moduleManager.pool.conditions["pm_channel_meterValue_" + i].name)
			);
		}
	}
	if($meterValueUL.children().length > 0){
		$pmUL.append(
			$("<li></li>").append("<#Lang.global.basicValue>").append($meterValueUL)
		)
	}

	var $statisticsValueUL = $("<ul></ul>");//statistics value
	for(var i = 0; i < itemInformation.statisticsValue.length; i++){
		if(moduleManager.pool.conditions["pm_channel_statisticsValue_" + i].key.length > 0){
			$statisticsValueUL.append(
				$("<li></li>").attr("val", "6_channel_statisticsValue_" + i).append(moduleManager.pool.conditions["pm_channel_statisticsValue_" + i].name)
			);
		}
	}
	if($statisticsValueUL.children().length > 0){
		$pmUL.append(
			$("<li></li>").append("<#Lang.global.statisticsValue>").append($statisticsValueUL)
		)
	}

	var $ioUL = $("<ul></ul>");//io
	if(moduleManager.pool.conditions["pm_io_AI"].key.length > 0){
		$ioUL.append(
			$("<li></li>").attr("val", "6_io_AI").append(moduleManager.pool.conditions["pm_io_AI"].name)
		);
	}
	if(moduleManager.pool.actions["pm_io_AO"].key.length > 0){
		$ioUL.append(
			$("<li></li>").attr("val", "6_io_AO").append(moduleManager.pool.actions["pm_io_AO"].name)
		);
	}
	if($ioUL.children().length > 0){
		$pmUL.append(
			$("<li></li>").append("<#Lang.global.ioInformation>").append($ioUL)
		)
	}

	var $customizedDataUL = $("<ul></ul>");//customizedData
	for(var condition in WISE.managers.moduleManager.pool.conditions){
		if(condition.match(/^pm_customizedData_(RI|RO)_/)){
			if(moduleManager.pool.conditions[condition].key.length > 0){
				$customizedDataUL.append(
					$("<li></li>").attr("val", "6_customizedData_" + moduleManager.pool.conditions[condition].dataModel + "_" + moduleManager.pool.conditions[condition].name).append(moduleManager.pool.conditions[condition].name)
				);
			}
		}
	}
	if($customizedDataUL.children().length > 0){
		$pmUL.append(
			$("<li></li>").append("<#Lang.global.otherInformation>").append($customizedDataUL)
		)
	}

	//root
	if($pmUL.children().length > 0){
		$ul.append(
			$("<li></li>").append("<#Lang['?'].powerMeter>").append($pmUL)
		)
	}

	if(WISE.managers.pueManager.pool.conditions.pue.key.length > 0){//PUE
		$ul.append(
			$("<li></li>").attr("val", "6_pue").append("<#Lang['?'].pue>")
		);
	}
}

WISE.saveCompareValue.saveExtendedCompareValue = function(settings){
	var splitArray = $("#" + settings.type).dropDownList("val").split("_");

	if(splitArray[1] == "channel"){
		var moduleManager = WISE.managers.moduleManager;
		var compareModule = moduleManager.pool.interfaces[$("#" + settings.source).val().split("_")[0]][parseInt($("#" + settings.source).val().split("_")[1], 10)].modules[parseInt($("#" + settings.module).val(), 10)];
		var tempArray = $("#" + settings.channel).val().split("_");

		settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
		settings.rule.value[settings.rule.type].type = "channel";
		settings.rule.value[settings.rule.type].loop = parseInt(tempArray[0], 10);
		settings.rule.value[settings.rule.type].phase = parseInt(tempArray[1], 10);
		settings.rule.value[settings.rule.type].itemType = tempArray[2];
		settings.rule.value[settings.rule.type].itemIndex = parseInt(tempArray[3], 10);
	}
	else if(splitArray[1] == "io"){
		var moduleManager = WISE.managers.moduleManager;
		var compareModule = moduleManager.pool.interfaces[$("#" + settings.source).val().split("_")[0]][parseInt($("#" + settings.source).val().split("_")[1], 10)].modules[parseInt($("#" + settings.module).val(), 10)];
		var tempArray = $("#" + settings.channel).val().split("_");

		settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
		settings.rule.value[settings.rule.type].channelType = tempArray[0];
		settings.rule.value[settings.rule.type].channelIndex = parseInt(tempArray[1], 10);
	}
	else if(splitArray[1] == "customizedData"){
		var moduleManager = WISE.managers.moduleManager;
		var compareModule = moduleManager.pool.interfaces[$("#" + settings.source).val().split("_")[0]][parseInt($("#" + settings.source).val().split("_")[1], 10)].modules[parseInt($("#" + settings.module).val(), 10)];

		settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
		settings.rule.value[settings.rule.type].customizedDataIndex = parseInt($("#" + settings.channel).val(), 10);
	}
	else if(splitArray[1] == "pue"){
		settings.rule.value[settings.rule.type].pueIndex = parseInt($("#" + settings.customizedAreaHandler + " select").val(), 10);
	}

	settings.rule.value[settings.rule.type].type = splitArray[1];
}

WISE.buildSelector.processExtendedModule = function(module, channelInfo){
	var findFlag = false;

	channelInfo.channelPool.channel = [];
	for(var loop = 0; loop < module.powerMeter.channel.length; loop++){
		channelInfo.channelPool.channel[loop] = [];

		for(var phase = 0; phase < module.powerMeter.channel[loop].length; phase++){
			if(module.powerMeter.channel[loop][phase].meterValue.length > 0 || module.powerMeter.channel[loop][phase].statisticsValue.length > 0){
				channelInfo.channelPool.channel[loop][phase] = true;
				findFlag = true;
			}
			else{
				channelInfo.channelPool.channel[loop][phase] = false;
			}
		}
	}

	channelInfo.channelPool.io = {};
	for(var typeArrayIndex = 0, typeArray = ["DI", "DO", "AI", "AO"]; typeArrayIndex < typeArray.length; typeArrayIndex++){
		if(module.powerMeter.io[typeArray[typeArrayIndex]].length > 0){
			channelInfo.channelPool.io[typeArray[typeArrayIndex]] = true;
			findFlag = true;
		}
	}

	channelInfo.channelPool.customizedData = {};
	for(var typeArrayIndex = 0, typeArray = ["CI", "CO", "RI", "RO"]; typeArrayIndex < typeArray.length; typeArrayIndex++){
		for(var ruleName in module.powerMeter.customizedData[typeArray[typeArrayIndex]]){
			channelInfo.channelPool.customizedData[typeArray[typeArrayIndex]] = true;
			findFlag = true;
		}
	}

	return findFlag;
};

WISE.buildSelector.onChangeExtendedModuleSelector = function($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, settings, channelInfo){
	var moduleManager = WISE.managers.moduleManager;
	var splitArray = $sourceSelector.val().split("_");
	var sourceType = splitArray[0];
	var sourceIndex = splitArray[1];
	var moduleIndex = parseInt($moduleSelector.val(), 10);
	var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

	if(typeof(channelInfo.channelPool.channel) != "undefined"){
		//build channel
		$channelTypeSelector.append($("<option></option>").attr("disabled", true).text("<#Lang.global.basicValue>"));
		var findFlag = false;

		if(module.powerMeter.phase == 1){
			for(var loop = 0; loop < channelInfo.channelPool.channel.length; loop++){
				var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";

				if(channelInfo.channelPool.channel[loop][0] == true){
					var text = "<#Lang.global.ctX>".replace("$no", loop + 1) + loopName;
					$("<option></option>").attr("value", "channel_" + loop + "_0").html("&nbsp;" + text).appendTo($channelTypeSelector);
					findFlag = true;
				}
			}
		}
		else{
			for(var loop = 0; loop < channelInfo.channelPool.channel.length; loop++){
				if(module.powerMeter.loop > 1){
					var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";
					$channelTypeSelector.append($("<option></option>").attr("disabled", true).html("&nbsp;" + "<#Lang.global.submeterX>".replace("$no", loop + 1) + loopName));
				}

				for(var phase = 0; phase < channelInfo.channelPool.channel[loop].length; phase++){
					if(channelInfo.channelPool.channel[loop][phase] == true){
						var text = module.powerMeter.loop > 1 ? "&nbsp;" : "";

						if(phase < module.powerMeter.phase){
							var phaseName = module.powerMeter.channel[loop][phase].name != "" ? "(" + module.powerMeter.channel[loop][phase].name + ")" : "";

							if(module.powerMeter.channel[loop].isSinglePhase == true){
								text += "<#Lang.global.ctX>".replace("$no", loop * 3 + phase + 1) + phaseName;
							}
							else{
								text += "<#Lang.global.phaseX>".replace("$no", String.fromCharCode(65 + phase)) + phaseName;
							}
						}
						else{
							text += "<#Lang.global.totalOrAverage>";
						}

						$("<option></option>").attr("value", "channel_" + loop + "_" + phase).html("&nbsp;" + text).appendTo($channelTypeSelector);
						findFlag = true;
					}
				}
			}
		}

		if(findFlag == false){
			$channelTypeSelector.children(":last").remove();
		}
	}

	//build io
	$channelTypeSelector.append($("<option></option>").attr("disabled", true).text("<#Lang.global.ioInformation>"));
	var findFlag = false;
	for(var channelType in channelInfo.channelPool.io){
		$channelTypeSelector.append($("<option></option>").val("io_" + channelType).html("&nbsp;" + channelType));
		findFlag = true;
	}
	if(findFlag == false){
		$channelTypeSelector.children(":last").remove();
	}

	//build customizedData
	$channelTypeSelector.append($("<option></option>").attr("disabled", true).text("<#Lang.global.otherInformation>"));
	var findFlag = false;
	for(var channelType in channelInfo.channelPool.customizedData){
		for(var ruleName in module.powerMeter.customizedData[channelType]){
			var counter = 0;
			for(var groupName in module.powerMeter.customizedData[channelType][ruleName]){
				for(var i = 0, mappingArray = module.powerMeter.customizedData[channelType][ruleName][groupName]; i < mappingArray.length; i++){
					var channel = module.powerMeter.customizedData[mappingArray[i]];

					counter++;
				}
			}

			$channelTypeSelector.append($("<option></option>").val("customizedData_" + channelType + "_" + ruleName).html("&nbsp;" + ruleName + (function(){
				return (counter == 1 && channel.name != "" ? "(" + channel.name + ")" : "")//only one item, show its nickname after rule name
			})()));

			findFlag = true;
		}
	}
	if(findFlag == false){
		$channelTypeSelector.children(":last").remove();
	}

	$channelTypeSelector.find("option:not(:disabled):first").attr("selected", true);//select first not disabled option
}

WISE.buildSelector.onChangeExtendedChannelSelector = function($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, $registerSelector, settings){
	var moduleManager = WISE.managers.moduleManager;

	var splitArray = $sourceSelector.val().split("_");
	var sourceType = splitArray[0];
	var sourceIndex = splitArray[1];
	var moduleIndex = parseInt($moduleSelector.val(), 10);
	var channelType = $channelTypeSelector.val();
	var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

	var splitArray = channelType.split("_");
	if(splitArray[0] == "channel"){
		for(var i = 0, valueTypeArray = ["meterValue", "statisticsValue"]; i < valueTypeArray.length; i++){
			var valueType = valueTypeArray[i];
			var items = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueType];
			for(var j = 0; j < items.length; j++){
				if(typeof(items[j]) == "undefined"){continue;}
				
				$channelSelector.append($("<option></option>").val(valueType + "_" + j).text(itemInformation[valueType][j].name));
			}
		}
	}
	else if(splitArray[0] == "io"){
		var channel = module.powerMeter.io[splitArray[1]];
		for(var i = 0; i < channel.length; i++){
			$channelSelector.append($("<option></option>").val(i).text(i + (channel[i].name != "" ? "(" + channel[i].name + ")" : "")));
		}
	}
	else if(splitArray[0] == "customizedData"){
		var groupPool = module.powerMeter.customizedData[splitArray[1]][splitArray[2]];
		for(var groupName in groupPool){
			var indent = "";
			if(groupName != ""){
				$channelSelector.append($("<option></option>").attr("disabled", true).text(groupName));
				indent = "&nbsp;";
			}

			for(var i = 0, mappingArray = groupPool[groupName]; i < mappingArray.length; i++){
				$channelSelector.append($("<option></option>").val(mappingArray[i]).html(indent + (module.powerMeter.customizedData[mappingArray[i]].itemName || i + 1) + (module.powerMeter.customizedData[mappingArray[i]].name != "" ? "(" + module.powerMeter.customizedData[mappingArray[i]].name + ")" : "")));
			}
		}
	}
}

WISE.buildSelector.extendedModuleFilter = function(channelPool){
	//reserve output only
	delete channelPool.channel;
	delete channelPool.io.DI;
	delete channelPool.io.AI;
	delete channelPool.customizedData.CI;
	delete channelPool.customizedData.RI;

	var emptyFlag = true;
	for(var io in channelPool.io){
		emptyFlag = false;
		break;
	}
	if(emptyFlag == true){
		delete channelPool.io;
	}

	var emptyFlag = true;
	for(var customizedData in channelPool.customizedData){
		emptyFlag = false;
		break;
	}
	if(emptyFlag == true){
		delete channelPool.customizedData;
	}
};

WISE.buildSelector.porcessChannelPrefix = function($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, $registerSelector, settings){
	var splitArray = $channelTypeSelector.val().split("_");

	if(splitArray[0] == "channel"){
		settings.channelPrefix.text("<#Lang['?'].info>");
	}
	else if(splitArray[0] == "io"){
		settings.channelPrefix.text("<#Lang['?'].ch>");
	}
	else if(splitArray[0] == "customizedData"){
		settings.channelPrefix.text("<#Lang['?'].item>");
	}
};

WISE.buildSelector.extendSourceSelector = function($sourceSelector){
	var pueManager = WISE.managers.pueManager;
	for(var key in pueManager.pool.pues){
		$sourceSelector.append(
			$("<option></option>").val("pue").html("<#Lang['?'].pue>")
		);
		break;
	}
};

WISE.buildSelector.extendSourceSelectorChange = function($sourceSelector, $customizedHandler, settings){
	if($sourceSelector.val() == "pue"){
		$customizedHandler.empty().append(
			$("<tr></tr>").append(
				$("<td></td>").append(
					$("<div></div>").attr("class", "tdRadius").append(
						$("<div></div>").css("padding", "3px 7px").html("<#Lang['?'].no>")
					)
				)
			).append(
				$("<td></td>").append((function(){
					var pueManager = WISE.managers.pueManager;
					var $select = $("<select></select>").attr("class", "pueSelector").bind("change.selector", function(event){
						if(typeof(settings.onChange) == "function"){
							settings.onChange("customized");
						}
					});

					for(var i = 0, pues = pueManager.pool.pues; i < pues.length; i++){
						if(typeof(pues[i]) == "undefined"){continue;}

						$select.append(
							$("<option></option>").val(i).text((i + 1) + (pueManager.pool.pues[i].name != "" ? "(" + pueManager.pool.pues[i].name + ")" : ""))
						);
					}

					if(settings.showAllChannel == true){
						$select.append(
							$("<option></option>").val("-1").text("<#Lang['?'].all>")
						);
					}

					return $select;
				})())
			)
		);
	}
};

WISE.buildVariableEditor.processExtendedModule = function(moduleInfo, channelVariable){
	var moduleManager = WISE.managers.moduleManager;
	var interfaceName = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name;
	var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

	var regex = /(\D+)(\d+)/;
	var result = regex.exec(channelVariable);

	if(result){
		for(var i = 0; i < result.length; i++){
			if(typeof(result[i]) == "undefined"){
				result[i] = "";
			}
		}

		moduleInfo.channelType = result[1].toUpperCase();
		moduleInfo.channel = parseInt(result[2].toUpperCase(), 10);
	}

	if(moduleInfo.channelType == "DI" || moduleInfo.channelType == "DO" || moduleInfo.channelType == "AI" || moduleInfo.channelType == "AO"){
		var channel = module.powerMeter.io[moduleInfo.channelType][moduleInfo.channel];

		var dataModel = module.powerMeter.format[channel.format].dataModel;
		var channelInfo = module[dataModel].remoteAddress[channel.address];
	}
	else{
		var dataModel = moduleInfo.channelType == "M" ? "RICB" : moduleInfo.channelType;
		var channelInfo = module[dataModel].remoteAddress[moduleInfo.channel];
	}

	if(channelInfo.type == "channel"){
		var loop = channelInfo.loop;
		var phase = channelInfo.phase;
		var text = "";

		if(module.powerMeter.phase == 1){
			var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";
			text += "<#Lang.global.ctX>".replace("$no", loop + 1) + loopName;
		}
		else{
			if(module.powerMeter.loop > 1){
				var loopName = module.powerMeter.channel[loop].name != "" ? "(" + module.powerMeter.channel[loop].name + ")" : "";
				text += "<#Lang.global.submeterX>".replace("$no", loop + 1) + loopName;
			}

			if(phase < module.powerMeter.phase){
				var phaseName = module.powerMeter.channel[loop][phase].name != "" ? "(" + module.powerMeter.channel[loop][phase].name + ")" : "";

				if(module.powerMeter.channel[loop].isSinglePhase == true){
					text += " <#Lang.global.ctX>".replace("$no", loop * 3 + phase + 1) + phaseName;
				}
				else{
					text += " <#Lang.global.phaseX>".replace("$no", String.fromCharCode(65 + phase)) + phaseName;
				}
			}
			else{
				text += " <#Lang.global.totalOrAverage>";
			}
		}

		return $("<span></span>").attr("tip", interfaceName + "<br>" + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex)).html(module.name + " " + text + " " + itemInformation[channelInfo.itemType][channelInfo.itemIndex].name);
	}
	else if(channelInfo.type == "io"){
		return $("<span></span>").attr("tip", interfaceName + "<br>" + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex)).html(module.name + " " + /*channelInfo.channelType*/ moduleInfo.channelType + /*channelInfo.channelIndex*/ moduleInfo.channel + (module.powerMeter.io[moduleInfo.channelType][moduleInfo.channel].name != "" ? "(" + module.powerMeter.io[moduleInfo.channelType][moduleInfo.channel].name + ")" : ""));
	}
	else if(channelInfo.type == "customizedData"){
		var channel = module.powerMeter.customizedData[channelInfo.customizedDataIndex];
		var itemName = "";
		var groupCounter = 0;
		var groupPool = module.powerMeter.customizedData[module.powerMeter.format[channel.format].dataModel][channel.ruleName];
		for(var groupName in groupPool){
			groupCounter++;
		}
		if(groupCounter > 1 || module.powerMeter.customizedData[module.powerMeter.format[channel.format].dataModel][channel.ruleName][channel.groupName || ""].length > 1){
			itemName = " " + (channel.groupName || "") + " " + (channel.itemName || channel.channelIndex + 1);
		}

		return $("<span></span>").attr("tip", interfaceName + "<br>" + WISE.powerMeterModuleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex)).html(module.name + " " + channel.ruleName + itemName + (channel.name != "" ? "(" + channel.name + ")" : ""));
	}
};

//require function
//from option value to remote data model and address
WISE.buildVariableEditor.getExtendedModuleRemoteChannelInfo = function(module, channelType, channel){
	var splitArray = channelType.split("_");

	if(splitArray[0] == "channel"){
		var valueInfo = channel.split("_");
		var item = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueInfo[0]][parseInt(valueInfo[1], 10)];

		channelType = module.powerMeter.format[item.format].dataModel;
		channelAddress = item.address;
	}
	else if(splitArray[0] == "io"){
		var channel = module.powerMeter.io[splitArray[1]][parseInt(channel, 10)];

		channelType = module.powerMeter.format[channel.format].dataModel;
		channelAddress = channel.address;
	}
	else if(splitArray[0] == "customizedData"){
		var channel = module.powerMeter.customizedData[parseInt(channel, 10)];

		channelType = module.powerMeter.format[channel.format].dataModel;
		channelAddress = channel.address;
	}

	return {
		"channelType": channelType,
		"channelAddress": channelAddress
	};
};

WISE.buildVariableEditor.extendRegex = "\\$Pue(\\d+)";

WISE.buildVariableEditor.extendReplaceElement = function(result){
	if(result[1]){
		var pueManager = WISE.managers.pueManager;
		var pueIndex = parseInt(result[1], 10) - 1;
		var pue = pueManager.pool.pues[pueIndex];

		if(typeof(pue) == "undefined"){
			return null;
		}
		else{
			return $("<span></span>").html("<#Lang['?'].pue>" + " " + (pueIndex + 1) + (pue.name != "" ? "(" + pue.name + ")" : ""));
		}
	}
};

//require function
//from option value to variable 
WISE.getVariable.encodeExtendedModuleChannelVariable = function(module, channelType, channel){
	var splitArray = channelType.split("_");
	var channelVariable = "";

	if(splitArray[0] == "channel"){
		var valueInfo = channel.split("_");
		var item = module.powerMeter.channel[parseInt(splitArray[1], 10)][parseInt(splitArray[2], 10)][valueInfo[0]][parseInt(valueInfo[1], 10)];

		if(valueInfo[0] == "statisticsValue"){
			channelVariable += "m";
		}
		else{
			channelVariable += module.powerMeter.format[item.format].dataModel.toLowerCase();
		}

		channelVariable += item.address;
	}
	else if(splitArray[0] == "io"){
		module.powerMeter.io[splitArray[1]][parseInt(channel, 10)];//check remote address exist

		channelVariable += splitArray[1].toLowerCase();
		channelVariable += channel;
	}
	else if(splitArray[0] == "customizedData"){
		var channel = module.powerMeter.customizedData[parseInt(channel, 10)];

		channelVariable += module.powerMeter.format[channel.format].dataModel.toLowerCase();
		channelVariable += channel.address;
	}

	return channelVariable;
};

//require function
//from variable to channelType and channel(for option value use)
WISE.getVariable.decodeExtendedModuleChannelVariable = function(module, channelVariable){
	var regex = /(di|do|ai|ao|ci|co|ri|ro|m)(\d+)/;
	var result = regex.exec(channelVariable);

	if(result){
		for(var i = 0; i < result.length; i++){
			if(typeof(result[i]) == "undefined"){
				result[i] = "";
			}
		}

		if(result[1] == "di" || result[1] == "do" || result[1] == "ai" || result[1] == "ao"){//the I/O of Power Meter
			return {
				"channelType": "io" + "_" + result[1].toUpperCase(),
				"channel": parseInt(result[2], 10)
			};
		}
		else{
			var dataModel = result[1] == "m" ? "RICB" : result[1].toUpperCase();
			var channelInfo = module[dataModel].remoteAddress[parseInt(result[2], 10)];

			if(channelInfo.type == "channel"){
				return {
					"channelType": "channel" + "_" + channelInfo.loop + "_" + channelInfo.phase,
					"channel": channelInfo.itemType + "_" + channelInfo.itemIndex
				};
			}
			else if(channelInfo.type == "customizedData"){
				var channel = module.powerMeter.customizedData[channelInfo.customizedDataIndex];
				var dataModel = module.powerMeter.format[channel.format].dataModel;

				return {
					"channelType": "customizedData" + "_" + dataModel + "_" + channel.ruleName,
					"channel": channelInfo.customizedDataIndex
				};
			}
		}
	}
};

WISE.getVariable.extendEncoder = function($customizedHandler){
	var variables = [];

	var $pueSelector = $customizedHandler.find(".pueSelector");//create by WISE.buildSelector.extendSourceSelectorChange

	if($pueSelector.length > 0){
		var $object = $pueSelector.val() == "-1" ? $pueSelector.children("[value!='-1']") : $pueSelector;
		for(var i = 0; i < $object.length; i++){
			variables.push("$Pue" + (parseInt($($object[i]).val(), 10) + 1));
		}
	}

	return variables;
};

WISE.getVariable.extendRegex = WISE.buildVariableEditor.extendRegex;

WISE.getVariable.extendDecoder = function($sourceSelector, $customizedHandler, regexResult){
	var foundFlag = true;

	if(regexResult[1]){
		if($sourceSelector.find("option[value='pue']").length > 0){
			$sourceSelector.val("pue").triggerHandler("change");
		}
		else{foundFlag = false;}

		var pueIndex = parseInt(regexResult[1], 10) - 1;
		var $pueSelector = $customizedHandler.find(".pueSelector");

		if(foundFlag && $pueSelector.find("option[value='" + pueIndex + "']").length > 0){
			$pueSelector.val(pueIndex).triggerHandler("change");
		}
		else{foundFlag = false;}

		if(foundFlag == false){
			$sourceSelector.find("option:first").attr("selected", true);
			$sourceSelector.triggerHandler("change");
		}
	}
}