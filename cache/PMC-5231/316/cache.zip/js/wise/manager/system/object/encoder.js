WISE.managers.systemManager.encodeXMLObject = function(xmlDoc){
	var xmlSNMP_TRAP = xmlDoc.createElement("SNMP_TRAP");

	for(var trapKey in this.pool.traps){
		var trap = this.pool.traps[trapKey];

		var xmlTRAP = xmlDoc.createElement("TRAP");
		xmlTRAP.setAttribute("idx", trap.index);
		//xmlTRAP.setAttribute("number", trap.number);
		xmlTRAP.setAttribute("nickname", trap.name);
		if(trap.description != ""){
			xmlTRAP.setAttribute("desc", trap.description);
		}

		if(trap.number == 6){
			xmlTRAP.setAttribute("id", trap.id);

			for(var messageKey in trap.messages){
				var message = trap.messages[messageKey];

				var xmlLIST = xmlDoc.createElement("LIST");
				xmlLIST.setAttribute("idx", message.index);
				xmlLIST.setAttribute("type", ["data", "message"][message.type]);
				xmlLIST.appendChild(xmlDoc.createTextNode(message.content));

				if(message.type == 0){
					xmlLIST.setAttribute("format", ["float", "string", "int"][message.format]);
				}
				else if(message.type == 1){
					xmlLIST.setAttribute("format", "string");
				}

				xmlTRAP.appendChild(xmlLIST);
			}
		}

		xmlSNMP_TRAP.appendChild(xmlTRAP);
	}

	if(xmlSNMP_TRAP.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlSNMP_TRAP);
				break;
			}
		}
	}
};

WISE.managers.systemManager.updateIndex = function(){
	var trapIndex = 0;
	for(var trapKey in this.pool.traps){
		this.pool.traps[trapKey].index = ++trapIndex;

		var messageIndex = 0;
		for(var messageKey in this.pool.traps[trapKey].messages){
			this.pool.traps[trapKey].messages[messageKey].index = ++messageIndex;
		}	
	}
};