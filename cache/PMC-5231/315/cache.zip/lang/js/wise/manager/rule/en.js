﻿$.extend(true, Lang, {
	"js/wise/manager/rule/base.js": {
		"copy": "Copy"
	},
	"js/wise/manager/rule/rule/object.js": {
		"ruleStatus": "Rule Status"
	},
	"js/wise/manager/rule/rule/encoder.js": {
		"someoneRulesAreError": "Error(s) occurs in rule(s), please correct the error(s).",
		"someoneRulesMissingConditionOrAction": "Missing condition or action in rule(s), please correct the error(s)."
	}
});
