WISE.managers.registerManager = (function(){
	return new function() {
		this.pool = {
			registers: []
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 70;
		this.retentiveRegister = {//keep date in FRAM
			minIndex: 50,//51
			maxIndex: 69//70
		};

		this.createRegister = function(settings){
			var register = $.extend(true, {
				"name": "",
				"description": "",
				"reference": [],

				"initialValue": 0
			}, settings);

			//var retKey = this.pool.key;
			//this.pool.registers[this.pool.key++] = register;
			return register;
		};

		this.removeRegister = function(index){
			delete this.pool.registers[index];
		};

		this.getRegister = function(index){
			if(typeof(this.pool.registers[index]) != "undefined"){
				return this.pool.registers[index];
			}
			else{
				return null;
			}
		};

		this.setRegister = function(index, register){
			this.pool.registers[index] = register;
		};

		this.getRegisters = function(){
			return this.pool.registers;
		};
	};
})();
