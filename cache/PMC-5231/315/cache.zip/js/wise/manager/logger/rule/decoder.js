WISE.managers.loggerManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "FTP"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.ftp);
			ruleObject.rule.value = {"0": 1, "1": 3, "2": 6, "3": 12, "4": 24}[$(xmlDoc).attr("op")];
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		}
	}

	if($(xmlDoc).attr("l_obj") == "LOG"){
		if(xmlDoc.tagName == "IF"){
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.logger);
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
	}

	return ruleObject;
};
