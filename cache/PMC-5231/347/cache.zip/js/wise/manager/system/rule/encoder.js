WISE.managers.systemManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "sdCard"){
			xmlDoc.setAttribute("l_obj", "MICROSD");
		}
		else if(ruleObject.ruleObjectKey == "signal"){
			xmlDoc.setAttribute("l_obj", "SMS");
			xmlDoc.setAttribute("l_ch", ruleObject.rule.unit == 0 ? "SIGNAL" : "SIGNAL_P");
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "reboot"){
			xmlDoc.setAttribute("l_obj", "REBOOT");
			xmlDoc.setAttribute("op", "1");
		}
		else if(ruleObject.ruleObjectKey == "reset"){
			xmlDoc.setAttribute("l_obj", "RESET_MODEM");
			xmlDoc.setAttribute("op", "1");
		}
		else if(ruleObject.ruleObjectKey == "delay"){
			xmlDoc.setAttribute("l_obj", "DELAY");
			xmlDoc.setAttribute("op", ruleObject.rule.frequency);
			xmlDoc.setAttribute("interval", ruleObject.rule.delay);
		}
	}
};