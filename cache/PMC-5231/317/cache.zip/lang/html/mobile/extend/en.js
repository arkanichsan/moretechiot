$.extend(true, Lang, {
	"pmGlobal": {
		"none": "No device is set.",
		"V": "V",
		"I": "I",
		"KW": "kW",
		"kvar": "kvar",
		"kVA": "kVA",
		"PF": "PF",
		"kWh": "kWh",
		"kvarh": "kvarh",
		"kVah": "kVAh",
		"kWh_day": "Daily Accu. Electricity",
		"kWh_month": "Monthly Accu. Electricity",
		"kWh_year": "Yearly Accu. Electricity",
		"co2_day": "Daily Carbon Emissions",
		"co2_month": "Monthly Carbon Emissions",
		"co2_year": "Yearly Carbon Emissions",
		"maxKw_hour": "Hourly Maximum Demand",
		"maxKw_day": "Daily Maximum Demand",
		"maxKw_month": "Monthly Maximum Demand",
		"kW_now": "Actual Demand",
		"kW_predict": "Forecast Demand",
		"aphase": "Phase A",
		"bphase": "Phase B",
		"cphase": "Phase C",
		"sum_average": "Total / Average",
		"loop": "Loop",
		"channel": "Channel",
		"sum": "Total",
		"average": "Average",
		"internalRegister": "Internal Register",
		"enterValue": "Please enter the value:",
		"submeter":"Submeter"
	},
	"pmmsg": {
		"loadingError": "An error occurred while loading data, please try again.",
		"getValueError": "An error occurred while loading data!",
		"noSup": "This option is not supported on the meter you've selected!",
		"noFile": "No file exists."
	},
	"html/mobile/home/main.htm": {
		"Home": "Home",
		"PMCName": "Nickname",
		"Firmware": "Firmware",
		"SDSpace": "microSD Space",
		"approxXDays": "Approx.$day Days",
		"Date": "Date",
		"Time": "Time",
		"ContractCapacity": "Contract Capacity",
		"pmNumber": "Total no. of PM",
		"ioNumber": "Total no. of I/O",
		"XB": "XW-Board",
		"pm": "Power Meter",
		"io": "I/O Module",
		"PMCInfo": "PMC Information",
		"ModuleList": "Power Meter List",
		"Module": "Module",
		"Interface": "Interface",
		"Address": "Address"
	},
	"html/mobile/home/menu.htm": {
		"Menu": "Menu",
		"Home": "Home",
		"meterInfo": "Power Meter Information",
		"ElectricityInfo": "Power Data Information",
		"ioinfo": "I/O Information",
		"eventRecord": "Event Log",
		"realTimeInfo": "Real-Time Information",
		"historyTimeInfo": "Historical Information",
		"custom": "Other Information",
		"groupInfo": "Group Information"
	},
	"html/mobile/home/default.htm": {
		//copy WISE default
		"internalRegister": "Internal Register",
		"no": "No.",
		"channel": "Ch.",
		"address": "Addr.",
		"counter": "Counter:",
		"enterValue": "Please enter the value:",
		"valueOfChannel": "The value of $channel:",
		"none": "None",
		"diCounterX": "DI Counter $channel",
		"internalRegisterX": "Internal Register $no",
		"popup": {
			"module": "Module:",
			"channel": "Channel:",
			"value": "Value:"
		}
	},
	"html/mobile/home/event.htm": {
		"eventRecord": "Event Log",
		"logNone": "No event record exists.",  
		"time": "Time",
		"type": "Type",
		"content": "Content",
		"result": "Result"
	},
	"html/mobile/home/pm_overview/pm_overview.htm": {
		"prinfo": "Power Data Information",
		"Filters": "Filters",
		"Apply": "Apply"
	},
	"html/mobile/home/pm_view/pm_view.htm": {
		"MeterParameterInformation": "Power Meter Attribute",
		"realTimeInfo": "Real-Time Information",
		"Nickname": "Nickname",
		"index": "Address",
		"tcpIndex": "No.",
		"ip": "IP",
		"portTcp": "Port",
		"netId": "NetID",
		"type": "Module Name",
		"pt": "PT Ratio",
		"ct": "CT Ratio",
		"portRtu": "COM Port",
		"ActualDemand": "Minutes Actual Demand",
		"ForecastDemand": "Minutes Forecast Demand",
		"ContractCapacity": "Contract Capacity",
		"doInfo": "DO Status of the Power Meter"
	},
	"html/mobile/home/pm_view/custom.htm": {
		"ptRatio": "PT Ratio",
		"ctRatio": "CT Ratio",
		"wiringMode": "Wiring Mode",
		"voltageMode": "Voltage Mode",
		"status": "Status",
		"setting": "Setting",
		"phaseSequence": "Phase Sequence",
		"refresh": "Refresh",
		"popup":{
			"thisFieldRangeIsBetweenAToB": "This field only accepts values between $minimum to $maximum.",
			"thisFieldRangeIsGreaterEqualX": "This field only accepts values greater than or equal to $minimum.",
			"thisFieldRangeIsLessEqualX": "This field only accepts values less than or equal to $maximum.",
			"thisFieldOnlyAllowInputInteger": "This field only accepts integers.",
			"thisFieldOnlyAllowInputIntegerOrFloatingPoint": "This field only accepts integers or floating point numbers."
		}
	},
	"html/mobile/home/pm_view/hy_chart.htm": {
		"Inquiry": "Inquiry",
		"dateRange": "Recorded Data File Range",
		"historyTimeInfo": "Historical Information",
		"item": "Item",
		"date": "Date",
		"time": "Time"
	},
	"html/mobile/home/group_view/group_view.htm":{
		"MainGroup": "Group",
		"CiGroup": "Subgroup",
		"GroupInformation": "Group Attribute",
		"realTimeInfo": "Real-Time Information"
	}
});