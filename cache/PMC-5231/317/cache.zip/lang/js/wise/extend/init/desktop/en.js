$.extend(true, Lang, {
	"js/wise/extend/init/desktop.js": {
		"pulseOutput": "Pulse Output",
		"powerMeter": "Power Meter",
		"channel": "Channel",
		"info": "Info.",
		"ch": "Ch.",
		"item": "Item",
		"no": "No.",
		"pue": "PUE",
		"all": "All"
	}
});