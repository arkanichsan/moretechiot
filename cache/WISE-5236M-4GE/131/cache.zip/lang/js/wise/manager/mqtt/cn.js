$.extend(true, Lang, {
	"js/wise/manager/mqtt/rule/object.js": {
		"brokerConnectionStatus": "Borker联机状态",
		"offline": "断线",
		"online": "联机",
		"mqttBrokerConnectionStatus": "MQTT Borker联机状态",
		"local": "本机",
		"remote": "远程",
		"internalRegister": "内部缓存器",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息",
		"brokerFunctionStatus": "Broker功能状态",
		"mqttBrokerFunctionStatus": "MQTT Broker($broker)功能状态",
		"publishMessage": "Publish讯息",
		"publish": "发布",
		"mqttPublishMessage": "MQTT Publish讯息",
		"resetTopic": "重置Topic",
		"reset": "重置"
	}
});