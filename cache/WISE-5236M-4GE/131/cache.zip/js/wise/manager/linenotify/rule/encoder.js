WISE.managers.lineNotifyManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "message"){
			xmlDoc.setAttribute("l_obj", "LINE_NOTIFY");
			xmlDoc.setAttribute("l_idx", this.pool.messages[ruleObject.rule.messageKey].index);
			xmlDoc.setAttribute("op", /*{0: "0", 1: "1"}[ruleObject.rule.value * 10 + ruleObject.rule.frequency]*/ "1");

			if(ruleObject.rule.delay > 0){
				xmlDoc.setAttribute("sleep", ruleObject.rule.delay);
			}
		}
	}
};
