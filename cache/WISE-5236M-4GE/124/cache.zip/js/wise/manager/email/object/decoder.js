WISE.managers.emailManager.decodeXMLObject = function(xmlDoc){
	var $xmlEMAIL = $(xmlDoc).find("WISE > NOTE > EMAIL");
	if($xmlEMAIL.length > 0){
		var $xmlE = $xmlEMAIL.find("> E");
		var maxKey = 0;
		for(var i = 0; i < $xmlE.length; i++){
			var key = parseInt($($xmlE[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var email = this.createEmail({
				"name": $($xmlE[i]).attr("nickname"),
				"description": $($xmlE[i]).attr("desc") || "",
				"smtpServer": {
					"url": $($xmlE[i]).attr("server"),
					"port": parseInt($($xmlE[i]).attr("port"), 10)
				},
				"authInfo": (function(id, password, passwordLength, securityMode){
					var retObject = {
						"securityMode": isNaN(parseInt(securityMode, 10)) ? undefined : parseInt(securityMode, 10)
					};

					if(retObject.securityMode != 3){
						retObject.id = id;
						retObject.password = {
							"plain": padding("", passwordLength, "*"),
							"encoded": password,
							"length": parseInt(passwordLength, 10)
						};
					}

					return retObject;
				})($($xmlE[i]).attr("id"), $($xmlE[i]).attr("password"), $($xmlE[i]).attr("password_len"), $($xmlE[i]).attr("security")),
				"senderInfo": {
					"name": $($xmlE[i]).attr("sender"),
					"address": $($xmlE[i]).attr("sender_email")
				},
				"subject": $($xmlE[i]).find("> SUBJECT:first").text(),
				"content": $($xmlE[i]).find("> CONTENT:first").text()
			});

			var receiverAddressArray = $($xmlE[i]).find("> RECIPIENT:first").text().split(",");
			for(var j = 0; j < receiverAddressArray.length; j++){
				email.receiverInfo.address.push(receiverAddressArray[j]);
			}

			this.setEmail(key, email);
		}

		this.pool.key = ++maxKey;
	}
};