WISE.managers.scheduleManager = (function(){
	return new function() {
		this.pool = {
			schedules: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 12;
		this.maxTimeAmount = 12;

		this.createSchedule = function(settings){
			var date = new Date();
			var schedule = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"initialStatus": 0,//0 is disable, 1 is enable
				"mode": 1,//0 is calendar, 1 is repeat
				"date":{
					/*for calendar*/
					"startDate":{
						"year": date.getFullYear(),
						"month": date.getMonth() + 1
					},
					"duration": 1,
					"skipDateArray": [0],

					/*for repeat*/
					"repeatDayArray": [false, false, false, false, false, false, false],//index 0 is Sunday, 6 is Saturday
					"exceptionDateArray": []//[[Mon, Day], ...]
				},
				"timeArray": [[0, 0, 0, 0, 0, 0]]//[[startHour, startMin, startSec, endHour, endMin, endSec], ...]
			}, settings);

			return schedule;
		};

		this.addSchedule = function(schedule){
			var retKey = this.pool.key;
			this.pool.schedules[this.pool.key++] = schedule;
			return retKey;
		};

		this.removeSchedule = function(key){
			delete this.pool.schedules[key];
		};

		this.getSchedule = function(key){
			if(typeof(this.pool.schedules[key]) != "undefined"){
				return this.pool.schedules[key];
			}
			else{
				return null;
			}
		};

		this.setSchedule = function(key, schedule){
			this.pool.schedules[key] = schedule;
		};

		this.getSchedules = function(){
			return this.pool.schedules;
		};
	};
})();
