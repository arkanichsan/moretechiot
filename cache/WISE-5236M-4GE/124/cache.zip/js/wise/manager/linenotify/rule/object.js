WISE.managers.lineNotifyManager.pool.actions = {
	"lineMessage": {
		"name": "LINE Notify",
		"fileName": "alinenotify",
		"rule":{
			"messageKey": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.messageKey == null){
				return false;
			}
			
			var lineNotifyManager = WISE.managers.lineNotifyManager;

			if(typeof(lineNotifyManager.pool.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var lineNotifyManager = WISE.managers.lineNotifyManager;
			var message = lineNotifyManager.pool.messages[this.rule.messageKey];
			var valueString = ["<#Lang['?'].send>"];

			return this.name + "(" + message.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.messageKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.lineNotifyManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['lineMessage']['key'] = [];

	for(var key in this.pool.messages){
		this.pool.actions['lineMessage']['key'].push(parseInt(key, 10));
	}
};