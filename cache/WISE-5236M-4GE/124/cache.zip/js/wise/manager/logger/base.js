WISE.managers.loggerManager = (function(){
	return new function() {
		this.pool = {
			"dataLogger":{
				"module":{
					"enable": false,
					"fileName": "",
					"sampleRate": 60,//0 means no periodically sample, unit in second
					"timeStamp": "yyyy/MM/dd,HH:mm:ss",
					"filePeriod": 60,//unit in minute 
					"csvHeader": 0,
					"useBOM": false,

					// Send back setting
					"ftpServers": [],//key
					"emailKey": -1,//-1: no attachment by email
					"cloud": false
				},
				"customized":{
					"logs": {},
					"key": 0
				},
				"mqtt":{
					"enable": false,
					"timeStamp": "yyyy/MM/dd,HH:mm:ss",
					"filePeriod": 60,//unit in minute 
					"useBOM": false,
					"ftpServers": [],//key
					"emailKey": -1//-1: no attachment by email
				}
			},
			"eventLogger":{
				"uploadFrequency": 0,//0: Disable, 1: Once a day, 7: Once a week, 30: Once a month
				"uploadTiming": {
					"day": 1,//date(1 ~ 31) or day(1 ~ 7)
					"hour": 0,
					"minute": 0
				},
				"ftpServers": []//key
			},
			"ftp":{
				"servers": {},
				"key": 0
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxCustomizedLogAmount = 12;
		this.maxFTPServerAmount = 12;

		//customize log
		this.createLog = function(settings){
			var date = new Date();
			var log = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"fileName": "",
				"sampleRate": 60,//0 means no periodically sample, unit in second
				"timeStamp": "yyyy/MM/dd HH:mm:ss",
				"filePeriod": 60,//unit in minute 
				"csvHeader": 0,
				"useBOM": false,
				"ftpServers": [],//key
				"emailKey": -1,//-1: no attachment by email
				"format": ""
			}, settings);

			return log;
		};

		this.addLog = function(log){
			var retKey = this.pool.dataLogger.customized.key;
			this.pool.dataLogger.customized.logs[this.pool.dataLogger.customized.key++] = log;
			return retKey;
		};

		this.removeLog = function(key){
			delete this.pool.dataLogger.customized.logs[key];
		};

		this.getLog = function(key){
			if(typeof(this.pool.dataLogger.customized.logs[key]) != "undefined"){
				return this.pool.dataLogger.customized.logs[key];
			}
			else{
				return null;
			}
		};

		this.setLog = function(key, log){
			this.pool.dataLogger.customized.logs[key] = log;
		};

		this.getLogs = function(){
			return this.pool.dataLogger.customized.logs;
		};

		//ftp server
		this.createServer = function(settings){
			var server = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"address": "192.168.255.1",
				"port": 21,
				"account": "anonymous",
				"password": {
					"plain": "",
					"encoded": "",
					"length": 0
				},
				"path": ""
			}, settings);

			return server;
		};

		this.addServer = function(server){
			var retKey = this.pool.ftp.key;
			this.pool.ftp.servers[this.pool.ftp.key++] = server;
			return retKey;
		};

		this.removeServer = function(key){
			delete this.pool.ftp.servers[key];
		};

		this.getServer = function(key){
			if(typeof(this.pool.ftp.servers[key]) != "undefined"){
				return this.pool.ftp.servers[key];
			}
			else{
				return null;
			}
		};

		this.setServer = function(key, server){
			this.pool.ftp.servers[key] = server;
		};

		this.getServers = function(){
			return this.pool.ftp.servers;
		};
	};
})();
