function init(){
	$("#loadingLoader, #loginContainer, #loginRunTimeDownContainer").remove();
	$("#container").show();
	$("#foot").html(copyRight);

	//ajax global setup
	$.ajaxSetup({
		cache: true,
		beforeSend: function(jqXHR, settings){
			if(typeof(debugMode) != "undefined" && debugMode == true){/*check debug mode command*/
				if(/^<\?xml /.test(settings.data) == true){
					settings.data = "!" + (typeof(settings.data) != "undefined" ? settings.data : "");
				}
			}
		},
		success: function(data, textStatus, jqXHR){
			if(this.dataType == "xml"){
				serverNoResponse = false;

				if($(data).children().attr("reply") == "kick" && $(data).children().attr("key") == WISE.getUser().key){
					if(typeof(aliveChecker) != "undefined"){//avoid receive kick when first to load rule file failed, because aliveChecker is not ready to go
						aliveChecker.stopAliveTimer();
						aliveChecker.stopIdleTimer();

						showIdleTooLongMessage();
					}

					this.error(jqXHR, "keyerror", "Key Error");
					return;
				}
			}

			if(typeof(this.done) == "function"){
				this.done(data, textStatus, jqXHR);
			}
		},
		done: function(){},
		error: function(jqXHR, textStatus, errorThrown){
			if(jqXHR.status == 500 || (jqXHR.status == 0 && (textStatus == "timeout" || textStatus == "error"))){
				if(typeof(serverNoResponse) == "undefined" || serverNoResponse == false){
					popupErrorWindow(LangLogin.runtimeServerNoResponse[WISE.language]);
				}

				serverNoResponse = true;
				//return;
			}
			else if(jqXHR.status == 404){
				popupErrorWindow(LangLogin.fileNotFound[WISE.language]);
			}

			if(typeof(this.fail) == "function"){
				this.fail(jqXHR, textStatus, errorThrown);
			}
		},
		fail: function(){}
	});

	$("#menuButton").bind("click", function(){
		if($("#menuWrapper").hasClass("active")){
			hideMenu();
		}
		else{
			showMenu();
		}
	});

	$("#logoutButton").bind("click", function(){
		popupConfirmWindow("<#Lang['?'].popup.areYouSureYouWantToLogout>", function(result){
			if(result == false){return;}

			WISE.bindFunctionExecute("beforeLogout");
			setCookie("password", "", -1);

			$("#loader").show();
			var xmlDoc = $.parseXML("<LOGOUT/>");
			xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

			$.ajax({ 
				url: "./dll/wise.dll",
				type: "POST",
				data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
				contentType: "text/xml",
				processData: false,
				cache: false,
				dataType: "xml",
				complete: function(xmlDoc){
					$(window).unbind("unload");						
					location.reload();
				}
			});
		});
	});

	$("#contentCover").bind("click", function(){
		hideMenu();
	});

	$("#menuPadding").css("height", $("#footContainer").outerHeight() + "px");

/*
	$("*[location]").livequery(function() { 
		$(this).bind("click", function(){
			redirectTo($(this).attr("location"));
		});
	});
*/
	$(window).bind("resize.updateViewport", function(){
		$("#contentWrapper, #menuWrapper").css("minHeight", $(window).height() + "px");
		updateViewport();
	}).triggerHandler("resize");

	/*browser compatibility process*/
	if($.browser.webkit){//since chrome version 39, chinese line-height not same with english.
		$("body").css("lineHeight", "1.15");
	}

	aliveChecker = WISE.createAliveChecker({
		"process": function($xmlALIVE){},
		"timeout": function(){
			showIdleTooLongMessage();
		}
	});

	//inset back and forward hash to history
	location.assign("#back");
	setTimeout(function(){
		location.assign("#");
		setTimeout(function(){
			location.assign("#forward");
			history.back();

			setTimeout(function(){
				//bind hash change event
				$(window).bind("hashchange", function(){
					var hash = location.hash.replace(/^#/, "");

					if($("#menuWrapper").hasClass("active")){//when open menu and click <back or forward>
						if(hash == "forward"){
							history.back();
						}
						else if(hash == "back"){
							history.forward();
							hideMenu();
						}
					}
					else{
						if(hash == "forward"){
							history.back();
	/*
							if(historyPool.index < historyPool.array.length - 1){
								history.back();
								historyPool.index++;
								historyChange();
							}
							else{
								history.back();
							}
	*/
						}
						else if(hash == "back"){
							history.forward();

							$('html, body').scrollTop(0);//fix for firefox

							setTimeout(function(){
								showMenu();
							}, 0);

	/*
							if(historyPool.index > 0){
								history.forward();
								//historyPool.index--;
								//historyChange();
							}
							else{
								history.back();
							}
	*/
						}
					}
				});

				loadMenu();
				//redirectTo("#home/main");
			}, 1);
		}, 1);
	}, 1);
}

function showIdleTooLongMessage(){
	popupAlarmWindow("<#Lang['?'].popup.idleTooLong>", function(){
		location.reload();
	});
}