WISE.managers.loggerManager.pool.actions = {
	"log": {
		"name": "<#Lang['?'].dataLogger>",
		"fileName": "alogger",
		"rule":{
			"logType": null,//module or customized
			"logKey": null,//for customized log
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			var loggerManager = WISE.managers.loggerManager;

			if(this.rule.logType == "module"){
				if(loggerManager.pool.dataLogger.module.enable == false){
					return false;
				}
			}
			else{
				var log = loggerManager.pool.dataLogger.customized.logs[this.rule.logKey];

				if(typeof(log) == "undefined"){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var loggerManager = WISE.managers.loggerManager;

			if(this.rule.logType == "module"){
				return "<#Lang['?'].moduleDataLogger>" + " " + ruleColor("<#Lang['?'].oneTimeLog>", 2);
			}
			else{
				var log = loggerManager.pool.dataLogger.customized.logs[this.rule.logKey];

				return "<#Lang['?'].customizedDataLogger>" + "(" + log.name + ") " + ruleColor("<#Lang['?'].oneTimeLog>", 2);
			}
		},

		//init and key will not be copied
		"init": function(){
			if(this.key[0] === true){
				this.rule.logType = "module";
			}
			else{
				this.rule.logType = "customized";
				this.rule.logKey = this.key[0];
			}
		},
		"key": []
	}
};

WISE.managers.loggerManager.updateRuleObject = function(){
	//clear key
	//this.pool.conditions['ftp']['key'] = [];
	this.pool.actions['log']['key'] = [];

	//if(this.pool.ftp.enable == true){
	//	this.pool.conditions['ftp']['key'].push(true);
	//}

	if(this.pool.dataLogger.module.enable == true){
		this.pool.actions['log']['key'].push(true);
	}

	for(var key in this.pool.dataLogger.customized.logs){
		this.pool.actions['log']['key'].push(parseInt(key, 10));
	}
};
