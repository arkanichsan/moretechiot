WISE.managers.iotstarManager.encodeXMLObject = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;

	var xmlIOTSTAR = xmlDoc.createElement("IOTSTAR");

	if(this.pool.sendback.realtime.enable == true){
		var xmlREALTIME = xmlDoc.createElement("REALTIME");
		var columnName = "", columnData = "";
		for(var i = 0; i < this.pool.sendback.realtime.columns.length; i++){
			var column = this.pool.sendback.realtime.columns[i];
			var xmlCOL = xmlDoc.createElement("COL");
			xmlCOL.setAttribute("idx", i + 1);

			if(column.channelType == "IR"){
				if(column.moduleKey == null){
					xmlCOL.setAttribute("b_obj", "IR");
					xmlCOL.setAttribute("b_idx", column.registerIndex + 1);

					xmlCOL.setAttribute("uid", "ir");
					xmlCOL.setAttribute("channel", "IR" + (column.registerIndex + 1));
				}
				else{
					var moduleInfo = processModuleInfo(xmlCOL, "b", column.moduleKey);
					var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", column.registerIndex);
					xmlCOL.setAttribute("b_ch", channelAddressInfo[0]);
					xmlCOL.setAttribute("b_chn", channelAddressInfo[1]);

					xmlCOL.setAttribute("uid", moduleInfo.module.uid);
					xmlCOL.setAttribute("channel", "IR" + (column.registerIndex + 1));
				}

				columnData += WISE.getVariable("register", column.moduleKey, column.registerIndex) + ",";
			}
			else{
				var moduleInfo = processModuleInfo(xmlCOL, "b", column.moduleKey);
				var moduleManager = WISE.managers.moduleManager;
				var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
				var module = moduleInfo.module;

				if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
					var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, column.channelType, column.channel);
					xmlCOL.setAttribute("b_ch", channelAddressInfo[0]);
					xmlCOL.setAttribute("b_chn", channelAddressInfo[1]);

					xmlCOL.setAttribute("uid", module.uid);
					xmlCOL.setAttribute("channel", column.channelType + column.channel);

					columnData += WISE.getVariable(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, column.channelType, column.channel) + ",";
				}
				else{
					if(typeof(module.extendedModule) != "undefined"){
						xmlCOL.setAttribute("uid", module.uid);
						this.processExtendedModuleRealTimeTag(column, xmlCOL);

						columnData += this.encodeXMLObject.processExtendedModuleRule(column, xmlCOL) + ",";
					}
					else{
						if(column.channelType == "DIC"){
							xmlCOL.setAttribute("b_ch", "DI");
							xmlCOL.setAttribute("b_cnt", "1");
						}
						else{
							xmlCOL.setAttribute("b_ch", column.channelType);
						}

						xmlCOL.setAttribute("b_chn", column.channel);

						xmlCOL.setAttribute("uid", module.uid);
						xmlCOL.setAttribute("channel", column.channelType + column.channel);

						columnData += WISE.getVariable(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, column.channelType, column.channel) + ",";
					}
				}
			}

			xmlREALTIME.appendChild(xmlCOL);

			columnName += column.name + ",";
		}

		xmlIOTSTAR.appendChild(xmlREALTIME);

		var xmlCOLNAME = xmlDoc.createElement("COLNAME");
		xmlCOLNAME.appendChild(xmlDoc.createTextNode(columnName.substring(0, columnName.length - 1)));
		xmlREALTIME.appendChild(xmlCOLNAME);

		var xmlCOLDATA = xmlDoc.createElement("COLDATA");
		xmlCOLDATA.appendChild(xmlDoc.createTextNode(columnData.substring(0, columnData.length - 1)));
		xmlREALTIME.appendChild(xmlCOLDATA);
	}

	if(xmlIOTSTAR.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlIOTSTAR);
				break;
			}
		}
	}

	// Video
	var xmlLINE_BOT = xmlDoc.getElementsByTagName("LINE_BOT")[0] || xmlDoc.createElement("LINE_BOT");

	// IP Camera
	var xmlCAMERA = xmlLINE_BOT.getElementsByTagName("CAMERA")[0] || xmlDoc.createElement("CAMERA");

	var counter = 0;
	var moduleManager = WISE.managers.moduleManager;
	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			if(typeof(modules[moduleIndex].iotstar) != "undefined"){
				if(modules[moduleIndex].iotstar.enable == true){
					var xmlC = null;

					// Search
					for(var i = 0, xmlCs = xmlCAMERA.getElementsByTagName("C"); i < xmlCs.length; i++){
						var cameraIndex = parseInt(xmlCs[i].getAttribute("camera_idx"), 10);
						if(cameraIndex == moduleIndex + 1){
							xmlC = xmlCs[i];
							break;
						}
					}

					xmlC = xmlC || xmlDoc.createElement("C");
					xmlC.setAttribute("camera_idx", moduleIndex + 1);
					xmlC.setAttribute("idx", ++counter);
					xmlC.setAttribute("mode", xmlC.getAttribute("mode") == "0" ? "0" : "1");

					var xmlMSG = xmlC.getElementsByTagName("MSG")[0] || xmlDoc.createElement("MSG");

					if(xmlMSG.childNodes[0] !== undefined){
						xmlMSG.childNodes[0].nodeValue = "";
					}

					xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].iotstar.content));
					xmlC.appendChild(xmlMSG);

					xmlCAMERA.appendChild(xmlC);
				}
			}
		}
	}

	if(xmlCAMERA.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCAMERA);
	}

    // CGI Server
    var xmlCGI_SERVER = xmlLINE_BOT.getElementsByTagName("CGI_SERVER")[0] || xmlDoc.createElement("CGI_SERVER");

    var cgiManager = WISE.managers.cgiManager;
    for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
        if(typeof(servers[sourceIndex]) == "undefined"){continue;}

		if(typeof(servers[sourceIndex].iotstar) != "undefined"){
	        if(servers[sourceIndex].iotstar.enable == true){
				var xmlC = null;

				// Search
				for(var i = 0, xmlCs = xmlCGI_SERVER.getElementsByTagName("C"); i < xmlCs.length; i++){
					var serverIndex = parseInt(xmlCs[i].getAttribute("idx"), 10);
					if(serverIndex == servers[sourceIndex].index){
						xmlC = xmlCs[i];
						break;
					}
				}

				xmlC = xmlC || xmlDoc.createElement("C");
	            xmlC.setAttribute("idx", servers[sourceIndex].index);
	            xmlC.setAttribute("mode", xmlC.getAttribute("mode") == "0" ? "0" : "1");

				var xmlMSG = xmlC.getElementsByTagName("MSG")[0] || xmlDoc.createElement("MSG");

				if(xmlMSG.childNodes[0] !== undefined){
					xmlMSG.childNodes[0].nodeValue = "";
				}

				xmlMSG.appendChild(xmlDoc.createTextNode(servers[sourceIndex].iotstar.content));
	       		xmlC.appendChild(xmlMSG);

	            xmlCGI_SERVER.appendChild(xmlC);
	        }
		}
    }

	if(xmlCGI_SERVER.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCGI_SERVER);
	}

    // FTP Server
    var xmlSENDBOX = null;
    var systemManager = WISE.managers.systemManager;
	var server = systemManager.pool.ftpServer;

	if(typeof(server.iotstar) != "undefined"){
	    if(server.iotstar.enable == true){
			xmlSENDBOX = xmlLINE_BOT.getElementsByTagName("SENDBOX")[0] || xmlDoc.createElement("SENDBOX");
			xmlSENDBOX.setAttribute("mode", xmlSENDBOX.getAttribute("mode") == "0" ? "0" : "1");

			if(xmlSENDBOX.childNodes[0] !== undefined){
				xmlSENDBOX.childNodes[0].nodeValue = "";
			}

			xmlSENDBOX.appendChild(xmlDoc.createTextNode(server.iotstar.content));

			xmlLINE_BOT.appendChild(xmlSENDBOX);
	    }
	}

	// 
	if(xmlLINE_BOT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_BOT);
				break;
			}
		}
	}
};
