$.extend(true, Lang, {
	"js/wise/manager/iotstar/rule/encoder.js": {
		"sendBackChannelIsEmpty": "云端实时数据回送的通道数量不能为0个。"
	}
});