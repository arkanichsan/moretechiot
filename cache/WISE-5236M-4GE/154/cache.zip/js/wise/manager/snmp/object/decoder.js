WISE.managers.snmpManager.decodeXMLObject = function(xmlDoc){
	var $xmlSNMP_TRAP = $(xmlDoc).find("WISE > NOTE > SNMP_TRAP");
	if($xmlSNMP_TRAP.length > 0){
		var $xmlTRAP = $xmlSNMP_TRAP.find("> TRAP");
		var maxTrapKey = 0;
		for(var i = 0; i < $xmlTRAP.length; i++){
			var trapKey = parseInt($($xmlTRAP[i]).attr("idx"), 10) - 1;
			if(trapKey > maxTrapKey){maxTrapKey = trapKey};

			var trap = this.createTrap({
				"name": $($xmlTRAP[i]).attr("nickname"),
				"description": $($xmlTRAP[i]).attr("desc") || "",

				"number": /*$($xmlTRAP[i]).attr("number")*/ 6,
				"id": parseInt($($xmlTRAP[i]).attr("id"), 10)
			});

			this.setTrap(trapKey, trap);

			var $xmlLIST = $($xmlTRAP[i]).find("> LIST");
			var maxMessageKey = 0;
			for(var j = 0; j < $xmlLIST.length; j++){
				var messageKey = parseInt($($xmlLIST[j]).attr("idx"), 10) - 1;
				if(messageKey > maxMessageKey){maxMessageKey = messageKey};

				var message = this.createMessage({
					"type": {"data": 0, "message": 1}[$($xmlLIST[j]).attr("type")],
					"content": $($xmlLIST[j]).text(),
					"format": {"float": 0, "string": 1, "int": 2}[$($xmlLIST[j]).attr("format")]
				});

				this.setMessage(trap, messageKey, message);
			}

			trap.key = ++maxMessageKey;
		}

		this.pool.key = ++maxTrapKey;
	}
};
