WISE.managers.timerManager.encodeXMLObject = function(xmlDoc){
	var xmlTIMER = xmlDoc.createElement("TIMER");

	for(var key in this.pool.timers){
		var timer = this.pool.timers[key];
		var xmlT = xmlDoc.createElement("T");

		xmlT.setAttribute("idx", timer.index);
		xmlT.setAttribute("value", timer.period < 0 ? "IR" + (timer.period * -1) : timer.period);
		xmlT.setAttribute("status", timer.initialStatus);
		xmlT.setAttribute("nickname", timer.name);

		if(timer.description != ""){
			xmlT.setAttribute("desc", timer.description);
		}

		xmlTIMER.appendChild(xmlT);
	}

	if(xmlTIMER.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlTIMER);
				break;
			}
		}
	}
};

WISE.managers.timerManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.timers){
		this.pool.timers[key].index = ++index;
	}
};