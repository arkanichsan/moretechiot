$.extend(true, Lang, {
	"js/wise/manager/system/rule/object.js": {
		"sdCardStatus": "SD卡状态",
		"abnormal": "异常",
		"signalStrength": "移动网络信号强度",
		"rebootSystem": "重新启动系统",
		"resetModem": "重置调制解调器",
		"delayProcess": "延迟",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息"
	}
});