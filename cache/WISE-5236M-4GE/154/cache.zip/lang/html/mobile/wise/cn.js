$.extend(true, Lang, {
	"html/mobile/frame.htm": {
		"goToDesktopVersion": "前往完整版网页",
		"dialog": "信息",
		"prompt": "提示"
	},
	"html/mobile/home/menu.htm": {
		"menu": "主选单",
		"home": "首页",
		"internalRegister": "内部缓存器",
		"customizeStatus": "实时信息显示"
	},
	"html/mobile/home/main.htm": {
		"systemInformation": "系统信息",
		"nickname": "名称",
		"date": "日期",
		"time": "时间",
		"microSDSpace": "microSD卡剩余空间",
		"approxXDays": "约剩$day天",
		"noSDCard": "未侦测到microSD卡。",
		"none": "无",
		"totalNumberOfIOModule": "I/O模块数量",
		"moduleList": "模块列表",
		"ipAndPort": "IP与端口",
		"address": "地址",
		"scanRate": "更新速率",
		"pollingTimeout": "轮询超时时间"
	}
});