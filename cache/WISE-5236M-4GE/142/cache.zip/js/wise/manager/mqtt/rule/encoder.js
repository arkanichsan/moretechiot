WISE.managers.mqttManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "broker"){
			xmlDoc.setAttribute("l_obj", "MQTT");
			xmlDoc.setAttribute("l_idx", this.pool.brokers[ruleObject.rule.brokerKey].index);
			xmlDoc.setAttribute("l_ch", "BROKER");
			xmlDoc.setAttribute("op", "0");
			xmlDoc.setAttribute("r_obj", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "topic"){
			xmlDoc.setAttribute("l_obj", "MQTT");
			xmlDoc.setAttribute("l_idx", this.pool.brokers[ruleObject.rule.brokerKey].index);
			xmlDoc.setAttribute("l_ch", "SUB");
			xmlDoc.setAttribute("l_chn", this.pool.brokers[ruleObject.rule.brokerKey].subscribe.topics[ruleObject.rule.topicKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);
			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "broker"){
			xmlDoc.setAttribute("l_obj", "MQTT");
			xmlDoc.setAttribute("l_idx", this.pool.brokers[ruleObject.rule.brokerKey].index);
			xmlDoc.setAttribute("l_ch", "BROKER");
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "message"){
			xmlDoc.setAttribute("l_obj", "MQTT");
			xmlDoc.setAttribute("l_idx", this.pool.brokers[ruleObject.rule.brokerKey].index);
			xmlDoc.setAttribute("l_ch", "PUB");
			xmlDoc.setAttribute("l_chn", this.pool.brokers[ruleObject.rule.brokerKey].publish.messages[ruleObject.rule.messageKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "topic"){
			xmlDoc.setAttribute("l_obj", "MQTT");
			xmlDoc.setAttribute("l_idx", this.pool.brokers[ruleObject.rule.brokerKey].index);
			xmlDoc.setAttribute("l_ch", "SUB");
			xmlDoc.setAttribute("l_chn", this.pool.brokers[ruleObject.rule.brokerKey].subscribe.topics[ruleObject.rule.topicKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
};
