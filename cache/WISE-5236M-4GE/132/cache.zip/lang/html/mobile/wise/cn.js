$.extend(true, Lang, {
	"html/mobile/frame.htm": {
		"goToDesktopVersion": "前往完整版网页",
		"dialog": "信息",
		"prompt": "提示"
	},
	"html/mobile/home/menu.htm": {
		"menu": "主选单",
		"home": "首页",
		"internalRegister": "内部缓存器",
		"customizeStatus": "实时信息显示"
	},
	"html/mobile/home/main.htm": {
		"systemInformation": "系统信息",
		"nickname": "名称",
		"date": "日期",
		"time": "时间",
		"microSDSpace": "microSD卡剩余空间",
		"approxXDays": "约剩$day天",
		"noSDCard": "未侦测到microSD卡。",
		"none": "无",
		"totalNumberOfIOModule": "I/O模块数量",
		"moduleList": "模块列表",
		"ipAndPort": "IP与端口",
		"address": "地址",
		"scanRate": "更新速率",
		"pollingTimeout": "轮询超时时间"
	},
	"html/mobile/home/status/default.htm": {
		"internalRegister": "内部缓存器",
		"no": "编号",
		"channel": "通道",
		"address": "地址",
		"counter": "计数器:",
		"enterValue": "请输入数值：",
		"valueOfChannel": "$channel数值：",
		"none": "无",
		"diCounterX": "DI计数器$channel",
		"doCounterX": "DO计数器$channel",
		"internalRegisterX": "内部缓存器$channel",
		"popup": {
			"module": "模块：",
			"channel": "通道：",
			"value": "数值："
		}
	},
	"html/desktop/home/status/ir.htm": {
		"none": "无",
		"ch": "通道",
		"outputChannel": "输出通道",
		"availableCommand": "可用命令",
		"transmit": "传送",
		"popup": {
			"outputChannelIsEmpty": "没有选择输出通道，请至少勾选一个输出通道后再按传送。"
		}
	}
});