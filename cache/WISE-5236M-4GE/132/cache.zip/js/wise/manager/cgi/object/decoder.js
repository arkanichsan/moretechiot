WISE.managers.cgiManager.decodeXMLObject = function(xmlDoc){
	var processFTPAttribute = function(attribute){
		var ftpServers = attribute != "" ? attribute.split(",") : [];
		for(var i = 0; i < ftpServers.length; i++){
			ftpServers[i] -= 1;
		}
		return ftpServers;
	};

	var $xmlCGI = $(xmlDoc).find("WISE > NOTE > CGI");
	if($xmlCGI.length > 0){
		// CGI Server
		var $xmlS = $xmlCGI.find("> S");
		if($xmlS.length > 0){
			var maxServerKey = 0;
			for(var i = 0; i < $xmlS.length; i++){
				var serverKey = parseInt($($xmlS[i]).attr("idx"), 10) - 1;
				if(serverKey > maxServerKey){maxServerKey = serverKey};

				var server = this.createServer({
					"name": $($xmlS[i]).attr("nickname"),
					"description": $($xmlS[i]).attr("desc") || "",

					"address": $($xmlS[i]).attr("server"),
					"port": parseInt($($xmlS[i]).attr("port"), 10),
					"retryTimes": parseInt($($xmlS[i]).attr("retry_times"), 10),
					"ftpServers": processFTPAttribute($($xmlS[i]).attr("ftp") || ""),
					"authInfo": (function(id, password, passwordLength, authType){
						var retObject = {
							"authType": parseInt(authType, 10)
						};

						if(retObject.authType != 0){
							retObject.id = id;
							retObject.password = {
								"plain": padding("", passwordLength, "*"),
								"encoded": password,
								"length": parseInt(passwordLength, 10)
							};
						}

						return retObject;
					})($($xmlS[i]).attr("id"), $($xmlS[i]).attr("password"), $($xmlS[i]).attr("password_len"), $($xmlS[i]).attr("auth"))
				});

				this.setServer(serverKey, server);

				var $xmlC = $($xmlS[i]).find("> C");
				if($xmlC.length > 0){
					var maxCommandKey = 0;
					for(var j = 0; j < $xmlC.length; j++){
						var commandKey = parseInt($($xmlC[j]).attr("idx"), 10) - 1;
						if(commandKey > maxCommandKey){maxCommandKey = commandKey};

						var command = this.createCommand({
							"name": $($xmlC[j]).attr("nickname"),
							"description": $($xmlC[j]).attr("desc") || "",

							"method": $($xmlC[j]).attr("method"),
							"command": $($xmlC[j]).attr("cmd"),
							"body": $($xmlC[j]).attr("body"),
							"saveResponseAsFile": (function(){
								if($($xmlC[j]).attr("filename")){
									return {
										"enable": true,
										"fileName": $($xmlC[j]).attr("filename"),
										"emailKey": $($xmlC[j]).attr("email") ? parseInt($($xmlC[j]).attr("email"), 10) - 1 : null
									};
								}
							})()
						});

						this.setCommand(server, commandKey, command);
					}

					server.key = ++maxCommandKey;
				}
			}

			this.pool.send.key = ++maxServerKey;
		}

		// CGI Query
		var $xmlQ = $xmlCGI.find("> Q");
		var maxVariableKey = 0, maxClientKey = 0;
		if($xmlQ.length > 0){
			var variableAttr = $xmlQ.attr("variable");
			if(typeof(variableAttr) != "undefined"){
				var splitArray = variableAttr.split(",");
				for(var i = 0; i < splitArray.length; i++){
					maxVariableKey = i;

					var variable = this.createVariable({
						"key": splitArray[i]
					});

					this.setVariable(i, variable);
				}

				this.pool.receive.variableKey = ++maxVariableKey;
			}

			var clientAttr = $xmlQ.attr("ip");
			if(typeof(clientAttr) != "undefined"){
				var splitArray = clientAttr.split(",");
				for(var i = 0; i < splitArray.length; i++){
					maxClientKey = i;

					var client = this.createClient({
						"address": splitArray[i]
					});

					this.setClient(i, client);
				}

				this.pool.receive.clientKey = ++maxClientKey;
			}
		}
	}
};
