WISE.registerInfo = function(registerIndex){
	var registerInfo = "";
	
	registerInfo += registerIndex + 1;
	if(WISE.managers.registerManager.pool.registers[registerIndex].name != ""){
		registerInfo += "(" + WISE.managers.registerManager.pool.registers[registerIndex].name + ")";
	}

	return registerInfo;
};

WISE.registerBitInfo = function(registerIndex, bit){
	var registerBitInfo = bit;
	var bitName = WISE.managers.registerManager.pool.registers[registerIndex].bitName[bit] || "";

	if(bitName != ""){
		registerBitInfo += "(" + bitName + ")";
	}

	return registerBitInfo;
};

/*
	moduleKey must sourceType, sourceIndex and moduleIndex.
	for example:
		moduleKey = {
			"sourceType": "comport",
			"sourceIndex": 2,
			"moduleIndex": 1
		}
*/
WISE.buildModuleSelector = function($sourceSelector, $moduleSelector, $channelSelector, key, channelType, hideMappingDI){
	if(typeof($sourceSelector) == "string"){
		$sourceSelector = $("#" + $sourceSelector);
	}
	if(typeof($moduleSelector) == "string"){
		$moduleSelector = $("#" + $moduleSelector);
	}
	if(typeof($channelSelector) == "string"){
		$channelSelector = $("#" + $channelSelector);
	}

	var moduleManager = WISE.managers.moduleManager;
	var interfaces = {};

	for(var i = 0; i < key.length; i++){
		var moduleInfo = WISE.managers.moduleManager.getModuleInfoByKey(key[i].moduleKey);

		if(typeof(interfaces[moduleInfo.sourceType]) == "undefined"){
			interfaces[moduleInfo.sourceType] = [];
		}
		if(typeof(interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex]) == "undefined"){
			interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex] = {
				"moduleIndexArray": [],
				"name": moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name
			};
		}

		interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].moduleIndexArray.push(moduleInfo.moduleIndex);
	}

	$sourceSelector.empty();
	for(var i = 0, sourceArray = ["onboard", "comport", "network", "camera"]; i < sourceArray.length; i++){
		if(typeof(interfaces[sourceArray[i]]) == "undefined"){continue;}
		for(var j = 0; j < interfaces[sourceArray[i]].length; j++){
			if(typeof(interfaces[sourceArray[i]][j]) == "undefined"){continue;}
			$("<option></option>").attr("value", sourceArray[i] + "_" + j).text(interfaces[sourceArray[i]][j].name).appendTo($sourceSelector);
		}
	}

	$sourceSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(event, data){
		//$moduleSelector.empty();
		var $temp = $moduleSelector.empty().clone(true, true);
		$moduleSelector.replaceWith($temp);
		$moduleSelector = $temp;

		var moduleSource = $(this).val().split("_");
		var sourceType = moduleSource[0];
		var sourceIndex = parseInt(moduleSource[1], 10);

		for(var i = 0, moduleIndexArray = interfaces[sourceType][sourceIndex].moduleIndexArray; i < moduleIndexArray.length; i++){
			$("<option></option>").attr("value", moduleIndexArray[i]).text(WISE.moduleInfo(sourceType, sourceIndex, moduleIndexArray[i])).appendTo($moduleSelector);
		}

		$moduleSelector.unbind("change.moduleSelect").bind("change.moduleSelect", function(event, data){
			if(typeof($channelSelector) == "undefined" || $channelSelector == null){return;}

			//$channelSelector.empty();
			var $temp = $channelSelector.empty().clone(true, true);
			$channelSelector.replaceWith($temp);
			$channelSelector = $temp;

			var moduleSource = $sourceSelector.val().split("_");
			var sourceType = moduleSource[0];
			var sourceIndex = parseInt(moduleSource[1], 10);
			var moduleIndex = parseInt($(this).val(), 10);
			var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

			if(module.type == "rtu" || module.type == "tcp"){
				for(var address in module[channelType].remoteAddress){
					if(module[channelType].blockArray[module[channelType].remoteAddress[address].blockIndex].disable == true){continue;}

					$("<option></option>").attr("value", address).text(WISE.channelInfo(sourceType, sourceIndex, moduleIndex, channelType, address)).appendTo($channelSelector);
				}
			}
			else if(module.type == "onboard" || module.type == "icpdas"){
				var counterType = null;

				//want to list counter, store channelType to counterType, change channelType
				if(channelType == "DIC"){
					counterType = channelType; channelType = "DI";
				}
				else if(channelType == "DOC"){
					counterType = channelType; channelType = "DO";
				}

				for(var channel = 0; channel < module[channelType].amount; channel++){
					if(module[channelType].setting[channel].disable == true){continue;}

					if(channelType == "DI" && module.type == "onboard" && counterType != null && module.DI.setting[channel].counterType == 0){continue;}//for XW-Board, not every channel have DI counter
					if(channelType == "DO" && module.DO.setting[channel].advancedFunction == 3 && hideMappingDI == true){continue;}

					$("<option></option>").attr("value", channel).text(WISE.channelInfo(sourceType, sourceIndex, moduleIndex, counterType || channelType, channel)).appendTo($channelSelector);
				}
				if(counterType != null){channelType = counterType;}//restore channelType
			}

			$channelSelector.triggerHandler("change");
		}).triggerHandler("change");
	}).triggerHandler("change");
};

WISE.buildRegisterSelector = function($registerModeSelector, $registerModuleKeySelector, $registerSelector, $registerBitSelector, $registerModuleHandler, key){
	if(typeof($registerModeSelector) == "string"){
		$registerModeSelector = $("#" + $registerModeSelector);
	}
	if(typeof($registerModuleKeySelector) == "string"){
		$registerModuleKeySelector = $("#" + $registerModuleKeySelector);
	}
	if(typeof($registerSelector) == "string"){
		$registerSelector = $("#" + $registerSelector);
	}
	if(typeof($registerBitSelector) == "string"){
		$registerBitSelector = $("#" + $registerBitSelector);
	}
	if(typeof($registerModuleHandler) == "string"){
		$registerModuleHandler = $("#" + $registerModuleHandler);
	}

	var moduleManager = WISE.managers.moduleManager;
	var registerManager = WISE.managers.registerManager;

	$registerModeSelector.empty();

	for(var i = 0; i < key.length; i++){
		if(key[i].moduleKey == null){
			$registerModeSelector.append(
				$("<option></option>").attr("value", "0").text("<#Lang['?'].local>")
			);
			break;
		}
	}

	var hasRemoteRegister = false;
	for(var i = 0; i < key.length; i++){
		if(key[i].moduleKey != null){
			$registerModeSelector.append(
				$("<option></option>").attr("value", "1").text("<#Lang['?'].remote>")
			);

			hasRemoteRegister = true;
			break;
		}
	}

	if(hasRemoteRegister == true){
		$registerModuleKeySelector.empty();
		for(var i = 0; i < key.length; i++){
			if(key[i].moduleKey != null){
				var moduleInfo = moduleManager.getModuleInfoByKey(key[i].moduleKey);

				$registerModuleKeySelector.append(
					$("<option></option>").attr("value", key[i].moduleKey).text(WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex))
				);
			}
		}
	}

	$registerModeSelector.unbind("change.registerSelect").bindFirst("change.registerSelect", function(){
		if($(this).val() == "0"){//local
			$registerModuleHandler.hide();
		}
		else{
			$registerModuleHandler.show();
		}

		$registerModuleKeySelector.unbind("change.registerSelect").bindFirst("change.registerSelect", function(){
			//$registerSelector.empty();
			var $temp = $registerSelector.empty().clone(true, true);
			$registerSelector.replaceWith($temp);
			$registerSelector = $temp;

			if($registerModeSelector.val() == "0"){//local
				for(var i = 0; i < registerManager.pool.registers.length; i++){
					if(typeof(registerManager.pool.registers[i]) == "undefined"){continue;}

					$registerSelector.append($("<option></option>").attr("value", i).text(WISE.registerInfo(i)));
				}
			}
			else{
				var moduleInfo = moduleManager.getModuleInfoByKey($(this).val());
				var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

				for(var i = 0; i < module.IR.amount; i++){
					$registerSelector.append($("<option></option>").attr("value", i).text(WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", i)));
				}
			}

			$registerSelector.unbind("change.registerSelect").bindFirst("change.registerSelect", function(){
				if(typeof($registerBitSelector) == "undefined" || $registerBitSelector == null){return;}

				var $temp = $registerBitSelector.empty().clone(true, true);
				$registerBitSelector.replaceWith($temp);
				$registerBitSelector = $temp;

				var registerManager = WISE.managers.registerManager;
				var registerIndex = parseInt($(this).val(), 10);

				$registerBitSelector.append(
					$("<option></option>").attr("value", "-1").text("<#Lang.global.disable>")
				);
				
				if($registerModeSelector.val() == "0"){
					for(var i = 0; i < 16; i++){
						$registerBitSelector.append(
							$("<option></option>").attr("value", i).text(WISE.registerBitInfo(registerIndex, i))
						);
					}

					if(registerManager.pool.registers[registerIndex].type > 2){
						for(var i = 16; i < 32; i++){
							$registerBitSelector.append(
								$("<option></option>").attr("value", i).text(WISE.registerBitInfo(registerIndex, i))
							);
						}
					}
				}
				else if($registerModeSelector.val() == "1"){
					for(var i = 0; i < 32; i++){
						$registerBitSelector.append(
							$("<option></option>").attr("value", i).text(i)
						);
					}
				}
			}).triggerHandler("change");
		}).triggerHandler("change");
	}).triggerHandler("change");
};

WISE.buildCameraSelector = function($cameraSelector, $commandSelector, key, channelType){
	if(typeof($cameraSelector) == "string"){
		$cameraSelector = $("#" + $cameraSelector);
	}
	if(typeof($commandSelector) == "string"){
		$commandSelector = $("#" + $commandSelector);
	}

	var moduleManager = WISE.managers.moduleManager;

	for(var i = 0; i < key.length; i++){
		var moduleInfo = moduleManager.getModuleInfoByKey(key[i].moduleKey);
		var module = moduleInfo.module;
		
		$("<option></option>").attr("value", moduleInfo.moduleIndex).text(WISE.moduleInfo("camera", 0, moduleInfo.moduleIndex)).appendTo($cameraSelector);
	}

	$cameraSelector.bind("change", function(){
		var $temp = $commandSelector.empty().clone(true, true);
		$commandSelector.replaceWith($temp);
		$commandSelector = $temp;

		var moduleIndex = parseInt($(this).val(), 10);
		var module = moduleManager.pool.interfaces.camera[0].modules[moduleIndex];

		if(channelType == "DI" || channelType == "DO" || channelType == "AI" || channelType == "AO"){
			for(var channel = 0; channel < module[channelType].amount; channel++){
				$("<option></option>").attr("value", channel).text(WISE.channelInfo("camera", 0, moduleIndex, channelType, channel)).appendTo($commandSelector);
			}
		}
		else{
			for(var command = 0; command < module[channelType].amount; command++){
				if(module[channelType].setting[command].disable == true){continue;}

				$("<option></option>").attr("value", command).text(module[channelType].setting[command].displayName).appendTo($commandSelector);
			}
		}
	});
};

WISE.buildSelector = function($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, $registerModeSelector, $registerModuleKeySelector, $registerSelector, $systemInformationSelector, $customizedHandler, settings){
/*
	interfaces = {
		"comport": [undefined, undefined, true, true],
		"network": [true],
		"register": true
	};
*/
	settings = settings || {};

	var matchModules = [];
	var moduleManager = WISE.managers.moduleManager;
	var registerManager = WISE.managers.registerManager;

	/*build source selector*/
/*
	//$sourceSelector.empty();//maybe user insert customize option, so don't clear it
	var $temp = $sourceSelector.empty().clone(true, true);
	$sourceSelector.replaceWith($temp);
	$sourceSelector = $temp;
*/
	for(var i = 0, sourceArray = ["onboard", "comport", "network", "camera"]; i < sourceArray.length; i++){
		var sourceType = sourceArray[i];

		for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces[sourceType].length; sourceIndex++){
			if(typeof(moduleManager.pool.interfaces[sourceType][sourceIndex]) == "undefined"){continue;}

			for(var moduleIndex = 0, modules = moduleManager.pool.interfaces[sourceType][sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];
				var channelInfo = {
					"moduleKey": module.key,
					"channelPool": {}//if without any object, it will be remove from matchModules
				};
				var findFlag = false;
				if(module.type == "rtu" || module.type == "tcp"){
					if(typeof(module.extendedModule) == "undefined"){
						//channelInfo.channelPool.channel = {};
						var typeArray = ["CI", "CO", "RI", "RO"];
						for(var typeArrayIndex = 0; typeArrayIndex < typeArray.length/* && findFlag == false*/; typeArrayIndex++){
							if(typeof(module[typeArray[typeArrayIndex]]) == "undefined"){continue;}

							for(var address in module[typeArray[typeArrayIndex]].remoteAddress){
								//channelInfo.channelPool.channel[typeArray[typeArrayIndex]] = true;
								channelInfo.channelPool[typeArray[typeArrayIndex]] = true;
								findFlag = true;
								break;
							}
						}
					}
					else{//check if extend module want to disaply or not
						if(typeof(WISE.buildSelector.processExtendedModule) == "function"){
							findFlag = WISE.buildSelector.processExtendedModule(module, channelInfo);
						}
					}
				}
				else{
					channelInfo.channelPool = {};
					var typeArray = ["DI", "DO", "AI", "AO"];
					for(var typeArrayIndex = 0; typeArrayIndex < typeArray.length/* && findFlag == false*/; typeArrayIndex++){
						if(typeof(module[typeArray[typeArrayIndex]]) == "undefined"){continue;}

						var channelType = typeArray[typeArrayIndex];
						for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
							if(module[channelType].setting[channelIndex].disable == false){
								channelInfo.channelPool[typeArray[typeArrayIndex]] = true;
								findFlag = true;
								break;
							}
						}
					}
				}

				if(findFlag == true){
					matchModules.push(channelInfo);
				}
			}
		}
	}

	if(typeof(settings.filter) == "function"){
		matchModules = settings.filter(matchModules);
	}

	//clear module that without any channel(because filter maybe clear channel)
	var interfaces = {};
	for(var i = 0; i < matchModules.length; i++){
		var channelExist = false;
		for(var channel in matchModules[i].channelPool){
			channelExist = true;
			break;
		}

		if(channelExist == false){
			matchModules.splice(i--, 1);
			continue;
		}

		var moduleInfo = moduleManager.getModuleInfoByKey(matchModules[i].moduleKey);
		var sourceType = moduleInfo.sourceType, sourceIndex = moduleInfo.sourceIndex;

		if(typeof(interfaces[sourceType]) == "undefined"){
			interfaces[sourceType] = [];
		}

		if(interfaces[sourceType][sourceIndex] != true){
			interfaces[sourceType][sourceIndex] = true;
			$sourceSelector.append(
				$("<option></option>").val(sourceType + "_" + sourceIndex).text(moduleManager.pool.interfaces[sourceType][sourceIndex].name)
			);
		}
	}

	if(registerManager.pool.conditions.register.key.length > 0){
		$sourceSelector.append(
			$("<option></option>").val("register").html("<#Lang['?'].internalRegister>")
		);
	}

	if($systemInformationSelector != null){
		$sourceSelector.append(
			$("<option></option>").val("system").html("<#Lang['?'].systemInformation>")
		);
	}

	if($customizedHandler != null && typeof(WISE.buildSelector.extendSourceSelector) == "function"){
		WISE.buildSelector.extendSourceSelector($sourceSelector);
	}

	$sourceSelector.unbind("change.selector").bindFirst("change.selector", function(event){
		var sourceType = null, sourceIndex = -1;
		if($(this).val() != null){
			var splitArray = $(this).val().split("_");
			sourceType = splitArray[0];
			sourceIndex = splitArray[1];
		}

		if(sourceType == null){
			if(typeof(settings.onChange) == "function"){
				settings.onChange(sourceType);
			}
		}
		else if(sourceType == "register"){
			if(typeof(settings.registerProcessor) == "function"){
				//$registerSelector.empty();
				var $temp = $registerSelector.empty().clone(true, true);
				$registerSelector.replaceWith($temp);
				$registerSelector = $temp;

				settings.registerProcessor($registerModeSelector, $registerModuleKeySelector, $registerSelector, registerManager.pool.conditions.register.key);
			}
			else{
				$registerModeSelector.empty();

				var key = registerManager.pool.conditions.register.key;
				for(var i = 0; i < key.length; i++){
					if(key[i].moduleKey == null){
						$registerModeSelector.append(
							$("<option></option>").attr("value", "0").text("<#Lang['?'].local>")
						);
						break;
					}
				}

				var hasRemoteRegister = false;
				for(var i = 0; i < key.length; i++){
					if(key[i].moduleKey != null){
						$registerModeSelector.append(
							$("<option></option>").attr("value", "1").text("<#Lang['?'].remote>")
						);

						hasRemoteRegister = true;
						break;
					}
				}

				if(hasRemoteRegister == true){
					$registerModuleKeySelector.empty();
					for(var i = 0; i < key.length; i++){
						if(key[i].moduleKey != null){
							var moduleInfo = moduleManager.getModuleInfoByKey(key[i].moduleKey);

							$registerModuleKeySelector.append(
								$("<option></option>").attr("value", key[i].moduleKey).text(WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex))
							);
						}
					}
				}

				$registerModeSelector.unbind("change.registerSelect").bindFirst("change.registerSelect", function(){
					if($(this).val() == "0"){//local
						//$registerModuleKeySelector.css("visibility", "hidden");
						$registerModuleKeySelector.hide();
					}
					else{
						//$registerModuleKeySelector.css("visibility", "visible");
						$registerModuleKeySelector.show();
					}

					$registerModuleKeySelector.unbind("change.registerSelect").bindFirst("change.registerSelect", function(){
						//$registerSelector.empty();
						var $temp = $registerSelector.empty().clone(true, true);
						$registerSelector.replaceWith($temp);
						$registerSelector = $temp;

						if($registerModeSelector.val() == "0"){//local
							for(var i = 0; i < registerManager.pool.registers.length; i++){
								if(typeof(registerManager.pool.registers[i]) == "undefined"){continue;}

								$registerSelector.append($("<option></option>").attr("value", i).text(WISE.registerInfo(i)));
							}
						}
						else{
							var moduleInfo = moduleManager.getModuleInfoByKey($(this).val());
							var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

							for(var i = 0; i < module.IR.amount; i++){
								$registerSelector.append($("<option></option>").attr("value", i).text(WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", i)));
							}
						}

						if(settings.showAllChannel == true){
							$registerSelector.append($("<option></option>").val("-1").text("<#Lang['?'].all>"));
						}

						$registerSelector.unbind("change.selector").bindFirst("change.selector", function(){
							if(typeof(settings.onChange) == "function"){
								settings.onChange("register", registerManager.pool.registers[parseInt($(this).val(), 10)]);
							}
						}).triggerHandler("change");
					}).triggerHandler("change");
				}).triggerHandler("change");

			}
		}
		else if(sourceType == "onboard" || sourceType == "comport" || sourceType == "network" || sourceType == "camera"){
			//$moduleSelector.empty();
			var $temp = $moduleSelector.empty().clone(true, true);
			$moduleSelector.replaceWith($temp);
			$moduleSelector = $temp;

			for(var i = 0; i < matchModules.length; i++){
				var moduleInfo = moduleManager.getModuleInfoByKey(matchModules[i].moduleKey);

				if(moduleInfo.sourceType == sourceType && moduleInfo.sourceIndex == sourceIndex){
					$moduleSelector.append(
						$("<option></option>").val(moduleInfo.moduleIndex).attr("matchModulesIndex", i).html(WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex))
					);
				}
			}

			$moduleSelector.unbind("change.selector").bindFirst("change.selector", function(event){
				//$channelTypeSelector.empty();
				var $temp = $channelTypeSelector.empty().clone(true, true);
				$channelTypeSelector.replaceWith($temp);
				$channelTypeSelector = $temp;

				var splitArray = $sourceSelector.val().split("_");
				var sourceType = splitArray[0];
				var sourceIndex = splitArray[1];
				var moduleIndex = parseInt($(this).val(), 10);
				var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

				var matchModulesIndex = parseInt($(this).find(":selected").attr("matchModulesIndex"), 10);

				if(module.type == "onboard" || module.type == "icpdas"){
					for(var channelType in matchModules[matchModulesIndex].channelPool){
						//DI
						if(channelType == "DI" && moduleManager.icpdasModule.isDICounterModule(module) && settings.showCounterModuleDI != true){
						}
						else{
							$channelTypeSelector.append($("<option></option>").val(channelType).text(channelType));
						}

						//DI Counter
						if(channelType == "DI" && settings.hiddenCounter != true && !moduleManager.icpdasModule.isNoDICounterModule(module)){
							if(module.type == "onboard"){//XW-Board can disable counter, need to check one or more DI counter are enable
								for(var j = 0; j < module.DI.amount; j++){
									if(module.DI.setting[j].disable == true){continue;}

									if(module.DI.setting[j].counterType > 0){
										$channelTypeSelector.append($("<option></option>").val("DIC").html("<#Lang['?'].diCounter>"));
										break;
									}
								}
							}
							else{
								$channelTypeSelector.append($("<option></option>").val("DIC").html("<#Lang['?'].diCounter>"));
							}
						}

						//DO Counter
						if(channelType == "DO" && settings.hiddenCounter != true && module.moduleType == "WISE"){
							$channelTypeSelector.append($("<option></option>").val("DOC").html("<#Lang['?'].doCounter>"));
						}
					}
				}
				else if((module.type == "rtu" || module.type == "tcp") && typeof(module.extendedModule) == "undefined"){//process only normal modbus modules
					var typeMappingPool = {"CI": "Discrete Input", "CO": "Coil Output", "RI": "Input Register", "RO": "Holding Register"};

					for(var channelType in matchModules[matchModulesIndex].channelPool){
						if(typeof(module[channelType]) == "undefined"){continue;}

						if(module[channelType].blockArray.length > 0){
							$channelTypeSelector.append($("<option></option>").val(channelType).html(typeMappingPool[channelType]));
						}
					}
				}

				//endtend modules
				if(typeof(module.extendedModule) != "undefined" && typeof(WISE.buildSelector.onChangeExtendedModuleSelector) == "function"){
					WISE.buildSelector.onChangeExtendedModuleSelector($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, settings, matchModules[matchModulesIndex]);
				}

				if(settings.showAllChannelType == true){
					$channelTypeSelector.append($("<option></option>").val("-1").html("<#Lang['?'].all>"));
				}

				$channelTypeSelector.unbind("change.selector").bindFirst("change.selector", function(event){
					//$channelSelector.empty();
					var $temp = $channelSelector.empty().clone(true, true);
					$channelSelector.replaceWith($temp);
					$channelSelector = $temp;

					var splitArray = $sourceSelector.val().split("_");
					var sourceType = splitArray[0];
					var sourceIndex = splitArray[1];
					var moduleIndex = parseInt($moduleSelector.val(), 10);
					var channelType = $(this).val();
					var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

					if(channelType != "-1"){//not all channel type
						if(module.type == "onboard" || module.type == "icpdas"){
							var counterType = null;

							if(channelType == "DIC" && module.type == "onboard"){
								counterType = channelType; channelType = "DI";
								for(var i = 0; i < module[channelType].amount; i++){
									if(module[channelType].setting[i].disable == true){continue;}

									if(module[channelType].setting[i].counterType > 0){
										$channelSelector.append($("<option></option>").val(i).text(WISE.channelInfo(sourceType, sourceIndex, moduleIndex, counterType || channelType, i)));
									}
								}
							}
							else{
								if(channelType == "DIC"){
									counterType = channelType; channelType = "DI";
								}
								else if(channelType == "DOC"){
									counterType = channelType; channelType = "DO";
								}

								for(var i = 0; i < module[channelType].amount; i++){
									if(module[channelType].setting[i].disable == true){continue;}

									$channelSelector.append($("<option></option>").val(i).text(WISE.channelInfo(sourceType, sourceIndex, moduleIndex, counterType || channelType, i)));
								}
							}

							if(typeof(settings.channelPrefix) != "undefined"){
								settings.channelPrefix.text("<#Lang.global.ch>");
							}
						}
						else if((module.type == "rtu" || module.type == "tcp") && typeof(module.extendedModule) == "undefined"){//process only normal modbus modules
							for(var address in module[channelType].remoteAddress){
								//if(module[channelType].blockArray[module[channelType].remoteAddress[address].blockIndex].disable == true){continue;}

								$channelSelector.append($("<option></option>").val(address).text(WISE.channelInfo(sourceType, sourceIndex, moduleIndex, channelType, address)));
							}

							if(typeof(settings.channelPrefix) != "undefined"){
								settings.channelPrefix.text("<#Lang.global.addr>");
							}
						}

						//endtend modules
						if(typeof(module.extendedModule) != "undefined"){
							if(typeof(WISE.buildSelector.onChangeExtendedModuleSelector) == "function"){
								WISE.buildSelector.onChangeExtendedChannelSelector($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, $registerSelector, settings);
							}

							if(typeof(WISE.buildSelector.porcessChannelPrefix) == "function" && typeof(settings.channelPrefix) != "undefined"){
								WISE.buildSelector.porcessChannelPrefix($sourceSelector, $moduleSelector, $channelTypeSelector, $channelSelector, $registerSelector, settings);
							}
						}

						if(settings.showAllChannel == true){
							$channelSelector.append($("<option></option>").val("-1").text("<#Lang['?'].all>"));
						}

						$channelSelector.show();
						settings.channelPrefix.show();
					}
					else{//all channel type
						$channelSelector.hide();
						settings.channelPrefix.hide();
					}

					$channelSelector.unbind("change.selector").bindFirst("change.selector", function(event){
						var splitArray = $sourceSelector.val().split("_");
						var sourceType = splitArray[0];
						var sourceIndex = splitArray[1];
						var moduleIndex = parseInt($moduleSelector.val(), 10);
						var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

						if(typeof(settings.onChange) == "function"){
							settings.onChange(sourceType, module);
						}
					}).triggerHandler("change");
				}).triggerHandler("change");
			}).triggerHandler("change");
		}
		else if(sourceType == "system"){
			//$systemInformationSelector.empty();
			var $temp = $systemInformationSelector.empty().clone(true, true);
			$systemInformationSelector.replaceWith($temp);
			$systemInformationSelector = $temp;

			$systemInformationSelector.append(
				$("<option></option>").val("Ty").text("<#Lang['?'].dateYear>")
			).append(
				$("<option></option>").val("TM").text("<#Lang['?'].dateMonth>")
			).append(
				$("<option></option>").val("Td").text("<#Lang['?'].dateDay>")
			).append(
				$("<option></option>").val("Th").text("<#Lang['?'].timeHour>")
			).append(
				$("<option></option>").val("Tm").text("<#Lang['?'].timeMinute>")
			).append(
				$("<option></option>").val("Ts").text("<#Lang['?'].timeSecond>")
			).append(
				$("<option></option>").val("TU").text("<#Lang['?'].timestamp>")
			);

			if(WISE.$.modelName.match(/-(3GWA|4GE|4GC)$/)){
				$systemInformationSelector.append(
					$("<option></option>").val("Ss").text("<#Lang['?'].signalStrengthDBM>")
				).append(
					$("<option></option>").val("Sp").text("<#Lang['?'].signalStrengthPercent>")
				);
			}

			$systemInformationSelector.unbind("change.selector").bind("change.selector", function(){
				if(typeof(settings.onChange) == "function"){
					settings.onChange("system", $(this).val());
				}
			}).triggerHandler("change");
		}
		else{
			if(typeof(WISE.buildSelector.extendSourceSelectorChange) == "function"){
				WISE.buildSelector.extendSourceSelectorChange($sourceSelector, $customizedHandler, settings);
			}

			if(typeof(settings.onChange) == "function"){
				settings.onChange(sourceType);
			}
		}
	}).triggerHandler("change");
};

WISE.buildVariableEditor = function($handler, settings){
	settings = $.extend(true, {
		"clickViewTab": function(){},
		"clickEditTab": function(){}
	}, settings);

	var $editor = $handler.find("textarea.variableEditor.editor");
	var $selector = $handler.find("div.variableEditor.selector");

	$editor.parent().hide();
	$selector.hide();

	var $viewer = $("<div></div>").addClass("variableEditor viewerStyle viewer").css({
		"height": $editor.height(),
		"marginTop": $editor.css("marginTop"), "marginBottom": $editor.css("marginBottom"), "marginLeft": $editor.css("marginLeft"), "marginRight": $editor.css("marginRight"),
		"paddingTop": $editor.css("paddingTop"), "paddingBottom": $editor.css("paddingBottom"), "paddingLeft": $editor.css("paddingLeft"), "paddingRight": $editor.css("paddingRight"),
	}).bind("click", function(){
		$(this).siblings("div.variableEditor.switchButton.editTab").triggerHandler("click", true);
	});

	$viewer.insertAfter($editor.parent());

	$handler.prepend(
		$("<div></div>").addClass("variableEditor switchButton editTab").html("<#Lang['?'].edit>").bind("click", function(event, cancelSelect){
			if($(this).hasClass("active")){return;}

			$selector.slideDown("fast");
			$editor.parent().show();

			var selectRange = $editor.insertAtCaret("range");
			if(cancelSelect == true){
				$editor.insertAtCaret("select", selectRange.index + selectRange.length, 0);
			}
			else{
				$editor.insertAtCaret("select", selectRange.index, selectRange.length);
			}

			$(this).parent().attr("viewerScrollTop", $viewer.scrollTop());//keep viewer scrollTop, when next one click view tab, restore it
			$viewer.hide();

			$(this).siblings("div.variableEditor.switchButton").removeClass("active");
			$(this).addClass("active");

			settings.clickEditTab($editor);
		})
	).prepend(
		$("<div></div>").addClass("variableEditor switchButton viewTab").html("<#Lang['?'].view>").bind("click", function(){
			if($(this).hasClass("active")){return;}

			$editor.triggerHandler("finishEdit");
			$selector.slideUp("fast");
			$viewer.show().scrollTop($(this).parent().attr("viewerScrollTop"));
			$editor.parent().hide();

			$(this).siblings("div.variableEditor.switchButton").removeClass("active");
			$(this).addClass("active");

			settings.clickViewTab($viewer);
		})
	);

	$editor.bind("finishEdit", function(){
		$viewer.empty();

		WISE.buildVariableEditor.convertVariable($(this)[0].value, $viewer, function($replaceElement, regex, result){
			$replaceElement.attr({
				"variableStartIndex": result.index, "variableLength": regex.lastIndex - result.index
			}).bind("click", function(event){
				var variableStartIndex = parseInt($(this).attr("variableStartIndex"), 10);
				$editor.parent().show();
				$editor.insertAtCaret("select", variableStartIndex, parseInt($(this).attr("variableLength"), 10));

				//scroll into view start
				var content = $editor.val().substring(0, variableStartIndex);
			    var $copyDiv = $('<div></div>').css({
					"width": $.browser.mozilla ? parseFloat($viewer.css('width')) - 2 + "px": $viewer.css('width'),
					//"width": $editor[0].clientWidth,
					"height": $viewer.css('height'),
					"paddingTop": $editor.css("paddingTop"), "paddingBottom": $editor.css("paddingBottom"), "paddingLeft": $editor.css("paddingLeft"), "paddingRight": $editor.css("paddingRight"),
					"fontSize": $editor.css('fontSize'),
					"lineHeight": $editor.css('lineHeight'),
					"fontFamily": $editor.css('fontFamily'),
					"wordWrap": "break-word",
					"position": "absolute",
					"left": "-9999px",
					"overflowY": "auto",
				}).append(content.replace(/\n/g, '<br>')).append(
					$("<span></span>").attr("id", "variableStartPosition")
				).appendTo("body");

				var position = $copyDiv.find('#variableStartPosition').position();
				$editor.scrollTop(position.top - $editor[0].clientHeight / 2);
				$copyDiv.remove();
				//scroll into view end

				$editor.parent().siblings("div.variableEditor.switchButton.editTab").triggerHandler("click");
				event.stopPropagation();
			});
		});
	}).bind("view", function(){
		$handler.children("div.variableEditor.switchButton.viewTab").triggerHandler("click");
	}).bind("edit", function(){
		$handler.children("div.variableEditor.switchButton.editTab").triggerHandler("click");
	});
};

WISE.buildVariableEditor.moduleProcessor = function(moduleInfo, channelVariable){
	try{
		var moduleManager = WISE.managers.moduleManager;
		var interfaceName = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name;
		var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];
		var moduleName = (function(sourceType, sourceIndex, moduleIndex){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
			var name = "";

			if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "onboard"){
				name = module.name || module.displayModelName;
			}
			else if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "comport485"){
				if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "dcon"){
					name = module.name || module.displayModelName;
				}
				else if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusRTU"){
					if(module.type == "icpdas"){//M7K
						name = module.name || module.displayModelName;
					}
					else{
						name = module.name;
					}
				}
			}
			else if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "network"){
				if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "modbusTCP"){
					if(module.type == "icpdas"){//M7K
						name = module.name || module.displayModelName;
					}
					else{
						name = module.name;
					}
				}
			}
			else if(moduleManager.pool.interfaces[sourceType][sourceIndex].type == "httpCGI"){
				if(moduleManager.pool.interfaces[sourceType][sourceIndex].protocol == "httpCGI"){
					if(module.type == "icpdas"){//M7K
						name = module.name || module.displayModelName;
					}
				}
			}

			return name;
		})(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex);

		if(typeof(module.extendedModule) != "undefined"){
			return WISE.buildVariableEditor.processExtendedModule(moduleInfo, channelVariable);
		}
		else{
			var regex = /(\D+)(\d+)/;
			var result = regex.exec(channelVariable);

			if(result){
				for(var i = 0; i < result.length; i++){
					if(typeof(result[i]) == "undefined"){
						result[i] = "";
					}
				}

				moduleInfo.channelType = result[1].toUpperCase();
				moduleInfo.channel = parseInt(result[2].toUpperCase(), 10);
			}

			if(module.type == "icpdas" || module.type == "onboard"){
				var protocol = WISE.managers.moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;

				if(protocol == "modbusRTU" || protocol == "modbusTCP"){//M7K
					var channelIndexInfo = WISE.managers.moduleManager.icpdasModule.channelAddressToIndex(module, moduleInfo.channelType, moduleInfo.channel);
					moduleInfo.channelType = channelIndexInfo[0];
					moduleInfo.channel = channelIndexInfo[1];
				}
				else{//I7K, XW-Board
					if(moduleInfo.channelType == "CI"){
						moduleInfo.channelType = "DIC";
					}
				}
			}

			var channelTypeName = {
				"DI": "DI$channel",
				"DIC": "<#Lang['?'].diCounterX>",
				"DO": "DO$channel",
				"DOC": "<#Lang['?'].doCounterX>",
				"AI": "AI$channel",
				"AO": "AO$channel",
				"CI": "Discrete Input $channel",
				"CO": "Coil Output $channel",
				"RI": "Input Register $channel",
				"RO": "Holding Register $channel",
				"IR": "<#Lang['?'].internalRegisterX>"//remote IR
			}[moduleInfo.channelType];

			return $("<span></span>").attr("tip", interfaceName + "<br>" + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex)).html(moduleName + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, moduleInfo.channelType, moduleInfo.channel).toString(channelTypeName));
		}
	}
	catch(error){
		return null;
	}
};

WISE.buildVariableEditor.registerProcessor = function(registerInfo, registerValue){
	try{
		return $("<span></span>").html("<#Lang['?'].internalRegister> " + WISE.registerInfo(registerInfo.registerIndex));
	}
	catch(error){
		return null;
	}
};

WISE.buildVariableEditor.systemInformationProcessor = function(systemInfo){
	try{
		var desc = {
			"Ty": "<#Lang['?'].dateYear>",
			"TM": "<#Lang['?'].dateMonth>",
			"Td": "<#Lang['?'].dateDay>",
			"Th": "<#Lang['?'].timeHour>",
			"Tm": "<#Lang['?'].timeMinute>",
			"Ts": "<#Lang['?'].timeSecond>",
			"TU": "<#Lang['?'].timestamp>",
			"Ss": "<#Lang['?'].signalStrengthDBM>",
			"Sp": "<#Lang['?'].signalStrengthPercent>"
		}[systemInfo.item];

		return $("<span></span>").html("<#Lang['?'].systemInformation>" + " " + desc);
	}
	catch(error){
		return null;
	}
};

WISE.buildVariableEditor.convertVariable = function(content, $container, elementProcessor){
	var undefinedToEmptyString = function(objectArray){
		if(!objectArray){return objectArray;}

		for(var i = 0; i < objectArray.length; i++){
			if(typeof(objectArray[i]) == "undefined"){
				objectArray[i] = "";
			}
		}

		return objectArray;
	};

	var content = content.replace(/</g, "&lt;"), index = 0;
	var regex = new RegExp("\\$(X|C(\\d+)D(\\d+))(\\D+\\d+)|\\$(T(\\d+)|C(\\d+)M(\\d+)|K(\\d+))(\\D+\\d+)|\\$(I(\\d+))|\\$(S(T[yMdhmsU]|S[sp]))" + (typeof(WISE.buildVariableEditor.extendRegex) == "string" ? "|(" + WISE.buildVariableEditor.extendRegex + ")": ""), "g");
	var result = undefinedToEmptyString(regex.exec(content));

	while(result != null) {
		var $replaceElement = null;
		if(result[1].charAt(0) == "X"){//xwboard
			$replaceElement = WISE.buildVariableEditor.moduleProcessor({
				"sourceType": "onboard",
				"sourceIndex": 0,
				"moduleIndex": 0
			}, result[4]);
		}
		else if(result[1].charAt(0) == "C"){//dcon
			$replaceElement = WISE.buildVariableEditor.moduleProcessor({
				"sourceType": "comport",
				"sourceIndex": parseInt(result[2], 10),
				"moduleIndex": parseInt(result[3], 10) - 1
			}, result[4]);
		}
		else if(result[5].charAt(0) == "T"){//modbus tcp
			$replaceElement = WISE.buildVariableEditor.moduleProcessor({
				"sourceType": "network",
				"sourceIndex": 0,
				"moduleIndex": parseInt(result[6], 10) - 1
			}, result[10]);
		}
		else if(result[5].charAt(0) == "C"){//modbus rtu
			$replaceElement = WISE.buildVariableEditor.moduleProcessor({
				"sourceType": "comport",
				"sourceIndex": parseInt(result[7], 10),
				"moduleIndex": parseInt(result[8], 10) - 1
			}, result[10]);
		}
		else if(result[5].charAt(0) == "K"){//camera
			$replaceElement = WISE.buildVariableEditor.moduleProcessor({
				"sourceType": "camera",
				"sourceIndex": 0,
				"moduleIndex": parseInt(result[9], 10) - 1
			}, result[10]);
		}
		else if(result[11].charAt(0) == "I"){//ir
			$replaceElement = WISE.buildVariableEditor.registerProcessor({
				"registerIndex": parseInt(result[12], 10) - 1,
				"moduleKey": null
			});
		}
		else if(result[13].charAt(0) == "S"){//system
			$replaceElement = WISE.buildVariableEditor.systemInformationProcessor({
				"item": result[14]
			});
		}
		else{
			if(typeof(WISE.buildVariableEditor.extendReplaceElement) == "function"){
				$replaceElement = WISE.buildVariableEditor.extendReplaceElement(result.slice(15));
			}
		}

		if($replaceElement != null){//channel is exist
			if(typeof(elementProcessor) == "function"){
				elementProcessor($replaceElement, regex, result);
			}

			$container.append(content.substring(index, result.index).replace(/\n/g, "<br>")).append($replaceElement);
			index = regex.lastIndex;
		}

		result = undefinedToEmptyString(regex.exec(content));
	}

	$container.append(content.substring(index).replace(/\n/g, "<br>"));
};

WISE.getVariable = function(sourceType, sourceIndex, moduleIndex, channelType, channel){
	if(sourceType == "register" && sourceIndex == null){
		var moduleKey = sourceIndex;
		var registerIndex = moduleIndex;
		var registerManager = WISE.managers.registerManager;

		if(typeof(registerManager.pool.registers[registerIndex]) != "undefined"){
			return "$I" + (registerIndex + 1);
		}
	}
	else if(sourceType == "system"){
		return "$S" + sourceIndex;
	}
	else{
		var moduleManager = WISE.managers.moduleManager;

		//remote IR on Holding Register
		if(sourceType == "register" && sourceIndex != null){
			var moduleKey = sourceIndex;
			var registerIndex = moduleIndex;

			var moduleInfo = moduleManager.getModuleInfoByKey(moduleKey);
			if(moduleInfo != null){
				sourceType = moduleInfo.sourceType;
				sourceIndex = moduleInfo.sourceIndex;
				moduleIndex = moduleInfo.moduleIndex;
				channelType = "IR";
				channel = registerIndex;
			}
		}

		var module = null;
		try{
			module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];
		}
		catch(error){}

		if(module != null){
			var variable = "$";

			if(sourceType == "onboard"){
				variable += "X"
			}
			else if(sourceType == "comport"){
				variable += "C" + sourceIndex;
			}
			else if(sourceType == "network"){}

			if(module.type == "onboard" || module.type == "icpdas"){
				var channelIndex = parseInt(channel, 10);

				try{
					if(channelType == "DIC"){
						channel = module.DI.setting[channelIndex];
					}
					else if(channelType == "DOC"){
						channel = module.DO.setting[channelIndex];
					}

					if(typeof(channel) == "undefined" || channel.disable == true){
						throw "channelNotFound";
					}
				}
				catch(error){
					channel = null;
				}

				if(channel != null){
					var protocol = moduleManager.pool.interfaces[sourceType][sourceIndex].protocol;
					if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
						if(protocol == "modbusRTU"){
							variable += "M" + (moduleIndex + 1);
						}
						else if(protocol == "modbusTCP"){
							variable += "T" + (moduleIndex + 1);
						}

						var channelAddressInfo = moduleManager.icpdasModule.channelIndexToAddress(module, channelType, channelIndex);

						if(channelAddressInfo[0] == "CI"){
							variable += "ci";
						}
						else if(channelAddressInfo[0] == "CO"){
							variable += "co";
						}
						else if(channelAddressInfo[0] == "RI"){
							variable += "ri";
						}
						else if(channelAddressInfo[0] == "RO"){
							variable += "ro";
						}

						variable += channelAddressInfo[1];
					}
					else{//XWB and I7K
						if(protocol == "dcon"){//I7K
							variable += "D" + (moduleIndex + 1);
						}
						else if(protocol == "httpCGI"){
							variable += "K" + (moduleIndex + 1);
						}

						if(channelType == "DI"){
							variable += "di";
						}
						else if(channelType == "DIC"){
							variable += "ci";
						}
						else if(channelType == "DO"){
							variable += "do";
						}
						else if(channelType == "AI"){
							variable += "ai";
						}
						else if(channelType == "AO"){
							variable += "ao";
						}

						variable += channelIndex;
					}

					return variable;
				}
			}
			else if(module.type == "rtu" || module.type == "tcp"){
				if(module.type == "rtu"){
					variable += "M" + (moduleIndex + 1);
				}
				else if(module.type == "tcp"){
					variable += "T" + (moduleIndex + 1);
				}

				try{
					if(typeof(module.extendedModule) != "undefined"){
						variable += WISE.getVariable.encodeExtendedModuleChannelVariable(module, channelType, channel);
					}
					else{
						var channelAddress;

						if(channelType == "CI"){
							variable += "ci";
						}
						else if(channelType == "CO"){
							variable += "co";
						}
						else if(channelType == "RI"){
							variable += "ri";
						}
						else if(channelType == "RO"){
							variable += "ro";
						}

						variable += channelAddress = parseInt(channel, 10);

						if(!module[channelType].remoteAddress[channelAddress]){//check remote address exist
							throw "channelNotFound";
						}
					}

					return variable;
				}
				catch(error){}
			}
		}
	}

	return "undefined";
};

WISE.createTempRule = function(){
	var ruleManager = WISE.managers.ruleManager;

	if(parameter[0] == "-1"){
		if(typeof(tempRule) == "undefined" || tempRule.ruleKey != parameter[0]){
			tempRule = ruleManager.createRule();
			tempRule.name = "<#Lang['html/desktop/home/rules/rule.htm'].rule> " + (ruleManager.pool.key + 1);
			tempRule.ruleKey = parameter[0];

			return tempRule;
		}
	}
	else if(typeof(ruleManager.pool.rules[parameter[0]]) != "undefined"){
		if(typeof(tempRule) == "undefined" || tempRule.ruleKey != parameter[0]){
			tempRule = $.extend(true, {"ruleKey": parameter[0]}, ruleManager.pool.rules[parameter[0]]);

			return tempRule;
		}
	}
	else{
		return null;
	}

	return tempRule;
};

WISE.initialRuleObject = function(){
	tempRule = this.createTempRule();

	try{
		var retRuleObject = tempRule[parameter[1]].rules[parameter[2]];
	}
	catch(error){
		return null;
	}

	if(parameter[2] == "-1"){
		var ruleObject = this.managers[parameter[3]].pool[parameter[4]][parameter[5]];

		if(ruleObject.key.length > 0){
			retRuleObject = $.extend(true, {}, ruleObject);
			retRuleObject.init();
			delete retRuleObject.init;
			delete retRuleObject.key;
		}
	}

	return typeof(retRuleObject) == "undefined" ? null : retRuleObject;
};

WISE.finalRuleObject = function(ruleObject){
	if(parameter[2] == "-1"){
		var index = tempRule[parameter[1]].rules.push(ruleObject) - 1;
		tempRule[parameter[1]].executionOrder.push(index);
		return index;
	}
	else{
		tempRule[parameter[1]].rules[parameter[2]] = ruleObject;
		return parameter[2];
	}
};

WISE.createRuleObject = function(ruleObject, init){
	var retRuleObject = $.extend(true, {}, ruleObject);

	if(init == true){
		retRuleObject.init();
	}

	delete retRuleObject.init;
	delete retRuleObject.key;

	return retRuleObject;
};

WISE.check = function(){//return true means no error, object means error
	var retObject = null;

	for(var managerKey in WISE.managers){
		if(managerKey == "ruleManager"){continue;}

		retObject = WISE.managers[managerKey].check();
		if(typeof(retObject) != "undefined" && retObject != null){
			return retObject;
		}
	}

	retObject = WISE.managers.ruleManager.check();//last one to check
	if(typeof(retObject) != "undefined" && retObject != null){
		return retObject;
	}

	return true;
};

WISE.saveRuleFile = function(settings){//download rule file to module
	settings = $.extend(true, {
		"success": function(){},
		"error": function(){},
		"complete": function(){}
	}, settings);

	this.bindFunctionExecute("beforeSave");

	var downloadRuleToModule = function(){
		var xmlRuleDoc = WISE.generateRuleFile();
		xmlRuleDoc.documentElement.setAttribute("ver", WISE.$.currentVersion);
		xmlRuleDoc.documentElement.setAttribute("project", WISE.$.currentApp);

		$.ajax({ 
			url: "./dll/wise.dll",
			type: "POST",
			data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlRuleDoc.documentElement, false),
			contentType: "text/xml",
			processData: false,
			cache: false,
			dataType: "xml",
			done: function(xmlDoc){
				var $xmlWISE = $(xmlDoc).find("WISE");
				if($xmlWISE.attr("reply") == "ok"){
					for(var managerKey in WISE.managers){//save managers pool to wise
						WISE.$.rulePool.managers[managerKey] = $.extend(true, {}, WISE.managers[managerKey].pool);
					}

					xmlRuleDoc.documentElement.removeAttribute("key");
					xmlRuleDoc.documentElement.removeAttribute("ver");
					xmlRuleDoc.documentElement.removeAttribute("project");
					WISE.$.ruleXMLString = xmlToString(xmlRuleDoc.documentElement);

					settings.success();
					WISE.bindFunctionExecute("afterSave");
				}
				else{
					this.fail($xmlWISE.attr("reply"));
				}
			},
			fail: function(reply){
				settings.error(reply);
			},
			complete: function(){
				settings.complete();
			}
		});
	};

	if(typeof(WISE.$.currentVersion) == "undefined"){
		var xmlDoc = $.parseXML("<VERSION/>");
		//xmlDoc.documentElement.setAttribute("key", WISE.getUser().key);

		$.ajax({
			url: "./dll/wise.dll",
			type: "POST",
			data: "<?xml version='1.0' encoding='utf-8'?>" + xmlToString(xmlDoc.documentElement, false),
			contentType: "text/xml",
			processData: false,
			cache: false,
			dataType: "xml",
			done: function(xmlDoc){
				var $xmlVERSION = $(xmlDoc).find("VERSION");
				if($xmlVERSION.length > 0){
					WISE.$.currentVersion = $xmlVERSION.attr("ver");
					WISE.$.currentApp = $xmlVERSION.attr("project");

					downloadRuleToModule();
				}
				else{
					this.fail();
				}
			},
			fail: function(){
				settings.error();
				settings.complete();
			}
		});
	}
	else{
		downloadRuleToModule();
	}
};

WISE.validateRuleFile = function(settings){//retrun true means pass
	settings = $.extend(true, {
		"success": function(){},
		"error": function(){},
		"complete": function(){}
	}, settings);

	var errorInfo = this.check();
	if(errorInfo != true){
		settings.error(errorInfo);
		return;
	}

	var xmlDoc = this.generateRuleFile();
	var baseXMLString = xmlToString(xmlDoc.documentElement);

	this.loadRuleFile({
		"xmlDoc": $.parseXML(baseXMLString),
		"success": function(){
			var errorInfo = WISE.check();
			if(errorInfo != true){
				settings.error(errorInfo);
				return;
			}

			var xmlDoc = WISE.generateRuleFile();
			var newXMLString = xmlToString(xmlDoc.documentElement);

			if(baseXMLString != newXMLString){
				settings.error({
					"baseXMLString": baseXMLString,
					"newXMLString": newXMLString
				});
				return;
			}

			settings.success();
		}
	});
};

WISE.createCompareValue = function(settings){
	var $ul = $("#" + settings.type);

	//assign value
	if(typeof(settings.constant) != "undefined"){
		$("<li></li>").attr("val", "0").text("<#Lang['?'].assignValue>").appendTo($ul);
		$("#" + settings.constant).val(settings.rule.value["0"].constant);
	}

	//registerManager exist
	if(typeof(settings.irMode) != "undefined" && typeof(settings.irModuleKey) != "undefined" && typeof(settings.ir) != "undefined" /*&& typeof(settings.irBit) != "undefined"*/ && typeof(WISE.managers.registerManager) != "undefined"){
		var registerManager = WISE.managers.registerManager;

		if(registerManager.pool.conditions.register.key.length > 0){
			$("<li></li>").attr("val", "1").text(registerManager.pool.conditions.register.name).appendTo($ul);

			WISE.buildRegisterSelector(settings.irMode, settings.irModuleKey, settings.ir, settings.irBit, settings.irModuleHandler, registerManager.pool.conditions.register.key);

			$("#" + settings.irMode).val(settings.rule.value["1"].moduleKey == null ? "0" : "1").triggerHandler("change");
			$("#" + settings.irModuleKey).val(settings.rule.value["1"].moduleKey);
			$("#" + settings.ir).val(settings.rule.value["1"].registerIndex).triggerHandler("change");
			//$("#" + settings.irBit).val(settings.rule.value["1"].bit);
		}
	}

	//moduleManager exist
	if(typeof(settings.source) != "undefined" && typeof(settings.module) != "undefined" && typeof(settings.channel) != "undefined" && typeof(WISE.managers.moduleManager) != "undefined"){
		var moduleManager = WISE.managers.moduleManager;

		//AI
		if(moduleManager.pool.conditions.AI.key.length > 0){
			$("<li></li>").attr("val", "2").text(moduleManager.pool.conditions.AI.name).appendTo($ul);
		}

		//AO
		if(moduleManager.pool.actions.AO.key.length > 0){
			$("<li></li>").attr("val", "3").text(moduleManager.pool.actions.AO.name).appendTo($ul);
		}

		//RI
		if(moduleManager.pool.conditions.RI.key.length > 0){
			$("<li></li>").attr("val", "4").text(moduleManager.pool.conditions.RI.name).appendTo($ul);
		}

		//RO
		if(moduleManager.pool.conditions.RO.key.length > 0){
			$("<li></li>").attr("val", "5").text(moduleManager.pool.actions.RO.name).appendTo($ul);
		}

		//DIC
		if(moduleManager.pool.conditions.DIC.key.length > 0){
			$("<li></li>").attr("val", "7").text(moduleManager.pool.conditions.DIC.name).appendTo($ul);
		}

		//DOC
		if(moduleManager.pool.conditions.DOC.key.length > 0){
			$("<li></li>").attr("val", "8").text(moduleManager.pool.conditions.DOC.name).appendTo($ul);
		}
	}

	//mqttManager exist
	if(typeof(settings.mqttBroker) != "undefined" && typeof(settings.mqttTopic) != "undefined" && typeof(WISE.managers.mqttManager) != "undefined"){
		var mqttManager = WISE.managers.mqttManager;

		if(mqttManager.pool.conditions.topic.key.length > 0){
			$("<li></li>").attr("val", "9").text("MQTT Subscribe Topic").appendTo($ul);

			for(var i = 0, key = mqttManager.pool.conditions.topic.key; i < key.length; i++){
				var broker = mqttManager.pool.brokers[key[i][0]];

				$("#" + settings.mqttBroker).append(
					$("<option></option>").attr("value", key[i][0]).text(broker.name)
				);
			}

			$("#" + settings.mqttBroker).val(settings.rule.value["9"].brokerKey).bind("change", function(){
				$("#" + settings.mqttTopic).empty();

				var topics = mqttManager.pool.brokers[parseInt($(this).val(), 10)].subscribe.topics;
				for(var topicKey in topics){
					var topic = topics[topicKey];

					$("#" + settings.mqttTopic).append(
						$("<option></option>").attr("value", topicKey).text(topic.name)
					);
				}
			}).triggerHandler("change");

			$("#" + settings.mqttTopic).val(settings.rule.value["9"].topicKey);
		}
	}

	//azureManager exist
	if(typeof(settings.azureVariable) != "undefined" && typeof(WISE.managers.azureManager) != "undefined"){
		var azureManager = WISE.managers.azureManager;

		if(azureManager.pool.conditions.subscribe.key.length > 0){
			$("<li></li>").attr("val", "10").text("<#Lang['?'].azureSubscribeMessage>").appendTo($ul);

			for(var i = 0, key = azureManager.pool.conditions.subscribe.key; i < key.length; i++){
				var variable = azureManager.pool.subscribe.variables[key[i]];

				$("#" + settings.azureVariable).append(
					$("<option></option>").attr("value", key[i]).text(variable.key)
				);
			}

			$("#" + settings.azureVariable).val(settings.rule.value["10"].variableKey);
		}
	}

	//bluemixManager exist
	if(typeof(settings.bluemixCommand) != "undefined" && typeof(settings.bluemixVariable) != "undefined" && typeof(WISE.managers.bluemixManager) != "undefined"){
		var bluemixManager = WISE.managers.bluemixManager;

		if(bluemixManager.pool.conditions.subscribe.key.length > 0){
			$("<li></li>").attr("val", "11").text("<#Lang['?'].bluemixSubscribeMessage>").appendTo($ul);

			for(var commandKey in bluemixManager.pool.subscribe.commands){
				var command = bluemixManager.pool.subscribe.commands[commandKey];

				$("#" + settings.bluemixCommand).append(
					$("<option></option>").attr("value", commandKey).text(command.key)
				);
			}

			for(var i = 0, key = bluemixManager.pool.conditions.subscribe.key; i < key.length; i++){
				var variable = bluemixManager.pool.subscribe.variables[key[i]];

				$("#" + settings.bluemixVariable).append(
					$("<option></option>").attr("value", key[i]).text(variable.key)
				);
			}

			$("#" + settings.bluemixCommand).val(settings.rule.value["11"].commandKey != null ? settings.rule.value["11"].commandKey : "-1");
			$("#" + settings.bluemixVariable).val(settings.rule.value["11"].variableKey);
		}
	}

	if(typeof(WISE.createCompareValue.createExtendedCompareValue) == "function"){
		WISE.createCompareValue.createExtendedCompareValue(settings);
	}

	$("#" + settings.type).dropDownList({
		"val": settings.rule.type + (function(){
			if(settings.rule.type == 6){//if extended module exist, append other information
				if(typeof(WISE.createCompareValue.processExtendedCompareDropDownListValue) == "function"){
					return WISE.createCompareValue.processExtendedCompareDropDownListValue(settings);
				}
			}

			return "";
		})(),
		"click": function(li){
			$("#" + settings.constantHandler + ", #" + settings.irHandler + ", #" + settings.moduleHandler + ", #" + settings.mqttHandler + ", #" + settings.azureHandler + ", #" + settings.bluemixHandler).hide();

			var splitArray = $(li).attr("val").split("_");
			var type = parseInt(splitArray[0], 10);

			if(type == 0){
				$("#" + settings.constantHandler).show();
			}
			else if(type == 1){
				$("#" + settings.irHandler).show();
			}
			else if(type >= 2 && type <= 8 && type != 6){
				if(type == 2 || type == 3){//AI, AO
					if(type == 2){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions.AI.key, "AI");
					}
					else if(type == 3){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.actions.AO.key, "AO");
					}

					if(settings.rule.value[type].moduleKey != null){
						var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
						if(moduleInfo != null){
							$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
							$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
							$("#" + settings.channel).val(settings.rule.value[type].channelIndex);
						}
					}

					$("#" + settings.channelPrefix).html("<#Lang.global.channel>");
				}
				else if(type == 4 || type == 5){//RI, RO
					if(type == 4){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions.RI.key, "RI");
					}
					else if(type == 5){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.actions.RO.key, "RO");
					}

					if(settings.rule.value[type].moduleKey != null){
						var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
						if(moduleInfo != null){
							$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
							$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
							$("#" + settings.channel).val(settings.rule.value[type].channelAddress);
						}
					}

					$("#" + settings.channelPrefix).html("<#Lang.global.address>");
				}
				else if(type == 7 || type == 8){//DIC, DOC
					if(type == 7){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions.DIC.key, "DIC");
					}
					else if(type == 8){
						WISE.buildModuleSelector(settings.source, settings.module, settings.channel, moduleManager.pool.conditions.DOC.key, "DOC");
					}

					if(settings.rule.value[type].moduleKey != null){
						var moduleInfo = moduleManager.getModuleInfoByKey(settings.rule.value[type].moduleKey);
						if(moduleInfo != null){
							$("#" + settings.source).val(moduleInfo.sourceType + "_" + moduleInfo.sourceIndex).triggerHandler("change");
							$("#" + settings.module).val(moduleInfo.moduleIndex).triggerHandler("change");
							$("#" + settings.channel).val(settings.rule.value[type].channelIndex);
						}
					}

					$("#" + settings.channelPrefix).html("<#Lang.global.channel>");
				}

				$("#" + settings.moduleHandler).show();
			}
			else if(type == 9){
				$("#" + settings.mqttHandler).show();
			}
			else if(type == 10){
				$("#" + settings.azureHandler).show();
			}
			else if(type == 11){
				$("#" + settings.bluemixHandler).show();
			}

			if(typeof(WISE.createCompareValue.processExtendedCompareDropDownListClick) == "function"){
				WISE.createCompareValue.processExtendedCompareDropDownListClick(li, settings);
			}
		}
	}).dropDownList("click");
};

WISE.saveCompareValue = function(settings){
	var splitArray = $("#" + settings.type).dropDownList("val").split("_");
	var type = parseInt(splitArray[0], 10);

	settings.rule.type = type;

	if(type == 0){
		//settings.rule.value[0].constant = parseFloat($("#" + settings.constant).val());
		settings.rule.value[0].constant = $("#" + settings.constant).val();
	}
	else if(type == 1){
		settings.rule.value[1].moduleKey = $("#" + settings.irMode).val() == "0" ? null : $("#" + settings.irModuleKey).val();
		settings.rule.value[1].registerIndex = parseInt($("#" + settings.ir).val(), 10);
		//settings.rule.value[1].bit = parseInt($("#" + settings.irBit).val(), 10);
	}
	else if(type >= 2 && type <= 8 && type != 6){
		var moduleManager = WISE.managers.moduleManager;
		var compareModule = moduleManager.pool.interfaces[$("#" + settings.source).val().split("_")[0]][parseInt($("#" + settings.source).val().split("_")[1], 10)].modules[parseInt($("#" + settings.module).val(), 10)];

		if(type == 2 || type == 3){//AI, AO
			settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
			settings.rule.value[settings.rule.type].channelIndex = parseInt($("#" + settings.channel).val(), 10);
		}
		else if(type == 4 || type == 5){//RI, RO
			settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
			settings.rule.value[settings.rule.type].channelAddress = parseInt($("#" + settings.channel).val(), 10);
		}
		else if(type == 7 || type == 8){//DIC, DOC
			settings.rule.value[settings.rule.type].moduleKey = compareModule.key;
			settings.rule.value[settings.rule.type].channelIndex = parseInt($("#" + settings.channel).val(), 10);
		}
	}
	else if(type == 9){
		settings.rule.value["9"].brokerKey = parseInt($("#" + settings.mqttBroker).val(), 10);
		settings.rule.value["9"].topicKey = parseInt($("#" + settings.mqttTopic).val(), 10);
	}
	else if(type == 10){
		settings.rule.value["10"].variableKey = parseInt($("#" + settings.azureVariable).val(), 10);
	}
	else if(type == 11){
		settings.rule.value["11"].commandKey = $("#" + settings.bluemixCommand).val() != "-1" ? parseInt($("#" + settings.bluemixCommand).val(), 10) : null;
		settings.rule.value["11"].variableKey = parseInt($("#" + settings.bluemixVariable).val(), 10);
	}

	if(typeof(WISE.saveCompareValue.saveExtendedCompareValue) == "function"){
		WISE.saveCompareValue.saveExtendedCompareValue(settings);
	}
};

