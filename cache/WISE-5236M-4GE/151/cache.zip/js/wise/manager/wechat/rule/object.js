WISE.managers.weChatManager.pool.actions = {
	"message": {
		"name": "<#Lang['?'].weChat>",
		"fileName": "awechat",
		"rule":{
			"messageKey": null,
			"frequency": -1
		},
		"check": function(){
			if(this.rule.messageKey == null){
				return false;
			}
			
			var weChatManager = WISE.managers.weChatManager;
            
            if(weChatManager.pool.enable == false){
				return false;
			}

			if(typeof(weChatManager.pool.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var weChatManager = WISE.managers.weChatManager;
			var message = weChatManager.pool.messages[this.rule.messageKey];

			return this.name + "(" + message.name + ") " + ruleColor("<#Lang['?'].send>", 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.messageKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.weChatManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['message']['key'] = [];

    if(this.pool.enable == true){
        for(var key in this.pool.messages){
            this.pool.actions['message']['key'].push(parseInt(key, 10));
        }
    }
};