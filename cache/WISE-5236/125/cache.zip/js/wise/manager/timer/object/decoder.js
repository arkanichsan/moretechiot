WISE.managers.timerManager.decodeXMLObject = function(xmlDoc){
	var $xmlTIMER = $(xmlDoc).find("WISE > NOTE > TIMER");
	if($xmlTIMER.length > 0){
		var $xmlT = $xmlTIMER.find("> T");
		var maxKey = 0;
		for(var i = 0; i < $xmlT.length; i++){
			var key = parseInt($($xmlT[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var timer = this.createTimer({
				"name": $($xmlT[i]).attr("nickname"),
				"description": $($xmlT[i]).attr("desc"),
				"period": (function(value){
					var matchArray = value.match(/^IR(\d+)$/);
					if(matchArray != null){
						return parseInt(matchArray[1], 10) * -1;
					}
					else{
						return parseInt(value, 10);
					}
				})($($xmlT[i]).attr("value")),
				"initialStatus": parseInt($($xmlT[i]).attr("status"), 10)
			});

			this.setTimer(key, timer);
		}

		this.pool.key = ++maxKey;
	}
};