WISE.managers.bluemixManager.decodeXMLObject = function(xmlDoc){
	var $xmlBLUEMIX = $(xmlDoc).find("WISE > NOTE > IOT > BLUEMIX");
	if($xmlBLUEMIX.length > 0){
		this.pool.enable = true;
		this.pool.organizationID = $xmlBLUEMIX.attr("org_id");
		this.pool.deviceType = $xmlBLUEMIX.attr("device_type");
		this.pool.deviceID = $xmlBLUEMIX.attr("device_id");
		this.pool.deviceAuthenticationToken = $xmlBLUEMIX.attr("auth_token");
		this.pool.keepAliveTimer = parseInt($xmlBLUEMIX.attr("alive_timer"), 10);
		this.pool.publishInterval = parseInt($xmlBLUEMIX.attr("publish_period"), 10);

		var $xmlP = $xmlBLUEMIX.find("> PUBLISH > P");
		if($xmlP.length > 0){
			var maxMessageKey = 0;
			for(var i = 0; i < $xmlP.length; i++){
				var messageKey = parseInt($($xmlP[i]).attr("idx"), 10) - 1;
				if(messageKey > maxMessageKey){maxMessageKey = messageKey};

				var message = this.createPublishMessage({
					"name": $($xmlP[i]).attr("nickname"),
					"description": $($xmlP[i]).attr("desc") || "",

					"eventID": $($xmlP[i]).attr("event_id"),
					"type": parseInt($($xmlP[i]).attr("data_type"), 10),
					"payload": $($xmlP[i]).attr("ch_var") || $($xmlP[i]).attr("data"),
					"json": $($xmlP[i]).attr("use_json") == "1" ? true : false,
					"autoPublish": {
						"timing": (function(){
							var timing = 0;
							if($($xmlP[i]).attr("pub_gate")){
								timing += 1;
							}
							if($($xmlP[i]).attr("period_pub") == "1"){
								timing += 2;
							}
							return timing;
						})(),
						"threshold": parseFloat($($xmlP[i]).attr("pub_gate") || 1)
					}
				});

				this.setPublishMessage(messageKey, message);
			}

			this.pool.publish.key = ++maxMessageKey;
		}

		var $xmlCOMMAND = $xmlBLUEMIX.find("> SUBSCRIBE > COMMAND");
		var maxCommandKey = 0;
		if($xmlCOMMAND.length > 0){
			var commandAttr = $xmlCOMMAND.attr("cmd");
			if(typeof(commandAttr) != "undefined"){
				var splitArray = commandAttr.split(",");
				for(var i = 0; i < splitArray.length; i++){
					maxCommandKey = i;

					var command = this.createSubscribeCommand({
						"key": splitArray[i]
					});

					this.setSubscribeCommand(i, command);
				}
			}
		}
		this.pool.subscribe.commandKey = ++maxCommandKey;

		var $xmlMESSAGE = $xmlBLUEMIX.find("> SUBSCRIBE > MESSAGE");
		var maxVariableKey = 0;
		if($xmlMESSAGE.length > 0){
			var variableAttr = $xmlMESSAGE.attr("key");
			if(typeof(variableAttr) != "undefined"){
				var splitArray = variableAttr.split(",");
				for(var i = 0; i < splitArray.length; i++){
					maxVariableKey = i;

					var variable = this.createSubscribeVariable({
						"key": splitArray[i]
					});

					this.setSubscribeVariable(i, variable);
				}
			}
		}

		this.pool.subscribe.variableKey = ++maxVariableKey;
	}
};
