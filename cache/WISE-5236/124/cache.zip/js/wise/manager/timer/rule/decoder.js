WISE.managers.timerManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "TIMER"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.timer);
			ruleObject.rule.timerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.timer);
			ruleObject.rule.timerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
	}

	return ruleObject;
};