WISE.managers.lineNotifyManager.decodeXMLObject = function(xmlDoc){
	var maxKey = 0;

	var $xmlMESSAGE = $(xmlDoc).find("WISE > NOTE > LINE_NOTIFY > MESSAGE");
	if($xmlMESSAGE.length > 0){
		maxKey = 0;

		var $xmlM = $xmlMESSAGE.find("> M");
		for(var i = 0; i < $xmlM.length; i++){
			var key = parseInt($($xmlM[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var message = this.createMessage({
				"name": $($xmlM[i]).attr("nickname"),
				"description": $($xmlM[i]).attr("desc") || "",
				"chatRooms": (function(chatRooms){
					for(var i = 0; i < chatRooms.length; i++){
						chatRooms[i]--;
					}
					return chatRooms;
				})($($xmlM[i]).attr("target_token").split(",")),
				"content": $($xmlM[i]).text()
			});

			this.setMessage(key, message);
		}

		this.pool.messageKey = ++maxKey;
	}

	var $xmlCAMERA = $(xmlDoc).find("WISE > NOTE > LINE_NOTIFY > CAMERA");
	if($xmlCAMERA.length > 0){
		var moduleManager = WISE.managers.moduleManager;

		var $xmlC = $xmlCAMERA.find("> C");
		for(var i = 0; i < $xmlC.length; i++){
			var moduleIndex = parseInt($($xmlC[i]).attr("camera_idx") - 1);

			var $xmlMSG = $($xmlC[i]).find("> MSG");
			if($xmlMSG.length > 0){
				moduleManager.pool.interfaces.camera[0].modules[moduleIndex].lineNotify = {
					"enable": true,
					"content": $xmlMSG.text(),
					"chatRooms": (function(){
						var chatRooms = $xmlMSG.attr("target_token").split(",");
						for(var i = 0; i < chatRooms.length; i++){
							chatRooms[i]--;
						}
						return chatRooms;
					})()
				};
			}
		}
	}

	var $xmlTOKEN = $(xmlDoc).find("WISE > NOTE > LINE_NOTIFY > TOKEN");
	if($xmlTOKEN.length > 0){
		maxKey = 0;

		var $xmlT = $xmlTOKEN.find("> T");
		for(var i = 0; i < $xmlT.length; i++){
			var key = parseInt($($xmlT[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var chatRoom = this.createChatRoom({
				"name": $($xmlT[i]).attr("nickname"),
				"description": $($xmlT[i]).attr("desc") || "",
				"token": $($xmlT[i]).attr("token"),
				"type": $($xmlT[i]).attr("type")
			});

			this.setChatRoom(key, chatRoom);
		}

		this.pool.chatRoomKey = ++maxKey;
	}
};