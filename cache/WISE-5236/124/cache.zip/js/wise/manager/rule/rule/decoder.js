WISE.managers.ruleManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "RULE"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.ruleStatus);
			ruleObject.rule.ruleKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.ruleStatus);
			ruleObject.rule.ruleKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
	}

	return ruleObject;
};
