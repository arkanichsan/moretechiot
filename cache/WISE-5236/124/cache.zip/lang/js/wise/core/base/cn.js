$.extend(true, Lang, {
	"js/wise/core/base.js": {
		"camera": "网络摄影机"
	}
});