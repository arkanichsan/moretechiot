(function($) {
	$.guideLine = function(selector, settings){
		$.guideLine.storyline.push([selector, settings]);

		return $;
	};

	$.guideLine.storyline = [];
	$.guideLine.livequery = [];

	$.guideLine.start = function(globalSettings){
		globalSettings = $.extend(true, {
			"eventType": "click",
			"handler": function(){return true;},
			"delay": false,
			"spotLight": {
				"close": function(){
					$.guideLine.stop();
				}
			}
		}, globalSettings);

		var stage = $.guideLine.storyline.shift();
		var camera = function(){
			$(stage[0]).spotLight(stage[1].spotLight).unbind(stage[1].eventType + ".guideLine").bind(stage[1].eventType + ".guideLine", function(){
				if(stage[1].handler.call(this) == true){
					$.guideLine.start();
				}
			});
		};

		if(stage){
			stage[1] = $.extend(true, globalSettings, stage[1]);

			if(stage[1].delay == true){
				$(stage[0]).livequery(camera);
				$.guideLine.livequery.push([stage[0], camera]);
			}
			else{
				camera();
			}
		}
	};

	$.guideLine.stop = function(){
		$.each($.guideLine.livequery, function(index, value){
			$(value[0]).expire(value[1]);
		});

		$.guideLine.storyline = [];
		$.guideLine.livequery = [];
	};
})(jQuery);
