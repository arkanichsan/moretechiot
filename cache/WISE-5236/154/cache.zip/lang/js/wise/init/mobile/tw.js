$.extend(true, Lang, {
	"js/wise/init/mobile.js": {
		"internalRegister": "內部暫存器",
		"no": "編號",
		"channel": "通道",
		"address": "位址",
		"counter": "計數器:",
		"enterValue": "請輸入數值：",
		"valueOfChannel": "$channel數值：",
		"none": "無",
		"diCounterX": "DI計數器$channel",
		"doCounterX": "DO計數器$channel",
		"internalRegisterX": "內部暫存器$channel",
		"ch": "通道",
		"outputChannel": "輸出通道",
		"availableCommand": "可用命令",
		"transmit": "傳送",
		"popup": {
			"areYouSureYouWantToLogout": "您確定要登出嗎？",
			"idleTooLong": "您閒置過久，為了安全起見系統已將您登出，請重新登入即可。",
			"module": "模組：",
			"channel": "通道：",
			"value": "數值：",
			"outputChannelIsEmpty": "沒有選擇輸出通道，請至少勾選一個輸出通道後再按傳送。"
		}
	}
});