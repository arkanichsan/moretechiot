WISE.managers.moduleManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

/*
	xmlDoc.setAttributes = function(attributes){
		for(var name in attributes){
			var value = attributes[name];
			this.setAttribute(name, value);
		}
	}
*/
	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "DI"){
/*
			xmlDoc.setAttributes({
				"l_obj": "DCON",
				"l_com": ruleObject.rule.sourceIndex,
				"l_idx": ruleObject.rule.moduleIndex,
				"l_ch": "DI",
				"l_chn": ruleObject.rule.channelIndex,
				"op": ruleObject.rule.value
			});
*/

			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "DI", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "DI");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}

			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "DIC"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "DIC", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "DIC");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.operate < 5){
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(ruleObject.ruleObjectKey == "DO"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "DO", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "DO");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}

			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "DOC"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "DOC", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			//else{
			//	xmlDoc.setAttribute("l_ch", "DOC");
			//	xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			//}
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.operate < 5){
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(ruleObject.ruleObjectKey == "AI"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "AI", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "AI");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.deadband > 0){
				xmlDoc.setAttribute("deadband", ruleObject.rule.deadband);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "AO"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "AO", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "AO");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.deadband > 0){
				xmlDoc.setAttribute("deadband", ruleObject.rule.deadband);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "CI"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "CI");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "CO"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "CO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "RI"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "RI");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.deadband > 0){
				xmlDoc.setAttribute("deadband", ruleObject.rule.deadband);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "RO"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "RO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);

			if(ruleObject.rule.deadband > 0){
				xmlDoc.setAttribute("deadband", ruleObject.rule.deadband);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "cameraDI"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "GPIO_DI");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "cameraDO"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "GPIO_DO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "cameraEvent"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "Event");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.commandIndex + 1);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
		else if(ruleObject.ruleObjectKey == "status"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "STATUS");
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "DIC"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var modbusInfo = this.icpdasModule.remoteModuleInformation[module.moduleType][module.mainType][module.subType][6][0][3];
				xmlDoc.setAttribute("l_ch", modbusInfo[0]);
				xmlDoc.setAttribute("l_chn", modbusInfo[1] + ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("op", "1");
			}
			else{
				xmlDoc.setAttribute("l_ch", "DIC");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "DO"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "DO", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "DO");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}
			xmlDoc.setAttribute("op", {0: "0", 1: "2", 10: "1", 11: "3", 20: "4"}[ruleObject.rule.value * 10 + ruleObject.rule.frequency]);
		}
		else if(ruleObject.ruleObjectKey == "AO"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
			var module = moduleInfo.module;

			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
				var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "AO", ruleObject.rule.channelIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}
			else{
				xmlDoc.setAttribute("l_ch", "AO");
				xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			}

			if(ruleObject.rule.frequency == 1){
				xmlDoc.setAttribute("op", ruleObject.rule.operate + 3);
			}
			else if(ruleObject.rule.frequency == 0){
				xmlDoc.setAttribute("op", ruleObject.rule.operate);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "CO"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "CO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);

			if(ruleObject.rule.frequency == 1){
				xmlDoc.setAttribute("op", ruleObject.rule.value + 2);
			}
			else if(ruleObject.rule.frequency == 0){
				xmlDoc.setAttribute("op", ruleObject.rule.value);
			}
		}
		else if(ruleObject.ruleObjectKey == "RO"){
			processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_ch", "RO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelAddress);

			if(ruleObject.rule.frequency == 1){
				xmlDoc.setAttribute("op", ruleObject.rule.operate + 3);
			}
			else if(ruleObject.rule.frequency == 0){
				xmlDoc.setAttribute("op", ruleObject.rule.operate);
			}

			processCompareModule(xmlDoc, ruleObject);
		}
		else if(ruleObject.ruleObjectKey == "IR"){
			var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
			var module = moduleInfo.module;

			var channelAddressInfo = this.icpdasModule.channelIndexToAddress(module, "AO", 0);
			xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);

			if(ruleObject.rule.frequency == 1){
				xmlDoc.setAttribute("op", ruleObject.rule.operate + 3);
			}
			else if(ruleObject.rule.frequency == 0){
				xmlDoc.setAttribute("op", ruleObject.rule.operate);
			}

			xmlDoc.setAttribute("r_obj", (ruleObject.rule.outputChannel << 16) + (ruleObject.rule.commandIndex + 1));
		}
		else if(ruleObject.ruleObjectKey == "cameraDO"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "GPIO_DO");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.channelIndex);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
//		else if(ruleObject.ruleObjectKey == "cameraEvent"){
//			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
//			xmlDoc.setAttribute("l_obj", "CAMERA");
//			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
//			xmlDoc.setAttribute("l_ch", "Event");
//			xmlDoc.setAttribute("l_chn", ruleObject.rule.commandIndex + 1);
//			xmlDoc.setAttribute("op", "0");
//		}
		else if(ruleObject.ruleObjectKey == "cameraSnapshot"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "Snapshot");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.commandIndex + 1);
			xmlDoc.setAttribute("op", "0");

			if(moduleManager.icpdasModule.isSupportOSDCamera(moduleInfo.module)){
				xmlDoc.setAttribute("osd_idx", ruleObject.rule.osdKey == null ? "0" : moduleInfo.module.osd.osds[ruleObject.rule.osdKey].index);
			}
		}
		else if(ruleObject.ruleObjectKey == "cameraVideo"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "Video");
			xmlDoc.setAttribute("l_chn", ruleObject.rule.commandIndex + 1);
			xmlDoc.setAttribute("op", "0");

			if(moduleManager.icpdasModule.isSupportRecordSpecifiedLengthVideo(moduleInfo.module)){
				xmlDoc.setAttribute("video_len", ruleObject.rule.recordLength);
			}

			if(moduleManager.icpdasModule.isSupportOSDCamera(moduleInfo.module)){
				xmlDoc.setAttribute("osd_idx", ruleObject.rule.osdKey == null ? "0" : moduleInfo.module.osd.osds[ruleObject.rule.osdKey].index);
			}
		}
		else if(ruleObject.ruleObjectKey == "cameraOSD"){
			var moduleInfo = moduleManager.getModuleInfoByKey(ruleObject.rule.moduleKey);
			xmlDoc.setAttribute("l_obj", "CAMERA");
			xmlDoc.setAttribute("l_idx", moduleInfo.moduleIndex + 1);
			xmlDoc.setAttribute("l_ch", "OSD");
			xmlDoc.setAttribute("l_chn", moduleInfo.module.osd.osds[ruleObject.rule.osdKey].index);
			xmlDoc.setAttribute("op", "0");
		}
	}
};

WISE.managers.moduleManager.encodeXMLRule.processModuleInfo = function(xmlDoc, attributePrefix, moduleKey){
	var moduleManager = WISE.managers.moduleManager;
	var moduleInfo = moduleManager.getModuleInfoByKey(moduleKey);
	var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

	if(module.type == "icpdas"){
		if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "dcon"){//M7K
			xmlDoc.setAttribute(attributePrefix + "_obj", "DCON");
		}
		else if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "modbusRTU"){
			xmlDoc.setAttribute(attributePrefix + "_obj", "RTU");
		}
		else if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "modbusTCP"){
			xmlDoc.setAttribute(attributePrefix + "_obj", "TCP");
		}
		else if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol == "httpCGI"){
			xmlDoc.setAttribute(attributePrefix + "_obj", "CAMERA");
		}

		if(moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].type == "comport485"){
			xmlDoc.setAttribute(attributePrefix + "_com", moduleInfo.sourceIndex);
		}

		xmlDoc.setAttribute(attributePrefix + "_idx", moduleInfo.moduleIndex + 1);
	}
	else if(module.type == "onboard"){
		xmlDoc.setAttribute(attributePrefix + "_obj", "XBOARD");
	}
	else if(module.type == "rtu"){
		xmlDoc.setAttribute(attributePrefix + "_obj", "RTU");
		xmlDoc.setAttribute(attributePrefix + "_com", moduleInfo.sourceIndex);
		xmlDoc.setAttribute(attributePrefix + "_idx", moduleInfo.moduleIndex + 1);
	}
	else if(module.type == "tcp"){
		xmlDoc.setAttribute(attributePrefix + "_obj", "TCP");
		xmlDoc.setAttribute(attributePrefix + "_idx", moduleInfo.moduleIndex + 1);
	}

	return moduleInfo;
};

WISE.managers.moduleManager.encodeXMLRule.processCompareModule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;

	if(ruleObject.rule.type == 0){
		xmlDoc.setAttribute("r_obj", ruleObject.rule.value[0].constant);
	}
	else if(ruleObject.rule.type == 1){
		xmlDoc.setAttribute("r_obj", "IR");
		xmlDoc.setAttribute("r_idx", ruleObject.rule.value[1].registerIndex + 1);

		if(ruleObject.rule.value[1].moduleKey == null){
			xmlDoc.setAttribute("r_obj", "IR");
			xmlDoc.setAttribute("r_idx", ruleObject.rule.value[1].registerIndex + 1);
		}
		else{
			var moduleInfo = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[1].moduleKey);
			var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", ruleObject.rule.value[1].registerIndex);
			xmlDoc.setAttribute("r_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("r_chn", channelAddressInfo[1]);
		}
	}
	else if(ruleObject.rule.type == 2){
		var moduleInfo = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[2].moduleKey);
		var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
		var module = moduleInfo.module;

		if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){
			var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, "AI", ruleObject.rule.value[2].channelIndex);
			xmlDoc.setAttribute("r_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("r_chn", channelAddressInfo[1]);
		}
		else{
			xmlDoc.setAttribute("r_ch", "AI");
			xmlDoc.setAttribute("r_chn", ruleObject.rule.value[2].channelIndex);
		}
	}
	else if(ruleObject.rule.type == 3){
		var moduleInfo = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[3].moduleKey);
		var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
		var module = moduleInfo.module;

		if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){
			var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, "AO", ruleObject.rule.value[3].channelIndex);
			xmlDoc.setAttribute("r_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("r_chn", channelAddressInfo[1]);
		}
		else{
			xmlDoc.setAttribute("r_ch", "AO");
			xmlDoc.setAttribute("r_chn", ruleObject.rule.value[3].channelIndex);
		}
	}
	else if(ruleObject.rule.type == 4){
		processModuleInfo(xmlDoc, "r", ruleObject.rule.value[4].moduleKey);
		xmlDoc.setAttribute("r_ch", "RI");
		xmlDoc.setAttribute("r_chn", ruleObject.rule.value[4].channelAddress);
	}
	else if(ruleObject.rule.type == 5){
		processModuleInfo(xmlDoc, "r", ruleObject.rule.value[5].moduleKey);
		xmlDoc.setAttribute("r_ch", "RO");
		xmlDoc.setAttribute("r_chn", ruleObject.rule.value[5].channelAddress);
	}
	else if(ruleObject.rule.type == 7){
		var moduleInfo = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[7].moduleKey);
		var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
		var module = moduleInfo.module;

		if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
			var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, "DIC", ruleObject.rule.value[7].channelIndex);
			xmlDoc.setAttribute("r_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("r_chn", channelAddressInfo[1]);
		}
		else{
			xmlDoc.setAttribute("r_ch", "DIC");
			xmlDoc.setAttribute("r_chn", ruleObject.rule.value[7].channelIndex);
		}
	}
	else if(ruleObject.rule.type == 8){
		var moduleInfo = processModuleInfo(xmlDoc, "r", ruleObject.rule.value[8].moduleKey);
		var protocol = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].protocol;
		var module = moduleInfo.module;

		if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K, encoded to modbus RTU
			var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(module, "DOC", ruleObject.rule.value[8].channelIndex);
			xmlDoc.setAttribute("r_ch", channelAddressInfo[0]);
			xmlDoc.setAttribute("r_chn", channelAddressInfo[1]);
		}
		else{
			xmlDoc.setAttribute("r_ch", "DOC");
			xmlDoc.setAttribute("r_chn", ruleObject.rule.value[8].channelIndex);
		}
	}
	else if(ruleObject.rule.type == 9){
		xmlDoc.setAttribute("r_obj", "MQTT");
		xmlDoc.setAttribute("r_idx", WISE.managers.mqttManager.pool.brokers[ruleObject.rule.value[9].brokerKey].index);
		xmlDoc.setAttribute("r_ch", "SUB");
		xmlDoc.setAttribute("r_chn", WISE.managers.mqttManager.pool.brokers[ruleObject.rule.value[9].brokerKey].subscribe.topics[ruleObject.rule.value[9].topicKey].index);
	}
	else if(ruleObject.rule.type == 10){
		xmlDoc.setAttribute("r_obj", "AZURE");
		xmlDoc.setAttribute("r_ch", "SUB");
		xmlDoc.setAttribute("r_chn", WISE.managers.azureManager.pool.subscribe.variables[ruleObject.rule.value[10].variableKey].index);
	}
	else if(ruleObject.rule.type == 11){
		xmlDoc.setAttribute("r_obj", "BLUEMIX");

		if(ruleObject.rule.value[11].commandKey != null){
			xmlDoc.setAttribute("r_idx", WISE.managers.bluemixManager.pool.subscribe.commands[ruleObject.rule.value[11].commandKey].index);
		}

		xmlDoc.setAttribute("r_ch", "SUB");
		xmlDoc.setAttribute("r_chn", WISE.managers.bluemixManager.pool.subscribe.variables[ruleObject.rule.value[11].variableKey].index);
	}
};
