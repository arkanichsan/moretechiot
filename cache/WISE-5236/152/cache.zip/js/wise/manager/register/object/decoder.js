WISE.managers.registerManager.decodeXMLObject = function(xmlDoc){
	var $xmlIR = $(xmlDoc).find("WISE > IR");
	if($xmlIR.length > 0){
		var $xmlIs = $xmlIR.find("> I");
		for(var i = 0; i < $xmlIs.length; i++){
			var $xmlI = $($xmlIs[i]);

			var register = this.createRegister({
				"name": $xmlI.attr("nickname"),
				"description": $xmlI.attr("desc"),
				"initialValue": parseFloat($xmlI.attr("value")),
				"type": parseFloat($xmlI.attr("type")),
				"bitName": (function(){
					var nameArray = [];
					var $xmlBs = $xmlI.find("> B");
					for(var j = 0; j < $xmlBs.length; j++){
						var $xmlB = $($xmlBs[j]);
						nameArray[parseInt($xmlB.attr("idx"), 10) - 1] = $xmlB.attr("nickname");
					}
					return nameArray;
				})(),
				"equation": (function(){
					var expression = $xmlI.attr("formula");

					if(typeof(expression) != "undefined"){
						return {
							"enable": true,
							"expression": expression
						};
					}
				})()
			});

			this.pool.registers[parseInt($xmlI.attr("idx"), 10) - 1] = register;
		}
	}
};
