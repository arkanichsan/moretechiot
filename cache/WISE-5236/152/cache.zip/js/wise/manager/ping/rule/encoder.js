WISE.managers.pingManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "ping"){
			xmlDoc.setAttribute("l_obj", "PING");
			xmlDoc.setAttribute("l_idx", this.pool.pings[ruleObject.rule.pingKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
};
