WISE.managers.activeioManager = (function(){
	return new function() {
		this.pool = {
			slave: {
				enable: false,//send back
				ip: 0,
				port: 502,
				netID: 1,
				timeout: 300,//ms
				update: {
					timing: 0,//bit0(1): when chagne, bit1(2): fixed interval
					threshold: 1,
					interval: 5//seconds
				},
				startAddress: {
					coil: 0,
					register: 0
				}
			},
			table: {
				coil: [],
				register: []
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.startAddress = 50000;
		this.maxRegisterAmount = 3000;

		this.generateTip = function(block){
			if(typeof(block.registerIndex) != "undefined"){
				if(block.moduleKey == null){
					return "<#Lang['?'].internalRegisterX>".replace("$channel", WISE.registerInfo(block.registerIndex));
				}
				else{
					var moduleManager = WISE.managers.moduleManager;
					var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
					var interfaceName = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name;
					var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

					return interfaceName + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + "<br>" + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", block.registerIndex).toString("<#Lang['?'].internalRegisterX>");
				}
			}
			else{
				var moduleManager = WISE.managers.moduleManager;
				var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
				var interfaceName = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name;
				var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

				var channelTypeName = {
					"DI": "DI$channel",
					"DIC": "<#Lang['?'].diCounterX>",
					"DO": "DO$channel",
					"DOC": "<#Lang['?'].doCounterX>",
					"AI": "AI$channel",
					"AO": "AO$channel",
					"CI": "Discrete Input $channel",
					"CO": "Coil Output $channel",
					"RI": "Input Register $channel",
					"RO": "Holding Register $channel"
				}[block.channelType];

				return interfaceName + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + "<br>" + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, block.channelType, block.channel).toString(channelTypeName);
			}
		};

		this.generateVariable = function(block){
			if(typeof(block.registerIndex) != "undefined"){
				if(block.moduleKey == null){
					return "IR" + (block.registerIndex + 1);
				}
				else{
					var moduleManager = WISE.managers.moduleManager;
					var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);

					return "L" + "N" + (moduleInfo.moduleIndex + 1) + "IR" + (block.registerIndex + 1);
				}
			}
			else{
				var moduleManager = WISE.managers.moduleManager;
				var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);

				return {
					"onboard": "X",
					"comport": "C" + moduleInfo.sourceIndex + "N" + (moduleInfo.moduleIndex + 1),
					"network": "L" + "N" + (moduleInfo.moduleIndex + 1),
					"camera": "K" + "N" + (moduleInfo.moduleIndex + 1)
				}[moduleInfo.sourceType] + "<br>" + ({
					"CI": "1" + padding(block.channel, "5", "0"),
					"CO": "0" + padding(block.channel, "5", "0"),
					"RI": "3" + padding(block.channel, "5", "0"),
					"RO": "4" + padding(block.channel, "5", "0")
				}[block.channelType] || block.channelType + block.channel);
			}
		};

		this.calculateSize = function(block){
			if(typeof(block.registerIndex) != "undefined"){
				if(block.moduleKey == null){
					var registerManager = WISE.managers.registerManager;
					if(registerManager.pool.registers[block.registerIndex].type < 2){
						return ["register", 16];
					}
					else{
						return ["register", 32];
					}
				}
				else{
					return ["register", 32];
				}
			}
			else{
				var moduleManager = WISE.managers.moduleManager;
				var moduleInfo = moduleManager.getModuleInfoByKey(block.moduleKey);
				var module = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].modules[moduleInfo.moduleIndex];

				if(block.channelType == "DI" || block.channelType == "DO" || block.channelType == "CI" || block.channelType == "CO"){
					return ["coil", 16];
				}
				else if(block.channelType == "DIC"){
					if(moduleManager.icpdasModule.is32BitsDICounterModule(module)){
						return ["register", 32];
					}
					else{
						return ["register", 16];
					}
				}
				else if(block.channelType == "DOC"){
					return ["register", 16];
				}
				else if(block.channelType == "AI" || block.channelType == "AO"){
						return ["register", 32];
				}
				else if(block.channelType == "RI" || block.channelType == "RO"){
					var channelBlock = module[block.channelType].blockArray[module[block.channelType].remoteAddress[block.channel].blockIndex];

					if(channelBlock.type < 2 && channelBlock.scaleRatio == 1 && channelBlock.offset == 0){
						return ["register", 16];
					}
					else{
						return ["register", 32];
					}
				}
			}
		}
	};
})();
