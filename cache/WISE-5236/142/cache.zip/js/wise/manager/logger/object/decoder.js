WISE.managers.loggerManager.decodeXMLObject = function(xmlDoc){
	var processFTPAttribute = function(attribute){
		var ftpServers = attribute != "" ? attribute.split(",") : [];
		for(var i = 0; i < ftpServers.length; i++){
			ftpServers[i] -= 1;
		}
		return ftpServers;
	};

	var $xmlDATALOG = $(xmlDoc).find("WISE > NOTE > DATALOG");
	if($xmlDATALOG.length > 0){
		//data logger(module)
		var $xmlALL_LOG = $xmlDATALOG.find("ALL_LOG");
		if($xmlALL_LOG.length > 0){
			this.pool.dataLogger.module.enable = true;
			this.pool.dataLogger.module.fileName = $xmlALL_LOG.attr("name");
			this.pool.dataLogger.module.sampleRate = parseInt($xmlALL_LOG.attr("sample_rate"), 10);
			this.pool.dataLogger.module.timeStamp = $xmlALL_LOG.attr("time_format");
			this.pool.dataLogger.module.filePeriod = parseInt($xmlALL_LOG.attr("upload_period"), 10);
			this.pool.dataLogger.module.csvHeader = parseInt($xmlALL_LOG.attr("header_type"), 10);
			this.pool.dataLogger.module.useBOM = $xmlALL_LOG.attr("bom") == "1" ? true : false;
			this.pool.dataLogger.module.ftpServers = processFTPAttribute($xmlALL_LOG.attr("ftp"));
			this.pool.dataLogger.module.emailKey = parseInt($xmlALL_LOG.attr("email") || 0, 10) - 1;
			this.pool.dataLogger.module.cloud = $xmlALL_LOG.attr("cloud") == "1" ? true : false;
		}

		//data logger(customized)
		var $xmlCUSTOM_LOG = $xmlDATALOG.find("CUSTOM_LOG");
		if($xmlCUSTOM_LOG.length > 0){
			var $xmlC = $xmlCUSTOM_LOG.find("> C");
			var maxKey = 0;
			for(var i = 0; i < $xmlC.length; i++){
				var key = parseInt($($xmlC[i]).attr("idx"), 10) - 1;
				if(key > maxKey){maxKey = key};

				var log = this.createLog({
					"name": $($xmlC[i]).attr("nickname"),
					"description": $($xmlC[i]).attr("desc") || "",

					"fileName": $($xmlC[i]).attr("name"),
					"sampleRate": parseInt($($xmlC[i]).attr("sample_rate"), 10),
					"timeStamp": $($xmlC[i]).attr("time_format"),
					"filePeriod": parseInt($($xmlC[i]).attr("upload_period"), 10),
					"csvHeader": parseInt($($xmlC[i]).attr("header_type"), 10),
					"useBOM": $($xmlC[i]).attr("bom") == "1" ? true : false,
					"ftpServers": processFTPAttribute($($xmlC[i]).attr("ftp")),
					"emailKey": parseInt($($xmlC[i]).attr("email") || 0, 10) - 1,
					"format": $($xmlC[i]).attr("content")
				});

				this.setLog(key, log);
			}

			this.pool.dataLogger.customized.key = ++maxKey;
		}

		//data logger(mqtt)
		var $xmlMQTT_LOG = $xmlDATALOG.find("MQTT_LOG");
		if($xmlMQTT_LOG.length > 0){
			this.pool.dataLogger.mqtt.enable = true;
			this.pool.dataLogger.mqtt.timeStamp = $xmlMQTT_LOG.attr("time_format");
			this.pool.dataLogger.mqtt.filePeriod = parseInt($xmlMQTT_LOG.attr("upload_period"), 10);
			this.pool.dataLogger.mqtt.useBOM = $xmlMQTT_LOG.attr("bom") == "1" ? true : false;
			this.pool.dataLogger.mqtt.ftpServers = processFTPAttribute($xmlMQTT_LOG.attr("ftp"));
			this.pool.dataLogger.mqtt.emailKey = parseInt($xmlMQTT_LOG.attr("email") || 0, 10) - 1;
		}

		//event logger
		var $xmlEVENTLOG = $xmlDATALOG.find("EVENT_LOG");
		if($xmlEVENTLOG.length > 0){
			this.pool.eventLogger.uploadFrequency = $xmlEVENTLOG.attr("upload_period");
			if(this.pool.eventLogger.uploadFrequency > 0){
				this.pool.eventLogger.uploadTiming.hour = $xmlEVENTLOG.attr("upload_hour");
				this.pool.eventLogger.uploadTiming.minute = $xmlEVENTLOG.attr("upload_minute");

				if(this.pool.eventLogger.uploadFrequency > 1){
					this.pool.eventLogger.uploadTiming.day = $xmlEVENTLOG.attr("upload_day");
				}
			}
			this.pool.eventLogger.ftpServers = processFTPAttribute($xmlEVENTLOG.attr("ftp"));
		}

		//ftp server
		var $xmlFTP = $xmlDATALOG.find("FTP");
		if($xmlFTP.length > 0){
			var $xmlF = $xmlFTP.find("> F");
			var maxKey = 0;
			for(var i = 0; i < $xmlF.length; i++){
				var key = parseInt($($xmlF[i]).attr("idx"), 10) - 1;
				if(key > maxKey){maxKey = key};

				var server = this.createServer({
					"name": $($xmlF[i]).attr("nickname"),
					"description": $($xmlF[i]).attr("desc") || "",

					"address": $($xmlF[i]).attr("url"),
					"port": parseInt($($xmlF[i]).attr("port"), 10),
					"account": $($xmlF[i]).attr("account"),
					"password": {
						"plain": padding("", $($xmlF[i]).attr("password_len"), "*"),
						"encoded": $($xmlF[i]).attr("password"),
						"length": parseInt($($xmlF[i]).attr("password_len"), 10)
					},
					"path": $($xmlF[i]).attr("path")
				});

				this.setServer(key, server);
			}

			this.pool.ftp.key = ++maxKey;
		}
	}
};
