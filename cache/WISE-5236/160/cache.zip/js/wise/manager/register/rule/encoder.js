WISE.managers.registerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "register"){
			if(ruleObject.rule.moduleKey == null){
				xmlDoc.setAttribute("l_obj", "IR");
				xmlDoc.setAttribute("l_idx", ruleObject.rule.registerIndex + 1);
				if(ruleObject.rule.bit >= 0){
					xmlDoc.setAttribute("l_ch", ruleObject.rule.bit + 1);//start from 1
					xmlDoc.setAttribute("op", ruleObject.rule.value[0].constant);
				}
				else{
					xmlDoc.setAttribute("op", ruleObject.rule.operate);
					processCompareModule(xmlDoc, ruleObject);
				}
			}
			else{
				var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
				var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", ruleObject.rule.registerIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
				xmlDoc.setAttribute("op", ruleObject.rule.operate);
				processCompareModule(xmlDoc, ruleObject);
			}
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "register"){
			if(ruleObject.rule.moduleKey == null){
				xmlDoc.setAttribute("l_obj", "IR");
				xmlDoc.setAttribute("l_idx", ruleObject.rule.registerIndex + 1);
			}
			else{
				var moduleInfo = processModuleInfo(xmlDoc, "l", ruleObject.rule.moduleKey);
				var channelAddressInfo = WISE.managers.moduleManager.icpdasModule.channelIndexToAddress(moduleInfo.module, "IR", ruleObject.rule.registerIndex);
				xmlDoc.setAttribute("l_ch", channelAddressInfo[0]);
				xmlDoc.setAttribute("l_chn", channelAddressInfo[1]);
			}

			xmlDoc.setAttribute("op", {0: "0", 1: "3", 10: "1", 11: "4", 20: "2", 21: "5", 30: "6", 31: "8", 40: "7", 41: "9", 50: "10", 51: "11"}[ruleObject.rule.operate * 10 + ruleObject.rule.frequency]);
			processCompareModule(xmlDoc, ruleObject);
		}
	}
};
