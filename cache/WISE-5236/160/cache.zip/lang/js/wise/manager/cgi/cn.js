$.extend(true, Lang, {
    "js/wise/manager/cgi/rule/object.js": {
		"cgiCommand": "CGI命令",
		"fromX": "来自$address",
		"local": "本机",
		"remote": "远程",
		"internalRegister": "内部缓存器",
		"send": "传送",
		"resetVariable": "重置参数",
		"reset": "重置"
    }
});