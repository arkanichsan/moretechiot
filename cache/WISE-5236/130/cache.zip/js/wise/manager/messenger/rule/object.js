WISE.managers.messengerManager.pool.actions = {
	"message": {
		"name": "<#Lang['?'].messenger>",
		"fileName": "amessenger",
		"rule":{
			"messageKey": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.messageKey == null){
				return false;
			}
			
			var messengerManager = WISE.managers.messengerManager;
            
            if(messengerManager.pool.enable == false){
				return false;
			}

			if(typeof(messengerManager.pool.messages[this.rule.messageKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var messengerManager = WISE.managers.messengerManager;
			var message = messengerManager.pool.messages[this.rule.messageKey];
			var valueString = ["<#Lang['?'].send>"];

			return this.name + "(" + message.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.messageKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.messengerManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['message']['key'] = [];

    if(this.pool.enable == true){
        for(var key in this.pool.messages){
            this.pool.actions['message']['key'].push(parseInt(key, 10));
        }
    }
};