WISE.managers.cgiManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "CGI"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.cgiCommand);
			ruleObject.rule.variableKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			if($(xmlDoc).attr("l_ch")){
				ruleObject.rule.clientKey = parseInt($(xmlDoc).attr("l_ch"), 10) - 1;
			}
			ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
			processCompareModule(xmlDoc, ruleObject);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("op") == "0" || $(xmlDoc).attr("op") == "1"){
				ruleObject = WISE.createRuleObject(this.pool.actions.cgiCommand);
				ruleObject.rule.serverKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.commandKey = parseInt($(xmlDoc).attr("l_ch"), 10) - 1;

				var code = {"0": 0, "1": 1}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("op") == "2" || $(xmlDoc).attr("op") == "3"){
				ruleObject = WISE.createRuleObject(this.pool.actions.cgiVariable);
				ruleObject.rule.variableKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				if(typeof($(xmlDoc).attr("l_ch")) != "undefined"){
					ruleObject.rule.clientKey = parseInt($(xmlDoc).attr("l_ch"), 10) - 1;
				}

				var code = {"2": 0, "3": 1}[$(xmlDoc).attr("op")];
				ruleObject.rule.value = Math.floor(code / 10);
				ruleObject.rule.frequency = code % 10;
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
		}
	}

	return ruleObject;
};
