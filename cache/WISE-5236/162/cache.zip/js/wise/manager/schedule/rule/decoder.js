WISE.managers.scheduleManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;

	if($(xmlDoc).attr("l_obj") == "SCHEDULE"){
		if(xmlDoc.tagName == "IF"){
			ruleObject = WISE.createRuleObject(this.pool.conditions.schedule);
			ruleObject.rule.scheduleKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			ruleObject = WISE.createRuleObject(this.pool.actions.schedule);
			ruleObject.rule.scheduleKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
			ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
		}
	}

	return ruleObject;
};