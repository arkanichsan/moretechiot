WISE.managers.azureManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "AZURE"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("r_obj"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "SUB"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.subscribe);
				ruleObject.rule.variableKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.actions.status);
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "PUB"){
				ruleObject = WISE.createRuleObject(this.pool.actions.publish);
				ruleObject.rule.messageKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "SUB"){
				ruleObject = WISE.createRuleObject(this.pool.actions.subscribe);
				ruleObject.rule.variableKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
			}
		}
	}

	return ruleObject;
};
