WISE.managers.lineNotifyManager.encodeXMLObject = function(xmlDoc){
	var xmlLINE_NOTIFY = xmlDoc.createElement("LINE_NOTIFY");

	// Message
	var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

	for(var key in this.pool.messages){
		var message = this.pool.messages[key];
		var xmlM = xmlDoc.createElement("M");

		xmlM.setAttribute("idx", message.index);
		xmlM.setAttribute("nickname", message.name);

		if(message.description != ""){
			xmlM.setAttribute("desc", message.description);
		}

		var chatRooms = [];
		for(var i = 0; i < message.chatRooms.length; i++){
			var key = message.chatRooms[i];

			if(typeof(this.pool.chatRooms[key]) != "undefined"){
				chatRooms.push(this.pool.chatRooms[key].index);
			}
		}
		xmlM.setAttribute("target_token", chatRooms.join(","));

		xmlM.appendChild(xmlDoc.createTextNode(message.content));

		xmlMESSAGE.appendChild(xmlM);
	}

	if(xmlMESSAGE.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlMESSAGE);
	}

    // FTP Server
    var xmlSENDBOX = null;
    var systemManager = WISE.managers.systemManager;
	var server = systemManager.pool.ftpServer;

    try{
        if(server.lineNotify.enable == true){
			xmlSENDBOX = xmlDoc.createElement("SENDBOX");
			xmlSENDBOX.appendChild(xmlDoc.createTextNode(server.lineNotify.content));

			// Chat Room
			var chatRooms = [];
			for(var i = 0; i < server.lineNotify.chatRooms.length; i++){
				var key = server.lineNotify.chatRooms[i];

				if(typeof(this.pool.chatRooms[key]) != "undefined"){
					chatRooms.push(this.pool.chatRooms[key].index);
				}
			}
			xmlSENDBOX.setAttribute("target_token", chatRooms.join(","));

			xmlLINE_NOTIFY.appendChild(xmlSENDBOX);
        }
    }
    catch(error){}

	// IP Camera
	var xmlCAMERA = xmlDoc.createElement("CAMERA");
	var counter = 0;

	var moduleManager = WISE.managers.moduleManager;
	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			try{
				if(modules[moduleIndex].lineNotify.enable == true){
					var xmlC = xmlDoc.createElement("C");
					xmlC.setAttribute("camera_idx", moduleIndex + 1);
					xmlC.setAttribute("idx", ++counter);

					var xmlMSG = xmlDoc.createElement("MSG");
					xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].lineNotify.content));

					// Chat Room
					var chatRooms = [];
					for(var i = 0; i < modules[moduleIndex].lineNotify.chatRooms.length; i++){
						var key = modules[moduleIndex].lineNotify.chatRooms[i];

						if(typeof(this.pool.chatRooms[key]) != "undefined"){
							chatRooms.push(this.pool.chatRooms[key].index);
						}
					}
					xmlMSG.setAttribute("target_token", chatRooms.join(","));
					xmlC.appendChild(xmlMSG);

					xmlCAMERA.appendChild(xmlC);
				}
			}
			catch(error){}
		}
	}

	if(xmlCAMERA.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlCAMERA);
	}

    // CGI Server
    var xmlCGI_SERVER = xmlDoc.createElement("CGI_SERVER");
    var cgiManager = WISE.managers.cgiManager;

    for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
        if(typeof(servers[sourceIndex]) == "undefined"){continue;}

        try{
            if(servers[sourceIndex].lineNotify.enable == true){
        		var xmlC = xmlDoc.createElement("C");
                xmlC.setAttribute("idx", servers[sourceIndex].index);

    			var xmlMSG = xmlDoc.createElement("MSG");
    			xmlMSG.appendChild(xmlDoc.createTextNode(servers[sourceIndex].lineNotify.content));

				// Chat Room
				var chatRooms = [];
				for(var i = 0; i < servers[sourceIndex].lineNotify.chatRooms.length; i++){
					var key = servers[sourceIndex].lineNotify.chatRooms[i];

					if(typeof(this.pool.chatRooms[key]) != "undefined"){
						chatRooms.push(this.pool.chatRooms[key].index);
					}
				}
				xmlMSG.setAttribute("target_token", chatRooms.join(","));
           		xmlC.appendChild(xmlMSG);

                xmlCGI_SERVER.appendChild(xmlC);
            }
        }
        catch(error){}
    }

	if(xmlCGI_SERVER.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlCGI_SERVER);
	}

	// Chat Room
	var xmlTOKEN = xmlDoc.createElement("TOKEN");

	for(var key in this.pool.chatRooms){
		var chatRoom = this.pool.chatRooms[key];
		var xmlT = xmlDoc.createElement("T");

		xmlT.setAttribute("idx", chatRoom.index);
		xmlT.setAttribute("nickname", chatRoom.name);

		if(chatRoom.description != ""){
			xmlT.setAttribute("desc", chatRoom.description);
		}

		xmlT.setAttribute("token", chatRoom.token);
		xmlT.setAttribute("type", chatRoom.type);

		xmlTOKEN.appendChild(xmlT);
	}

	if(xmlTOKEN.childNodes.length > 0){
		xmlLINE_NOTIFY.appendChild(xmlTOKEN);
	}

	// 
	if(xmlLINE_NOTIFY.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_NOTIFY);
				break;
			}
		}
	}
};

WISE.managers.lineNotifyManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}

	index = 0;
	for(var key in this.pool.chatRooms){
		this.pool.chatRooms[key].index = ++index;
	}
};