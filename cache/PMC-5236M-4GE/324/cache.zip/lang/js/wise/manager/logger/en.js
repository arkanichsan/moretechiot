$.extend(true, Lang, {
	"js/wise/manager/logger/rule/object.js": {
		"ftpUploadStatus": "FTP Upload Status",
		"uploadFailedContinuingXHours": "Upload Failed Continuing $hours Hour(s)",
		"dataLogger": "Data Logger",
		"stop": "Stop",
		"start": "Start",
		"oneTimeLog": "One-Time Log"
	}
});