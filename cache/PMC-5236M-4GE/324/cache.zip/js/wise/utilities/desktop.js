function createNumberSelection(target, min, max, paddingZero){
	var string = "";
	if(typeof(paddingZero) != "undefined" && paddingZero == true){
		for(var i = 0; i < max.toString().length; i++){
			string += "0";
		}
	}

	$(target).each(function(index) {
		for(var i = min; i <= max; i++){
			$(this).append(
				$("<option></option>").attr("value", i).text(string.substring(0, string.length - i.toString().length) + i)
			);
		}
	});
}

function bindIPFieldEvent($ipTextField){
	$ipTextField = $($ipTextField);

	$ipTextField.bind("keypress", function(event){
		if(String.fromCharCode(event.charCode || event.keyCode) == "."){
			$(this).next().focus().select();

			return false;
		}
	}).bind("keydown", function(event){
		if($(this).val().length == 0 && event.keyCode == 8){
			$(this).prev().focus().select();
			return false;
		}
	});
}

function wordCount(words){
	var counter = 0;

	for(var i = 0; i < words.length; i++){
		var charCode = words.charCodeAt(i);
		if(charCode < 32 || charCode > 126){
			counter += 2;
		}
		else{
			counter += 1;
		}
	}

	return counter;
};

function wordCut(words, length){
	var counter = 0;

	for(var i = 0; i < words.length; i++){
		var charCode = words.charCodeAt(i);
		if(charCode < 32 || charCode > 126){
			counter += 2;
		}
		else{
			counter += 1;
		}

		if(counter > length){
			return i;
		}
	}

	return words.length;
};

function toReadableByteString(bytes){//(int)bytes
	if(isNaN(bytes)){
		return null;
	}
	else{
		var retObject = {
			"join": function(string){
				return this.bytes + string + this.unit;
			}
		};

		if(bytes < 1024){
			retObject.bytes = bytes.toString();
			retObject.unit = "B";
		}
		else{
		    var i = -1;
		    var unitArray = ["KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];

		    do {
		        bytes /= 1024;
		        i++;
		    } while (bytes > 1024);

			retObject.bytes = bytes.toFixed(1);
			retObject.unit = unitArray[i];
		}

		return retObject;
	}
};

function versionCompare(ver1, ver2, op){
	var splitArray1 = ver1.split("."), splitArray2 = ver2.split(".");
	var maxLength = Math.max(splitArray1.length, splitArray2.length);
	var compare = 0;

	for(var i = 0; i < maxLength; i++){
		splitArray1[i] = parseInt(splitArray1[i], 10);
		splitArray2[i] = parseInt(splitArray2[i], 10);

		if(isNaN(splitArray1[i])){splitArray1[i] = 0;}
		if(isNaN(splitArray2[i])){splitArray2[i] = 0;}

		if(splitArray1[i] < splitArray2[i]){
			compare = -1;
			break;
		}
		else if(splitArray1[i] > splitArray2[i]){
			compare = 1;
			break;
		}
	}

	switch (op) {
		case '>':
			return (compare > 0);
		case '>=':
			return (compare >= 0);
		case '<':
    		return (compare < 0);
		case '<=':
			return (compare <= 0);
		case '==':
			return (compare === 0);
		case '!=':
			return (compare !== 0);
		default:
			return null;
	}
}

//prototype
String.prototype.splice = function(idx, rem, s) {
    return (this.slice(0, idx) + s + this.slice(idx + Math.abs(rem)));
};

/*
//Warning! If add this prototype to array, when use foreach traverse a array, one key will be "clean"
Array.prototype.clean = function(deleteValue) {
	for (var i = 0; i < this.length; i++) {
		if (this[i] == deleteValue) {
			this.splice(i, 1);
			i--;
		}
	}

	return this;
};
*/

/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/
var Base64 = {
 	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
 
	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = Base64._utf8_encode(input);
 
		while (i < input.length) {
 			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);
 
			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;
 
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
 
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
 		}
 
		return output;
	},
 
	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
		while (i < input.length) {
 			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));
 
			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
 
			output = output + String.fromCharCode(chr1);
 
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
 		}
 
		output = Base64._utf8_decode(output);
 
		return output;
 
	},
 
	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
 
		for (var n = 0; n < string.length; n++) {
 			var c = string.charCodeAt(n);
 
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
 		}
 
		return utftext;
	},
 
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
 
		while ( i < utftext.length ) {
 			c = utftext.charCodeAt(i);
 
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
		}
		return string;
	}
}

/**
*
*  AJAX IFRAME METHOD (AIM)
*  http://www.webtoolkit.info/
*
**/
var AIM = {
	frame : function(settings) {
		var id = 'f' + Math.floor(Math.random() * 99999);

		var iframe = document.createElement('iframe');
		iframe.style.display = "none";
		iframe.id = iframe.name = id;
		iframe.onComplete = settings.onComplete || function(){};
		iframe.onError = settings.onError || function(){};

		iframe.setAttribute("src", "about:blank");
		iframe.setAttribute("pid", setInterval(function(){
			var doc = AIM.getDocument(iframe);

			if(doc == null){
				clearInterval(iframe.getAttribute("pid"));
				iframe.onError();
			}
			else{
				if(doc.location.href != "about:blank") {
					clearInterval(iframe.getAttribute("pid"));

					iframe.onComplete(doc);
				}
			}
		}, 1000));

		document.body.appendChild(iframe);

		return id;
	},

	submit : function(form, settings) {
		form.setAttribute("target", AIM.frame(settings));

		if (settings && typeof(settings.onStart) == 'function') {
			return settings.onStart();
		}
		else {
			return true;
		}
	},

	getDocument: function(iframe){
		try{
			if (iframe.contentDocument) {
				var doc = iframe.contentDocument;
			}
			else if (iframe.contentWindow) {
				var doc = iframe.contentWindow.document;
			}
			else {
				var doc = iframe.document;
			}

			doc.location;

			return doc;
		}
		catch(error){
			return null;
		}
	}
};