(function($) {
/*
	var originalVal = jQuery.fn.val;

	$.fn.val = function(){
		console.log( "Override method" );
		return originalVal.apply(this, arguments);
	};
*/
	$.fn.spinner = function(option, p1, p2){
		var createBlock = function($selector, $spinnerBlockContainer){
			$selector.find("option").each(function(index){
				$spinnerBlockContainer.append(
					$("<div></div>").addClass("spinnerBlock").attr("val", $(this).attr("value")).text($(this).text())
				)
			});
		};

		if(option == "create"){
			var length = 5;

			return this.each(function(){
				var $selector = $(this);
				$(this).hide();

				//create layout
				var $spinnerBlockContainer = $("<div></div>").addClass("spinnerBlockContainer");

				createBlock($(this), $spinnerBlockContainer);
/*
				$(this).find("option").each(function(index){
					$spinnerBlockContainer.append(
						$("<div></div>").addClass("spinnerBlock").attr("val", $(this).attr("value")).text($(this).text())
					)
				});
*/
				$("<div></div>").addClass("spinnerContainer").append(
					$("<div></div>").addClass("spinnerButtonUp").append(
						$("<div></div>").addClass("spinnerButtonArrow spinnerIcons add")
					).bind("click", function(){
						var $spinnerBlockContainer = $(this).siblings(".spinnerBlockWrapper").children(".spinnerBlockContainer");
						$spinnerBlockContainer.stop().triggerHandler("touchend", {"index": parseInt($spinnerBlockContainer.attr("index"), 10) + 1})
					})
				).append(
					$("<div></div>").addClass("spinnerBlockWrapper").append($spinnerBlockContainer)
				).append(
					$("<div></div>").addClass("spinnerButtonDown").append(
						$("<div></div>").addClass("spinnerButtonArrow spinnerIcons sub")
					).bind("click", function(){
						var $spinnerBlockContainer = $(this).siblings(".spinnerBlockWrapper").children(".spinnerBlockContainer");
						$spinnerBlockContainer.stop().triggerHandler("touchend", {"index": parseInt($spinnerBlockContainer.attr("index"), 10) - 1})
					})
				).insertBefore($(this));

				//bind event
				$spinnerBlockContainer.bind("touchstart", function(event){
					event.preventDefault();
					var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];

					$(this).stop(true).attr("base", parseInt($(this).css("top"), 10) - touch.pageY);

					$(this)[0].spinner = [];
				}).bind("touchmove", function(event){
					event.preventDefault();
					var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];

					$(this).css("top", (parseInt($(this).attr("base"), 10) + touch.pageY) + "px");

					var spinner = $(this)[0].spinner;
					spinner.splice(0, 0, {offset: touch.pageY, time: (new Date().getTime())});
					spinner.splice(length, spinner.length);
				}).bind("touchend", function(event, settings){
					event.preventDefault();

					settings = $.extend(true, {
						"duration": 400
					}, settings);

					var top = parseInt($(this).css("top"), 10);
					var containerHeight = $(this).parent().height();
					var blockHeight = $(this).children(":first").height();
					var blockIndex = typeof(settings.index) != "undefined" ? settings.index : Math.floor((containerHeight / 2 - top) / blockHeight);

					var $blocks = $(this).children();
					if(blockIndex < 0){
						blockIndex = 0;
					}
					else if(blockIndex > $blocks.length - 1){
						blockIndex = $blocks.length - 1;
					}

					//$selector.find("option:eq(" + blockIndex + ")").attr("selected", true);
					$(this).attr("index", blockIndex);

					if(typeof(settings.index) == "undefined"){
						var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
						var spinner = $(this)[0].spinner;

						spinner.splice(0, 0, {offset: touch.pageY, time: (new Date().getTime())});
						spinner.splice(length, spinner.length);

						if(typeof(spinner[0]) != "undefined" && typeof(spinner[spinner.length - 1]) != "undefined"){
							var d = spinner[spinner.length - 1].offset - spinner[0].offset;
							var t = spinner[spinner.length - 1].time - spinner[0].time;

							var v = d / t;
						}
						else{
							var v = 0;
						}

						if(v > 0.1 || v < -0.1){
							$(this).triggerHandler("touchend", {"index": blockIndex + Math.floor(v * 7) * -1});
							return;
						}
					}

					spinner = [];
					$(this).animate({"top": (containerHeight / 2 - (blockIndex * blockHeight + blockHeight / 2)) + "px"}, settings.duration, "easeOutQuad");
					$selector.triggerHandler("end");
				}).triggerHandler("touchend", {"index": $(this).find("option:selected").index(), "duration": 0});

				//assign id
				var id = "spinner" + Math.floor(Math.random() * 10000);
				$spinnerBlockContainer.attr("id", id);
				$(this).attr("spinner", id);
			});
		}
		else if(option == "value"){
			if(typeof(p1) == "undefined"){//get value
				var $spinnerBlockContainer = $("#" + $(this).attr("spinner"));

				return $spinnerBlockContainer.find("div.spinnerBlock:eq(" + parseInt($spinnerBlockContainer.attr("index"), 10) + ")").attr("val");
			}
			else{//set value
				return this.each(function(){
					var $spinnerBlockContainer = $("#" + $(this).attr("spinner"));
					var index = $spinnerBlockContainer.find("div.spinnerBlock[val='" + p1 + "']").index();
					$spinnerBlockContainer.triggerHandler("touchend", {"index": index, "duration": 0});
				});
			}
		}
		else if(option == "update"){
			var $spinnerBlockContainer = $("#" + $(this).attr("spinner"));
			$spinnerBlockContainer.empty();
			createBlock($(this), $spinnerBlockContainer);
			$spinnerBlockContainer.triggerHandler("touchend", {"index": $(this).find("option:selected").index()})
			$(this).triggerHandler("end");
		}
		else if(option == "bind"){
			$(this).bind(p1, p2);//p1: name, p2: handler
		}
	};
})(jQuery);
