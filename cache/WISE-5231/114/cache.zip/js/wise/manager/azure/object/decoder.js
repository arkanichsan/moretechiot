WISE.managers.azureManager.decodeXMLObject = function(xmlDoc){
	var $xmlAZURE = $(xmlDoc).find("WISE > NOTE > IOT > AZURE");
	if($xmlAZURE.length > 0){
		this.pool.enable = true;
		this.pool.sasToken = $xmlAZURE.attr("sas_token");
		this.pool.keepAliveTimer = parseInt($xmlAZURE.attr("alive_timer"), 10);
		this.pool.publishInterval = parseInt($xmlAZURE.attr("publish_period"), 10);

		var $xmlP = $xmlAZURE.find("> PUBLISH > P");
		if($xmlP.length > 0){
			var maxMessageKey = 0;
			for(var i = 0; i < $xmlP.length; i++){
				var messageKey = parseInt($($xmlP[i]).attr("idx"), 10) - 1;
				if(messageKey > maxMessageKey){maxMessageKey = messageKey};

				var message = this.createPublishMessage({
					"name": $($xmlP[i]).attr("nickname"),
					"description": $($xmlP[i]).attr("desc") || "",

					"type": parseInt($($xmlP[i]).attr("data_type"), 10),
					"payload": $($xmlP[i]).attr("ch_var") || $($xmlP[i]).attr("data"),
					"json": $($xmlP[i]).attr("use_json") == "1" ? true : false,
					"autoPublish": {
						"timing": (function(){
							var timing = 0;
							if($($xmlP[i]).attr("pub_gate")){
								timing += 1;
							}
							if($($xmlP[i]).attr("period_pub") == "1"){
								timing += 2;
							}
							return timing;
						})(),
						"threshold": parseFloat($($xmlP[i]).attr("pub_gate") || 1)
					}
				});

				this.setPublishMessage(messageKey, message);
			}

			this.pool.publish.key = ++maxMessageKey;
		}

		var $xmlMESSAGE = $xmlAZURE.find("> SUBSCRIBE > MESSAGE");
		var maxVariableKey = 0;
		if($xmlMESSAGE.length > 0){
			var variableAttr = $xmlMESSAGE.attr("key");
			if(typeof(variableAttr) != "undefined"){
				var splitArray = variableAttr.split(",");
				for(var i = 0; i < splitArray.length; i++){
					maxVariableKey = i;

					var variable = this.createSubscribeVariable({
						"key": splitArray[i]
					});

					this.setSubscribeVariable(i, variable);
				}
			}
		}

		this.pool.subscribe.variableKey = ++maxVariableKey;
	}
};
