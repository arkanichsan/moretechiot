var historyPool = {array: [], index: -1};
var currentLevel = [];
var currentLevelwithParameter = [];
var parameter = [];

function loadMenu(){
	$.ajax({
		url: "html/mobile/home/menu.htm",
		type: "GET",
		dataType: "html",
		success: function(htmlString){
			htmlString = processLanguage(htmlString, this.url.split("?")[0]);
			$("#menuContainer").html(htmlString);

			$("#menu").find("ul").hide().each(function(index){
				$(this).prev("li").bind("click", function(){
					$("#menu > li:first").show();

					$(this).addClass("hover");
					$(this).siblings("li").hide();

					$(this).parents("ul").prev("li").removeClass("up down left right").addClass("left");
					$(this).removeClass("up down left right").addClass("down");

					var $ul = $(this).next("ul").show();
					$ul.find("> ul").hide();
					$ul.find("> li").removeClass("hover up down left right").addClass("right").show();

					updateViewport();
				}).append(
					$("<span></span>").addClass("arrows")
				);
			});

			$("#menu > li:first").bind("click", function(){
				$(this).hide();
			}).triggerHandler("click");

			$("#menu li[location]").each(function(index){
				$(this).bind("click", function(){
					hideMenu();
					redirectTo($(this).attr("location"));

					$(this).parents("#menu").find("li").removeClass("active");
					$(this).addClass("active");
				});
			}).first().triggerHandler("click");
		}
	});
}

function expandMenu($li){
	$($li.parents("ul").prev("li").get().reverse()).each(function(){
		$(this).triggerHandler("click");
	});
}

function updateNavigation(){
	var $navigationItems = $('#menu li').removeClass("active").filter('[location^="#' + currentLevel.join("/") + '"]'), $li = null;
	if($navigationItems.length > 1){
		$li = $navigationItems.filter('[location="#' + currentLevel.join("/") + "!" + parameter.join("&") + '"]').first().addClass("active");
	}
	else{
		$li = $navigationItems.first().addClass("active");
	}

	//expand menu
	if($li.length > 0){
		expandMenu($li);
	}

	$("#title").text($li.text());
}

function redirectTo(hash, replace){
	hash = hash.replace(/^#/, "");

	if(historyPool.array[historyPool.index] == hash){return;}

	if(historyPool.index < historyPool.array.length - 1){
		historyPool.array.splice(historyPool.index + 1);
	}

	historyPool.index = historyPool.array.push(hash) - 1;
	historyChange();
};

function historyChange(){
	var hash = historyPool.array[historyPool.index];
	if(typeof(hash) == "undefined"){return;}

	WISE.stopTimers("content");
	WISE.abortAjaxs("content");

	currentLevel = [];
	currentLevelwithParameter = [];
	parameter = [];

	for(var i = 0, tempArray = hash.split("/"); i < tempArray.length; i++){
		temp1Array = tempArray[i].split("+");

		var temp2Array = temp1Array[0].split("!");
		currentLevel[i] = temp2Array[0];

		if(temp2Array.length >= 2){//has !
			currentLevelwithParameter[i] = currentLevel[i] + "!" + temp2Array[1];

			if(i == tempArray.length - 1){
				parameter = temp2Array[1].split("&");
			}
		}
		else{
			currentLevelwithParameter[i] = currentLevel[i];
		}
	}

	$("#loader").show();
	WISE.startAjax("content", {
		url: "html/mobile" + "/" + currentLevel.join("/") + ".htm",
		type: "GET",
		dataType: "html",
		done: function(htmlString){
			htmlString = processLanguage(htmlString, this.url.split("?")[0]);

			$("#loader").hide();
			delayShowFlag = false;
			$("#contentContainer").html(htmlString);

			if(delayShowFlag == true){
				$("#loader").show();
			}

			setTimeout(function(){//fix for firefox
				$('html, body').scrollTop(0);
			}, 0);

			updateNavigation();
		}
	});
};

function hideMenu(){
	$("#contentCover").hide();
	$("#menuWrapper").removeClass("active");
/*
	$("#wrapper").animate({
	    marginLeft: 0
	}, "fast");
*/
	$("#wrapper").css("marginLeft", "0");
	updateViewport();
}

function showMenu(){
	$("#contentCover").show();
	$("#menuWrapper").addClass("active");
	expandMenu($("#menu li.active"));
	$("#wrapper").animate({
	    marginLeft: 270
	}, "fast");
	updateViewport();
}

function delayShow(){
	delayShowFlag = true;
}

function startShow(){
	$("#loader").hide();
}

function updateViewport(){
	if($("#menuWrapper").hasClass("active")){
		$("#container").css("height", Math.max($("#menuMeasurer").height(), $(window).height()) + "px");
	}
	else{
		$("#container").css("height", "");
	}
}