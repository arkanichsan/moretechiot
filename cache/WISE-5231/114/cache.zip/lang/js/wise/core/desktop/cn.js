$.extend(true, Lang, {
	"js/wise/core/desktop.js": {
		"all": "全部",
		"view": "预览",
		"edit": "编辑",
		"local": "本机",
		"remote": "远程",
		"internalRegister": "内部缓存器",
		"diCounter": "DI计数器",
		"doCounter": "DO计数器",
		"diCounterX": "DI计数器$channel",
		"doCounterX": "DO计数器$channel",
		"internalRegisterX": "内部缓存器$channel",
		"assignValue": "自定义数值",
		"systemInformation": "系统信息",
		"item": "项目",
		"dateYear": "日期(年)",
		"dateMonth": "日期(月)",
		"dateDay": "日期(日)",
		"timeHour": "时间(时)",
		"timeMinute": "时间(分)",
		"timeSecond": "时间(秒)",
		"signalStrengthDBM": "3G信号强度(dBm)",
		"signalStrengthPercent": "3G信号强度(%)"
	}
});