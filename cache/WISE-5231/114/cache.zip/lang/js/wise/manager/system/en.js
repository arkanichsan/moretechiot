﻿$.extend(true, Lang, {
	"js/wise/manager/system/rule/object.js": {
		"sdCardStatus": "SD Card Status",
		"abnormal": "Abnormal",
		"signalStrength": "3G Signal Strength",
		"rebootSystem": "Reboot System"
	}
});