﻿$.extend(true, Lang, {
	"js/wise/manager/snmp/rule/object.js": {
		"snmpTrap": "SNMP Trap",
		"send": "傳送"
	}
});