WISE.managers.registerManager = (function(){
	return new function() {
		this.pool = {
			registers: []
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 100;
		this.retentiveRegister = {//keep date in FRAM
			minIndex: 80,//81
			maxIndex: 99//100
		};

		this.createRegister = function(settings){
			var register = $.extend(true, {
				"name": "",
				"description": "",
				"reference": [],

				"initialValue": 0,
				"type": 0,//
				//"bitSplit": false,
				"bitName": []
			}, settings);

			//var retKey = this.pool.key;
			//this.pool.registers[this.pool.key++] = register;
			return register;
		};

		this.removeRegister = function(index){
			delete this.pool.registers[index];
		};

		this.getRegister = function(index){
			if(typeof(this.pool.registers[index]) != "undefined"){
				return this.pool.registers[index];
			}
			else{
				return null;
			}
		};

		this.setRegister = function(index, register){
			this.pool.registers[index] = register;
		};

		this.getRegisters = function(){
			return this.pool.registers;
		};

		this.getTypeRange = function(type){
			if(type == 0){//16-bit Signed Integer
				return {"min": -32768, "max": 32767, "type": "int"};
			}
			else if(type == 1){//16-bit Unsigned Integer
				return {"min": 0, "max": 65535, "type": "int"};
			}
			else if(type == 2){//16-bit HEX
				return {"min": 0, "max": 0, "type": "float"};
			}
			else if(type == 3){//32-bit Signed Long
				return {"min": -2147483648, "max": 2147483647, "type": "int"};
			}
			else if(type == 4){//32-bit Unsigned Long
				return {"min": 0, "max": 4294967295, "type": "int"};
			}
			else{//32-bit Floating Point
				//var min = -65535 * block.scaleRatio + block.offset, max = 65535 * block.scaleRatio + block.offset;
				//return {"min": Math.min(min, max), "max": Math.max(min, max), "type": "float"};
				return {"min": Number.NEGATIVE_INFINITY, "max": Number.POSITIVE_INFINITY, "type": "float"};
			}
		}

		this.getRegisterRange = function(index){
			return this.getTypeRange(this.pool.registers[index].type);
		};
	};
})();
