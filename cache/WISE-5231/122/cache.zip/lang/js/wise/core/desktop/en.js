$.extend(true, Lang, {
	"js/wise/core/desktop.js": {
		"all": "All",
		"view": "View",
		"edit": "Edit",
		"local": "Local",
		"remote": "Remote",
		"internalRegister": "Internal Register",
		"diCounter": "DI Counter",
		"doCounter": "DO Counter",
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel",
		"assignValue": "User-Defined",
		"systemInformation": "System Information",
		"item": "Item",
		"dateYear": "Date(Year)",
		"dateMonth": "Date(Month)",
		"dateDay": "Date(Day)",
		"timeHour": "Time(Hour)",
		"timeMinute": "Time(Minute)",
		"timeSecond": "Time(Second)",
		"signalStrengthDBM": "Mobile Network Signal Strength(dBm)",
		"signalStrengthPercent": "Mobile Network Signal Strength(%)"
	}
});