WISE.managers.timerManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "timer"){
			xmlDoc.setAttribute("l_obj", "TIMER");
			xmlDoc.setAttribute("l_idx", this.pool.timers[ruleObject.rule.timerKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "timer"){
			xmlDoc.setAttribute("l_obj", "TIMER");
			xmlDoc.setAttribute("l_idx", this.pool.timers[ruleObject.rule.timerKey].index);
			xmlDoc.setAttribute("op", ruleObject.rule.value);
		}
	}
};

WISE.managers.timerManager.check = function(){
	var registerManager = WISE.managers.registerManager;

	for(var key in this.pool.timers){
		var timer = this.pool.timers[key];

		if(timer.period < 0){
			var registerIndex = (timer.period * -1) - 1;

			if(typeof(registerManager.pool.registers[registerIndex]) == "undefined"){
				//this.removeTimer(key);

				return {
					"hash": "#home/advanced/timer!" + key,
					"message": "<#Lang['?'].someoneTimerUseAlreadyRemovedRegister>"
				};
			}
		}
	}
};