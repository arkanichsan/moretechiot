WISE.managers.lineBotManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "message"){
			xmlDoc.setAttribute("l_obj", "LINE_BOT");
			xmlDoc.setAttribute("l_idx", this.pool.messages[ruleObject.rule.messageKey].index);
			xmlDoc.setAttribute("op", "1");
		}
	}
};
