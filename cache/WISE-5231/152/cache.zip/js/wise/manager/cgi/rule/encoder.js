WISE.managers.cgiManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = moduleManager.encodeXMLRule.processModuleInfo;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "cgiCommand"){
			xmlDoc.setAttribute("l_obj", "CGI");
			xmlDoc.setAttribute("l_idx", this.pool.receive.variables[ruleObject.rule.variableKey].index);
			if(ruleObject.rule.clientKey != null){
				xmlDoc.setAttribute("l_ch", this.pool.receive.clients[ruleObject.rule.clientKey].index);
			}
			xmlDoc.setAttribute("op", ruleObject.rule.operate);
			processCompareModule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "cgiCommand"){
			xmlDoc.setAttribute("l_obj", "CGI");
			xmlDoc.setAttribute("l_idx", this.pool.send.servers[ruleObject.rule.serverKey].index);
			xmlDoc.setAttribute("l_ch", this.pool.send.servers[ruleObject.rule.serverKey].commands[ruleObject.rule.commandKey].index);
			xmlDoc.setAttribute("op", "0");
		}
		else if(ruleObject.ruleObjectKey == "cgiVariable"){
			xmlDoc.setAttribute("l_obj", "CGI");
			xmlDoc.setAttribute("l_idx", this.pool.receive.variables[ruleObject.rule.variableKey].index);
			if(ruleObject.rule.clientKey != null){
				xmlDoc.setAttribute("l_ch", this.pool.receive.clients[ruleObject.rule.clientKey].index);
			}
			xmlDoc.setAttribute("op", "2");
		}
	}
};
