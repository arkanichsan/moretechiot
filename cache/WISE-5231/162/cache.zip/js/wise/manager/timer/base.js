WISE.managers.timerManager = (function(){
	return new function() {
		this.pool = {
			timers: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 12;

		this.createTimer = function(settings){
			var timer = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"period": 1,
				"initialStatus": 0
			}, settings);

			return timer;
		};

		this.addTimer = function(timer){
			var retKey = this.pool.key;
			this.pool.timers[this.pool.key++] = timer;
			return retKey;
		};

		this.removeTimer = function(key){
			delete this.pool.timers[key];
		};

		this.getTimer = function(key){
			if(typeof(this.pool.timers[key]) != "undefined"){
				return this.pool.timers[key];
			}
			else{
				return null;
			}
		};

		this.setTimer = function(key, timer){
			this.pool.timers[key] = timer;
		};

		this.getTimers = function(){
			return this.pool.timers;
		};
	};
})();
