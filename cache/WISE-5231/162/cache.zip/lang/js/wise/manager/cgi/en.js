$.extend(true, Lang, {
    "js/wise/manager/cgi/rule/object.js": {
        "cgiCommand": "CGI Command",
        "fromX": "From $address",
        "local": "Local",
        "remote": "Remote",
        "internalRegister": "Internal Register",
		"send": "Send",
		"resetVariable": "Reset Variable",
		"reset": "Reset"
    }
});