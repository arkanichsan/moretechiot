WISE.managers.pingManager.pool.conditions = {
	"ping": {
		"name": "Ping",
		"fileName": "cping",
		"rule":{
			"pingKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.pingKey == null){
				return false;
			}

			var pingManager = WISE.managers.pingManager;

			if(typeof(pingManager.pool.pings[this.rule.pingKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var pingManager = WISE.managers.pingManager;
			var ping = pingManager.pool.pings[this.rule.pingKey];
			var valueString = ["<#Lang['?'].failed>"];

			return this.name + "(" + ping.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.pingKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.pingManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['ping']['key'] = [];

	for(var key in this.pool.pings){
		this.pool.conditions['ping']['key'].push(parseInt(key, 10));
	}
};