WISE.managers.moduleManager.pool.conditions = {
	"DI": {
		"name": "DI",
		"fileName": "cdi",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,//[string]
			"channelIndex": 0,//[int]
			"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DI.amount <= this.rule.channelIndex || module.DI.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = module.type == "onboard" && module.moduleType != "XVBoard" ? ["ON", "OFF", "<#Lang['?'].offToON>", "<#Lang['?'].onToOFF>", "<#Lang['?'].statusChange>"] : ["OFF", "ON", "<#Lang['?'].onToOFF>", "<#Lang['?'].offToON>", "<#Lang['?'].statusChange>"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DI", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"DIC": {
		"name": "<#Lang['?'].diCounter>",
		"fileName": "cdic",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DI.amount <= this.rule.channelIndex || module.DI.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			if(module.type == "onboard" && module.DI.setting[this.rule.channelIndex].counterType == 0){
				return false;
			}

			if(this.rule.operate != 5){
				var registerManager = WISE.managers.registerManager;

				if(this.rule.type == 1){
					if(this.rule.value[1].moduleKey == null){
						if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
							return false;
						}
					}
					else{
						if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
							return false;
						};
					}
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

					if(compareModule == null){
						return false;
					}
					else{
						if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
							return false;
						}
						else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
							return false;
						}
						else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
							return false;
						}
						else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
							return false;
						}
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
					if(this.extendedModule.check(this) == false){
						return false;
					}
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<=", "<#Lang['?'].change>"];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DIC", this.rule.channelIndex), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.operate != 5){
				if(this.rule.type == 0){
					retString += ruleColor(this.rule.value[0].constant, 2);
				}
				else if(this.rule.type == 1){
					if(this.rule.value[1].moduleKey == null){
						retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
					}
					else{
						var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
						retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
					}
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

					if(this.rule.type == 2){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
					}
					else if(this.rule.type == 3){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
					}
					else if(this.rule.type == 4){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
					}
					else if(this.rule.type == 5){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
					retString += this.extendedModule.parseToString(this) || "";
				}
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"DO": {
		"name": "DO",
		"fileName": "cdo",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,//[string]
			"channelIndex": 0,//[int]
			"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DO.amount <= this.rule.channelIndex || module.DO.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = module.type == "onboard" && module.moduleType != "XVBoard" ? ["ON", "OFF", "<#Lang['?'].offToON>", "<#Lang['?'].onToOFF>", "<#Lang['?'].statusChange>"] : ["OFF", "ON", "<#Lang['?'].onToOFF>", "<#Lang['?'].offToON>", "<#Lang['?'].statusChange>"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DO", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"DOC": {
		"name": "<#Lang['?'].doCounter>",
		"fileName": "cdoc",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DO.amount <= this.rule.channelIndex || module.DO.setting[this.rule.channelIndex].disable == true){
				return false;
			}
/*
			if(module.type == "onboard" && module.DO.setting[this.rule.channelIndex].counterType == 0){
				return false;
			}
*/
			if(this.rule.operate != 5){
				var registerManager = WISE.managers.registerManager;

				if(this.rule.type == 1){
					if(this.rule.value[1].moduleKey == null){
						if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
							return false;
						}
					}
					else{
						if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
							return false;
						};
					}
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

					if(compareModule == null){
						return false;
					}
					else{
						if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
							return false;
						}
						else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
							return false;
						}
						else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
							return false;
						}
						else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
							return false;
						}
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
					if(this.extendedModule.check(this) == false){
						return false;
					}
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<=", "<#Lang['?'].change>"];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DOC", this.rule.channelIndex), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.operate != 5){
				if(this.rule.type == 0){
					retString += ruleColor(this.rule.value[0].constant, 2);
				}
				else if(this.rule.type == 1){
					if(this.rule.value[1].moduleKey == null){
						retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
					}
					else{
						var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
						retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
					}
				}
				else if(this.rule.type >= 2 && this.rule.type <= 5){
					var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

					if(this.rule.type == 2){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
					}
					else if(this.rule.type == 3){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
					}
					else if(this.rule.type == 4){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
					}
					else if(this.rule.type == 5){
						retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
					}
				}

				if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
					retString += this.extendedModule.parseToString(this) || "";
				}
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"AI": {
		"name": "AI",
		"fileName": "cai",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"deadband": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.AI.amount <= this.rule.channelIndex || module.AI.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor((moduleInfo.module.moduleType != "DL" ? this.name : "") + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "AI", this.rule.channelIndex), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleManager.icpdasModule.getAIRange(moduleInfo.module, this.rule.channelIndex).unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.value[0].constant = moduleManager.icpdasModule.checkAIRange(module, this.rule.channelIndex, this.rule.value[0].constant);
		},
		"key": []
	},
	"AO": {
		"name": "AO",
		"fileName": "cao",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"deadband": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.AO.amount <= this.rule.channelIndex || module.AO.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor((moduleInfo.module.moduleType != "DL" ? this.name : "") + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "AO", this.rule.channelIndex), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleManager.icpdasModule.getAORange(moduleInfo.module.AO.setting[this.rule.channelIndex].type).unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.value[0].constant = moduleManager.icpdasModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
		},
		"key": []
	},
	"CI": {
		"name": "Discrete Input",
		"fileName": "cci",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.CI.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["OFF", "ON"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "CI", this.rule.channelAddress), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.CI.blockArray.length; i++){
					if(module.CI.blockArray[i].disable == true){continue;}

					return module.CI.blockArray[i].startAddress;
				}
			})();
		},
		"key": []
	},
	"CO": {
		"name": "Coil Output",
		"fileName": "cco",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.CO.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["OFF", "ON"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "CO", this.rule.channelAddress), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.CO.blockArray.length; i++){
					if(module.CO.blockArray[i].disable == true){continue;}

					return module.CO.blockArray[i].startAddress;
				}
			})();
		},
		"key": []
	},
	"RI": {
		"name": "Input Register",
		"fileName": "cri",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"deadband": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI, 3 for AO, 4 for RI, 5 for RO, 6 for PM
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.RI.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "RI", this.rule.channelAddress), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleInfo.module.RI.remoteAddress[this.rule.channelAddress].unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.RI.blockArray.length; i++){
					if(module.RI.blockArray[i].disable == true){continue;}

					return module.RI.blockArray[i].startAddress;
				}
			})();
			this.rule.value[0].constant = moduleManager.modbusModule.checkRegisterRange(module, "RI", this.rule.channelAddress, this.rule.value[0].constant);
		},
		"key": []
	},
	"RO": {
		"name": "Holding Register",
		"fileName": "cro",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"deadband": 0,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			}
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.RO.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", ">", "<", ">=", "<="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "RO", this.rule.channelAddress), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleInfo.module.RO.remoteAddress[this.rule.channelAddress].unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.RO.blockArray.length; i++){
					if(module.RO.blockArray[i].disable == true){continue;}

					return module.RO.blockArray[i].startAddress;
				}
			})();
			this.rule.value[0].constant = moduleManager.modbusModule.checkRegisterRange(module, "RO", this.rule.channelAddress, this.rule.value[0].constant);
		},
		"key": []
	},
	"cameraDI": {
		"name": "DI",
		"fileName": "ccamdi",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DI.amount <= this.rule.channelIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["OFF", "ON", "<#Lang['?'].onToOFF>", "<#Lang['?'].offToON>", "<#Lang['?'].statusChange>"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DI", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	},
	"cameraDO": {
		"name": "DO",
		"fileName": "ccamdo",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"value": 0//[int] 0 => "OFF", 1 => "ON", 2 => "ON to OFF", 3 => "OFF to ON", 4 => "Change"
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DO.amount <= this.rule.channelIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["OFF", "ON", "<#Lang['?'].onToOFF>", "<#Lang['?'].offToON>", "<#Lang['?'].statusChange>"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DO", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	},
	"cameraEvent": {
		"name": "<#Lang['?'].event>",
		"fileName": "ccamevent",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"commandIndex": 0,
			"value": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.conditionEvent.amount <= this.rule.commandIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["<#Lang['?'].trigger>"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + module.conditionEvent.setting[this.rule.commandIndex].displayName, 1) + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	},
	"status": {
		"name": "<#Lang['?'].connectionStatus>",
		"fileName": "cstatus",
		"rule":{
			"moduleKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["<#Lang['?'].offline>", "<#Lang['?'].online>"];

			var retString = this.name + " " + moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(valueString[this.rule.value], 2);

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	}
};

WISE.managers.moduleManager.pool.actions = {
	"DIC": {
		"name": "<#Lang['?'].diCounter>",
		"fileName": "adic",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DI.amount <= this.rule.channelIndex || module.DI.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			if(module.type == "onboard" && module.DI.setting[this.rule.channelIndex].counterType == 0){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["<#Lang['?'].reset>"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + (!moduleManager.icpdasModule.isSingleResetDICounterFlagModule(moduleInfo.module) ? " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DIC", this.rule.channelIndex) : ""), 1) + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"DO": {
		"name": "DO",
		"fileName": "ado",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DO.amount <= this.rule.channelIndex || module.DO.setting[this.rule.channelIndex].disable == true || module.DO.setting[this.rule.channelIndex].advancedFunction == 3){
				return false;
			}

			if(module.type == "onboard" && this.rule.value == 2 && module.DO.setting[this.rule.channelIndex].advancedFunction != 1){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["OFF", "ON", "<#Lang['?'].pulseOutput>"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DO", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
		},
		"key": []
	},
	"AO": {
		"name": "AO",
		"fileName": "aao",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"operate": 0,
			"type": 0,//0 for a constant, 1 for IR, 2 for AI, 3 for AO
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			},
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.AO.amount <= this.rule.channelIndex || module.AO.setting[this.rule.channelIndex].disable == true){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", "+=", "-="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor((moduleInfo.module.moduleType != "DL" ? this.name : "") + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "AO", this.rule.channelIndex), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleManager.icpdasModule.getAORange(moduleInfo.module.AO.setting[this.rule.channelIndex].type).unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.value[0].constant = moduleManager.icpdasModule.checkAORange(module, this.rule.channelIndex, this.rule.value[0].constant);
		},
		"key": []
	},
	"CO": {
		"name": "Coil Output",
		"fileName": "aco",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.CO.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var valueString = ["OFF", "ON"];

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "CO", this.rule.channelAddress), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.CO.blockArray.length; i++){
					if(module.CO.blockArray[i].disable == true){continue;}

					return module.CO.blockArray[i].startAddress;
				}
			})();
		},
		"key": []
	},
	"RO": {
		"name": "Holding Register",
		"fileName": "aro",
		"menuPath": "<#Lang['?'].modbusModule>",
		"rule":{
			"moduleKey": null,
			"channelAddress": null,
			"operate": 0,
			"type": 0,//0 for a value, 1 for IR, 2 for AI
			"value": {
				0: {
					"constant": 0
				},
				1: {
					"moduleKey": null,
					"registerIndex": null
				},
				2: {
					"moduleKey": null,
					"channelIndex": 0
				},
				3: {
					"moduleKey": null,
					"channelIndex": 0
				},
				4: {
					"moduleKey": null,
					"channelAddress": null
				},
				5: {
					"moduleKey": null,
					"channelAddress": null
				}
			},
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}
			if(this.rule.type == 1 && this.rule.value[1].registerIndex == null){
				return false;
			}
			if(this.rule.type >= 2 && this.rule.value[this.rule.type].moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.RO.remoteAddress[this.rule.channelAddress]) == "undefined"){
				return false;
			}

			var registerManager = WISE.managers.registerManager;

			if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					if(typeof(registerManager.pool.registers[this.rule.value[1].registerIndex]) == "undefined"){
						return false;
					}
				}
				else{
					if(moduleManager.getModuleByKey(this.rule.value[1].moduleKey) == null){
						return false;
					};
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModule = moduleManager.getModuleByKey(this.rule.value[this.rule.type].moduleKey);

				if(compareModule == null){
					return false;
				}
				else{
					if(this.rule.type == 2 && (compareModule.AI.amount <= this.rule.value[2].channelIndex || compareModule.AI.setting[this.rule.value[2].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 3 && (compareModule.AO.amount <= this.rule.value[3].channelIndex || compareModule.AO.setting[this.rule.value[3].channelIndex].disable == true)){
						return false;
					}
					else if(this.rule.type == 4 && typeof(compareModule.RI.remoteAddress[this.rule.value[4].channelAddress]) == "undefined"){
						return false;
					}
					else if(this.rule.type == 5 && typeof(compareModule.RO.remoteAddress[this.rule.value[5].channelAddress]) == "undefined"){
						return false;
					}
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.check) == "function"){
				if(this.extendedModule.check(this) == false){
					return false;
				}
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var registerManager = WISE.managers.registerManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var operateString = ["=", "+=", "-="];

			var retString = moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "RO", this.rule.channelAddress), 1) + " " + operateString[this.rule.operate] + " ";

			if(this.rule.type == 0){
				retString += ruleColor(this.rule.value[0].constant + " " + moduleInfo.module.RO.remoteAddress[this.rule.channelAddress].unit, 2);
			}
			else if(this.rule.type == 1){
				if(this.rule.value[1].moduleKey == null){
					retString += "<#Lang['?'].local>" + " " + "<#Lang['?'].internalRegister>" + " " + WISE.registerInfo(this.rule.value[1].registerIndex);
				}
				else{
					var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.value[1].moduleKey);
					retString += "<#Lang['?'].remote>" + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + "<#Lang['?'].internalRegister>" + " " + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "IR", this.rule.value[1].registerIndex);
				}
			}
			else if(this.rule.type >= 2 && this.rule.type <= 5){
				var compareModuleInfo = moduleManager.getModuleInfoByKey(this.rule.value[this.rule.type].moduleKey);

				if(this.rule.type == 2){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor((compareModuleInfo.module.moduleType != "DL" ? moduleManager.pool.conditions.AI.name : "") + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AI", this.rule.value[2].channelIndex), 1);
				}
				else if(this.rule.type == 3){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.AO.name + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "AO", this.rule.value[3].channelIndex), 1);
				}
				else if(this.rule.type == 4){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.conditions.RI.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RI", this.rule.value[4].channelAddress), 1);
				}
				else if(this.rule.type == 5){
					retString += moduleManager.pool.interfaces[compareModuleInfo.sourceType][compareModuleInfo.sourceIndex].name + " " + WISE.moduleInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex) + " " + ruleColor(moduleManager.pool.actions.RO.name + " " + WISE.channelInfo(compareModuleInfo.sourceType, compareModuleInfo.sourceIndex, compareModuleInfo.moduleIndex, "RO", this.rule.value[5].channelAddress), 1);
				}
			}

			if(typeof(this.extendedModule) != "undefined" && typeof(this.extendedModule.parseToString) == "function"){
				retString += this.extendedModule.parseToString(this) || "";
			}

			return retString;
		},

		/*init and key will not be copied*/
		"init": function(){
			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.key[0].moduleKey);
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.channelAddress = (function(){
				for(var i = 0; i < module.RO.blockArray.length; i++){
					if(module.RO.blockArray[i].disable == true){continue;}

					return module.RO.blockArray[i].startAddress;
				}
			})();
			this.rule.value[0].constant = moduleManager.modbusModule.checkRegisterRange(module, "RO", this.rule.channelAddress, this.rule.value[0].constant);
		},
		"key": []
	},
	"IR": {
		"name": "<#Lang['?'].infrared>",
		"fileName": "air",
		"menuPath": "<#Lang['?'].icpdasModule>",
		"rule":{
			"moduleKey": null,
			"commandIndex": 0,
			"outputChannel": 1,//one bit, one channel
			"operate": 0,//always is 0
			"type": 0,//always is 0
			"value": {
				0: {
					"constant": 0
				}
			},
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || typeof(module.command[this.rule.commandIndex]) == "undefined" || this.rule.outputChannel.toString(2).length > moduleManager.icpdasModule.getIRChannelAmount(module)){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);

			var channelString = "", binaryString = this.rule.outputChannel.toString(2);
			for(var i = binaryString.length - 1; i >= 0; i--){
				if(binaryString[i] == "1"){
					channelString += ", " + (binaryString.length - i);
				}
			}

			channelString = channelString.substr(2);

			return moduleManager.pool.interfaces[moduleInfo.sourceType][moduleInfo.sourceIndex].name + " " + WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor("<#Lang['?'].ch>" + channelString + " ", 1) + ruleColor("<#Lang['?'].transmitCommand>" + " " + (this.rule.commandIndex + 1) + (moduleInfo.module.command[this.rule.commandIndex] != "" ? "(" + moduleInfo.module.command[this.rule.commandIndex] + ")" : ""), 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0].moduleKey;
			this.rule.commandIndex = this.key[0].commandIndex;
		},
		"key": []
	},
	"cameraDO": {
		"name": "DO",
		"fileName": "acamdo",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"channelIndex": 0,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.DO.amount <= this.rule.channelIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["OFF", "ON"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + WISE.channelInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex, "DO", this.rule.channelIndex), 1) + " = " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	},
//	"cameraEvent": {
//		"name": "<#Lang['?'].event>",
//		"fileName": "acamevent",
//		"menuPath": "<#Lang['?'].camera>",
//		"rule":{
//			"moduleKey": null,
//			"commandIndex": 0,
//			"value": 0,
//			"frequency": 0,
//			"delay": 0
//		},
//		"check": function(){
//			if(this.rule.moduleKey == null){
//				return false;
//			}
//
//			var moduleManager = WISE.managers.moduleManager;
//			var module = moduleManager.getModuleByKey(this.rule.moduleKey);
//
//			if(module == null || module.actionEvent.amount <= this.rule.commandIndex){
//				return false;
//			}
//
//			return true;
//		},
//		"parseToString": function(){
//			var moduleManager = WISE.managers.moduleManager;
//			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
//			var module = moduleInfo.module;
//			var valueString = ["<#Lang['?'].trigger>"];
//
//			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name + " " + module.actionEvent.setting[this.rule.commandIndex].displayName, 1) + " " + ruleColor(valueString[this.rule.value], 2);
//		},
//
//		/*init and key will not be copied*/
//		"init": function(){
//			this.rule.moduleKey = this.key[0];
//		},
//		"key": []
//	},
	"cameraSnapshot": {
		"name": "<#Lang['?'].snapshot>",
		"fileName": "acamsnapshot",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"commandIndex": 0,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.actionSnapshot.amount <= this.rule.commandIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["<#Lang['?'].capture>"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name/* + " " + module.actionSnapshot.setting[this.rule.commandIndex].displayName*/, 1) + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	},
	"cameraVideo": {
		"name": "<#Lang['?'].video>",
		"fileName": "acamvideo",
		"menuPath": "<#Lang['?'].camera>",
		"rule":{
			"moduleKey": null,
			"commandIndex": 0,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.moduleKey == null){
				return false;
			}

			var moduleManager = WISE.managers.moduleManager;
			var module = moduleManager.getModuleByKey(this.rule.moduleKey);

			if(module == null || module.actionVideo.amount <= this.rule.commandIndex){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var moduleManager = WISE.managers.moduleManager;
			var moduleInfo = moduleManager.getModuleInfoByKey(this.rule.moduleKey);
			var module = moduleInfo.module;
			var valueString = ["<#Lang['?'].record>"];

			return WISE.moduleInfo(moduleInfo.sourceType, moduleInfo.sourceIndex, moduleInfo.moduleIndex) + " " + ruleColor(this.name/* + " " + module.actionVideo.setting[this.rule.commandIndex].displayName*/, 1) + " " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.moduleKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.moduleManager.updateRuleObject = function(){
	var moduleManager = this;
	var icpdasModuleKeyProcessor = function(module, keyData){
		if(!moduleManager.icpdasModule.isDICounterModule(module)){
			for(var i = 0; i < module.DI.amount; i++){
				if(module.DI.setting[i].disable == true){continue;}

				moduleManager.pool.conditions['DI']['key'].push(keyData);
				break;
			}
		}

		for(var i = 0; i < module.DI.amount; i++){
			if(module.DI.setting[i].disable == true){continue;}

			if(module.type == "onboard"){
				if(module.DI.setting[i].counterType > 0){
					moduleManager.pool.conditions['DIC']['key'].push(keyData);
					moduleManager.pool.actions['DIC']['key'].push(keyData);
					break;
				}
			}
			else{
				if(!moduleManager.icpdasModule.isNoDICounterModule(module)){
					moduleManager.pool.conditions['DIC']['key'].push(keyData);
				}

				if(!moduleManager.icpdasModule.isNoDICounterResetModule(module)){
					moduleManager.pool.actions['DIC']['key'].push(keyData);
				}

				break;
			}
		}
		
		for(var i = 0; i < module.DO.amount; i++){
			if(module.DO.setting[i].disable == true){continue;}

			moduleManager.pool.conditions['DO']['key'].push(keyData);

			if(module.moduleType == "WISE"){
				moduleManager.pool.conditions['DOC']['key'].push(keyData);
			}

			break;
		}
		
		for(var i = 0; i < module.DO.amount; i++){
			if(module.DO.setting[i].disable == true){continue;}

			if(module.DO.setting[i].advancedFunction != 3){//mapping to DI
				moduleManager.pool.actions['DO']['key'].push(keyData);
				break;
			}
		}

		for(var i = 0; i < module.AI.amount; i++){
			if(module.AI.setting[i].disable == true){continue;}

			moduleManager.pool.conditions['AI']['key'].push(keyData);
			break;
		}

		for(var i = 0; i < module.AO.amount; i++){
			if(module.AO.setting[i].disable == true){continue;}

			moduleManager.pool.conditions['AO']['key'].push(keyData);
			moduleManager.pool.actions['AO']['key'].push(keyData);
			break;
		}

		if(module.moduleType == "IR"){
			for(var i = 0; i < module.command.length; i++){
				if(typeof(module.command[i]) != "undefined"){
					keyData.commandIndex = i;
					moduleManager.pool.actions['IR']['key'].push(keyData);
					break;
				}
			}
		}

		if(module.type != "onboard"){
			moduleManager.pool.conditions['status']['key'].push(keyData);
		}
	};

	var modbusModuleKeyProcessor = function(module, keyData){
		for(var i = 0; i < module.CI.blockArray.length; i++){
			if(module.CI.blockArray[i].disable == true){continue;}

			moduleManager.pool.conditions['CI']['key'].push(keyData);
			break;
		}
		for(var i = 0; i < module.CO.blockArray.length; i++){
			if(module.CO.blockArray[i].disable == true){continue;}

			moduleManager.pool.conditions['CO']['key'].push(keyData);
			moduleManager.pool.actions['CO']['key'].push(keyData);
			break;
		}
		for(var i = 0; i < module.RI.blockArray.length; i++){
			if(module.RI.blockArray[i].disable == true){continue;}

			moduleManager.pool.conditions['RI']['key'].push(keyData);
			break;
		}
		for(var i = 0; i < module.RO.blockArray.length; i++){
			if(module.RO.blockArray[i].disable == true){continue;}

			moduleManager.pool.conditions['RO']['key'].push(keyData);
			moduleManager.pool.actions['RO']['key'].push(keyData);
			break;
		}

		moduleManager.pool.conditions['status']['key'].push(keyData);
	};

	//clear key
	this.pool.conditions['DI']['key'] = [];
	this.pool.conditions['DIC']['key'] = [];
	this.pool.conditions['DO']['key'] = [];
	this.pool.conditions['DOC']['key'] = [];
	this.pool.conditions['AI']['key'] = [];
	this.pool.conditions['AO']['key'] = [];
	this.pool.conditions['CI']['key'] = [];
	this.pool.conditions['CO']['key'] = [];
	this.pool.conditions['RI']['key'] = [];
	this.pool.conditions['RO']['key'] = [];
	this.pool.conditions['cameraDI']['key'] = [];
	this.pool.conditions['cameraDO']['key'] = [];
	this.pool.conditions['cameraEvent']['key'] = [];
	this.pool.conditions['status']['key'] = [];
	this.pool.actions['DIC']['key'] = [];
	this.pool.actions['DO']['key'] = [];
	this.pool.actions['AO']['key'] = [];
	this.pool.actions['CO']['key'] = [];
	this.pool.actions['RO']['key'] = [];
	this.pool.actions['IR']['key'] = [];
	this.pool.actions['cameraDO']['key'] = [];
	//this.pool.actions['cameraEvent']['key'] = [];
	this.pool.actions['cameraSnapshot']['key'] = [];

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.onboard.length; sourceIndex++){
		if(typeof(this.pool.interfaces.onboard[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = this.pool.interfaces.onboard[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			var keyData = {
				"moduleKey": modules[moduleIndex].key
			};

			icpdasModuleKeyProcessor(modules[moduleIndex], keyData);
		}
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.comport.length; sourceIndex++){
		if(typeof(this.pool.interfaces.comport[sourceIndex]) == "undefined" || this.pool.interfaces.comport[sourceIndex].type != "comport485"){continue;}

		for(var moduleIndex = 0, modules = this.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			var keyData = {
				"moduleKey": modules[moduleIndex].key
			};

			if(this.pool.interfaces.comport[sourceIndex].protocol == "dcon"){
				icpdasModuleKeyProcessor(modules[moduleIndex], keyData);
			}
			else if(this.pool.interfaces.comport[sourceIndex].protocol == "modbusRTU"){
				if(modules[moduleIndex].type == "icpdas"){//M7K
					icpdasModuleKeyProcessor(modules[moduleIndex], keyData);
				}
				else{
					modbusModuleKeyProcessor(modules[moduleIndex], keyData);
				}
			}
		}
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.network.length; sourceIndex++){
		if(typeof(this.pool.interfaces.network[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = this.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			var keyData = {
				"moduleKey": modules[moduleIndex].key
			};

			if(modules[moduleIndex].type == "icpdas"){//M7K
				icpdasModuleKeyProcessor(modules[moduleIndex], keyData);
			}
			else{
				modbusModuleKeyProcessor(modules[moduleIndex], keyData);
			}
		}
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(this.pool.interfaces.network[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = this.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			if(modules[moduleIndex].DI.amount > 0){
				this.pool.conditions['cameraDI']['key'].push(modules[moduleIndex].key);
			}

			if(modules[moduleIndex].DO.amount > 0){
				this.pool.conditions['cameraDO']['key'].push(modules[moduleIndex].key);
			}

			if(modules[moduleIndex].conditionEvent.amount > 0){
				this.pool.conditions['cameraEvent']['key'].push(modules[moduleIndex].key);
			}

			if(modules[moduleIndex].DO.amount > 0){
				this.pool.actions['cameraDO']['key'].push(modules[moduleIndex].key);
			}

//			if(modules[moduleIndex].actionEvent.amount > 0){
//				this.pool.actions['cameraEvent']['key'].push(modules[moduleIndex].key);
//			}

			if(modules[moduleIndex].actionSnapshot.amount > 0){
				this.pool.actions['cameraSnapshot']['key'].push(modules[moduleIndex].key);
			}

			if(modules[moduleIndex].actionVideo.amount > 0){
				this.pool.actions['cameraVideo']['key'].push(modules[moduleIndex].key);
			}
		}
	}
};

