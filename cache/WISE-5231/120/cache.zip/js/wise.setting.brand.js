var title = "WISE - ICP DAS";

var copyRight = "&copy; ICP DAS Co., Ltd. All Rights Reserved";