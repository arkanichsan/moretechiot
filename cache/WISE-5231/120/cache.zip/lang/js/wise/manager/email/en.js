﻿$.extend(true, Lang, {
	"js/wise/manager/email/rule/object.js": {
		"email": "Email",
		"send": "Send"
	}
});