﻿$.extend(true, Lang, {
	"js/wise/manager/schedule/rule/object.js": {
		"schedule": "排程",
		"outOfRange": "範圍外",
		"inRange": "範圍內"
	}
});