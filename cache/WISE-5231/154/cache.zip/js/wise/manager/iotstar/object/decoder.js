WISE.managers.iotstarManager.decodeXMLObject = function(xmlDoc){
	var moduleManager = WISE.managers.moduleManager;

	var $xmlREALTIME = $(xmlDoc).find("WISE > NOTE > IOTSTAR > REALTIME");
	if($xmlREALTIME.length > 0){
		this.pool.sendback.realtime.enable = true;

		var $xmlCOL = $xmlREALTIME.find("> COL");
		for(var i = 0; i < $xmlCOL.length; i++){
			var column = {};

			if($($xmlCOL[i]).attr("b_obj") == "IR"){
				column.channelType = "IR";
				column.registerIndex = parseInt($($xmlCOL[i]).attr("b_idx"), 10) - 1;
			}
			else{
				var module = null, protocol;
				if($($xmlCOL[i]).attr("b_obj") == "XBOARD"){
					var interfaces = moduleManager.pool.interfaces.onboard[0];
					protocol = interfaces.protocol;
					module = interfaces.modules[0];
				}
				else if($($xmlCOL[i]).attr("b_obj") == "DCON"){
					var interfaces = moduleManager.pool.interfaces.comport[parseInt($($xmlCOL[i]).attr("b_com"), 10)];
					protocol = interfaces.protocol;
					module = interfaces.modules[parseInt($($xmlCOL[i]).attr("b_idx"), 10) - 1];
				}
				else if($($xmlCOL[i]).attr("b_obj") == "RTU"){
					var interfaces = moduleManager.pool.interfaces.comport[parseInt($($xmlCOL[i]).attr("b_com"), 10)];
					protocol = interfaces.protocol;
					module = interfaces.modules[parseInt($($xmlCOL[i]).attr("b_idx"), 10) - 1];
				}
				else if($($xmlCOL[i]).attr("b_obj") == "TCP"){
					var interfaces = moduleManager.pool.interfaces.network[0];
					protocol = interfaces.protocol;
					module = interfaces.modules[parseInt($($xmlCOL[i]).attr("b_idx"), 10) - 1];
				}
				else if($($xmlCOL[i]).attr("b_obj") == "CAMERA"){
					var interfaces = moduleManager.pool.interfaces.camera[0];
					protocol = interfaces.protocol;
					module = interfaces.modules[parseInt($($xmlCOL[i]).attr("b_idx"), 10) - 1];
				}

				column.moduleKey = module.key;
				if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
					var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $($xmlCOL[i]).attr("b_ch"), parseInt($($xmlCOL[i]).attr("b_chn"), 10));
					column.channelType = channelIndexInfo[0];

					if(column.channelType == "IR"){
						column.registerIndex = channelIndexInfo[1];
					}
					else{
						column.channel = channelIndexInfo[1];
					}
				}
				else{
					if(typeof(module.extendedModule) != "undefined"){
						this.decodeXMLObject.processExtendedModuleRule(column, $($xmlCOL[i]));
					}
					else{
						column.channelType = $($xmlCOL[i]).attr("b_ch");

						if($($xmlCOL[i]).attr("b_cnt") == "1"){//is counter
							column.channelType = "DIC";
						}

						column.channel = parseInt($($xmlCOL[i]).attr("b_chn"), 10);
					}
				}
			}

			this.pool.sendback.realtime.columns.push(column);
		}

		var $xmlCOLNAME = $xmlREALTIME.find("> COLNAME");
		var splitArray = $xmlCOLNAME.text().split(",");
		for(var i = 0; i < splitArray.length; i++){
			this.pool.sendback.realtime.columns[i].name = splitArray[i];
		}
	}

	// Video
    var $xmlLINE_BOT = $(xmlDoc).find("WISE > NOTE > LINE_BOT");

    if($xmlLINE_BOT.length > 0){
		// IP Camera
		var $xmlCAMERA = $xmlLINE_BOT.find("> CAMERA");
		if($xmlCAMERA.length > 0){
			var moduleManager = WISE.managers.moduleManager;

			var $xmlC = $xmlCAMERA.find("> C");
			for(var i = 0; i < $xmlC.length; i++){
				if($($xmlC[i]).attr("mode") === undefined || $($xmlC[i]).attr("mode") == "0" || $($xmlC[i]).attr("mode") == "1"){// undefined for downward compatibility
					var moduleIndex = parseInt($($xmlC[i]).attr("camera_idx") - 1);

					var $xmlMSG = $($xmlC[i]).find("> MSG");

					moduleManager.pool.interfaces.camera[0].modules[moduleIndex].iotstar = {
						"enable": true,
						"content": $xmlMSG.text()
					};
				}
			}
		}

    	// CGI Server
		var $xmlCGI_SERVER = $xmlLINE_BOT.find("> CGI_SERVER");
	    if($xmlCGI_SERVER.length > 0){
	        var cgiManager = WISE.managers.cgiManager;

	        var $xmlC = $xmlCGI_SERVER.find("> C");
	        for(var i = 0; i < $xmlC.length; i++){
				if($($xmlC[i]).attr("mode") === undefined || $($xmlC[i]).attr("mode") == "0" || $($xmlC[i]).attr("mode") == "1"){// undefined for downward compatibility
		            var index = parseInt($($xmlC[i]).attr("idx") - 1);

					var $xmlMSG = $($xmlC[i]).find("> MSG");

		            cgiManager.pool.send.servers[index].iotstar = {
		                "enable": true,
		                "content": $xmlMSG.text()
		            };
				}
	        }
	    }

    	// FTP Server
	    var $xmlSENDBOX = $xmlLINE_BOT.find("> SENDBOX");
	    if($xmlSENDBOX.length > 0){
	        var systemManager = WISE.managers.systemManager;

			if($xmlSENDBOX.attr("mode") === undefined || $xmlSENDBOX.attr("mode") == "0" || $xmlSENDBOX.attr("mode") == "1"){// undefined for downward compatibility
				systemManager.pool.ftpServer.iotstar = {
		            "enable": true,
		            "content": $xmlSENDBOX.text()
				}
			}
	    }
	}
};