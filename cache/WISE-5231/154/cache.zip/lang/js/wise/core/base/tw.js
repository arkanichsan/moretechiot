$.extend(true, Lang, {
	"js/wise/core/base.js": {
		"camera": "網路攝影機"
	}
});