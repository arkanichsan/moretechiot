$.extend(true, Lang, {
	"js/wise/manager/azure/rule/object.js": {
		"connectionStatus": "联机状态",
		"offline": "断线",
		"online": "联机",
		"azureConnectionStatus": "Microsoft Azure联机状态",
		"subscribeMessage": "接收讯息",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"local": "本机",
		"remote": "远程",
		"internalRegister": "内部缓存器",
		"azureSubscribeMessage": "Microsoft Azure接收讯息",
		"bluemixSubscribeMessage": "IBM Bluemix接收讯息",
		"functionStatus": "功能状态",
		"azureFunctionStatus": "Microsoft Azure功能状态",
		"publishMessage": "发布讯息",
		"publish": "发布",
		"resetVariable": "重置参数",
		"reset": "重置"
	}
});