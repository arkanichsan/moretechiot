WISE.managers.smsManager.pool.actions = {
	"sms": {
		"name": "<#Lang['?'].smsAlarm>",
		"fileName": "asms",
		"rule":{
			"smsAlarmKey": null,
			"value": 0,
			"frequency": 0,
			"delay": 0
		},
		"check": function(){
			if(this.rule.smsAlarmKey == null){
				return false;
			}
			
			var smsManager = WISE.managers.smsManager;

			if(typeof(smsManager.pool.smsAlarms[this.rule.smsAlarmKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var smsManager = WISE.managers.smsManager;
			var smsAlarm = smsManager.pool.smsAlarms[this.rule.smsAlarmKey];
			var valueString = ["<#Lang['?'].send>"];

			return this.name + "(" + smsAlarm.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.smsAlarmKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.smsManager.updateRuleObject = function(){
	//clear key
	this.pool.actions['sms']['key'] = [];

	for(var key in this.pool.smsAlarms){
		this.pool.actions['sms']['key'].push(parseInt(key, 10));
	}
};