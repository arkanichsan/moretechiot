$.extend(true, Lang, {
	"js/wise/manager/messenger/rule/object.js": {
		"messenger": "Messenger",
        "send": "Send"
	}
});