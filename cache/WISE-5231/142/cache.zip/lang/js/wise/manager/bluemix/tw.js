$.extend(true, Lang, {
	"js/wise/manager/bluemix/rule/object.js": {
		"connectionStatus": "連線狀態",
		"offline": "斷線",
		"online": "連線",
		"bluemixConnectionStatus": "IBM Bluemix連線狀態",
		"subscribeMessage": "接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息",
		"functionStatus": "功能狀態",
		"bluemixFunctionStatus": "IBM Bluemix功能狀態",
		"publishMessage": "發佈訊息",
		"publish": "發佈",
		"bluemixPublishMessage": "IBM Bluemix發佈訊息",
		"resetVariable": "重置參數",
		"reset": "重置"
	}
});