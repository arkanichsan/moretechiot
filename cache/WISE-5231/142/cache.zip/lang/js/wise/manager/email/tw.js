$.extend(true, Lang, {
	"js/wise/manager/email/rule/object.js": {
		"email": "電子郵件",
		"send": "傳送"
	}
});