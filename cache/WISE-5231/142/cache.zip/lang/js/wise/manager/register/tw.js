$.extend(true, Lang, {
	"js/wise/manager/register/rule/object.js": {
		"internalRegister": "內部暫存器",
		"local": "本機",
		"remote": "遠端",
		"bit": "位元",
		"azureSubscribeMessage": "Microsoft Azure接收訊息",
		"bluemixSubscribeMessage": "IBM Bluemix接收訊息"
	}
});