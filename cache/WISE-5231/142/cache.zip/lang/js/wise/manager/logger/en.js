$.extend(true, Lang, {
	"js/wise/manager/logger/rule/object.js": {
		"dataLogger": "Data Logger",
		"moduleDataLogger": "I/O Module Data Logger",
		"customizedDataLogger": "User-Defined Data Logger",
		"oneTimeLog": "One-Time Log"
	},
	"js/wise/manager/logger/object/encoder.js": {
		"year": "Year",
		"month": "Month",
		"day": "Day",
		"hour": "Hour",
		"minute": "Minute",
		"second": "Second",
		"mode": "Mode",
		"diCounterX": "DI Counter $channel",
		"doCounterX": "DO Counter $channel",
		"internalRegisterX": "Internal Register $channel"
	}
});