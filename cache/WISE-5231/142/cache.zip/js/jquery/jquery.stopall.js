(function($) {
	$.fn.stopAll = function(){
		var queue = this.queue("fx");
		for(var i = 0; i < queue.length; i++){
			$(this).stop(false, true);
		}
		return $(this);
	};
})(jQuery);
