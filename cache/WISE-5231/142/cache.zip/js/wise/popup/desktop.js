function popupWindow(mode, message, settings){
	settings = $.extend(true, {
		"okButtonText": "<#Lang.global.ok>",
		"cancelButtonText": "<#Lang.global.cancel>",
		"callback": function(){}
	}, settings);

	disableHash(true);

	if(mode == 0){//Confirm
		$('#popupCancelButton').css("display", "inline");
		$('#popupIcon span').attr("class", "icon2 hugeWarning");
	}
	else if(mode == 1){//Error
		$('#popupCancelButton').css("display", "none");
		$('#popupIcon span').attr("class", "icon2 hugeError");
	}
	else if(mode == 2){//Done
		$('#popupCancelButton').css("display", "none");
		$('#popupIcon span').attr("class", "icon2 hugeOK");
	}
	else{//Alarm
		$('#popupCancelButton').css("display", "none");
		$('#popupIcon span').attr("class", "icon2 hugeWarning");
	}

	$("#popupOKButton").html(settings.okButtonText);
	$("#popupCancelButton").html(settings.cancelButtonText);

	popupCallback = function(result){//assign callback function
		disableHash(false);
		settings.callback(result);
	};

	$('#popupMessage').html(message);
	$('#popupWindow').show();

	$('.popupBackground').css("opacity", 0).animate({
		"opacity": 0.6
	}, "fast");

	$('.popupOuterTable').css("opacity", 0).animate({
		"opacity": 1
	}, "fast", function(){
		$('#popupOKButton').focus();
	});
}

function popupButtonClick(result){
	$('#popupWindow').fadeOut("fast", function(){
		popupCallback(result);
	});
}

function showWaitingMessage(message, callback){
	disableHash(true);

	//$("body").css("overflowY", "hidden");
	$("#waitingMessage").css("display", "block");
	$("#waitingMessageContent").html(message);

	var height = $("#waitingMessage .waitingMessageContentDiv").css("height", "").height();
	$("#waitingMessage .waitingMessageContentDiv").css("height", "0px").animate({"height": height + "px"}, "fast", function(){
		if(typeof(callback) == "function"){
			callback();
		}
	});
}

function hideWaitingMessage(){
	disableHash(false);

	//$("#waitingMessage .waitingMessageContentDiv").animate({"height": "0px"}, "fast", function(){
		//$("body").css("overflowY", "visible");
		$("#waitingMessage").css("display", "none");
	//});
}