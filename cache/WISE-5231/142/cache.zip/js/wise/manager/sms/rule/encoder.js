WISE.managers.smsManager.encodeXMLRule = function(xmlDoc, ruleObject){
	if(xmlDoc.tagName == "IF"){
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
		if(ruleObject.ruleObjectKey == "sms"){
			xmlDoc.setAttribute("l_obj", "SMS");
			xmlDoc.setAttribute("l_idx", this.pool.smsAlarms[ruleObject.rule.smsAlarmKey].index);
			xmlDoc.setAttribute("op", "0");
		}
	}
};