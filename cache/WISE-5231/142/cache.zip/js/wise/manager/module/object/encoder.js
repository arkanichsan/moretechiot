WISE.managers.moduleManager.encodeXMLObject = function(xmlDoc){
	var processICPDASModule = function(xmlDoc, xmlNode, module){
		for(var channelIndex = 0; channelIndex < module.DI.amount; channelIndex++){
			if(module.DI.setting[channelIndex].disable == true){continue;}

			var xmlDI = xmlDoc.createElement("DI");
			xmlDI.setAttribute("idx", channelIndex);

			if(module.type == "onboard"){
				xmlDI.setAttribute("cnt_type", ["0", "2", "1"][module.DI.setting[channelIndex].counterType]);
			}

			if(module.DI.setting[channelIndex].name != ""){
				xmlDI.setAttribute("nickname", module.DI.setting[channelIndex].name);
			}

			if(module.DI.setting[channelIndex].counterName != ""){
				xmlDI.setAttribute("cnt_nickname", module.DI.setting[channelIndex].counterName);
			}

			xmlNode.appendChild(xmlDI);
		}

		for(var channelIndex = 0; channelIndex < module.DO.amount; channelIndex++){
			if(module.DO.setting[channelIndex].disable == true){continue;}

			var xmlDO = xmlDoc.createElement("DO");
			xmlDO.setAttribute("idx", channelIndex);

			if(module.type == "onboard"){
				xmlDO.setAttribute("power_on", module.DO.setting[channelIndex].powerOnValue);
			}
			else if(module.type == "icpdas"){}

			if(module.DO.setting[channelIndex].advancedFunction == 1){
				xmlDO.setAttribute("pulse_hi", module.DO.setting[channelIndex].pulse.high);
				xmlDO.setAttribute("pulse_lo", module.DO.setting[channelIndex].pulse.low);
			}
			else if(module.DO.setting[channelIndex].advancedFunction == 2){
				xmlDO.setAttribute("back_off", module.DO.setting[channelIndex].autoOFF);
			}
			else if(module.DO.setting[channelIndex].advancedFunction == 3){
				xmlDO.setAttribute("di_map", "1");
			}

			if(module.DO.setting[channelIndex].name != ""){
				xmlDO.setAttribute("nickname", module.DO.setting[channelIndex].name);
			}

			if(module.DO.setting[channelIndex].counterName != ""){
				xmlDO.setAttribute("cnt_nickname", module.DO.setting[channelIndex].counterName);
			}

			xmlNode.appendChild(xmlDO);
		}

		for(var channelIndex = 0; channelIndex < module.AI.amount; channelIndex++){
			if(module.AI.setting[channelIndex].disable == true){continue;}

			var xmlAI = xmlDoc.createElement("AI");
			xmlAI.setAttribute("idx", channelIndex);

			if(module.type == "onboard"){
				xmlAI.setAttribute("type", module.AI.setting[channelIndex].type);
			}
			else if(module.type == "icpdas"){
				//if(module.moduleType != "DL"){
					xmlAI.setAttribute("type", module.AI.setting[channelIndex].type);
				//}
				//else{
				//	xmlAI.setAttribute("type", 0);
				//}
			}

			if(module.AI.setting[channelIndex].scale.max != 0 || module.AI.setting[channelIndex].scale.min != 0){
				xmlAI.setAttribute("scale_max", module.AI.setting[channelIndex].scale.max);
				xmlAI.setAttribute("scale_min", module.AI.setting[channelIndex].scale.min);
				xmlAI.setAttribute("scale_unit", module.AI.setting[channelIndex].scale.unit);
			}

			if(module.AI.setting[channelIndex].scale.ratio != 1 || module.AI.setting[channelIndex].scale.offset != 0){
				xmlAI.setAttribute("ratio", module.AI.setting[channelIndex].scale.ratio);
				xmlAI.setAttribute("offset", module.AI.setting[channelIndex].scale.offset);
				xmlAI.setAttribute("scale_unit", module.AI.setting[channelIndex].scale.unit);
			}

			if(module.AI.setting[channelIndex].name != ""){
				xmlAI.setAttribute("nickname", module.AI.setting[channelIndex].name);
			}

			xmlNode.appendChild(xmlAI);
		}

		for(var channelIndex = 0; channelIndex < module.AO.amount; channelIndex++){
			if(module.AO.setting[channelIndex].disable == true){continue;}

			var xmlAO = xmlDoc.createElement("AO");
			xmlAO.setAttribute("idx", channelIndex);

			if(module.type == "onboard"){
				xmlAO.setAttribute("type", module.AO.setting[channelIndex].type);
				xmlAO.setAttribute("power_on", module.AO.setting[channelIndex].powerOnValue);
			}
			else if(module.type == "icpdas"){
				xmlAO.setAttribute("type", module.AO.setting[channelIndex].type);
			}

			if(module.AO.setting[channelIndex].name != ""){
				xmlAO.setAttribute("nickname", module.AO.setting[channelIndex].name);
			}

			xmlNode.appendChild(xmlAO);
		}

		for(var channelIndex = 0; channelIndex < module.IR.amount; channelIndex++){
			if(module.IR.setting[channelIndex].name != ""){
				var xmlREG = xmlDoc.createElement("REG");
				xmlREG.setAttribute("idx", channelIndex + 1);
				xmlREG.setAttribute("nickname", module.IR.setting[channelIndex].name);
				xmlNode.appendChild(xmlREG);
			}
		}

		if(module.moduleType == "IR"){
			for(var i = 0; i < module.command.length; i++){
				if(typeof(module.command[i]) != "undefined"){
					var xmlIR = xmlDoc.createElement("IR");
					xmlIR.setAttribute("idx", i + 1);
					xmlIR.appendChild(xmlDoc.createTextNode(module.command[i]));
					xmlNode.appendChild(xmlIR);
				}
			}
		}
	};

	var processModbusModule = function(xmlDoc, xmlNode, module, isICPDASModule){//if isICPDASModule == true, encode rule without hex_xxx attribute, name and unit
		for(var dataModelIndex = 0, dataModelArray = ["CI", "CO", "RI", "RO"]; dataModelIndex < dataModelArray.length; dataModelIndex++){
			var dataModel = dataModelArray[dataModelIndex];

			for(var blockArrayIndex = 0; blockArrayIndex < module[dataModel].blockArray.length; blockArrayIndex++){
				var xmlElement = xmlDoc.createElement(dataModel);
				xmlElement.setAttribute("idx", blockArrayIndex);
				xmlElement.setAttribute("start_add", module[dataModel].blockArray[blockArrayIndex].startAddress);
				xmlElement.setAttribute("len", module[dataModel].blockArray[blockArrayIndex].length);

				if(module[dataModel].blockArray[blockArrayIndex].cross == true){
					xmlElement.setAttribute("cross", "1");
				}

				if(module[dataModel].blockArray[blockArrayIndex].visible == false){
					xmlElement.setAttribute("visible", "0");
				}

				if(dataModel == "RI" || dataModel == "RO"){
					xmlElement.setAttribute("type", module[dataModel].blockArray[blockArrayIndex].type);

					if(isICPDASModule != true){
						xmlElement.setAttribute("endian", module[dataModel].blockArray[blockArrayIndex].inverse == true ? "1" : "0");

						if(module[dataModel].blockArray[blockArrayIndex].scaleRatio != 1){
							xmlElement.setAttribute("ratio", module[dataModel].blockArray[blockArrayIndex].scaleRatio);
						}
						if(module[dataModel].blockArray[blockArrayIndex].offset != 0){
							xmlElement.setAttribute("offset", module[dataModel].blockArray[blockArrayIndex].offset);
						}

						if(module[dataModel].blockArray[blockArrayIndex].type == 2){
							xmlElement.setAttribute("hex_max", module[dataModel].blockArray[blockArrayIndex].hexMax);
							xmlElement.setAttribute("hex_min", module[dataModel].blockArray[blockArrayIndex].hexMin);
							xmlElement.setAttribute("real_max", module[dataModel].blockArray[blockArrayIndex].realMax);
							xmlElement.setAttribute("real_min", module[dataModel].blockArray[blockArrayIndex].realMin);
						}
					}
				}

				if(dataModel == "CO" || dataModel == "RO"){
					if(isICPDASModule != true){
						var readWrite = 0;

						if(module[dataModel].blockArray[blockArrayIndex].readable == true){
							readWrite += 1;
						}
						if(module[dataModel].blockArray[blockArrayIndex].writable == true){
							readWrite += 2;
						}

						xmlElement.setAttribute("rw", readWrite);
					}
				}

				for(var dataIndex = 0; dataIndex < module[dataModel].blockArray[blockArrayIndex].length && isICPDASModule != true; dataIndex++){
					var hasAttribute = false;
					var xmlN = xmlDoc.createElement("N");
					xmlN.setAttribute("idx", dataIndex);

					if(module[dataModel].blockArray[blockArrayIndex].name[dataIndex] != ""){
						xmlN.setAttribute("nickname", module[dataModel].blockArray[blockArrayIndex].name[dataIndex]);
						hasAttribute = true;
					}
					if((dataModel == "RI" || dataModel == "RO") && module[dataModel].blockArray[blockArrayIndex].unit[dataIndex] != ""){
						xmlN.setAttribute("unit", module[dataModel].blockArray[blockArrayIndex].unit[dataIndex]);
						hasAttribute = true;
					}
					
					if(hasAttribute == true){
						xmlElement.appendChild(xmlN);
					}
				}

				xmlNode.appendChild(xmlElement);
			}
		}
	};

	var calculateChannelAmount = function(module, channelType){
		var amount = 0;

		for(var channelIndex = 0; channelIndex < module[channelType].amount; channelIndex++){
			if(module[channelType].setting[channelIndex].disable == false){
				amount++;
			}
		}

		return amount;
	}

	if(typeof(this.pool.interfaces.onboard[0]) != "undefined" && typeof(this.pool.interfaces.onboard[0].modules[0]) != "undefined"){
		var module = this.pool.interfaces.onboard[0].modules[0];
		var xmlXBOARD = xmlDoc.createElement("XBOARD");

		xmlXBOARD.setAttribute("name", module.modelName);
		xmlXBOARD.setAttribute("group", module.mainType);
		xmlXBOARD.setAttribute("sub", module.subType);
		xmlXBOARD.setAttribute("type", {
			"xw": "W",
			"xv": "V",
		}[this.pool.interfaces.onboard[0].protocol]);
		xmlXBOARD.setAttribute("di", calculateChannelAmount(module, "DI"));
		xmlXBOARD.setAttribute("do", calculateChannelAmount(module, "DO"));
		xmlXBOARD.setAttribute("ai", calculateChannelAmount(module, "AI"));
		xmlXBOARD.setAttribute("ao", calculateChannelAmount(module, "AO"));
		xmlXBOARD.setAttribute("nickname", module.name);
		if(module.AI.singleEnded == 1){
			xmlXBOARD.setAttribute("single_end", module.AI.singleEnded);
		}
		xmlXBOARD.setAttribute("start_address", this.pool.interfaces.onboard[0].modbusTableStartAddress);
		xmlXBOARD.setAttribute("uid", module.uid);
		xmlXBOARD.setAttribute("csv_header", module._csvHeader);
		xmlXBOARD.setAttribute("csv_index", module._csvIndex);
		xmlXBOARD.setAttribute("level", module.permission.userLevel);

		if(module.description != ""){
			xmlXBOARD.setAttribute("desc", module.description);
		}

		processICPDASModule(xmlDoc, xmlXBOARD, module);

		xmlDoc.documentElement.appendChild(xmlXBOARD);
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.comport.length; sourceIndex++){
		if(typeof(this.pool.interfaces.comport[sourceIndex]) == "undefined" || this.pool.interfaces.comport[sourceIndex].protocol == null){continue;}

		var xmlCOM = xmlDoc.createElement("COM");
		xmlCOM.setAttribute("idx", sourceIndex);
		if(this.pool.interfaces.comport[sourceIndex].type == "comport232"){
			xmlCOM.setAttribute("baud", this.pool.interfaces.comport[sourceIndex].baudrate);
			xmlCOM.setAttribute("parity", ["N", "O", "E"][this.pool.interfaces.comport[sourceIndex].parity]);
			xmlCOM.setAttribute("stopbit", this.pool.interfaces.comport[sourceIndex].stopbits);

			if(this.pool.interfaces.comport[sourceIndex].protocol == "hmi"){
				xmlCOM.setAttribute("type", "3");
			}
		}
		else if(this.pool.interfaces.comport[sourceIndex].type == "comport485"){
			xmlCOM.setAttribute("baud", this.pool.interfaces.comport[sourceIndex].baudrate);
			xmlCOM.setAttribute("parity", ["N", "O", "E"][this.pool.interfaces.comport[sourceIndex].parity]);
			xmlCOM.setAttribute("stopbit", this.pool.interfaces.comport[sourceIndex].stopbits);

			if(this.pool.interfaces.comport[sourceIndex].protocol == "dcon"){
				xmlCOM.setAttribute("type", "1");
				xmlCOM.setAttribute("timeout", this.pool.interfaces.comport[sourceIndex].dcon.timeout);
				xmlCOM.setAttribute("checksum", this.pool.interfaces.comport[sourceIndex].dcon.checksum);

				for(var moduleIndex = 0, modules = this.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
					if(typeof(modules[moduleIndex]) == "undefined"){continue;}

					var module = modules[moduleIndex];
					var xmlMODULE = xmlDoc.createElement("MODULE");	
					xmlMODULE.setAttribute("idx", moduleIndex + 1);
					xmlMODULE.setAttribute("address", module.address);
					xmlMODULE.setAttribute("name", module.modelName);
					xmlMODULE.setAttribute("group", module.mainType);
					xmlMODULE.setAttribute("sub", module.subType);
					xmlMODULE.setAttribute("di", module.DI.amount);
					xmlMODULE.setAttribute("do", module.DO.amount);
					xmlMODULE.setAttribute("ai", module.AI.amount);
					xmlMODULE.setAttribute("ao", module.AO.amount);
					xmlMODULE.setAttribute("nickname", module.name);
					xmlMODULE.setAttribute("update_delay", module.scanInterval);
					xmlMODULE.setAttribute("retry", module.retryInterval);
					if(module.AI.singleEnded == 1){
						xmlMODULE.setAttribute("single_end", module.AI.singleEnded);
					}
					if(module.temperatureUnit == 1){
						xmlMODULE.setAttribute("fahrenheit", module.temperatureUnit);
					}
					xmlMODULE.setAttribute("start_address", this.pool.interfaces.comport[sourceIndex].modbusTableStartAddress + this.modbusTableMaxLength * moduleIndex);
					xmlMODULE.setAttribute("uid", module.uid);
					xmlMODULE.setAttribute("csv_header", module._csvHeader);
					xmlMODULE.setAttribute("csv_index", module._csvIndex);
					xmlMODULE.setAttribute("level", module.permission.userLevel);

					if(module.description != ""){
						xmlMODULE.setAttribute("desc", module.description);
					}

					processICPDASModule(xmlDoc, xmlMODULE, module);

					xmlCOM.appendChild(xmlMODULE);
				}
			}
			else if(this.pool.interfaces.comport[sourceIndex].protocol == "modbusRTU"){
				xmlCOM.setAttribute("type", "2");
				xmlCOM.setAttribute("silent", this.pool.interfaces.comport[sourceIndex].modbusRTU.silentInterval);

				for(var moduleIndex = 0, modules = this.pool.interfaces.comport[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
					if(typeof(modules[moduleIndex]) == "undefined"){continue;}

					var module = modules[moduleIndex];
					var xmlMODULE = xmlDoc.createElement("MODULE");

					if(module.type == "icpdas"){//M7K
						xmlMODULE.setAttribute("name", module.modelName);
						if(module.AI.singleEnded == 1){
							xmlMODULE.setAttribute("single_end", module.AI.singleEnded);
						}
						if(module.temperatureUnit == 1){
							xmlMODULE.setAttribute("fahrenheit", module.temperatureUnit);
						}

						var tempModule = this.icpdasModule.toModbusModule(module);//create a modbus module
						xmlMODULE.setAttribute("ci", tempModule.CI.blockArray.length);
						xmlMODULE.setAttribute("co", tempModule.CO.blockArray.length);
						xmlMODULE.setAttribute("ri", tempModule.RI.blockArray.length);
						xmlMODULE.setAttribute("ro", tempModule.RO.blockArray.length);
						processModbusModule(xmlDoc, xmlMODULE, tempModule, true);

						var xmlM7000 = xmlDoc.createElement("M7000");
						processICPDASModule(xmlDoc, xmlM7000, module);
						xmlMODULE.appendChild(xmlM7000);
					}
					else{
						xmlMODULE.setAttribute("ci", module.CI.blockArray.length);
						xmlMODULE.setAttribute("co", module.CO.blockArray.length);
						xmlMODULE.setAttribute("ri", module.RI.blockArray.length);
						xmlMODULE.setAttribute("ro", module.RO.blockArray.length);
						processModbusModule(xmlDoc, xmlMODULE, module);
					}

					xmlMODULE.setAttribute("idx", moduleIndex + 1);
					xmlMODULE.setAttribute("address", module.type == "icpdas" ? module.address : module.modbusRTU.address);
					xmlMODULE.setAttribute("nickname", module.name);
					xmlMODULE.setAttribute("update_delay", module.scanInterval);
					xmlMODULE.setAttribute("retry", module.retryInterval);
					xmlMODULE.setAttribute("timeout", module.pollingTimeout);
					xmlMODULE.setAttribute("start_address", this.pool.interfaces.comport[sourceIndex].modbusTableStartAddress + this.modbusTableMaxLength * moduleIndex);
					xmlMODULE.setAttribute("uid", module.uid);
					xmlMODULE.setAttribute("csv_header", module._csvHeader);
					xmlMODULE.setAttribute("csv_index", module._csvIndex);
					xmlMODULE.setAttribute("level", module.permission.userLevel);

					if(module.description != ""){
						xmlMODULE.setAttribute("desc", module.description);
					}

					xmlCOM.appendChild(xmlMODULE);
				}
			}
			else if(this.pool.interfaces.comport[sourceIndex].protocol == "hmi"){
				xmlCOM.setAttribute("type", "4");
			}
		}
		xmlDoc.documentElement.appendChild(xmlCOM);
	}

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.network.length; sourceIndex++){
		if(typeof(this.pool.interfaces.network[sourceIndex]) == "undefined" || this.pool.interfaces.network[sourceIndex].protocol == null){continue;}

		var xmlTCP = xmlDoc.createElement("TCP");
		if(this.pool.interfaces.network[sourceIndex].protocol == "modbusTCP"){
			for(var moduleIndex = 0, modules = this.pool.interfaces.network[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];
				var xmlMODULE = xmlDoc.createElement("MODULE");	

				if(module.type == "icpdas"){//M7K
					xmlMODULE.setAttribute("name", module.modelName);
					if(module.AI.singleEnded == 1){
						xmlMODULE.setAttribute("single_end", module.AI.singleEnded);
					}
					if(module.temperatureUnit == 1){
						xmlMODULE.setAttribute("fahrenheit", module.temperatureUnit);
					}

					var tempModule = this.icpdasModule.toModbusModule(module);//create a modbus module
					xmlMODULE.setAttribute("ci", tempModule.CI.blockArray.length);
					xmlMODULE.setAttribute("co", tempModule.CO.blockArray.length);
					xmlMODULE.setAttribute("ri", tempModule.RI.blockArray.length);
					xmlMODULE.setAttribute("ro", tempModule.RO.blockArray.length);
					processModbusModule(xmlDoc, xmlMODULE, tempModule, true);

					var xmlM7000 = xmlDoc.createElement("M7000");
					processICPDASModule(xmlDoc, xmlM7000, module);
					xmlMODULE.appendChild(xmlM7000);
				}
				else{
					xmlMODULE.setAttribute("ci", module.CI.blockArray.length);
					xmlMODULE.setAttribute("co", module.CO.blockArray.length);
					xmlMODULE.setAttribute("ri", module.RI.blockArray.length);
					xmlMODULE.setAttribute("ro", module.RO.blockArray.length);
					processModbusModule(xmlDoc, xmlMODULE, module);
				}

				xmlMODULE.setAttribute("idx", moduleIndex + 1);
				xmlMODULE.setAttribute("ip", integerToIP(module.type == "icpdas" ? module.ip : module.modbusTCP.ip));
				xmlMODULE.setAttribute("port", module.type == "icpdas" ? module.port : module.modbusTCP.port);
				xmlMODULE.setAttribute("netid", module.type == "icpdas" ? module.netID : module.modbusTCP.netID);
				xmlMODULE.setAttribute("nickname", module.name);
				xmlMODULE.setAttribute("update_delay", module.scanInterval);
				xmlMODULE.setAttribute("retry", module.retryInterval);
				xmlMODULE.setAttribute("timeout", module.pollingTimeout);
				xmlMODULE.setAttribute("start_address", this.pool.interfaces.network[sourceIndex].modbusTableStartAddress + this.modbusTableMaxLength * moduleIndex);
				xmlMODULE.setAttribute("uid", module.uid);
				xmlMODULE.setAttribute("csv_header", module._csvHeader);
				xmlMODULE.setAttribute("csv_index", module._csvIndex);
				xmlMODULE.setAttribute("level", module.permission.userLevel);

				if(module.description != ""){
					xmlMODULE.setAttribute("desc", module.description);
				}

				xmlTCP.appendChild(xmlMODULE);
			}
		}

		xmlDoc.documentElement.appendChild(xmlTCP);
	}

	var loggerManager = WISE.managers.loggerManager;
	var processFTPAttribute = function(ftpServers){
		var ftpAttribute = "";
		for(var i = 0; i < ftpServers.length; i++){
			if(typeof(loggerManager.pool.ftp.servers[ftpServers[i]]) == "undefined"){continue;}

			ftpAttribute += loggerManager.pool.ftp.servers[ftpServers[i]].index + ",";
		}
		return ftpAttribute.substr(0, ftpAttribute.length - 1);
	};

	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(this.pool.interfaces.camera[sourceIndex]) == "undefined" || this.pool.interfaces.camera[sourceIndex].protocol == null){continue;}

		var xmlIPCAMERA = xmlDoc.createElement("IPCAMERA");
		if(this.pool.interfaces.camera[sourceIndex].protocol == "httpCGI"){
			for(var moduleIndex = 0, modules = this.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];

				var xmlCAM = xmlDoc.createElement("CAM");
				xmlCAM.setAttribute("idx", moduleIndex + 1);
				xmlCAM.setAttribute("type", module.modelName);
				xmlCAM.setAttribute("server", integerToIP(module.ip));
				xmlCAM.setAttribute("port", module.port);
				xmlCAM.setAttribute("timesync", module.timeSync == true ? "1" : "0");
				xmlCAM.setAttribute("ftp", processFTPAttribute(module.ftpServers));

				xmlCAM.setAttribute("id", module.authInfo.id);
				if(module.authInfo.password.plain == "" || module.authInfo.password.plain != padding("", module.authInfo.password.length, "*")){//setup new password
					xmlCAM.setAttribute("password", module.authInfo.password.plain);
					xmlCAM.setAttribute("password_len", module.authInfo.password.plain.length);
				}
				else{
					xmlCAM.setAttribute("password", module.authInfo.password.encoded);
					xmlCAM.setAttribute("password_len", module.authInfo.password.length);
				}

				xmlCAM.setAttribute("nickname", module.name);
				if(module.description != ""){
					xmlCAM.setAttribute("desc", module.description);
				}

				// OSD
				for(osdKey in module.osd.osds){
					var osd = module.osd.osds[osdKey];

					var xmlOSD = xmlDoc.createElement("OSD");
					xmlOSD.setAttribute("idx", osd.index);
					xmlOSD.setAttribute("nickname", osd.name);

					if(osd.description != ""){
						xmlOSD.setAttribute("desc", osd.description);
					}
					xmlOSD.setAttribute("interval", osd.duration);
					xmlOSD.setAttribute("color", {
						"0": "White",
						"1": "Black",
						"2": "Red",
						"3": "Green",
						"4": "Blue",
						"5": "Yellow"
					}[osd.color]);
					xmlOSD.setAttribute("msg", osd.text);

					if(osd.timeout.enable == true){
						xmlOSD.setAttribute("timeout_flag", "1");
						xmlOSD.setAttribute("timeout_msg", osd.timeout.text);
						xmlOSD.setAttribute("timeout_color", {
							"0": "White",
							"1": "Black",
							"2": "Red",
							"3": "Green",
							"4": "Blue",
							"5": "Yellow"
						}[osd.timeout.color]);
					}
					else{
						xmlOSD.setAttribute("timeout_flag", "0");
					}

					xmlCAM.appendChild(xmlOSD);
				}

				xmlIPCAMERA.appendChild(xmlCAM);
			}
		}

		xmlDoc.documentElement.appendChild(xmlIPCAMERA);
	}

	return xmlDoc;
};

WISE.managers.moduleManager.updateIndex = function(){
	// OSD
	for(var sourceIndex = 0; sourceIndex < this.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(this.pool.interfaces.camera[sourceIndex]) == "undefined" || this.pool.interfaces.camera[sourceIndex].protocol == null){continue;}

		if(this.pool.interfaces.camera[sourceIndex].protocol == "httpCGI"){
			for(var moduleIndex = 0, modules = this.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
				if(typeof(modules[moduleIndex]) == "undefined"){continue;}

				var module = modules[moduleIndex];

				var index = 0;
				for(var osdKey in module.osd.osds){
					module.osd.osds[osdKey].index = ++index;
				}
			}
		}
	}
};