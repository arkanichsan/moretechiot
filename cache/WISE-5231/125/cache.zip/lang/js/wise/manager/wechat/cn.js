$.extend(true, Lang, {
	"js/wise/manager/wechat/rule/object.js": {
        "weChat": "微信",
		"send": "传送"
	}
});