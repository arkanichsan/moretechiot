WISE.managers.ruleManager = (function(){
	return new function() {
		this.pool = {
			rules: {},
			key: 0,
			executionOrder: []
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxRuleAmount = 36;
		this.maxConditionAmount = 6;
		this.maxActionAmount = 12;

		this.createRule = function(settings){
			var rule = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"enable": true
			}, settings);

			rule.ifConditions = {"rules":[], "executionOrder":[], "operate": 1};//0 = OR, 1 = AND
			rule.thenActions = {"rules":[], "executionOrder":[]};
			rule.elseActions = {"rules":[], "executionOrder":[]};

			return rule;
		};

		this.addRule = function(rule){
			this.pool.rules[this.pool.key] = rule;
			this.pool.executionOrder.push(this.pool.key);
			return this.pool.key++;
		};

		this.removeRule = function(key){
			for(var i = 0; i < this.pool.executionOrder.length; i++){
				if(this.pool.executionOrder[i] == key){
					this.pool.executionOrder.splice(i, 1);
					break;
				}
			}

			delete this.pool.rules[key];
		};

		this.cloneRule = function(key){
			var cloneRule = $.extend(true, {}, this.pool.rules[key]);

			cloneRule.name += "(<#Lang['?'].copy>)";

			return this.addRule(cloneRule);
		};

		this.setRule = function(key, rule){
			this.pool.rules[key] = rule;
		};

		this.listSelection = function(type){
			var list = {};
			var managers = WISE.managers;
			var processKey = function(managerKey, ruleObjectKey){
				return {
					"managerKey": managerKey,
					"ruleObjectKey": ruleObjectKey,
					"ruleName": managers[managerKey].pool[type][ruleObjectKey].name,
					"fileName": managers[managerKey].pool[type][ruleObjectKey].fileName
				};
			};

			for(var managerKey in managers){
				for(var ruleObjectKey in managers[managerKey].pool[type]){
					if(managers[managerKey].pool[type][ruleObjectKey].key.length > 0){
						var pathArray = (function(ruleObject){
							if(typeof(ruleObject.menuPath) == "undefined"){return [];}
							else{
								var splitArray = ruleObject.menuPath.split(">");
								for(var i = 0; i < splitArray.length; i++){
									if(typeof(splitArray[i]) == "undefined" || splitArray[i] == ""){
										splitArray.splice(i--, 1);
									}
								}
								return splitArray;
							}
						})(managers[managerKey].pool[type][ruleObjectKey]);

						if(pathArray.length == 0){
							list["_" + ruleObjectKey] = processKey(managerKey, ruleObjectKey);
						}
						else{
							for(var i = 0, path = list; i < pathArray.length; i++){
								if(typeof(path[pathArray[i]]) == "undefined"){
									path[pathArray[i]] = {};
								}

								if(i + 1 >= pathArray.length){
									path[pathArray[i]]["_" + ruleObjectKey] = processKey(managerKey, ruleObjectKey);
								}
								else{
									path = path[pathArray[i]];
								}
							}
						}
					}
				}
			}

			return list;
		};

		this.checkRules = function(){//return true means no error
			for(var ruleKey in this.pool.rules){
				var rule = this.pool.rules[ruleKey];

				for(var i = 0, ruleTypeArray = ["ifConditions", "thenActions", "elseActions"]; i < ruleTypeArray.length; i++){
					for(var j = 0; j < rule[ruleTypeArray[i]].executionOrder.length; j++){
						var ruleObject = rule[ruleTypeArray[i]].rules[rule[ruleTypeArray[i]].executionOrder[j]];

						if(!ruleObject.check()){
							return false;
						}
					}
				}
			}

			return true;
		};
	};
})();
