WISE.managers.mqttManager.decodeXMLRule = function(xmlDoc){
	var ruleObject = null;
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.decodeXMLRule.processCompareModule;

	if($(xmlDoc).attr("l_obj") == "MQTT"){
		if(xmlDoc.tagName == "IF"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.broker);
				ruleObject.rule.brokerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("r_obj"), 10);
			}
			else if($(xmlDoc).attr("l_ch") == "SUB"){
				ruleObject = WISE.createRuleObject(this.pool.conditions.topic);
				ruleObject.rule.brokerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.topicKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.operate = parseInt($(xmlDoc).attr("op"), 10);
				processCompareModule(xmlDoc, ruleObject);
			}
		}
		else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
			if($(xmlDoc).attr("l_ch") == "BROKER"){
				ruleObject = WISE.createRuleObject(this.pool.actions.broker);
				ruleObject.rule.brokerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "PUB"){
				ruleObject = WISE.createRuleObject(this.pool.actions.message);
				ruleObject.rule.brokerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.messageKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
			else if($(xmlDoc).attr("l_ch") == "SUB"){
				ruleObject = WISE.createRuleObject(this.pool.actions.topic);
				ruleObject.rule.brokerKey = parseInt($(xmlDoc).attr("l_idx"), 10) - 1;
				ruleObject.rule.topicKey = parseInt($(xmlDoc).attr("l_chn"), 10) - 1;
				ruleObject.rule.value = parseInt($(xmlDoc).attr("op"), 10);
				ruleObject.rule.delay = parseInt($(xmlDoc).attr("sleep") || 0, 10);
			}
		}
	}

	return ruleObject;
};
