WISE.managers.lineBotManager.encodeXMLObject = function(xmlDoc){
	var xmlLINE_BOT = xmlDoc.createElement("LINE_BOT");

	// Message
	var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

	for(var key in this.pool.messages){
		var message = this.pool.messages[key];
		var xmlM = xmlDoc.createElement("M");

		xmlM.setAttribute("idx", message.index);
		xmlM.setAttribute("nickname", message.name);

		if(message.description != ""){
			xmlM.setAttribute("desc", message.description);
		}

		xmlM.appendChild(xmlDoc.createTextNode(message.content));

		xmlMESSAGE.appendChild(xmlM);
	}

	if(xmlMESSAGE.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlMESSAGE);
	}

	// IP Camera
	var counter = 0;
	var xmlCAMERA = xmlDoc.createElement("CAMERA");

	var moduleManager = WISE.managers.moduleManager;
	for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
		if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

		for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
			if(typeof(modules[moduleIndex]) == "undefined"){continue;}

			var xmlC = xmlDoc.createElement("C");
			xmlC.setAttribute("camera_idx", moduleIndex + 1);

			try{
				if(modules[moduleIndex].lineBot.enable == true){
					var xmlMSG = xmlDoc.createElement("MSG");

					xmlMSG.appendChild(xmlDoc.createTextNode(modules[moduleIndex].lineBot.content));

					xmlC.appendChild(xmlMSG);
				}
			}
			catch(error){}

			if(xmlC.childNodes.length > 0){
				xmlC.setAttribute("idx", ++counter);
				xmlCAMERA.appendChild(xmlC);
			}
		}
	}

	if(xmlCAMERA.childNodes.length > 0){
		xmlLINE_BOT.appendChild(xmlCAMERA);
	}

	// 
	if(xmlLINE_BOT.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlLINE_BOT);
				break;
			}
		}
	}
};

WISE.managers.lineBotManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};