WISE.managers.pingManager = (function(){
	return new function() {
		this.pool = {
			pings: {},
			key: 0
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxAmount = 12;

		this.createPing = function(settings){
			var ping = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"target": "",
				"timeout": 1000,//ms
				"interval": 1,//sec
				"condition": {
					"mode": "continuous",
					"continuous":{
						"fail": 5//fail times
					},
					"accumulative":{
						"fail": 5,//fail times
						"test": 10//total times
					}
				}
			}, settings);

			return ping;
		};

		this.addPing = function(ping){
			var retKey = this.pool.key;
			this.pool.pings[this.pool.key++] = ping;
			return retKey;
		};

		this.removePing = function(key){
			delete this.pool.pings[key];
		};

		this.getPing = function(key){
			if(typeof(this.pool.pings[key]) != "undefined"){
				return this.pool.pings[key];
			}
			else{
				return null;
			}
		};

		this.setPing = function(key, ping){
			this.pool.pings[key] = ping;
		};

		this.getPings = function(){
			return this.pool.pings;
		};
	};
})();
