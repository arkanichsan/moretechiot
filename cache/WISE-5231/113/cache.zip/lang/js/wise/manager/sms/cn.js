﻿$.extend(true, Lang, {
	"js/wise/manager/sms/rule/object.js": {
		"smsAlarm": "SMS简讯警报",
		"send": "传送"
	}
});