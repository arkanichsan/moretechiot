﻿$.extend(true, Lang, {
	"js/wise/manager/module/base.js": {
		"humidity": "相對濕度",
		"celsiusTemperature": "溫度(°C)",
		"fahrenheitTemperature": "溫度(°F)",
		"celsiusDewPointTemperature": "露點溫度(°C)",
		"fahrenheitDewPointTemperature": "露點溫度(°F)"
	},
	"js/wise/manager/module/rule/object.js": {
		"icpdasModule": "泓格模組",
		"modbusModule": "Modbus模組",
		"diCounter": "DI計數器",
		"doCounter": "DO計數器",
		"onToOFF": "ON至OFF",
		"offToON": "OFF至ON",
		"statusChange": "狀態改變",
		"change": "變動",
		"local": "本機",
		"remote": "遠端",
		"internalRegister": "內部暫存器",
		"reset": "重置",
		"connectionStatus": "連線狀態",
		"online": "連線",
		"offline": "斷線",
		"pulseOutput": "脈衝輸出",
		"infrared": "紅外線",
		"ch": "通道",
		"transmitCommand": "發送命令"
	}
});