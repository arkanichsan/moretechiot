WISE.managers.mqttManager = (function(){
	return new function() {
		this.pool = {
			brokers: {},
			key: 0,
			imports: {
				"topics": []
			}
		};

		//.object.encoder.js
		this.encodeXMLObject = function(xmlDoc){};
		this.updateIndex = function(){};

		//.object.decoder.js
		this.decodeXMLObject = function(xmlDoc){};


		//.rule.object.js
		this.pool.conditions = {};
		this.pool.actions = {};
		this.updateRuleObject = function(){};

		//.rule.encoder.js
		this.encodeXMLRule = function(xmlDoc, ruleObject){};
		this.beforeEncodeRuleFile = function(){};
		this.afterEncodeRuleFile = function(){};
		this.check = function(){};

		//.rule.decoder.js
		this.decodeXMLRule = function(xmlDoc){};
		this.beforeDecodeRuleFile = function(){};
		this.afterDecodeRuleFile = function(){};

		/*customize data member*/
		this.maxBrokerAmount = 2;
		this.maxPublishMessageAmount = 12;
		this.maxSubscribeTopicAmount = 12;

		this.createBroker = function(settings){
			var broker = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"initialStatus": true,//false is disable, true is enable
				"address": "",
				"port": 1883,
				"authInfo": {
					"enable": false,
					"id": "",
					"password": {
						"plain": "",
						"encoded": "",
						"length": 0,
					}
				},
				"encryption": false,
				"clientId": "",
				"keepAliveTimer": 60,

				"will": {
					"enable": false,
					"topicName": "",
					"payload": "",
					"qos": 0
				},
				"publishInterval": 5,
				"prefix": "",

				"publish": {
					"messages": {},
					"key": 0
				},
				"subscribe": {
					"topics": {},
					"key": 0
				}
			}, settings);
			
			return broker;
		};

		this.addBroker = function(broker){
			var retKey = this.pool.key;
			this.pool.brokers[this.pool.key++] = broker;
			return retKey;
		};

		this.removeBroker = function(key){
			delete this.pool.brokers[key];
		};

		this.getBroker = function(key){
			if(typeof(this.pool.brokers[key]) != "undefined"){
				return this.pool.brokers[key];
			}
			else{
				return null;
			}
		};

		this.setBroker = function(key, broker){
			this.pool.brokers[key] = broker;
		};

		this.getBrokers = function(){
			return this.pool.brokers;
		};

		//Publish Topic
		this.createPublishMessage = function(settings){
			var message = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"topicName": "",// aa/bb/cc
				"usePrefix": false,
				"type": 0,//0: channel, 1: user-defined
				"payload": "",
				"qos": 0,
				"retain": false,
				"autoPublish": {
					"timing": 0,//bit0(1): when chagne, bit1(2): fixed interval,
					"threshold": 1
				}
			}, settings);
			
			return message;
		};

		this.addPublishMessage = function(broker, message){
			var retKey = broker.publish.key;
			broker.publish.messages[broker.publish.key++] = message;
			return retKey;
		};

		this.removePublishMessage = function(broker, key){
			delete broker.publish.messages[key];
		};

		this.getPublishMessage = function(broker, key){
			if(typeof(broker.publish.messages[key]) != "undefined"){
				return broker.publish.messages[key];
			}
			else{
				return null;
			}
		};

		this.setPublishMessage = function(broker, key, message){
			broker.publish.messages[key] = message;
		};

		this.getPublishMessages = function(broker){
			return broker.publish.messages;
		};

		//Subscribe Topic
		this.createSubscribeTopic = function(settings){
			var topic = $.extend(true, {
				"index": 0,
				"name": "",
				"description": "",
				"reference": [],

				"topicName": "",// aa/bb/cc
				"usePrefix": false,
				"qos": 0
			}, settings);
			
			return topic;
		};

		this.addSubscribeTopic = function(broker, topic){
			var retKey = broker.subscribe.key;
			broker.subscribe.topics[broker.subscribe.key++] = topic;
			return retKey;
		};

		this.removeSubscribeTopic = function(broker, key){
			delete broker.subscribe.topics[key];
		};

		this.getSubscribeTopic = function(broker, key){
			if(typeof(broker.subscribe.topics[key]) != "undefined"){
				return broker.subscribe.topics[key];
			}
			else{
				return null;
			}
		};

		this.setSubscribeTopic = function(broker, key, topic){
			broker.subscribe.topics[key] = topic;
		};

		this.getSubscribeTopics = function(broker){
			return broker.subscribe.topics;
		};

		this.importTopics = function(fileString){
			//from http://stackoverflow.com/a/14991797
			function parseCSV(str) {
			    var arr = [];
			    var quote = false;  // true means we're inside a quoted field

			    // iterate over each character, keep track of current row and column (of the returned array)
			    for (var row = col = c = 0; c < str.length; c++) {
			        var cc = str[c], nc = str[c+1];        // current character, next character
			        arr[row] = arr[row] || [];             // create a new row if necessary
			        arr[row][col] = arr[row][col] || '';   // create a new column (start with empty string) if necessary

			        // If the current character is a quotation mark, and we're inside a
			        // quoted field, and the next character is also a quotation mark,
			        // add a quotation mark to the current column and skip the next character
			        if (cc == '"' && quote && nc == '"') { arr[row][col] += cc; ++c; continue; }  

			        // If it's just one quotation mark, begin/end quoted field
			        if (cc == '"') { quote = !quote; continue; }

			        // If it's a comma and we're not in a quoted field, move on to the next column
			        if (cc == ',' && !quote) { ++col; continue; }

			        // If it's a newline and we're not in a quoted field, move on to the next
			        // row and move to column 0 of that new row
			        if (cc == '\n' && !quote) { ++row; col = 0; continue; }

			        // Otherwise, append the current character to the current column
			        arr[row][col] += cc;
			    }
			    return arr;
			}

			//process newline
			var fileArray = fileString.replace(/(\r\n|\r|\n)/g, '\n').split('\n');
			for (var i = 0; i < fileArray.length; i++) {
				if (fileArray[i] == "") {
					fileArray.splice(i, 1);
					i--;
				}
			}
			fileString = fileArray.join('\n');

			var csvArray = parseCSV(fileString);

			//validate csv format
			var validate = true;
			for(var i = 0; i < csvArray.length; i++){
				if(csvArray[i].length != 2){
					validate = false;
					break;
				}
			}

			if(validate == true){
				this.pool.imports.topics = [];
				for(var i = 0; i < csvArray.length; i++){
					this.pool.imports.topics.push({
						"name": csvArray[i][0],
						"topicName": csvArray[i][1]
					});
				}

				return true;
			}
			else{
				return false;
			}
		};

		this.getTopicName = function(sourceType, sourceIndex, moduleIndex, channelType, channel){
			if(sourceType == "register" && sourceIndex == null){
				var moduleKey = sourceIndex;
				var registerIndex = moduleIndex;
				var registerManager = WISE.managers.registerManager;
				var variable = "ir";

				try{
					if(typeof(registerManager.pool.registers[registerIndex]) == "undefined"){
						throw "registerNotFound";
					}

					variable += "/" + (registerIndex + 1);

					return variable;
				}
				catch(error){
					return variable;
				}
			}
			else if(sourceType == "system"){
				var variable = "system";

				variable += {
					"Ty": "/date/year",
					"TM": "/date/month",
					"Td": "/date/day",
					"Th": "/time/hour",
					"Tm": "/time/minute",
					"Ts": "/time/Second",
					"Ss": "/signal/dbm",
					"Sp": "/signal/percent"
				}[sourceIndex];

				return variable;
			}
			else{
				var moduleManager = WISE.managers.moduleManager;

				if(sourceType == "register" && sourceIndex != null){//remote IR
					var moduleKey = sourceIndex;
					var registerIndex = moduleIndex;

					var moduleInfo = moduleManager.getModuleInfoByKey(moduleKey);
					if(moduleInfo != null){
						sourceType = moduleInfo.sourceType;
						sourceIndex = moduleInfo.sourceIndex;
						moduleIndex = moduleInfo.moduleIndex;
						channelType = "IR";
						channel = registerIndex + 1;
					}
				}

				try{
					var variable = "";
					var module = moduleManager.pool.interfaces[sourceType][sourceIndex].modules[moduleIndex];

					if(sourceType == "onboard"){
						variable += "xvboard"
					}
					else if(sourceType == "comport"){
						variable += "com" + sourceIndex;
					}
					else if(sourceType == "network"){
						variable += "lan";
					}

					if(module.type == "onboard" || module.type == "icpdas"){
						var protocol = moduleManager.pool.interfaces[sourceType][sourceIndex].protocol;
						if(module.type != "onboard"){
							variable += "/no" + (moduleIndex + 1);
						}

						if(channelType == "DI"){
							variable += "/di";
						}
						else if(channelType == "DIC"){
							variable += "/di_counter";
						}
						else if(channelType == "DO"){
							variable += "/do";
						}
						else if(channelType == "DOC"){
							variable += "/do_counter";
						}
						else if(channelType == "AI"){
							variable += "/ai";
						}
						else if(channelType == "AO"){
							variable += "/ao";
						}
						else if(channelType == "IR"){
							variable += "/ir";
						}
						else{
							throw "channelTypeError";
						}

						var channelIndex = parseInt(channel, 10);

						if(channelType == "DIC"){
							channel = module.DI.setting[channelIndex];
						}
						else if(channelType == "DOC"){
							channel = module.DO.setting[channelIndex];
						}

						if(typeof(channel) == "undefined" || (typeof(channel) != "object" && isNaN(channel)) || (channelType != "IR" && channel.disable == true)){
							throw "channelNotFound";
						}

						variable += "/" + channelIndex;

						return variable;
					}
					else if(module.type == "rtu" || module.type == "tcp"){
						variable += "/no" + (moduleIndex + 1);

						if(typeof(module.extendedModule) != "undefined"){
						}
						else{
							if(channelType == "CI"){
								variable += "/discrete_input";
							}
							else if(channelType == "CO"){
								variable += "/coil_output";
							}
							else if(channelType == "RI"){
								variable += "/input_register";
							}
							else if(channelType == "RO"){
								variable += "/holding_register";
							}
							else{
								throw "channelTypeError";
							}

							var channelAddress = parseInt(channel, 10);

							if(!module[channelType].remoteAddress[channelAddress]){//check remote address exist
								throw "channelNotFound";
							}

							variable += "/" + channelAddress;

							return variable;
						}
					}
				}
				catch(error){
					return variable;
				}
			}

			return "";
		}
	};
})();

WISE.managers.mqttManager.loadFile = function(){
	return fileLoader(["?./topics.csv"]).done(function(fileContents){
		if(typeof(fileContents[0]) != "undefined"){
			WISE.managers.mqttManager.importTopics(fileContents[0]);
		}
	});
};