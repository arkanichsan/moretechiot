WISE.managers.activeioManager.decodeXMLObject = function(xmlDoc){
	var that = this;
	var moduleManager = WISE.managers.moduleManager;
	var processModuleInfo = function($xmlDoc){
		var block = {};

		if($xmlDoc.attr("l_obj") == "IR"){
			block.registerIndex = parseInt($xmlDoc.attr("l_idx"), 10) - 1;
		}
		else{
			var module = null, protocol;
			if($xmlDoc.attr("l_obj") == "XBOARD"){
				var interfaces = moduleManager.pool.interfaces.onboard[0];
				protocol = interfaces.protocol;
				module = interfaces.modules[0];
			}
			else if($xmlDoc.attr("l_obj") == "DCON"){
				var interfaces = moduleManager.pool.interfaces.comport[parseInt($xmlDoc.attr("l_com"), 10)];
				protocol = interfaces.protocol;
				module = interfaces.modules[parseInt($xmlDoc.attr("l_idx"), 10) - 1];
			}
			else if($xmlDoc.attr("l_obj") == "RTU"){
				var interfaces = moduleManager.pool.interfaces.comport[parseInt($xmlDoc.attr("l_com"), 10)];
				protocol = interfaces.protocol;
				module = interfaces.modules[parseInt($xmlDoc.attr("l_idx"), 10) - 1];
			}
			else if($xmlDoc.attr("l_obj") == "TCP"){
				var interfaces = moduleManager.pool.interfaces.network[0];
				protocol = interfaces.protocol;
				module = interfaces.modules[parseInt($xmlDoc.attr("l_idx"), 10) - 1];
			}

			block.moduleKey = module.key;
			if(module.type == "icpdas" && (protocol == "modbusRTU" || protocol == "modbusTCP")){//M7K
				var channelIndexInfo = moduleManager.icpdasModule.channelAddressToIndex(module, $xmlDoc.attr("l_ch"), parseInt($xmlDoc.attr("l_chn"), 10));
				if(channelIndexInfo[0] == "IR"){
					block.registerIndex = channelIndexInfo[1];
				}
				else{
					block.channelType = channelIndexInfo[0];
					block.channel = channelIndexInfo[1];
				}
			}
			else{
				block.channelType = $xmlDoc.attr("l_ch");
				block.channel = parseInt($xmlDoc.attr("l_chn"), 10);
			}
		}

		return block;
	};

	var $xmlACTIVE_IO = $(xmlDoc).find("WISE > NOTE > ACTIVE_IO");
	if($xmlACTIVE_IO.length > 0){
		var $xmlCs = $xmlACTIVE_IO.find("> TABLE > COIL > C");
		for(var i = 0; i < $xmlCs.length; i++){
			var $xmlC = $($xmlCs[i]);

			this.pool.table.coil.push(processModuleInfo($xmlC));
		}

		var $xmlRs = $xmlACTIVE_IO.find("> TABLE > REGISTER > R");
		for(var i = 0; i < $xmlRs.length; i++){
			var $xmlR = $($xmlRs[i]);

			var $xmlCs = $xmlR.children("C");
			if($xmlCs.length <= 0){
				this.pool.table.register.push(processModuleInfo($xmlR));
			}
			else{
				for(var j = 0; j < $xmlCs.length; j++){
					var $xmlC = $($xmlCs[j]);
					this.pool.table.register.push(processModuleInfo($xmlC));
				}
			}
		}

		var $xmlRECEIVER = $xmlACTIVE_IO.find("> RECEIVER");
		if($xmlRECEIVER.length > 0){
			this.pool.slave = {
				enable: true,
				ip: ipToInteger($xmlRECEIVER.attr("url")),
				port: parseInt($xmlRECEIVER.attr("port"), 10),
				netID: parseInt($xmlRECEIVER.attr("netid"), 10),
				timeout: parseInt($xmlRECEIVER.attr("timeout"), 10),
				update: {
					timing: parseInt($xmlRECEIVER.attr("send_mode"), 10),
					threshold: parseInt($xmlRECEIVER.attr("send_threshold") || "0", 10),
					interval: parseInt($xmlRECEIVER.attr("send_period") || "5", 10)
				},
				startAddress: {
					coil: parseInt($xmlRECEIVER.attr("coil_address"), 10),
					register: parseInt($xmlRECEIVER.attr("register_address"), 10)
				}
			}
		}
	}
};

WISE.managers.activeioManager.afterDecodeRuleFile = function(){
	for(var typeArrayIndex = 0, typeArray = ["coil", "register"]; typeArrayIndex < typeArray.length; typeArrayIndex++){
		var blockArray = this.pool.table[typeArray[typeArrayIndex]];
		for(var i = 0; i < blockArray.length; i++){
			var block = blockArray[i];

			block.tip = this.generateTip(block);
			block.variable = this.generateVariable(block);
			block.type = this.calculateSize(block).join("");
		}
	}
}
