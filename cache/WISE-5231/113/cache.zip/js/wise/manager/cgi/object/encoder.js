WISE.managers.cgiManager.encodeXMLObject = function(xmlDoc){
	var loggerManager = WISE.managers.loggerManager;
	var processFTPAttribute = function(ftpServers){
		var ftpAttribute = "";
		for(var i = 0; i < ftpServers.length; i++){
			if(typeof(loggerManager.pool.ftp.servers[ftpServers[i]]) == "undefined"){continue;}

			ftpAttribute += loggerManager.pool.ftp.servers[ftpServers[i]].index + ",";
		}
		return ftpAttribute.substr(0, ftpAttribute.length - 1);
	};

	var xmlCGI = xmlDoc.createElement("CGI");

	for(var serverKey in this.pool.send.servers){
		var server = this.pool.send.servers[serverKey];
		var xmlS = xmlDoc.createElement("S");

		xmlS.setAttribute("idx", server.index);
		xmlS.setAttribute("server", server.address);
		xmlS.setAttribute("port", server.port);
		xmlS.setAttribute("retry_times", server.retryTimes);
		xmlS.setAttribute("ftp", processFTPAttribute(server.ftpServers));

		xmlS.setAttribute("auth", server.authInfo.authType);
		if(server.authInfo.authType != 0){
			xmlS.setAttribute("id", server.authInfo.id);
			if(server.authInfo.password.plain == "" || server.authInfo.password.plain != padding("", server.authInfo.password.length, "*")){//setup new password
				xmlS.setAttribute("password", server.authInfo.password.plain);
				xmlS.setAttribute("password_len", server.authInfo.password.plain.length);
			}
			else{
				xmlS.setAttribute("password", server.authInfo.password.encoded);
				xmlS.setAttribute("password_len", server.authInfo.password.length);
			}
		}

		xmlS.setAttribute("nickname", server.name);
		if(server.description != ""){
			xmlS.setAttribute("desc", server.description);
		}

		for(var commandKey in server.commands){
			var command = server.commands[commandKey];
			var xmlC = xmlDoc.createElement("C");

			xmlC.setAttribute("idx", command.index);
			xmlC.setAttribute("cmd", command.command);

			if(command.saveResponseAsFile.enable == true){
				xmlC.setAttribute("filename", command.saveResponseAsFile.fileName);//appear means save file in sd card

				if(command.saveResponseAsFile.emailKey != null){
					var email = WISE.managers.emailManager.pool.emails[command.saveResponseAsFile.emailKey];

					if(typeof(email) != "undefined"){
						xmlC.setAttribute("email", email.index);
					}
				}
			}

			xmlC.setAttribute("nickname", command.name);
			if(command.description != ""){
				xmlC.setAttribute("desc", command.description);
			}

			xmlS.appendChild(xmlC);
		}

		xmlCGI.appendChild(xmlS);
	}

	//variable and client
	var xmlQ = xmlDoc.createElement("Q");

	var variableAttr = "";
	for(var variabeKey in this.pool.receive.variables){
		var variable = this.pool.receive.variables[variabeKey];
		variableAttr += variable.key + ",";
	}
	variableAttr = variableAttr.substring(0, variableAttr.length - 1);

	var clientAttr = "";
	for(var clientKey in this.pool.receive.clients){
		var variable = this.pool.receive.clients[clientKey];
		clientAttr += variable.address + ",";
	}
	clientAttr = clientAttr.substring(0, clientAttr.length - 1);

	if(variableAttr != ""){
		xmlQ.setAttribute("variable", variableAttr);
	}

	if(clientAttr != ""){
		xmlQ.setAttribute("ip", clientAttr);
	}

	if(variableAttr != "" || clientAttr != ""){
		xmlCGI.appendChild(xmlQ);
	}

	if(xmlCGI.childNodes.length > 0){
		for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
			if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
				xmlDoc.documentElement.childNodes[i].appendChild(xmlCGI);
				break;
			}
		}
	}
};

WISE.managers.cgiManager.updateIndex = function(){
	var serverIndex = 0;
	for(var serverKey in this.pool.send.servers){
		this.pool.send.servers[serverKey].index = ++serverIndex;

		var commandIndex = 0;
		for(var commandKey in this.pool.send.servers[serverKey].commands){
			this.pool.send.servers[serverKey].commands[commandKey].index = ++commandIndex;
		}	
	}

	var variableIndex = 0;
	for(var variabeKey in this.pool.receive.variables){
		this.pool.receive.variables[variabeKey].index = ++variableIndex;
	}

	var clientIndex = 0;
	for(var clientKey in this.pool.receive.clients){
		this.pool.receive.clients[clientKey].index = ++clientIndex;
	}
};
