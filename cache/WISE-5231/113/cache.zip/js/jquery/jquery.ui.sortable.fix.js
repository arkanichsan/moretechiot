// UI Fix for draggable

$.extend($['ui']['sortable'].prototype, {
	_intersectsWithPointer: function(item) {
		function isOverAxis( x, reference, size ) {/*modify here*/
			return ( x > reference ) && ( x < ( reference + size ) );
		}

		var isOverElementHeight = (this.options.axis === "x") || isOverAxis(this.positionAbs.top + this.offset.click.top, item.top, item.height),
			isOverElementWidth = (this.options.axis === "y") || isOverAxis(this.positionAbs.left + this.offset.click.left, item.left, item.width),
			isOverElement = isOverElementHeight && (this.options.overElementWidth/*modify here*/ || isOverElementWidth),
			verticalDirection = this._getDragVerticalDirection(),
			horizontalDirection = this._getDragHorizontalDirection();

		if (!isOverElement) {
			return false;
		}

		return this.floating ?
			( ((horizontalDirection && horizontalDirection === "right") || verticalDirection === "down") ? 2 : 1 )
			: ( verticalDirection && (verticalDirection === "down" ? 2 : 1) );
	}
});
