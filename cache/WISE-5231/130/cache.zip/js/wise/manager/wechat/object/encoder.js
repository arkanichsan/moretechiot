WISE.managers.weChatManager.encodeXMLObject = function(xmlDoc){
    if(this.pool.enable == true){
        var xmlWECHAT = xmlDoc.createElement("WECHAT");
        xmlWECHAT.setAttribute("corp_id", this.pool.corpId);

        // Application
        var xmlAPPLICATION = xmlDoc.createElement("APPLICATION");

        for(var key in this.pool.applications){
            var application = this.pool.applications[key];
            var xmlA = xmlDoc.createElement("A");

            xmlA.setAttribute("idx", application.index);
            xmlA.setAttribute("agentid", application.agentId);
            xmlA.setAttribute("secret", application.secret);

            xmlAPPLICATION.appendChild(xmlA);
        }

        if(xmlAPPLICATION.childNodes.length > 0){
            xmlWECHAT.appendChild(xmlAPPLICATION);
        }

        // Message
        var xmlMESSAGE = xmlDoc.createElement("MESSAGE");

        for(var key in this.pool.messages){
            var message = this.pool.messages[key];
            var xmlM = xmlDoc.createElement("M");

            xmlM.setAttribute("idx", message.index);
            xmlM.setAttribute("nickname", message.name);

            if(message.description != ""){
                xmlM.setAttribute("desc", message.description);
            }

            var applications = [];
            for(var i = 0; i < message.applications.length; i++){
                var key = message.applications[i];

                if(typeof(this.pool.applications[key]) != "undefined"){
                    applications.push(this.pool.applications[key].index);
                }
            }
            xmlM.setAttribute("app", applications.join(","));

            xmlM.appendChild(xmlDoc.createTextNode(message.content));

            xmlMESSAGE.appendChild(xmlM);
        }

        if(xmlMESSAGE.childNodes.length > 0){
            xmlWECHAT.appendChild(xmlMESSAGE);
        }

        // IP Camera
        var cameraCounter = 0;
        var xmlCAMERA = xmlDoc.createElement("CAMERA");

        var moduleManager = WISE.managers.moduleManager;
        for(var sourceIndex = 0; sourceIndex < moduleManager.pool.interfaces.camera.length; sourceIndex++){
            if(typeof(moduleManager.pool.interfaces.camera[sourceIndex]) == "undefined"){continue;}

            for(var moduleIndex = 0, modules = moduleManager.pool.interfaces.camera[sourceIndex].modules; moduleIndex < modules.length; moduleIndex++){
                if(typeof(modules[moduleIndex]) == "undefined"){continue;}

                var xmlC = xmlDoc.createElement("C");

                try{
                    if(modules[moduleIndex].weChat.enable == true){
                        xmlC.setAttribute("camera_idx", moduleIndex + 1);
                        xmlC.setAttribute("idx", ++cameraCounter);
                        var applications = [];
                        for(var i = 0; i < modules[moduleIndex].weChat.applications.length; i++){
                            var key = modules[moduleIndex].weChat.applications[i];

                            if(typeof(this.pool.applications[key]) != "undefined"){
                                applications.push(this.pool.applications[key].index);
                            }
                        }
                        xmlC.setAttribute("app", applications.join(","));
                    }
                    xmlCAMERA.appendChild(xmlC);
                }
                catch(error){}
            }
        }

        // CGI Server
        var xmlCGI_SERVER = xmlDoc.createElement("CGI_SERVER");

        var cgiManager = WISE.managers.cgiManager;
        for(var sourceIndex = 0, servers = cgiManager.pool.send.servers; sourceIndex < cgiManager.pool.send.key; sourceIndex++){
            if(typeof(servers[sourceIndex]) == "undefined"){continue;}

            var xmlC = xmlDoc.createElement("C");

            try{
                if(servers[sourceIndex].weChat.enable == true){
                    xmlC.setAttribute("idx", servers[sourceIndex].index);
                    var applications = [];
                    for(var i = 0; i < servers[sourceIndex].weChat.applications.length; i++){
                        var key = servers[sourceIndex].weChat.applications[i];

                        if(typeof(this.pool.applications[key]) != "undefined"){
                            applications.push(this.pool.applications[key].index);
                        }
                    }
                    xmlC.setAttribute("app", applications.join(","));
                }
                xmlCGI_SERVER.appendChild(xmlC);
            }
            catch(error){}
        }

        // LINK
        var xmlLINK = xmlDoc.createElement("LINK");

        if(xmlCAMERA.childNodes.length > 0){
            xmlLINK.appendChild(xmlCAMERA);
        }

        if(xmlCGI_SERVER.childNodes.length > 0){
            xmlLINK.appendChild(xmlCGI_SERVER);
        }

        if(xmlCAMERA.childNodes.length > 0 || xmlCGI_SERVER.childNodes.length > 0){
            xmlWECHAT.appendChild(xmlLINK);
        }

        // 
        if(xmlWECHAT.childNodes.length > 0){
            for(var i = 0; i < xmlDoc.documentElement.childNodes.length; i++){
                if(xmlDoc.documentElement.childNodes[i].nodeName == "NOTE"){
                    xmlDoc.documentElement.childNodes[i].appendChild(xmlWECHAT);
                    break;
                }
            }
        } 
    }
};

WISE.managers.weChatManager.updateIndex = function(){
	var index = 0;
	for(var key in this.pool.applications){
		this.pool.applications[key].index = ++index;
	}
    
    index = 0;
	for(var key in this.pool.messages){
		this.pool.messages[key].index = ++index;
	}
};