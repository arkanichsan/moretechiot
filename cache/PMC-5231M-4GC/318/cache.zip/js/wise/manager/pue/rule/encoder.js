WISE.managers.pueManager.encodeXMLRule = function(xmlDoc, ruleObject){
	var moduleManager = WISE.managers.moduleManager;
	var processCompareModule = moduleManager.encodeXMLRule.processCompareModule;
	var processExtendedModuleRule = WISE.managers.moduleManager.encodeXMLRule.processExtendedModuleRule;

	if(xmlDoc.tagName == "IF"){
		if(ruleObject.ruleObjectKey == "pue"){
			xmlDoc.setAttribute("l_obj", "PUE");
			xmlDoc.setAttribute("l_idx", ruleObject.rule.pueIndex + 1);
			xmlDoc.setAttribute("op", ruleObject.rule.operate);
			processCompareModule(xmlDoc, ruleObject);
			processExtendedModuleRule(xmlDoc, ruleObject);
		}
	}
	else if(xmlDoc.tagName == "THEN" || xmlDoc.tagName == "ELSE"){
	}
};

WISE.managers.pueManager.check = function(){
	var moduleManager = WISE.managers.moduleManager;

	for(var i = 0, pues = this.pool.pues; i < pues.length; i++){
		if(typeof(pues[i]) == "undefined"){continue;}

		for(var j = 0, totalEnergys = pues[i].totalEnergys; j < totalEnergys.length; j++){
			if(moduleManager.getModuleByKey(totalEnergys[j].moduleKey) == null){
				totalEnergys.splice(j, 1);
				j--;
			}
		}

		for(var j = 0, itEnergys = pues[i].itEnergys; j < itEnergys.length; j++){
			if(moduleManager.getModuleByKey(itEnergys[j].moduleKey) == null){
				itEnergys.splice(j, 1);
				j--;
			}
		}
	}

	for(var i = 0, pues = this.pool.pues; i < pues.length; i++){
		if(typeof(pues[i]) == "undefined"){continue;}

		if(pues[i].totalEnergys.length <= 0){
			return {
				"hash": "#home/advanced/pue/setting!" + i,
				"message": "<#Lang['html/desktop/home/advanced/pue/setting.htm'].popup.totalFacilityEnergyIsEmpty>"
			};
		}

		if(pues[i].itEnergys.length <= 0){
			return {
				"hash": "#home/advanced/pue/setting!" + i,
				"message": "<#Lang['html/desktop/home/advanced/pue/setting.htm'].popup.itEquipmentEnergyIsEmpty>"
			};
		}
	}
};