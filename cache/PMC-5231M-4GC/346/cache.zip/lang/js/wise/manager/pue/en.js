$.extend(true, Lang, {
	"js/wise/manager/pue/rule/object.js": {
		"pue": "PUE",
		"azureSubscribeMessage": "Microsoft Azure Subscribe Message",
		"bluemixSubscribeMessage": "IBM Bluemix Subscribe Message"
	}
});