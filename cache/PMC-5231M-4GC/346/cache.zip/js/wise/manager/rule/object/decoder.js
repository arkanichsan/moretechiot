WISE.managers.ruleManager.decodeXMLObject = function(xmlDoc){
	var $xmlRULE = $(xmlDoc).find("WISE > NOTE > RULE");
	if($xmlRULE.length > 0){
		var $xmlR = $xmlRULE.find("> R");
		var maxKey = 0;

		for(var i = 0; i < $xmlR.length; i++){
			var key = parseInt($($xmlR[i]).attr("idx"), 10) - 1;
			if(key > maxKey){maxKey = key};

			var rule = this.createRule({
				"name": $($xmlR[i]).attr("nickname"),
				"description": $($xmlR[i]).attr("desc") || "",
				"enable": $($xmlR[i]).attr("in_use")
			});
			rule.ifConditions.operate = (function(op){
				if(op == 0 || op == 1){return 1;}
				else{return 0;}
			})(parseInt($($xmlR[i]).attr("op"), 10));

			var $xmlRChildren = $($xmlR[i]).children();
			for(var j = 0; j < $xmlRChildren.length; j++){
				for(var managerKey in WISE.managers){//ask all manager who want to process this rule
					var ruleObject = null;

					if(location.host != "localhost" && debugMode != true){
						try{//maybe rule file is incomplete(exist error)
							ruleObject = WISE.managers[managerKey].decodeXMLRule($xmlRChildren[j]);
						}
						catch(error){
							ruleObject = null;
						}
					}
					else{
						ruleObject = WISE.managers[managerKey].decodeXMLRule($xmlRChildren[j]);
					}

					if(ruleObject != null){
						if($xmlRChildren[j].tagName == "IF"){
							rule.ifConditions.rules[parseInt($($xmlRChildren[j]).attr("idx"), 10) - 1] = ruleObject;
						}
						else if($xmlRChildren[j].tagName == "THEN"){
							rule.thenActions.rules[parseInt($($xmlRChildren[j]).attr("idx"), 10) - 1] = ruleObject;
						}
						else if($xmlRChildren[j].tagName == "ELSE"){
							rule.elseActions.rules[parseInt($($xmlRChildren[j]).attr("idx"), 10) - 1] = ruleObject;
						}

						break;
					}
				}
			}

			//clear undefined element and build up rule.ifConditions.executionOrder
			for(var j = 0; j < rule.ifConditions.rules.length;){
				if(typeof(rule.ifConditions.rules[j]) == "undefined"){
					rule.ifConditions.rules.splice(j, 1);
				}
				else{
					rule.ifConditions.executionOrder.push(j);
					j++;
				}
			}
			for(var j = 0; j < rule.thenActions.rules.length;){
				if(typeof(rule.thenActions.rules[j]) == "undefined"){
					rule.thenActions.rules.splice(j, 1);
				}
				else{
					rule.thenActions.executionOrder.push(j);
					j++;
				}
			}
			for(var j = 0; j < rule.elseActions.rules.length;){
				if(typeof(rule.elseActions.rules[j]) == "undefined"){
					rule.elseActions.rules.splice(j, 1);
				}
				else{
					rule.elseActions.executionOrder.push(j);
					j++;
				}
			}

			this.setRule(key, rule);
			this.pool.executionOrder[key] = key;
		}

		//clear undefined element in pool.executionOrder
		for(var i = 0; i < this.pool.executionOrder.length;){
			if(typeof(this.pool.executionOrder[i]) == "undefined"){
				this.pool.executionOrder.splice(i, 1);
			}
			else{
				i++;
			}
		}

		this.pool.key = ++maxKey;
	}
};
