var LangLogin = {
	"adminAlreadyLogin": {
		"en": "Administrator is already logged in.",
		"tw": "系統管理員已登入。",
		"cn": "系统管理员已登录。"
	},
	"reachMaximumNumberOfLoginUser": {
		"en": "System has reached the maximum number of logged in users.",
		"tw": "系統已經達到最大的可登入人數。",
		"cn": "系统已经达到最大的可登录人数。"
	},
	"passwordIncorrect": {
		"en": "The password is incorrect.",
		"tw": "密碼錯誤。",
		"cn": "密码错误。"
	},
	"runtimeServerNotStartup": {
		//"en": "The run-time server does not startup, please check the setting of the server.",
		//"tw": "伺服器尚未啟動，請檢查伺服器的設定。",
		//"cn": "服务器尚未启动，请检查服务器的设定。"
		"en": "The system is busy, please try again later.",
		"tw": "系統忙碌中，請稍後再試。",
		"cn": "系统忙碌中，请稍后再试。"
	},
	"password": {
		"en": "Password",
		"tw": "密碼",
		"cn": "密码"
	},
	"rememberMe": {
		"en": "Remember me",
		"tw": "記住我",
		"cn": "记住我"
	},
	"login": {
		"en": "Login",
		"tw": "登入",
		"cn": "登录"
	},
	"fileCanNotLoad": {
		"en": "Some files could not be loaded, please reload this page again.",
		"tw": "部分檔案無法載入，請重新讀取此頁面。",
		"cn": "部分文件无法加载，请再次刷新此页面。"
	},
	"loadingPleaseWait": {
		"en": "Loading, please wait...",
		"tw": "載入中，請稍後。",
		"cn": "加载中，请稍后。"
	},
	"runtimeServerNoResponse": {
		//"en": "The run-time server is not responding, please check the status of the server.",
		//"tw": "伺服器沒有回應，請檢查伺服器的狀態。",
		//"cn": "服务器没有回应，请检查服务器的状态。"
		"en": "The system is busy, please try again later.",
		"tw": "系統忙碌中，請稍後再試。",
		"cn": "系统忙碌中，请稍后再试。"
	},
	"fileNotFound": {
		"en": "The system can't find the file, please check if the firmware file is correct.",
		"tw": "找不到檔案，請檢查韌體檔是否完整。",
		"cn": "找不到文件，请检查固件文件是否完整。"
	}
};
