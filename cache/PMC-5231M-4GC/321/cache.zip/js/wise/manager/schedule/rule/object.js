WISE.managers.scheduleManager.pool.conditions = {
	"schedule": {
		"name": "<#Lang['?'].schedule>",
		"fileName": "cschedule",
		"rule":{
			"scheduleKey": null,
			"value": 0
		},
		"check": function(){
			if(this.rule.scheduleKey == null){
				return false;
			}

			var scheduleManager = WISE.managers.scheduleManager;

			if(typeof(scheduleManager.pool.schedules[this.rule.scheduleKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var scheduleManager = WISE.managers.scheduleManager;
			var schedule = scheduleManager.pool.schedules[this.rule.scheduleKey];
			var valueString = ["<#Lang['?'].outOfRange>", "<#Lang['?'].inRange>"];

			return this.name + "(" + schedule.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.scheduleKey = this.key[0];
			this.rule.value = 1;
		},
		"key": []
	}
};

WISE.managers.scheduleManager.pool.actions = {
	"schedule": {
		"name": "<#Lang['?'].schedule>",
		"fileName": "aschedule",
		"rule":{
			"scheduleKey": null,
			"value": 0,
			"frequency": -1,
			"delay": 0
		},
		"check": function(){
			if(this.rule.scheduleKey == null){
				return false;
			}
			
			var scheduleManager = WISE.managers.scheduleManager;

			if(typeof(scheduleManager.pool.schedules[this.rule.scheduleKey]) == "undefined"){
				return false;
			}

			return true;
		},
		"parseToString": function(){
			var scheduleManager = WISE.managers.scheduleManager;
			var schedule = scheduleManager.pool.schedules[this.rule.scheduleKey];
			var valueString = ["<#Lang.global.disable>", "<#Lang.global.enable>"];

			return this.name + "(" + schedule.name + ") " + ruleColor(valueString[this.rule.value], 2);
		},

		/*init and key will not be copied*/
		"init": function(){
			this.rule.scheduleKey = this.key[0];
		},
		"key": []
	}
};

WISE.managers.scheduleManager.updateRuleObject = function(){
	//clear key
	this.pool.conditions['schedule']['key'] = [];
	this.pool.actions['schedule']['key'] = [];

	for(var key in this.pool.schedules){
		this.pool.conditions['schedule']['key'].push(parseInt(key, 10));
		//this.pool.actions['schedule']['key'].push(parseInt(key, 10));
	}
};