$.extend(true, Lang, {
	"html/desktop/frame.htm": {
		"resetRule": "New",
		"loadRule": "Load",
		"saveRule": "Save",
		"logout": "Logout",
		"freeSpaceOnSDCard": "Available space on the microSD card.",
		"enterPasswordToContinue": "Please enter the password to continue...",
		"enterPasswordBelow": "Your login session has expired, please enter the password again to continue editing:",
		"password": "Password:",
		"login": "Login"
	},
	"html/desktop/home.htm": {
		"saveAndLogout": "Save and Logout",
		"logout": "Logout",
		"popup": {
			"pleaseWaitAFewSeconds": "This may take a few seconds, please wait a moment.",
			"pleaseWaitAFewSecondsAndDontCloseWindow": "This may take a few seconds, please wait a moment. Do NOT close this window before saving process is completed.",
			"clearSuccess": "Reset successfully.",
			"loadSuccess": "Load successfully.",
			"loadFailed": "Load failed.",
			"saveFailed": "Save failed.",
			"systemInitializing": "The system is initializing, please try again later.",
			"saveBeforeLogout": "Do you want to save the settings before logout?"
		}
	},
	"html/desktop/home/menu.htm": {
		"mainPage": "Main Page",
		"systemSetting": "System Setting",
		"moduleSetting": "Module Setting",
		"loggerSetting": "Logger Setting",
		"iotSetting": "IoT Platform Setting",
		"advancedSetting": "Advanced Setting",
		"rulesSetting": "Rules Setting",
		"channelStatus": "Channel Status",
		"sendToX": "Send to $name",
		"sendToXChatRoom": "Send to $length chat room(s).",
		"noSendToAnyChatRoom": "Do not upload to any chat room",
		"oneOnOne": "1-on-1",
		"group": "Group"
	},
	"html/desktop/home/system.htm": {
		"systemSettingPage": "System Setting Page",
		"dateAndTime": "Date & Time",
		"timeSynchronization": "Time Synchronization",
		"macAddress": "MAC Address",
		"port": "Port",
		"ddns": "Dynamic DNS",
		"connectionStatus": "Connection Status",
		"status": "Status",
		"connectionInformation": "Connection Information",
		"connected": "Connected",
		"disconnected": "Disconnected",
		"connecting": "Connecting...",
		"disconnect": "Disconnect",
		"connect": "Connect",
		"cancel": "Cancel",
		"signalStrength": "Signal Strength",
		"cloudManagerSystem": "Cloud Manager System",
		"localFTPServer": "Local FTP Server",
		"firmwareUpdateSetting": "Firmware Update Setting",
		"firmwareInformation": "Firmware Information",
		"currentVersion": "Current Version",
		"availableVersion": "Available Version",
		"check": "Check",
		"newFirmwareRelease": "There is a new firmware(version: $version) release.",
		"checkFailed": "Check failed.",
		"firmwareUpdate": "Firmware Update",
		"firmware": "Firmware",
		"browse": "Browse...",
		"update": "Update",
		"popup": {
			"doNotColseThisWindow": "Do NOT close or leave this page.",
			"selectFirmwareToUpload": "Please select a firmware file for the upload process.",
			"areYouSureYouWantToUpdateFirmware": "Are you sure you want to update firmware? All settings without save will lost after you update firmware.",
			"areYouSureYouWantToLeave": "The firmware update is in progress. If you leave this page now may cause update failure. Are you sure you want to leave this page? ",
			"firmwareUploading": "Uploading the firmware...",
			"firmwareUploadFailedUploadTimeout": "Failed to upload the firmware, the uploading process takes too long. It is recommended to upload the firmware by using the PC in the same local area network.",
			"firmwareUpdating": "The firmware is in update status.",
			"firmwareUpdateFailedFirmwareIsIncorrect": "Failed to update the firmware due to invalid firmware file.",
			"firmwareUpdateFailedNotEnoughDiskSpace": "Failed to update the firmware due to insufficient disk space.",
			"firmwareUpdateFailedUnzipError": "Failed to update the firmware due to unzip the firmware file error.",
			"firmwareUpdateFailed": "Failed to update the firmware.",
			"systemRestarting": "The system is in re-start status.",
			"firmwareUpdateSuccessToVersionXPressOKToLogout": "The firmware has been updated to $version successfully. Please click OK to logout and login again to get into the new system.",
			"firmwareUpdateFailedPressOKToLogout": "Failed to update the firmware. Please click OK to logout and login again to get back into the system."
		},
		"vpn":{
			"VPNSetting":"VPN Setting",
			"VPNState":"VPN State",
			"ip": "IP",
			"mask": "Mask",
			"gateway": "Gateway",
			"dns": "DNS",
			"online":"Online",
			"offline":"Offline",
			"connecting":"Connecting",
			"enable":"Enable",
			"disable":"Disable"
		}
	},
	"html/desktop/home/system/menu.htm": {
		"timeSetting": "Time Setting",
		"networkSetting": "Network Setting",
		"vpnSetting": "VPN Setting",
		"snmpSetting": "SNMP Setting",
		"securitySetting": "Security Setting",
		"interfaceSetting": "I/O Interface Setting",
		"otherSetting": "Other Setting",
		//----------------------pmc--------------------------
		"GroupSetting": "Power Meter Group Setting"
		//---------------------------------------------------
	},
	"html/desktop/home/system/time.htm": {
		"timeSettingPage": "Time Setting Page",
		"date": "Date",
		"time": "Time",
		"loadTime": "Time Duplication",
		"load": "Load",
		"loadComputerTimeSetting": "Load current time of this computer.",
		"timeSynchronizationSetting": "Time Synchronization Setting",
		"functionStatus": "Function Status",
		"sntpTimeServer": "SNTP Time Server",
		"useDefaultSNTPTimeServers": "Use Default SNTP Time Servers",
		"port": "Port",
		"syncInterval": "Sync Interval",
		"timeZoneSetting": "Time Zone Setting",
		"timeZone": "Time Zone",
		"timeZoneKey": {
			"Dateline Standard Time": "(UTC-12:00) International Date Line West",
			"UTC-11": "(UTC-11:00) Coordinated Universal Time -11",
			"Hawaiian Standard Time": "(UTC-10:00) Hawaii",
			"Alaskan Standard Time": "(UTC-09:00) Alaska",
			"Pacific Standard Time": "(UTC-08:00) Pacific Time (US & Canada)",
			"Pacific Standard Time (Mexico)": "(UTC-08:00) Baja California",
			"Mountain Standard Time": "(UTC-07:00) Mountain Time (US & Canada)",
			"Mountain Standard Time (Mexico)": "(UTC-07:00) Chihuahua, La Paz, Mazatlan",
			"US Mountain Standard Time": "(UTC-07:00) Arizona",
			"Canada Central Standard Time": "(UTC-06:00) Saskatchewan",
			"Central Standard Time (Mexico)": "(UTC-06:00) Guadalajara, Mexico City, Monterrey",
			"Central Standard Time": "(UTC-06:00) Central Time (US & Canada)",
			"Central America Standard Time": "(UTC-06:00) Central America",
			"US Eastern Standard Time": "(UTC-05:00) Indiana (East)",
			"Eastern Standard Time": "(UTC-05:00) Eastern Time (US & Canada)",
			"Eastern Standard Time (Mexico)": "(UTC-05:00) Chetumal",
			"SA Pacific Standard Time": "(UTC-05:00) Bogota, Lima, Quito, Rio Branco",
			"Venezuela Standard Time": "(UTC-04:30) Caracas",
			"SA Western Standard Time": "(UTC-04:00) Georgetown, La Paz, Manaus, San Juan",
			"Central Brazilian Standard Time": "(UTC-04:00) Cuiaba",
			"Atlantic Standard Time": "(UTC-04:00) Atlantic Time (Canada)",
			"Paraguay Standard Time": "(UTC-04:00) Asuncion",
			"Newfoundland Standard Time": "(UTC-03:30) Newfoundland",
			"Pacific SA Standard Time": "(UTC-03:00) Santiago",
			"Bahia Standard Time": "(UTC-03:00) Salvador",
			"Montevideo Standard Time": "(UTC-03:00) Montevideo",
			"Greenland Standard Time": "(UTC-03:00) Greenland",
			"SA Eastern Standard Time": "(UTC-03:00) Cayenne, Fortaleza",
			"Argentina Standard Time": "(UTC-03:00) Buenos Aires",
			"E. South America Standard Time": "(UTC-03:00) Brasilia",
			"UTC-2": "(UTC-02:00) Coordinated Universal Time -02",
			"Cape Verde Standard Time": "(UTC-01:00) Cabo Verde Is.",
			"Azores Standard Time": "(UTC-01:00) Azores",
			"Morocco Standard Time": "(UTC) Casablanca",
			"UTC": "(UTC) Coordinated Universal Time",
			"GMT Standard Time": "(UTC) Dublin, Edinburgh, Lisbon, London",
			"Greenwich Standard Time": "(UTC) Monrovia, Reykjavik",
			"W. Europe Standard Time": "(UTC+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna",
			"Central Europe Standard Time": "(UTC+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague",
			"Romance Standard Time": "(UTC+01:00) Brussels, Copenhagen, Madrid, Paris",
			"Central European Standard Time": "(UTC+01:00) Sarajevo, Skopje, Warsaw, Zagreb",
			"W. Central Africa Standard Time": "(UTC+01:00) West Central Africa",
			"Namibia Standard Time": "(UTC+01:00) Windhoek",
			"Jordan Standard Time": "(UTC+02:00) Amman",
			"GTB Standard Time": "(UTC+02:00) Athens, Bucharest",
			"Middle East Standard Time": "(UTC+02:00) Beirut",
			"Egypt Standard Time": "(UTC+02:00) Cairo",
			"Syria Standard Time": "(UTC+02:00) Damascus",
			"E. Europe Standard Time": "(UTC+02:00) E. Europe",
			"South Africa Standard Time": "(UTC+02:00) Harare, Pretoria",
			"FLE Standard Time": "(UTC+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius",
			"Turkey Standard Time": "(UTC+02:00) Istanbul",
			"Israel Standard Time": "(UTC+02:00) Jerusalem",
			"Kaliningrad Standard Time": "(UTC+02:00) Kaliningrad (RTZ 1)",
			"Libya Standard Time": "(UTC+02:00) Tripoli",
			"Arabic Standard Time": "(UTC+03:00) Baghdad",
			"Arab Standard Time": "(UTC+03:00) Kuwait, Riyadh",
			"Belarus Standard Time": "(UTC+03:00) Minsk",
			"Russian Standard Time": "(UTC+03:00) Moscow, St. Petersburg, Volgograd (RTZ 2)",
			"E. Africa Standard Time": "(UTC+03:00) Nairobi",
			"Iran Standard Time": "(UTC+03:30) Tehran",
			"Arabian Standard Time": "(UTC+04:00) Abu Dhabi, Muscat",
			"Azerbaijan Standard Time": "(UTC+04:00) Baku",
			"Russia Time Zone 3 Standard Time": "(UTC+04:00) Izhevsk, Samara (RTZ 3)",
			"Mauritius Standard Time": "(UTC+04:00) Port Louis",
			"Georgian Standard Time": "(UTC+04:00) Tbilisi",
			"Caucasus Standard Time": "(UTC+04:00) Yerevan",
			"Afghanistan Standard Time": "(UTC+04:30) Kabul",
			"West Asia Standard Time": "(UTC+05:00) Ashgabat, Tashkent",
			"Ekaterinburg Standard Time": "(UTC+05:00) Ekaterinburg (RTZ 4)",
			"Pakistan Standard Time": "(UTC+05:00) Islamabad, Karachi",
			"India Standard Time": "(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi",
			"Sri Lanka Standard Time": "(UTC+05:30) Sri Jayawardenepura",
			"Nepal Standard Time": "(UTC+05:45) Kathmandu",
			"Central Asia Standard Time": "(UTC+06:00) Astana",
			"Bangladesh Standard Time": "(UTC+06:00) Dhaka",
			"N. Central Asia Standard Time": "(UTC+06:00) Novosibirsk (RTZ 5)",
			"Myanmar Standard Time": "(UTC+06:30) Yangon (Rangoon)",
			"SE Asia Standard Time": "(UTC+07:00) Bangkok, Hanoi, Jakarta",
			"North Asia Standard Time": "(UTC+07:00) Krasnoyarsk (RTZ 6)",
			"China Standard Time": "(UTC+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
			"North Asia East Standard Time": "(UTC+08:00) Irkutsk (RTZ 7)",
			"Singapore Standard Time": "(UTC+08:00) Kuala Lumpur, Singapore",
			"W. Australia Standard Time": "(UTC+08:00) Perth",
			"Taipei Standard Time": "(UTC+08:00) Taipei",
			"Ulaanbaatar Standard Time": "(UTC+08:00) Ulaanbaatar",
			"Tokyo Standard Time": "(UTC+09:00) Osaka, Sapporo, Tokyo",
			"Korea Standard Time": "(UTC+09:00) Seoul",
			"Yakutsk Standard Time": "(UTC+09:00) Yakutsk (RTZ 8)",
			"Cen. Australia Standard Time": "(UTC+09:30) Adelaide",
			"AUS Central Standard Time": "(UTC+09:30) Darwin",
			"E. Australia Standard Time": "(UTC+10:00) Brisbane",
			"AUS Eastern Standard Time": "(UTC+10:00) Canberra, Melbourne, Sydney",
			"West Pacific Standard Time": "(UTC+10:00) Guam, Port Moresby",
			"Tasmania Standard Time": "(UTC+10:00) Hobart",
			"Magadan Standard Time": "(UTC+10:00) Magadan",
			"Vladivostok Standard Time": "(UTC+10:00) Vladivostok, Magadan (RTZ 9)",
			"Russia Time Zone 10 Standard Time": "(UTC+11:00) Chokurdakh (RTZ 10)",
			"Central Pacific Standard Time": "(UTC+11:00) Solomon Is., New Caledonia",
			"Russia Time Zone 11 Standard Time": "(UTC+12:00) Anadyr, Petropavlovsk-Kamchatsky (RTZ 11)",
			"New Zealand Standard Time": "(UTC+12:00) Auckland, Wellington",
			"UTC+12": "(UTC+12:00) Coordinated Universal Time +12",
			"Fiji Standard Time": "(UTC+12:00) Fiji",
			"Tonga Standard Time": "(UTC+13:00) Nuku'alofa",
			"Samoa Standard Time": "(UTC+13:00) Samoa",
			"Line Islands Standard Time": "(UTC+14:00) Kiritimati Island"
		},
		"daylightSavingTime": "Daylight Saving Time",
		"tip": {
			"date": "Click on the calendar to select a date.",
			"time": "Modify the time setting manually.",
			"loadTime": "Load the system time setting from the computer that the browser is located.",
			"functionStatus": "Check 'Enable' to enable the Time Synchronization function.",
			"sntpTimeServer": "Input the address of the SNTP Time Server.",
			"port": "Input the Port of the SNTP Time Server.",
			"syncInterval": "Set up the frequency of the Time Synchronization.",
			"timeZone": "Set up the Time Zone that the controller is located in.",
			"daylightSavingTime": "Check 'Enable' to enable the 'Daylight Saving Time' operation."
		},
		"popup": {
			"timeServerIsEmpty": "SNTP time server fields is empty, you must specify at least one server address.",
			"saveFailed": "Save failed."
		}
	},
	"html/desktop/home/system/network.htm": {
		"networkSetting": "Network Setting",
		"connectionMode": "Connection Mode",
		"ip": "IP",
		"specifyIPAddress": "Specify an IP address",
		"obtainIPAddressViaDHCP": "Obtain an IP address automatically(DHCP)",
		"mask": "Mask",
		"gateway": "Gateway",
		"dns": "DNS",
		"mobileNetwork": "Mobile Network",
		"dialNumber": "Dial-up Number",
		"apn": "APN",
		"authentication": "Authentication",
		"username": "Username",
		"password": "Password",
		"referToThisDocumentToConfigureTheSetting": "Please refer to <a href='http://wise.icpdas.com/downloads/gprs_apn.pdf' target='_blank'>this document</a> to configure the setting.",
		"mobileCode": "Mobile Code",
		"mcc": "MCC",
		"mnc": "MNC",
		"referToThisWebPageToConfigureTheSetting": "Please refer to <a href='https://en.wikipedia.org/wiki/Mobile_country_code' target='_blank'>this web page</a> to configure the setting.",
		"autoConnectWhenPowerOn": "Automatic Connection When Power On",
		"connectionTesting": "Connection Testing",
		"testing": "Testing",
		"connectSuccessfully": "Connect successfully.",
		"connectFailed": "Connect Failed.",
		"mobileNetworkNoResponsePleaseCheckServerSetting": "The mobile network is not responding. Please make sure the mobile network setting is valid.",
		"userAuthenticationFailedPleaseCheckUsernameOrPasswordSetting": "User authentication failed. Please make sure the username and password are valid.",
		"securityAuthenticationFailedPleaseCheckSecuritySetting": "Security authentication failed. Please make sure the mobile network setting is valid.",
		"unknownErrorPleaseCheckMobileNetworkSetting": "Unknown error. Please make sure the mobile network setting is valid.",
		"saveAndConnect": "Save and Connect",
		"disablePINCodeFromSIMCardFirst": "Please disable the PIN code first",
		"portSetting": "Port Setting",
		"webServerPort": "Web Server Port",
		"modbusTCPPort": "Modbus TCP Port",
		"modbusNetID": "Modbus NetID",
		"ddnsSetting": "Dynamic DNS Setting",
		"serviceX": "Service $number",
		"serviceProvider": "Service Provider",
		"domainName": "Domain Name",
		"token": "Token",
		"status": "Status",
		"lastUpdateTime": "Last Update Time",
		"lastUpdateStatus": "Last Update Status",
		"externalIP": "Last Registered IP",
		"updateSuccess": "Update successfully.",
		"connectionFailed": "Connection failed.",
		"authorizationFailed": "Authorization failed.",
		"domainNameNotExist": "The domain name does not exist.",
		"unknownError": "Unknown error.",
		"cloudManagerSystemSetting": "Cloud Manager System Setting",
		"functionStatus": "Function Status",
		"serverAddress": "Server Address",
		"createAccount": "Create Account",
		"specifyServerAddress": "Specify an address of server",
		"serverPort": "Server Port",
		"connecting": "Connecting.",
		"connected": "Connected.",
		"connectionStatus": "Connection Status",
		"unableEstablishConnectionWithServer": "Unable to establish a connection to the server.",
		"usernameOrPasswordError": "The username or password is incorrect.",
		"reachMaximumDeviceAmount": "The number of devices reaches the maximum.",
		"unableEstablishConnectionWithDatabase": "Unable to establish a connection to the database.",
		"unableToConnectToTheSystem": "Unable to connect to the system!",
		"useUtilityToSearchSystemIP": "The IP address of the controller has been changed. Please use WISE Utility to search the IP address and login again with the IP address being found.",
		"errorOccursInSettingCheckSettingsAgain": "There is an possible setting error, please check the settings again.",
		"systemLostConnectionWithCloudAccessViaIPDirectly": "The controller is disconnected from the cloud manager system. This may due to a connection problem or invalid login username/password. Please login the controller via IP address directly.",
		"macAddress": "MAC Address:",
		"tip": {
			"connectionMode": "Specify the way to obtain an IP address from the network.",
			"ip": "Input the IP of the controller.",
			"mask": "Input the mask of the controller.",
			"gateway": "Input the gateway of the controller.",
			"dns": "Input the DNS(Domain Name Server) IP address.",
			"dialNumber": "Input the dial-up number of the mobile network.",
			"apn": "Input the Access Point Name(APN) of the mobile network.",
			"authentication": "Input the login username and password of the mobile network.",
			"mobileCode": "Click 'Enable' to enable the mobile code function.",
			"mcc": "Input the Mobile Country Code(MCC) of the mobile network.",
			"mnc": "Input the Mobile Network Code(MNC) of the mobile network.",
			"autoConnectWhenPowerOn": "Check 'Enable' to enable the automatically connect function when power on.",
			"connectionTesting": "Click 'Testing' to establish a connection to the mobile network to make sure your setting is OK.",
			"webServerPort": "Input the web server port of the controller.",
			"modbusTCPPort": "Input the Modbus TCP port of the controller.",
			"modbusNetID": "Input the NetID of the controller.",
			"serviceProvider": "Set up the service provider of the dynamic DNS.",
			"username": "Input the login username of the dynamic DNS service provider. ",
			"password": "Input the login password of the dynamic DNS service provider. ",
			"domainName": "Input the domain name provided from the dynamic DNS service provider.",
			"token": "Input the update token provided from the dynamic DNS service provider.",
			"status": "Current system status of the dynamic DNS",
			"cloud": {
				"functionStatus": "Click 'Enable' to enable the cloud manager system function.",
				"serverAddress": "Input the address of the cloud manager system.",
				"serverPort": "Input the port of the cloud manager system.",
				"username": "Input the login username of the cloud manager system.",
				"password": "Input the login password of the cloud manager system.",
				"connectionStatus": "The connection status of the cloud manager system."
			}
		},
		"popup": {
			"areYouSureYouWantToChangeSettingMaybeLostConnection": "Are you sure you want to change the setting? After this process is completed, the connection to the system may lost and will lost all unsaved settings.",
			"areYouSureYouWantToChangeSettingRedirectAutomatically": "Are you sure you want to change the setting? After this process is completed, web page will be redirected to the new address, all unsaved settings will be lost.",
			"pleaseWaitAFewSeconds": "Please wait a few seconds.",
			"saveSuccessPressOKRedirect": "Save successfully. After click the OK button, the web page will be redirected to the new address.",
			"modifykNetworkFailed": "Failed to modify the network setting.",
			"modifykPortFailed": "Failed to modify the port setting.",
			"areYouSureYouWantToTestMobileNetworkSettingTheMobileNetworkWillBeDisconnected": "Are you sure you want to test the mobile network setting? This action will cause users who access from mobile network ip address disconnected.",
			"dialNumberIsEmpty": "Dial-up number field can't be empty.",
			"apnIsEmpty": "APN field can't be empty.",
			"mccIsEmpty": "MCC field can't be empty.",
			"mncIsEmpty": "MNC field can't be empty.",
			"modifykWebServerPortSuccessfully": "Successfully modify the web server port setting.",
			"modifykModbusTCPPortSuccessfully": "Successfully modify the Modbus TCP port setting.",
			"modifykModbusNetIDSuccessfully": "Successfully modify the Modbus NetID setting.",
			"modifykWebServerPortFailed": "Failed to modify the web server port setting.",
			"modifykModbusTCPPortFailed": "Failed to modify the Modbus TCP port setting.",
			"modifykModbusNetIDFailed": "Failed to modify the Modbus NetID setting.",
			"saveFailed": "Save failed.",
			"usernameIsEmpty": "Username field can't be empty.",
			"passwordIsEmpty": "Password field can't be empty.",
			"domainNameIsEmpty": "Domain name field can't be empty.",
			"tokenIsEmpty": "Token field can't be empty.",
			"serverAddressIsEmpty": "Server Address field can't be empty.",
			"areYouSureYouWantToChangeSettingAccessViaCloudMaybeLostConnectionWithCloud": "Are you sure you want to change the setting? You are accessing to the controller via cloud manager system currently, this action may cause the controller being not able  to re-establish a connection to the cloud manager system."
		}
	},
	"html/desktop/home/system/snmp.htm": {
		"snmpSettingPage": "SNMP Setting Page",
		"version": "Version",
		"readCommunityName": "Read Community Name",
		"writeCommunityName": "Write Community Name",
		"trapCommunityName": "Trap Community Name",
		"contact": "Contact",
		"location": "Location",
		"snmpManagerList": "SNMP Manager List",
		"address": "Address",
		"polling": "Read/Write",
		"trap": "Trap",
		"noSNMPManagerExistClickThisButtonToAdd": "No SNMP Manager exists, press this button to create one.",
		"remove": "Remove",
		"tip": {
			"version": "Set the version of SNMP Trap.",
			"readCommunityName": "Input the Read Community Name.",
			"writeCommunityName": "Input the Write Community Name.",
			"trapCommunityName": "Input the Trap Community Name.",
			"contact": "Input the Contact information.",
			"location": "Input the Location information.",
			"polling": "Click to allow accepting the Read/Write commands from this SNMP Manager. Please note, if no SNMP Manager is selected to accept the commands, it will allow accepting the Read/Write commands from any SNMP Manager.",
			"trap": "Click to allow to send SNMP Trap to this SNMP Manager."
		},
		"popup": {
			"addressIsEmpty": "The address field can't be empty.",
			"addressExists": "This address already exists.",
			"readCommunityNameIsEmpty": "The Read Community Name field can't be empty.",
			"writeCommunityNameIsEmpty": "The Write Community Name field can't be empty.",
			"trapCommunityNameIsEmpty": "The Trap Community Name field can't be empty.",
			"atLeastSelectOneFunction": "Please enable at least one function for the SNMP Manager.",
			"saveFailed": "Save failed."
		}
	},
	"html/desktop/home/system/security.htm": {
		"adminPasswordSetting": "Administrator Password Setting",
		"currentPassword": "Current Password",
		"newPassword": "New Password",
		"retypeNewPassword": "Retype New Password",
		"guestPasswordSetting": "Guest Password Setting",
		"adminProfileSetting": "Administrator Profile Setting",
		"emailAddress": "Email Address",
		"localFTPSetting": "Local FTP Server Setting",
		"id": "ID",
		"password": "Password",
		"changePassword": "Change password",
		"serverStatus": "Server Status",
		"idleTimeSetting": "Idle Time Setting",
		"idleTime": "Idle Time",
		"tip": {
			"adminPassword": "Input the current administrator password.",
			"adminNewPassword": "Input new administrator password.",
			"adminRetypeNewPassword": "Input new administrator password again to confirm.",
			"guestPassword": "Input the current guest password.",
			"guestNewPassword": "Input new guest password.",
			"guestRetypeNewPassword": "Input new guest password again to confirm.",
			"emailAddress": "Input the email address of the administrator, when the administrator password is forgotten, the user could switch the rotary switch on the device to 8; get into the login page; and then click 'Forgot password?'. The system will send the administrator password to the email the user previously set.",
			"ftpEnable": "Check 'Enable' to enable local FTP server.",
			"id": "The login account for local FTP server.",
			"password": "Click 'Change Password' to set new password for local FTP server.",
			"idleTime": "Set the idle timeout period when an user log in into the web page. If the idle time exceeds the maximum time allowed to remain idle, the user will be automatically logged out."
		},
		"popup": {
			"passwordIsEmpty": "Password field can't be empty.",
			"retypePasswordNotMatch": "The new password and retype password does not match.",
			"passwordIncorrect": "The password is incorrect.",
			"saveFailed": "Save failed.",
			"adminEmailIsEmpty": "Email address field can't be empty."
		}
	},
	"html/desktop/home/system/interface.htm": {
		"ioInterfaceSettingPage": "I/O Interface Setting Page",
		"function": "Function",
		"dconMaster": "DCON Master",
		"modbusRTUMaster": "Modbus RTU Master",
		"modbusRTUSlave": "Modbus RTU Slave",
		"modbusTCPMaster": "Modbus TCP Master",
		"modbusTCPSlave": "Modbus TCP Slave",
		"modem": "GTM-203M-3GWA",
		"timeout": "Timeout",
		"silentInterval": "Silent Interval",
		"tip": {
			"function": "Select a function for this I/O interface.",
			"baudrate": "Set the baudrate of this COM port.",
			"parity": "Set the parity of this COM port.",
			"stopbits": "Set the stop bits of this COM port.",
			"timeout": "Input the polling timeout for remote devices.",
			"checksum": "Set the checksum of this COM port.",
			"silentInterval": "Input the silent interval for Modbus devices."
		}
	},
	"html/desktop/home/module.htm": {
		"moduleSettingPage": "Module Setting Page",
		"none": "None",
		"moduleNameOrNickname": "Module Name / Nickname",
		"noModuleExist": "No module exists",
		"no": "No.",
		"address": "Address",
		"pollingTimeout": "Polling Timeout(ms)",
		"ipAndPort": "IP and Port",
		"netID": "NetID"
	},
	"html/desktop/home/module/menu.htm": {
		"xwboardSetting": "XW-Board Setting",
		"xvboardSetting": "XV-Board Setting",
		"ioModuleSetting": "I/O Module Setting"
	},
	"html/desktop/home/module/local.htm": {
		"xwboardSettingPage": "XW-Board Setting Page",
		"xvboardSettingPage": "XV-Board Setting Page",
		"module": "Module",
		"none": "None",
		"tip": {
			"module": "Select the module you are using from the drop down list."
		}
	},
	"html/desktop/home/module/local/setting.htm": {
		"moduleXSetting": "Module $moduleName Setting",
		"digitalChannel": "Digital Channel",
		"chX": "Ch.$no",
		"aiType": "AI Type",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "Temperature Unit",
		"celsius": "Celsius(°C)",
		"fahrenheit": "Fahrenheit(°F)",
		"diAttribute": "DI Attribute",
		"doAttribute": "DO Attribute",
		"aiAttribute": "AI Attribute",
		"aoAttribute": "AO Attribute",
		"channel": "Channel",
		"ch": "Ch.",
		"counterType": "Counter Type",
		"counterInitialValue": "Counter Initial Value",
		"powerOnValue": "Power On Value",
		"advancedFunction": "Advanced Function",
		"type": "Type",
		"deadband": "Deadband",
		"scale": "Scale",
		"rising": "Rising",
		"falling": "Falling",
		"pulseOutput": "Pulse Output",
		"autoOFF": "Auto OFF",
		"mappingToDI": "DI Status Mapping",
		"pulseHigh": "Pulse High:",
		"pulseLow": "Pulse Low:",
		"autoOFFAfterXSeconds": "Automatically return to OFF status after<br>$input second(s)",
		"cloneDIXChannelStatus": "Copy DI channel $di status",
		"scaleMin": "Minimum:",
		"scaleMax": "Maximum:",
		"scaleUnit": "Unit:",
		"tip": {
			"nickname": "Input the nickname of this module.",
			"description": "Input the description of this XW-Board.",
			"digitalChannel": "Specify the type of the channel. Each digital channel can be used as DI or DO.",
			"aiType": "Set the AI channel input type.",
			"temperatureUnit": "Set the temperature unit of the AI channel."
		}
	},
	"html/desktop/home/module/remote.htm": {
		"remoteIOModuleSettingPage": "Remote I/O Module Setting Page",
		"dconModuleList": " DCON Module List",
		"modbusRTUList": "Modbus RTU Module List",
		"modbusTCPList": "Modbus TCP Module List",
		"i7000Series": "I-7000 Series",
		"m7000Series": "M-7000 Series",
		"tMSeries": "tM Series",
		"lcSeries": "LC Series",
		"dlSeries": "DL Series",
		"interfaceNotEnable": "This port is disabled. Enable it in <a href='#home/system/interface'>I/O Interface Setting</a>.",
		"interfaceIsModbusRTUSlave": "This port is running in Modbus RTU Slave mode. To modify the setting, please go to <a href='#home/system/interface'>I/O Interface Setting</a>.",
		"no": "No.",
		"address": "Address",
		"module": "Module",
		"moduleNameOrNickname": "Module Name / Nickname",
		"pollingTimeout": "Polling Timeout(ms)",
		"retryInterval": "Retry Interval(secs)",
		"ip": "IP",
		"port": "Port",
		"netID": "NetID",
		"search": "Search",
		"noModuleExistClickThisButtonToAdd": "No module exists, press this button to create one.",
		"icpdasModule": "ICP DAS Module",
		"decreaseNo": "Move Up",
		"increaseNo": "Move Down",
		"copy": "Copy",
		"removeModule": "Remove",
		"moduleSettingConflict": "Conflicts in some module settings.",
		"selectModuleYouWant": "Please select the module that you want to use for each address.",
		"previousMoudle": "Previous-set Module",
		"scannedMoudle": "Scanned Module",
		"none": "None",
		"scanAddressRange": "Set the address range to scan:",
		"scanAddressRangeFromAToB": "Scan address from $inputFrom to $inputTo. This process will take several seconds, it depends on the address range that you set.",
		"comPort": "COM Port",
		"silentInterval": "Silent Interval",
		"timeout": "Timeout",
		"scan": "Scan",
		"popup": {
			"reachMaximumModulesAmount": "Reach the maximum number of modules. The maximum number of I/O modules is $ioModule and the maximum number of modules(including the power meter and I/O modules) on this port is $totalModule.",
			"moduleNotFound": "Module not found, please search the module by typing the first few letters of the module name and select the module from the list.",
			"nicknameOrModuleNameIsEmpty": "Nickname / Module Name field can't be empty.",
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"ipIsEmpty": "IP field can't be empty."
		}
	},
	"html/desktop/home/module/remote/modbus.htm": {
		"moduleXSetting": "Module $moduleName Setting",
		"no": "No.",
		"address": "Address",
		"ip": "IP",
		"port": "Port",
		"netID": "NetID",
		"scanRate": "Scan Rate",
		"pollingTimeout": "Polling Timeout",
		"retryInterval": "Retry Interval",
		"modbusTableSetting": "Modbus Mapping Table Setting",
		"dataModel": "Data Model",
		"startAddress": "Start Address",
		"length": "Data Number",
		"type": "Type",
		"hexType": "HEX Type",
		"hex": "HEX",
		"real": "Real",
		"minimum": "Minimum:",
		"maximum": "Maximum:",
		"dataAdjustment": "Data Adjustment",
		"scaleRatio": "Scale Ratio",
		"offset": "Offset",
		"deadband": "Deadband",
		"add": "Add",
		"modbusTable": "Modbus Mapping Table",
		"addressSetting": "Address Setting",
		"nicknameSetting": "Nickname Setting",
		"localAddress": "Local<br>Address",
		"removeAllBlock": "Remove All Setting",
		"collapseAllBlock": "Collapse All",
		"expandAllBlock": "Expand All",
		"noBlockInModbusTable": "No mapping table configuration",
		"dataAddress": "Data Address",
		"hexMinimum": "HEX Minimum",
		"hexMaximum": "HEX Maximum",
		"realMinimum": "Real Minimum",
		"realMaximum": "Real Maximum",
		"remove": "Remove",
		"unit": "Unit",
		"tip": {
			"nickname": "Input the nickname of this module.",
			"description": "Input the description of this module.",
			"no": "Set up the index number of the module, the data of the module will be stored in the Modbus mapping table that corresponds to the index number.",
			"address": "Set the address of this module.",
			"ip": "Input the IP address of this module.",
			"port": "Input the port of this module.",
			"netID": "Input the NetID of this module.",
			"scanRateForRTU": "Input the time interval to update the data of the channels on this module, if the value is set as '0' indicates the data will be immediately updated without delay.",
			"scanRateForTCP": "Input the time interval to update the data of the channels on this module.",
			"pollingTimeout": "Input the polling timeout of this module.",
			"retryInterval": "Input the timeout retry interval of this module.",
			"dataModel": "Select the data model of the retrieved data on the Modbus module.",
			"startAddress": "Input the start address of the retrieved data on the Modbus module.",
			"length": "Input how many data sets you are going to retrieve.",
			"type": "Set the data type of the retrieved data.",
			"hexType": "Input the parameters for HEX transformation.",
			"scaleRatio": "Input the scale ratio of the data, the new value will be the old value times this scale ratio.",
			"offset": "Input the offset of the data, the final value of the modified data will be the value(old value times scale ratio) plus this offset.",
			"deadband": "Input the deadband value of this data used in rule judgement."
		},
		"popup": {
			"addressReachMaximum": "Address of data must be less than or equal to 65535.",
			"addressAlreadyExist": "Some address of the data already exists in the Modbus mapping table.",
			"lengthReachMaximum": "The length of data has exceeded the limit, the maximum length of data is $length.",
			"modbusTableReachMaximum": "The length of Modbus mapping table has exceeded the limit, the maximum length of Modbus mapping table is $maxLength.",
			"hexMaximumEqualToMinimum": "The maximum value can't be equal to the minimum value of the HEX value.",
			"realMaximumLessThanMinimum": "The maximum value can't be less than or equal to the minimum value of the Real value.",
			"nicknameIsEmpty": "Nickname field can't be empty."
		}
	},
	"html/desktop/home/module/remote/icpdas.htm": {
		"moduleXSetting": "Module $moduleName Setting",
		"no": "No.",
		"address": "Address",
		"scanRate": "Scan Rate",
		"pollingTimeout": "Polling Timeout",
		"retryInterval": "Retry Interval",
		"aiType": "AI Type",
		"differential": "Differential",
		"singleEnded": "Single-ended",
		"temperatureUnit": "Temperature Unit",
		"celsius": "Celsius(°C)",
		"fahrenheit": "Fahrenheit(°F)",
		"diAttribute": "DI Attribute",
		"doAttribute": "DO Attribute",
		"aiAttribute": "AI Attribute",
		"aoAttribute": "AO Attribute",
		"channel": "Channel",
		"ch": "Ch.",
		"resetCounterWhenPowerOn": "Reset Counter When Start Up",
		"advancedFunction": "Advanced Function",
		"autoOFF": "Auto OFF",
		"mappingToDI": "DI Status Mapping",
		"autoOFFAfterXSeconds": "Automatically return to OFF status after $input second(s)",
		"cloneDIXChannelStatus": "Copy DI channel $di status",
		"type": "Type",
		"deadband": "Deadband",
		"scale": "Scale",
		"scaleMin": "Minimum:",
		"scaleMax": "Maximum:",
		"scaleUnit": "Unit:",
		"tip": {
			"nickname": "Input the nickname of this module.",
			"description": "Input the description of this module.",
			"no": "Set up the index number of the module, the data of the module will be stored in the Modbus mapping table that corresponds to the index number.",
			"address": "Set the address of this module.",
			"scanRate": "Input the time interval to update the data of the channels on this module, if the value is set as '0' indicates the data will be immediately updated without delay.",
			"pollingTimeout": "Input the polling timeout of this module.",
			"retryInterval": "Input the timeout retry interval of this module.",
			"aiType": "Set up the signal mode of the AI channel ",
			"temperatureUnit": "Set up the unit of temperature."
		}
	},
	"html/desktop/home/logger.htm": {
		"loggerSettingPage": "Logger Setting Page",
		"powerMeterDataLogger": "Power Data Logger",
		"ioModuleDataLogger": "I/O Data Logger",
		"userDefinedDataLogger": "User-Defined Data Logger",
		"logAttribute": "Log Attribute",
		"ftpUploadFunction": "FTP Upload Function",
		"dataLogUploadFunction": "Data Log Upload Function",
		"powerMeterDataLog": "Power Data Log",
		"ioModuleDataLog": "I/O Data Log",
		"userDefinedDataLog": "User-Defined Data Log",
		"eventLogUploadFunction": "Event Log Upload Function",
		"eventLog": "Event Log",
		"cloudUploadFunction": "Cloud Upload Function"
	},
	"html/desktop/home/logger/menu.htm": {
		"dataLoggerSetting": "Data Logger Setting",
		"eventLoggerSetting": "Event Logger Setting",
		"ftpUploadSetting": "FTP Upload Setting",
		"cloudUploadSetting": "Cloud Upload Setting",
	},
	"html/desktop/home/logger/data.htm": {
		"powerMeterDataLoggerSetting": "Power Data Logger Setting",
		"functionStatus": "Function Status",
		"logMode": "Log Mode",
		"average": "Average",
		"instantaneous": "Instantaneous",
		"report": "Reports",
		"english": "English",
		"traditionalChinese": "Traditional Chinese",
		"simplifiedChinese": "Simplified Chinese",
		"ioModuleDataLoggerSetting": "I/O Data Logger Setting",
		"userDefinedDataLoggerSetting": "User-Defined Data Logger Setting",
		"dataFormat": "Data Format",
		"insert": "Insert",
		"logAttributeSetting": "Log Attribute Setting",
		"logInterval": "Log Interval",
		"fileNameFormat": "File Name Format",
		"endOfLineChar": "End of Line Character",
		"columnHeader": "Column Header",
		"add": "Add",
		"logFileRetentionTime": "Log File Retention Time",
		"tip": {
			"functionStatus": "Check 'Enable' to enable the logger function.",
			"logMode": "Set the data log mode to be Average or Instantaneous when performing data recording.",
			"columnHeader": "Check 'Add' to add a column header to the log file.",
			"report": "Set to enable Excel reports or not.",
			"dataFormat": "Input the format of the data recording.",
			"logInterval": "Set the time interval of the recording session.",
			"fileNameFormat": "Set the file name format for the log file.",
			"endOfLineChar": "Set the End of Line Character for the data record.",
			"logFileRetentionTime": "Set the file retention time for the log file."
		},
		"popup": {
			"dataFormatIsEmpty": "Data format field can't be empty."
		}
	},
	"html/desktop/home/logger/event.htm": {
		"eventLoggerSetting": "Event Logger Setting Page",
		"logFileRetentionTime": "Log File Retention Time",
		"tip": {
			"logFileRetentionTime": "Set the file retention time for the log file."
		}
	},
	"html/desktop/home/logger/ftp.htm": {
		"ftpUploadSettingPage": "FTP Upload Setting Page",
		"functionStatus": "Function Status",
		"remoteFTPServer": "Remote FTP Server",
		"address": "Address",
		"port": "Port",
		"id": "ID",
		"password": "Password",
		"path": "Path",
		"ftpSettingTest": "Remote FTP Server Setting Test",
		"send": "Send",
		"sentSuccessfully": "Sent successfully.",
		"sentFailed": "Sent Failed.",
		"dataLogUploadFunction": "Data Log Upload Function",
		"uploadPowerMeterDataLog": "Upload Power Data Log",
		"uploadIOModuleDataLog": "Upload I/O Data Log",
		"uploadUserDefinedDataLog": "Upload User-Defined Data Log",
		"eventLogUploadFunction": "Event Log Upload Function",
		"uploadEventLog": "Upload Event Log",
		"frequency": "Frequency",
		"everyXMinutes": "Every $minute minutes",
		"everyXHour": "Every $hour hour",
		"everyXHours": "Every $hour hours",
		"eventLogUploadSetting": "Event Log Upload Setting",
		"onceADay": "Once a day",
		"onceAWeek": "Once a week",
		"onceAMonth": "Once a month",
		"enablePowerMeterDataLoggerFirst": "Enable power data logger first.",
		"enableIOModuleDataLoggerFirst": "Enable I/O data logger first.",
		"enableUserDefinedDataLoggerFirst": "Enable user-defined data logger first.",
		"tip": {
			"functionStatus": "Check 'Enable' to enable the logger upload function to the remote FTP server.",
			"dataLogUploadFunction": "Select the data log type you would like to upload and set up the frequency.",
			"eventLogUploadFunction": "Select the event log type you would like to upload and set up the frequency.",
			"frequency": "Set the frequency to upload the log file to the remote FTP server.",
			"remoteFTPServer": "Input the information of the remote FTP server.",
			"address": "Input the address of the remote FTP server.",
			"port": "Input the port of the remote FTP server.",
			"id": "Input the login ID of the remote FTP server.",
			"password": "Input the login password of the remote FTP server.",
			"path": "Input the upload path of the log files on the remote FTP server.",
			"ftpSettingTest": "After clicking 'Send', the system will try to login into the remote FTP server to create a folder and send the testing file to make sure your setting is OK."
		},
		"popup": {
			"urlIsEmpty": "Address field can't be empty.",
			"idIsEmpty": "User ID field can't be empty."
		}
	},
	"html/desktop/home/logger/cloud.htm": {
		"cloudUploadSettingPage": "Cloud Upload Setting Page",
		"functionStatus": "Function Status",
		"dataLogUploadFunction": "Data Log Upload Function",
		"uploadPowerMeterDataLog": "Upload Power Data Log",
		"uploadIOModuleDataLog": "Upload I/O Data Log",
		"enablePowerMeterDataLoggerFirst": "Enable power data logger first.",
		"enableIOModuleDataLoggerFirst": "Enable I/O data logger first.",
		"enableCloudFunctionFirst": "Enable 'System Setting > Network Setting > Cloud Manager System' function to upload the data log.",
		"tip": {
			"functionStatus": "Check 'Enable' to enable the logger upload function to the cloud.",
			"dataLogUploadFunction": "Select the data log type you would like to upload."
		}
	},
	"html/desktop/home/iot.htm": {
		"iotSettingPage": "IoT Platform Setting Page",
		"azureDescription": "The system features connection ability to the Microsoft Azure platform. It allows users to publish messages to Microsoft Azure and subscribe messages from Microsoft Azure, and use the content of the received messages as the IF Condition.",
		"bluemixDescription": "The system features connection ability to the IBM Bluemix platform. It allows users to publish messages to IBM Bluemix and subscribe messages from IBM Bluemix, and use the content of the received messages as the IF Condition.",
		"mqttDescription": "The MQTT client function allows to setup publish messages and subscribe topics of specific brokers, and use the content of the received topic messages as the IF Condition."
	},
	"html/desktop/home/iot/menu.htm": {
		"azureSetting": "Microsoft Azure Platform Setting",
		"bluemixSetting": "IBM Bluemix Platform Setting",
		"mqttSetting": "MQTT Setting"
	},
	"html/desktop/home/iot/azure.htm": {
		"azureSettingPage": "Microsoft Azure Setting Page",
		"functionStatus": "Function Status",
		"sasToken": "SAS Token",
		"keepAliveTime": "Keep Alive Time",
		"periodicallyPublishInterval": "Periodical Publish Interval",
		"input0RepresentDisablePeriodicallyPublish": "Input 0 represent disable periodical publish.",
		"connectionTesting": "Connection Testing",
		"testing": "Testing",
		"connectSuccessfully": "Connect successfully.",
		"connectFailed": "Connect Failed.",
		"publishAndSubscribeSetting": "Publish & Subscribe Setting",
		"publish": "Publish",
		"subscribe": "Subscribe",
		"message": "Message",
		"createNewPublishMessage": "Add new Publish Message",
		"copy": "Copy",
		"remove": "Remove",
		"noMessageExist": "No Message exists.",
		"variableName": "Variable Name",
		"add": "Add",
		"variable": "Variable",
		"noVariableNameExist": "No variable name exists.",
		"tip": {
			"functionStatus": "Click 'Enable' to enable the Microsoft Azure function.",
			"sasToken": "Input the SAS token provided by Microsoft Azure.",
			"keepAliveTime": "Input the keep alive time.",
			"periodicallyPublishInterval": "Input the interval of peridical publish. All topics which enable the auto-publish function in periodical publish mode will be published peroidically according to this interval.",
			"connectionTesting": "Click 'Testing' to establish a connection to Microsoft Azure to make sure your setting is OK.",
			"variableName": "Input the variable name. Each variable consists of a name and a value. The variable's value can work as a criteria for IF condition evaluation."
		},
		"popup": {
			"sasTokenIsEmpty": "SAS token field can't be empty.",
			"variableNameIsEmpty": "Variable name field can't be empty.",
			"variableNameIsDuplicate": "Variable name field can't be duplicated."
		}
	},
	"html/desktop/home/iot/azure/publish.htm": {
		"messageType": "Message Type",
		"channelData": "Channel Data",
		"userDefinedData": "User-Defined Data",
		"insert": "Insert",
		"useJSONFormat": "JSON Format",
		"autoPublish": "Auto Publish",
		"dataChangeGreatX": "When the I/O channel data changed and the variation exceeds $threshold.",
		"periodicallyPublish": "Periodical Publish",
		"none": "None",
		"message": "Message",
		"publishMessageXSetting": "Publish Message $name Setting",
		"tip": {
			"nickname": "Input the nickname of this message.",
			"description": "Input the description of this message.",
			"messageType": "Set up the data type of this message.",
			"channelData": "Select the channel data as the content of this message.",
			"userDefinedData": "Input the user-defined information as the content of this message.",
			"autoPublish": "Select the auto-publish mode to enable the auto-publish function of this message"
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"noAvailableChannelData": "No channel data is available. Please add at least one module or internal register first.",
			"userDefinedDataIsEmpty": "User-defined data field can't be empty."
		}
	},
	"html/desktop/home/iot/bluemix.htm": {
		"bluemixSettingPage": "IBM Bluemix Setting Page",
		"functionStatus": "Function Status",
		"organizationID": "Organization ID",
		"deviceType": "Device Type",
		"deviceID": "Device ID",
		"deviceAuthenticationToken": "Device Authentication Token",
		"keepAliveTime": "Keep Alive Time",
		"periodicallyPublishInterval": "Periodical Publish Interval",
		"input0RepresentDisablePeriodicallyPublish": "Input 0 represent disable periodical publish.",
		"connectionTesting": "Connection Testing",
		"testing": "Testing",
		"connectSuccessfully": "Connect successfully.",
		"connectFailed": "Connect Failed.",
		"publishAndSubscribeSetting": "Publish & Subscribe Setting",
		"publish": "Publish",
		"subscribe": "Subscribe",
		"message": "Message",
		"createNewPublishMessage": "Add new Publish Message",
		"copy": "Copy",
		"remove": "Remove",
		"noMessageExist": "No Message exists.",
		"commandName": "Command Name",
		"variableName": "Variable Name",
		"add": "Add",
		"command": "Command",
		"variable": "Variable",
		"noCommandNameExist": "No command name exists.",
		"noVariableNameExist": "No variable name exists.",
		"tip": {
			"functionStatus": "Click 'Enable' to enable the IBM Bluemix function.",
			"organizationID": "Input the organization ID.",
			"deviceType": "Input the device type.",
			"deviceID": "Input the device ID.",
			"deviceAuthenticationToken": "Input the device authentication token.",
			"keepAliveTime": "Input the keep alive time.",
			"periodicallyPublishInterval": "Input the interval of peridical publish. All topics which enable the auto-publish function in periodical publish mode will be published peroidically according to this interval.",
			"connectionTesting": "Click 'Testing' to establish a connection to IBM Bluemix to make sure your setting is OK.",
			"commandName": "Input the command name. The name can work as a criteria for IF condition evaluation.",
			"variableName": "Input the variable name. Each variable consists of a name and a value. The variable's value can work as a criteria for IF condition evaluation."
		},
		"popup": {
			"organizationIDIsEmpty": "Organization ID field can't be empty.",
			"deviceTypeIsEmpty": "Device type can't be empty.",
			"deviceIDIsEmpty": "Device ID field can't be empty.",
			"deviceAuthenticationTokenIsEmpty": "Device authentication token field can't be empty.",
			"commandNameIsEmpty": "Command name field can't be empty.",
			"commandNameIsDuplicate": "Command name field can't be duplicated.",
			"variableNameIsEmpty": "Variable name field can't be empty.",
			"variableNameIsDuplicate": "Variable name field can't be duplicated."
		}
	},
	"html/desktop/home/iot/bluemix/publish.htm": {
		"eventID": "Event ID",
		"messageType": "Message Type",
		"channelData": "Channel Data",
		"userDefinedData": "User-Defined Data",
		"insert": "Insert",
		"useJSONFormat": "JSON Format",
		"autoPublish": "Auto Publish",
		"dataChangeGreatX": "When the I/O channel data changed and the variation exceeds $threshold.",
		"periodicallyPublish": "Periodical Publish",
		"none": "None",
		"message": "Message",
		"publishMessageXSetting": "Publish Message $name Setting",
		"tip": {
			"nickname": "Input the nickname of this message.",
			"description": "Input the description of this message.",
			"eventID": "Input the event ID of this message.",
			"messageType": "Set up the data type of this message.",
			"channelData": "Select the channel data as the content of this message.",
			"userDefinedData": "Input the user-defined information as the content of this message.",
			"autoPublish": "Select the auto-publish mode to enable the auto-publish function of this message"
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"eventIDIsEmpty": "Event ID field can't be empty.",
			"noAvailableChannelData": "No channel data is available. Please add at least one module or internal register first.",
			"userDefinedDataIsEmpty": "User-defined data field can't be empty."
		}
	},
	"html/desktop/home/iot/mqtt.htm": {
		"mqttSettingPage": "MQTT Setting Page",
		"brokerSetting": "Broker Setting",
		"topicImportExport": "Topic Import/Export",
		"address": "Address",
		"port": "Port",
		"initialStatus": "Initial Status",
		"createNewOne": "Add new MQTT Broker",
		"noBrokerExist": "No MQTT Broker exists.",
		"copy": "Copy",
		"remove": "Remove",
		"importTopic": "Import Topic",
		"export": "Export",
		"popup": {
			"importingPleaseWait": "Importing, please wait...",
			"noExportTopicPleaseSelectLastOneTopic": "No topic is exportable, please select at least one topic.",
			"importFailed": "Import failed.",
			"importFailedFileFormatIsInvalid": "Import failed, the file format is invalid.",
			"importSuccess": "Import successfully.",
			"reachMaximumBrokerAmount": "Reach maximum broker amount."
		}
	},
	"html/desktop/home/iot/mqtt/broker.htm": {
		"brokerAttributeSetting": "Broker Attribute Setting",
		"initialStatus": "Initial Status",
		"address": "Address",
		"port": "Port",
		"authentication": "Authentication",
		"id": "ID",
		"password": "Password",
		"clientID": "Client ID",
		"encryption": "Encryption",
		"keepAliveTime": "Keep Alive Time",
		"connectionTesting": "Connection Testing",
		"testing": "Testing",
		"connectSuccessfully": "Connect successfully.",
		"connectFailed": "Connect Failed.",
		"messageSetting": "Message Setting",
		"message": "Message",
		"periodicallyPublishInterval": "Periodical Publish Interval",
		"input0RepresentDisablePeriodicallyPublish": "Input 0 represent disable periodical publish.",
		"topicPrefix": "Topic Prefix",
		"publishAndSubscribeSetting": "Publish & Subscribe Setting",
		"createNewPublishMessage": "Add new Publish Message",
		"createNewSubscribeTopic": "Add new Subscribe Topic",
		"noTopicExist": "No Topic exists.",
		"noMessageExist": "No Message exists.",
		"copy": "Copy",
		"remove": "Remove",
		"brokerXSetting": "Broker $name Setting",
		"tip": {
			"nickname": "Input the nickname of this broker.",
			"description": "Input the description of this broker.",
			"initialStatus": "Set up the initial connection status for this broker when power on.",
			"address": "Input the address of this broker.",
			"port": "Input the port number of this broker.",
			"authentication": "If the broker require the account authentication, please click 'Enable' to enable the account authorization function.",
			"lastWill": "Check the 'Enable' to enable the 'Last Will' function.",
			"clientID": "Input the client ID of this broker. If the Client ID is not inputted, the system will automatically generate an ID for this broker.",
			"encryption": "Set up if the data encryption function is enabled when sending and receiving the data.",
			"keepAliveTime": "Input the keep alive time of this broker.",
			"periodicallyPublishInterval": "Input the interval of peridical publish. All topics which enable the auto-publish function in periodical publish mode will be published peroidically according to this interval.",
			"topicPrefix": "Input the topic prefix of this broker. You can specify whether or not to use the prefix in each topic setting.",
			"connectionTesting": "Click 'Testing' to establish a connection to this broker to make sure your setting is OK."
		},
		"popup": {
			"reachMaximumAmount": "Reach maximum amount.",
			"nicknameIsEmpty": "Nickname of Broker field can't be empty.",
			"addressIsEmpty": "Address field can't be empty.",
			"idIsEmpty": "ID field can't be empty.",
			"willTopicIsEmpty": "Will Topic field can't be empty.",
			"willMessageIsEmpty": "Will Message field can't be empty."
		}
	},
	"html/desktop/home/iot/mqtt/broker/publish.htm": {
		"messageType": "Message Type",
		"channelData": "Channel Data",
		"userDefinedData": "User-Defined Data",
		"insert": "Insert",
		"useJSONFormat": "JSON Format",
		"usePrefix": "Use Prefix",
		"import": "Import",
		"use": "Use",
		"retain": "Retain",
		"autoPublish": "Auto Publish",
		"dataChangeGreatX": "When the I/O channel data changed and the variation exceeds $threshold.",
		"periodicallyPublish": "Periodical Publish",
		"none": "None",
		"message": "Message",
		"publishMessageXSetting": "Publish Message $name Setting",
		"tip": {
			"nickname": "Input the nickname of this message.",
			"description": "Input the description of this message.",
			"messageType": "Set up the data type of this message.",
			"channelData": "Select the channel data as the content of this message.",
			"userDefinedData": "Input the user-defined information as the content of this message.",
			"topic": "Input the topic of this publish message",
			"qos": "Set up the QoS of this message",
			"retain": "Check the 'Enable' to enable retain function of this message.",
			"autoPublish": "Select the auto-publish mode to enable the auto-publish function of this message"
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"noAvailableChannelData": "No channel data is available. Please add at least one module or internal register first.",
			"userDefinedDataIsEmpty": "User-defined data field can't be empty.",
			"topicIsEmpty": "Topic field can't be empty."
		}
	},
	"html/desktop/home/iot/mqtt/broker/subscribe.htm": {
		"usePrefix": "Use Prefix",
		"import": "Import",
		"use": "Use",
		"subscribeTopicXSetting": "Subscribe Topic $name Setting",
		"tip": {
			"nickname": "Input the nickname of this topic.",
			"description": "Input the description of this topic.",
			"topic": "Input the topic name to be subscribed.",
			"qos": "Set up the QoS of this topic"
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"topicIsEmpty": "Topic field can't be empty.",
			"topicContainIllegalCharacter": "Topic field can't contain the symbols '+' or '#'."
		}
	},
	"html/desktop/home/advanced.htm": {
		"advancedSettingPage": "Advanced Setting Page",
		"internalRegisterDescription": "48 Internal Registers are provided. They can be used to hold temporary variables and the data can be read/written on the Registers via Modbus command.  The data on the registers can also be read and evaluated in IF Condition and be written after performing a THEN/ELSE Action.",
		"timerDescription": "Timer function provides Timeout/Not Timeout status for condition evaluations. With the timer function, the users are able to edit logic that requires timing approach. In addition, the timer function can be reseted/started in real time that increases flexibility when performing logic control.",
		"scheduleDescription": "Schedule function supports the scheduled routine tasks. With Calendar user interface provided, Schedule setting can be more efficient and flexible for the users.",
		"emailDescription": "The Email function allows sending pre-set Email message(s) to the pre-set Email receiver(s) under certain conditions. The I/O channel information can be sent via Email in real time; the system status will be reported immediately.",
		"cgiDescription": "The CGI Command function allows sending pre-input CGI Command to pre-set remote network device under certain conditions.",
		"smsDescription": "The SMS function allows to include SMS alarm sending action into logic rules to send a pre-set SMS message to related personnel when an event occurs and allows to receive the SMS commands sending by specific phones numbers to perform tasks such as real-time channel monitoring and channel data modification, etc.",
		"statusDescription": "Channel Status function allows to display the channel status of the controller on the Web page. User can define the content of the page to display the data from different channels of the modules.",
		"hmiDescription": "User could design the customized Flash HMI page by using the Flash HMI editor & Flash HMI graphic components for the remote monitoring and control of the system. ",
		"snmpTrapDescription": "SNMP Trap function allows to initiative sending of the channel data in real time automatically when unusual events occur; so that the SNMP Manager can respond immediately with corresponding operations.",
		"pueDescription": "Help user to calculate the PUE(Power Usage Effectiveness) of the facility room. The value can also be used in IF Condition.",
		"lineNotifyDescription": "The LINE Notify function allows to push pre-set message(s) to the LINE App on your mobile phone when an event occurs. Using the IP Camera with LINE Notify function also allows it to send live images so that the related personnel can respond to the emergency situations on site in real time."
	},
	"html/desktop/home/advanced/menu.htm": {
		"internalRegisterSetting": "Internal Register Setting",
		"timerSetting": "Timer Setting",
		"scheduleSetting": "Schedule Setting",
		"emailSetting": "Email Setting",
		"cgiCommandSetting": "CGI Command Setting",
		"smsSetting": "SMS Setting",
		"statusSetting": "Channel Status Setting",
		"hmiSetting": "Flash HMI Setting",
		"snmpTrapSetting": "SNMP Trap Setting",
		"lineNotifySetting": "LINE Notify Setting"
	},
	"html/desktop/home/advanced/register.htm": {
		"internalRegisterSettingPage": "Internal Register Setting Page",
		"no": "No.",
		"initialValue": "Initial Value",
		"noInternalRegisterExistClickThisButtonToAdd": "No register exists, press this button to create one.",
		"copy": "Copy",
		"remove": "Remove",
		"internalRegister": "Internal Register",
		"retainVariable": "Retain Variable",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount."
		}
	},
	"html/desktop/home/advanced/register/setting.htm": {
		"internalRegisterXSetting": "Internal Register $name Setting",
		"no": "No.",
		"initialValue": "Initial Value",
		"tip": {
			"no": "The index of Internal Register.",
			"nickname": "Input the nickname of this Internal Register.",
			"description": "Input the description of this Internal Register.",
			"initialValue": "Input the initial value of this Internal Register."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty."
		}
	},
	"html/desktop/home/advanced/timer.htm": {
		"timerSettingPage": "Timer Setting Page",
		"timer": "Timer",
		"initialStatus": "Initial Status",
		"period": "Period",
		"stop": "Stop",
		"start": "Start",
		"assignPeriod": "Assign Period",
		"internalRegister": "Internal Register",
		"no": "No.",
		"alreadyRemove": "(Removed)",
		"noTimerExistClickThisButtonToAdd": "No timer exists, press this button to create one.",
		"copy": "Copy",
		"remove": "Remove",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount.",
			"someoneTimerUseAlreadyRemovedRegister": "This Internal Register has been disabled, the value of this Internal Register can't be used as the length of the period time of the Timer."
		}
	},
	"html/desktop/home/advanced/timer/setting.htm": {
		"timerXSetting": "Timer $name Setting",
		"initialStatus": "Initial Status",
		"period": "Period",
		"stop": "Stop",
		"start": "Start",
		"assignPeriod": "Assign Period",
		"internalRegister": "Internal Register",
		"no": "No.",
		"tip": {
			"nickname": "Input the nickname of this timer.",
			"description": "Input the description of this timer.",
			"initialStatus": "Set the initial status for this timer when power on.",
			"period": "Input the period of this timer."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty."
		}
	},
	"html/desktop/home/advanced/schedule.htm": {
		"scheduleSettingPage": "Schedule Setting Page",
		"mode": "Mode",
		"calendar": "Calendar",
		"repeat": "Repeat",
		"createNewOne": "Add new schedule",
		"copy": "Copy",
		"remove": "Remove",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount."
		}
	},
	"html/desktop/home/advanced/schedule/setting.htm": {
		"scheduleXSetting": "Schedule $name Setting",
		"schedule": "Schedule",
		"scheduleDetailSetting": "Schedule Content Setting",
		"initialStatus": "Initial Status",
		"mode": "Mode",
		"calendar": "Calendar",
		"repeat": "Repeat",
		"date": "Date",
		"startMonth": "Starting Month",
		"duration": "Duration",
		"month": "Month(s)",
		"day": "Day(s) of Week",
		"exceptionDate": "Exception Date(s)",
		"timeRange": "Time Range(s)",
		"add": "Add",
		"remove": "Remove",
		"selectAll": "Select All",
		"unSelectAll": "Unselect All",
		"selectWeekday": "Select Weekday",
		"selectWeekend": "Select Weekend",
		"inRange": "In Range",
		"outOfRange": "Out of Range",
		"tip": {
			"nickname": "Input the nickname of this schedule.",
			"description": "Input the description of this schedule.",
			"initialStatus": "Set the initial status for this schedule when power on.",
			"mode": "Select the Schedule mode; the mode 'Calendar' allows to set individual dates of the year to execute the tasks; the mode 'Repeat' allows to set days of the week to execute the tasks periodically.",
			"calendarDate": "Set the date range of this schedule.",
			"day": "Select the days of the week to execute tasks repeatedly.",
			"exceptionDate": "Set the exceptional date in this periodic schedule.",
			"timeRange": "Set the time period of this schedule."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"selectAtLeastOneDate": "Please specify at least one date to be In Range.",
			"selectAtLeastOneDay": "Please specify at least one day in a week.",
			"selectAtLeastOneTimeRange": "Please specify at least one time range.",
			"startTimeIsSameWithEndTime": "The end time cannot be exactly the same as the start time.",
			"timeRangeIsOverlap": "The range of time cannot be overlapped."
		}
	},
	"html/desktop/home/advanced/email.htm": {
		"emailSettingPage": "Email Setting Page",
		"subject": "Subject",
		"receiver": "Receiver",
		"createNewOne": "Add new email",
		"copy": "Copy",
		"remove": "Remove",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount."
		}
	},
	"html/desktop/home/advanced/email/setting.htm": {
		"emailXSetting": "Email $name Setting",
		"email": "Email",
		"smtpServerSetting": "SMTP Server Setting",
		"smtpServer": "SMTP Server",
		"specifySMTPServer": "Specify an address of SMTP server",
		"port": "Port",
		"authentication": "Authentication",
		"id": "ID",
		"password": "Password",
		"security": "Security",
		"noSecurity": "No Security",
		"emailAddressSetting": "Email Address Setting",
		"senderName": "Sender Name",
		"senderEmail": "Sender Email Address",
		"receiverEmail": "Receiver Email Address",
		"add": "Add",
		"remove": "Remove",
		"emailSettingTest": "Email Setting Test",
		"send": "Send",
		"sentSuccessfully": "Sent successfully.",
		"sentFailed": "Sent Failed.",
		"emailContenttSetting": "Email Content Setting",
		"subject": "Subject",
		"content": "Content",
		"insert": "Insert",
		"tip": {
			"nickname": "Input the nickname of this email.",
			"description": "Input the description of this email.",
			"smtpServer": "Input the SMTP server address.",
			"port": "Input the SMTP server port.",
			"authentication": "If the SMTP server does not allow anonymous connection, please check 'Enable' for authentication and input the login name and password.",
			"id": "Input the SMTP server login ID.",
			"password": "Input the SMTP server login password.",
			"security": "Set the encryption of the SMTP server.",
			"senderName": "Input the sender's name.",
			"senderEmail": "Input the sender's email address.",
			"receiverEmail": "Input the receiver's email address.",
			"emailSettingTest": "Click 'Send' to send a testing Email to the first receiver Email address to make sure your setting is OK.",
			"emailSubject": "Input the email subject.",
			"emailContent": "Input the email content."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"smtpServerIsEmpty": "SMTP server field can't be empty.",
			"idIsEmpty": "ID field can't be empty.",
			"senderNameIsEmpty": "Sender name field can't be empty.",
			"senderEmailIsEmpty": "Sender email address field can't be empty.",
			"receiverEmailIsEmpty": "Number of receiver email address must be greater than or equal to 1.",
			"subjectIsEmpty": "Subject field can't be empty.",
			"contentIsEmpty": "Content field can't be empty."
		}
	},
	"html/desktop/home/advanced/cgi.htm": {
		"cgiCommandSetting": "CGI命令設定頁面",
		"cgiServerAddress": "CGI伺服器位址",
		"port": "連接埠",
		"commandNumber": "Command Number",
		"noCGIServerExistClickThisButtonToAdd": "無設定CGI伺服器，請按此按鈕新增。",
		"copy": "複製",
		"remove": "移除",
		"cgiServer": "CGI伺服器",
		"popup": {
			"cgiServerAddressIsEmpty": "CGI伺服器位址不能為空白。",
			"reachMaximumAmount": "達到最大數量。",
			"commandIsEmpty": "The command number of server must be greater than or equal to 1."
		}
	},
	"html/desktop/home/advanced/cgi/server.htm": {
		"cgiServerAddress": "CGI伺服器位址",
		"port": "連接埠",
		"authentication": "帳號驗證",
		"type": "認證類型",
		"id": "帳號",
		"password": "密碼",
		"retryTimes": "重試次數",
		"times": "次",
		"cgiCommandSetting": "CGI命令設定",
		"cgiCommand": "CGI命令",
		"createNewOne": "新增CGI命令",
		"copy": "複製",
		"remove": "移除",
		"cgiServerXSetting": "CGI伺服器 $name 設定",
		"tip": {
			"nickname": "輸入對此CGI伺服器的名稱。",
			"description": "輸入對此CGI伺服器的說明。",
			"cgiServerAddress": "輸入此CGI伺服器的位址。",
			"port": "輸入此CGI伺服器的連接埠。",
			"authentication": "若您的CGI伺服器要求認證，請勾選'啟用'以啟用帳號驗證功能。",
			"type": "設定此CGI伺服器認證類型。",
			"id": "輸入此CGI伺服器的認證帳號。",
			"password": "輸入此CGI伺服器的認證密碼。",
			"retryTimes": "輸入當此CGI命令發送失敗時，重新嘗試發送的次數。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"cgiServerAddressIsEmpty": "CGI伺服器位址不能為空白。",
			"idIsEmpty": "帳號不能為空白。",
			"commandIsEmpty": "The number of CGI command must be greater than or equal to 1."
		}
	},
	"html/desktop/home/advanced/cgi/server/command.htm": {
		"cgiCommand": "CGI命令",
		"source": "來源",
		"module": "模組",
		"channel": "通道",
		"no": "編號",
		"insert": "插入",
		"connectionTesting": "連線測試",
		"testing": "測試",
		"responseContentSetting": "回應內容設定",
		"saveAsFile": "儲存成檔案",
		"savePath": "儲存路徑",
		"fileName": "檔名",
		"yyyyDescription": "四位數西元年。",
		"HHDescription": "時，數值從00到23。",
		"MMDescription": "月，數值從01到12。",
		"mmDescription": "分，數值從00到59。",
		"ddDescription": "日，數值從01到31。",
		"ssDescription": "秒，數值從00到59。",
		"sendBackViaEmail": "透過電子郵件寄出",
		"sentSuccessfully": "傳送成功。",
		"sentFailed": "傳送失敗。",
		"cgiCommandXSetting": "CGI命令 $name 設定",
		"tip": {
			"nickname": "輸入對此CGI命令的名稱。",
			"description": "輸入對此CGI命令的說明。",
			"cgiCommand": "輸入此CGI命令的內容。",
			"connectionTesting": "按下測試後，系統將會依據您的設定，嘗試傳送一個CGI命令至您設定的伺服器上，以確定設定正確。",
			"saveAsFile": "勾選'啟用'以啟用將CGI回應的內容儲存成檔案功能。",
			"savePath": "輸入檔案儲存於SD卡的路徑。",
			"fileName": "輸入檔案的檔名。若您沒有輸入附檔名，系統會嘗試以CGI回應的Content-Type來決定附檔名。",
			"sendBackViaEmail": "設定檔案欲透過的電子郵件設定寄出。",
			"setupEmailFirst": "請先設定電子郵件。"
		},
		"popup": {
			"nicknameIsEmpty": "名稱不能為空白。",
			"cgiCommandIsEmpty": "CGI命令內容不能為空白。",
			"fileNameIsEmpty": "檔名不能為空白。",
			"fileNameIsInvalid": "檔名不能為index或default。"
		}
	},
	"html/desktop/home/advanced/sms.htm": {
		"smsSettingPage": "SMS Setting Page",
		"smsAlarm": "SMS Alarm",
		"smsCommand": "SMS Command",
		"pinCode": "PIN Code",
		"smsCommandFunction": "SMS Command Function",
		"authorizedPhoneNumbers": "Authorized Phone Numbers",
		"add": "Add",
		"copy": "Copy",
		"remove": "Remove",
		"smsAlarmsList": "SMS Alarm List",
		"phoneNumbers": "Phone Numbers",
		"message": "Message",
		"createNewSMSAlarm": "Add new SMS alarm",
		"smsCommandsList": "SMS Command List",
		"command": "Command",
		"commandString": "Command String",
		"createNewSMSCommand": "Add new SMS command",
		"tip": {
			"pinCode": "Input the PIN code of the SIM card.",
			"smsCommandFunction": "Click the check box to enable the SMS Command receiving function.",
			"authorizedPhoneNumbers": "Input the phone numbers that are authorized to send SMS commands to the controller. The authorized Phone Number has to be input in the format: Country code, area code and number."
		},
		"popup": {
			"reachMaximumAmount": "Reach maximum amount.",
			"authorizedPhoneNumbersIsEmpty": "Number of authorized phone numbers must be greater than or equal to 1."
		}
	},
	"html/desktop/home/advanced/sms/alarms.htm": {
		"smsAlarmXSetting": "SMS Alarm $name Setting",
		"smsAlarm": "SMS Alarm",
		"phoneNumbers": "Phone Number",
		"add": "Add",
		"remove": "Remove",
		"message": "Message",
		"unicode": "Multilingual Support(Unicode)",
		"insert": "Insert",
		"tip": {
			"nickname": "Input the nickname of this SMS Alarm.",
			"description": "Input the description of this SMS Alarm.",
			"phoneNumbers": "Input the phone numbers to receive the SMS alarm messages.",
			"unicode": "When characters other than English alphabet or numbers are used in the SMS Alarm message content, please check this option.",
			"message": "Input the content of the SMS Alarm message. The length of the SMS content is limited to 160 characters, if the Unicode mode is adopted, the length of the content is limited to 70 characters."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"phoneNumbersIsEmpty": "The count of the phone numbers must be greater than or equal to 1.",
			"messageIsEmpty": "Message field can't be empty."
		}
	},
	"html/desktop/home/advanced/sms/quickcommands.htm": {
		"smsCommandSetting": "SMS Command Setting",
		"command": "Command",
		"commandString": "Command String Editor",
		"insert": "Insert",
		"value": "Value",
		"none": "None",
		"tip": {
			"command": "Input the command.",
			"commandString": "Set the command string."
		},
		"popup": {
			"quickCommandIsEmpty": "Command field can't be empty.",
			"originalCommandIsEmpty": "Command string field can't be empty.",
			"quickCommandIsUsed": "This command has been used."
		}
	},
	"html/desktop/home/advanced/status.htm": {
		"customizeStatusSetting": "Channel Status Setting Page",
		"groupAmount": "Group Amount",
		"createNewOne": "Add new channel status page",
		"copy": "Copy",
		"remove": "Remove",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount."
		}
	},
	"html/desktop/home/advanced/status/setting.htm": {
		"customizeStatusXSetting": "Channel Status $name Setting",
		"customizeStatus": "Channel Status",
		"createNewGroup": "Add new group",
		"addStatus": "Add Channel Status",
		"none": "None",
		"internalRegister": "Internal Register",
		"source": "Source",
		"module": "Module",
		"channel": "Channel",
		"no": "No.",
		"add": "Add",
		"group": "Group",
		"tip": {
			"nickname": "Input the nickname of this channel status page.",
			"description": "Input the description of this channel status page."
		},
		"popup": {
			"reachMaximumAmount": "Reach maximum amount.",
			"nicknameIsEmpty": "Nickname field can't be empty."
		}
	},
	"html/desktop/home/advanced/hmi.htm": {
		"loadingFlashPlayer": "Loading the Flash HMI Tools, please wait a moment.",
		"popup": {
			"loadFlashPlayerFailed": "Failed to load the Flash HMI Tools, please check the flash player status.",
			"flashPlayerVersionTooOld": "The version of Flash Player is too old, please upgrade the Flash Player."
		}
	},
	"html/desktop/home/advanced/snmp.htm": {
		"snmpTrapSettingPage": "SNMP Trap Setting Page",
		"specificTrapID": "Specific ID",
		"messageNumber": "Amount of Variable Bindings",
		"noSNMPTrapExistClickThisButtonToAdd": "No SNMP Trap exists, press this button to create one.",
		"copy": "Copy",
		"remove": "Remove",
		"snmpTrap": "SNMP Trap",
		"popup": {
			"messageNumberIsZero": "The amount of variable bindings of SNMP Trap must be greater than or equal to 1."
		}
	},
	"html/desktop/home/advanced/snmp/message.htm": {
		"specificTrapID": "Specific ID",
		"snmpTrapMessageList": "SNMP Trap Variable Binding List",
		"content": "Content",
		"format": "Format",
		"createNewMessage": "Add new variable bindings",
		"copy": "Copy",
		"remove": "Remove",
		"snmpTrapXSetting": "SNMP Trap $name Setting",
		"tip": {
			"nickname": "Input the nickname of this SNMP Trap.",
			"description": "Input the description of this SNMP Trap.",
			"specificTrapID": "Input the Specific ID of this SNMP Trap."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"messageNumberIsZero": "The amount of variable bindings of SNMP Trap must be greater than or equal to 1."
		}
	},
	"html/desktop/home/advanced/snmp/message/setting.htm": {
		"snmpTrapMessageSettingPage": "SNMP Trap Variable Binding Setting Page",
		"type": "Type",
		"channelData": "Channel Data",
		"userDefinedData": "User-Defined Data",
		"format": "Format",
		"insert": "Insert",
		"none": "None",
		"tip": {
			"type": "Set the type of this variable binding.",
			"channelData": "Select the channel data to be binded.",
			"format": "Set the format of this variable.",
			"userDefinedData": "Input the user-defined information to be binded."
		},
		"popup": {
			"noAvailableChannelData": "No channel data is available. Please add at least one module or internal register first.",
			"userDefinedDataIsEmpty": "User-defined data field can't be empty."
		}
	},
	"html/desktop/home/advanced/linenotify.htm": {
		"lineNotifyMessageSettingPage": "LINE Notify Message Setting Page",
		"lineNotifyCameraSettingPage": "LINE Notify & IP Camera Connection Setting Page",
		"lineNotifyChatRoomSettingPage": "LINE Notify Chat Room Setting Page",
		"message": "Message",
		"ipCamera": "IP Camera",
		"chatRoom": "Chat Room",
		"content": "Content",
		"chatRoomNumber": "Amount of Chat Room",
		"createNewMessage": "Add new message",
		"noMessageExist": "No message exists.",
		"copy": "Copy",
		"remove": "Remove",
		"functionStatus": "Function Status",
		"noCameraExist": "No IP camera exists.",
		"type": "Type",
		"accessToken": "Access Token",
		"createNewChatRoom": "Add new chat room",
		"noChatRoomExist": "No chat room exists.",
		"oneOnOne": "1-on-1",
		"group": "Group",
		"popup": {
			"someMessageNoChatRoom": "Some messages don't specify any chat room."
		}
	},
	"html/desktop/home/advanced/linenotify/message.htm": {
		"content": "Content",
		"insert": "Insert",
		"chatRoom": "Chat Room",
		"createNewChatRoom": "Add New Chat Room",
		"unSelectAll": "Unselect All",
		"selectAll": "Select All",
		"message": "Message",
		"messageXSetting": "Message $name Setting",
		"tip": {
			"nickname": "Input the nickname of this message.",
			"description": "Input the description of this message.",
			"content": "Input the content of this message.",
			"chatRoom": "Set up the chat room to send the message to."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"contentIsEmpty": "Content field can't be empty.",
			"chatRoomIsEmpty": "Chat Room field can't be empty. Please select at least one chat room."
		}
	},
	"html/desktop/home/advanced/linenotify/chatroom.htm": {
		"type": "Type",
		"accessToken": "Access Token",
		"oneOnOne": "1-on-1",
		"group": "Group",
		"chatRoomXSetting": "Chat Room $name Setting",
		"tip": {
			"nickname": "Input the nickname of this chat room.",
			"description": "Input the description of this chat room.",
			"type": "The type of this chat room.",
			"accessToken": "The access token of this chat room."
		},
		"popup": {
			"nicknameIsEmpty": "Nickname field can't be empty."
		}
	},
	"html/desktop/home/rules.htm": {
		"ruleOverview": "Rule Overview",
		"noRuleExist": "No rule exists, press left side button to create one.",
		"noCondition": "No condition",
		"noAction": "No action",
		"delayXSecond": "Delay $delay second(s)"
	},
	"html/desktop/home/rules/menu.htm": {
		"addRule": "Add new rule",
		"moveUp": "Move up",
		"moveDown": "Move down",
		"remove": "Remove",
		"copy": "Copy",
		"popup": {
			"reachMaximumAmount": "Reach maximum amount."
		}
	},
	"html/desktop/home/rules/rule.htm": {
		"ruleInfomationSetting": "Rule Information Setting",
		"rule": "Rule",
		"status": "Status",
		"ruleContentSetting": "Rule Content Setting",
		"addCondition": "Add a new Condition:",
		"noCondition": "No Condition exists",
		"addAction": "Add a new Action:",
		"noAction": "No Action exists",
		"selectCondition": "Set a Condition",
		"selectAction": "Set an Action",
		"oneTimeAction": "One Time Action",
		"repaetAction": "Repeat Action",
		"delayXSecondAfterExecution": "Delay $delay second(s) after execution.",
		"setting": "Setting",
		"copy": "Copy",
		"remove": "Remove",
		"tip": {
			"nickname": "Input the nickname of this rule.",
			"description": "Input the description of this rule.",
			"status": "Enable or disable this rule."
		},
		"popup": {
			"reachMaximumAmount": "Reach maximum amount.",
			"nicknameIsEmpty": "Nickname field can't be empty.",
			"conditionAmountIsZero": "The amount of Condition must be greater than or equal to 1.",
			"actionAmountIsZero": "The amount of Action must be greater than or equal to 1.",
			"existErrorRule": "Error(s) occurs in rule(s) (with red border around), please correct the error(s)."
		}
	},
	"html/desktop/home/rules/rule/cai.htm": {
		"aiConditionSetting": "AI Condition Setting",
		"moduleAndChannel": "Module & Channel",
		"operator": "Operator",
		"value": "Value",
		"channel": "Channel",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cci.htm": {
		"discreteInputConditionSetting": "Discrete Input Condition Setting",
		"moduleAndAddress": "Module & Address",
		"interface": "I/O Interface",
		"module": "Module",
		"address": "Address",
		"status": "Status",
		"tip": {
			"moduleAndAddress": "Select the module and address.",
			"status": "Set the value for comparison."
		}
	},
	"html/desktop/home/rules/rule/cco.htm": {
		"coilOutputConditionSetting": "Coil Output Condition Setting",
		"moduleAndAddress": "Module & Address",
		"interface": "I/O Interface",
		"module": "Module",
		"address": "Address",
		"status": "Status",
		"tip": {
			"moduleAndAddress": "Select the module and address.",
			"status": "Set the value for comparison."
		}
	},
	"html/desktop/home/rules/rule/cdi.htm": {
		"diConditionSetting": "DI Condition Setting",
		"moduleAndChannel": "Module & Channel",
		"interface": "I/O Interface",
		"module": "Module",
		"channel": "Channel",
		"status": "Status",
		"tip": {
			"moduleAndChannel": "Select the module and channel.",
			"status": "Set the value for comparison."
		}
	},
	"html/desktop/home/rules/rule/cdic.htm": {
		"diCounterConditionSetting": "DI Counter Condition Setting",
		"moduleAndChannel": "Module & Channel",
		"operator": "Operator",
		"value": "Value",
		"channel": "Channel",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cregister.htm": {
		"registerConditionSetting": "Internal Register Condition Setting",
		"no": "No.",
		"operator": "Operator",
		"value": "Value"
	},
	"html/desktop/home/rules/rule/cri.htm": {
		"inputRegisterConditionSetting": "Input Register Condition Setting",
		"moduleAndAddress": "Module & Address",
		"operator": "Operator",
		"value": "Value",
		"address": "Address",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cro.htm": {
		"holdingRegisterConditionSetting": "Holding Register Condition Setting",
		"moduleAndAddress": "Module & Address",
		"operator": "Operator",
		"value": "Value",
		"address": "Address",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cstatus.htm": {
		"connectionStatusConditionSetting": "Module Connection Status Condition Setting",
		"interface": "I/O Interface",
		"module": "Module",
		"status": "Status",
		"tip": {
			"module": "Select the module.",
			"status": "Set the connection status of this module to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/crule.htm": {
		"ruleStatusConditionSetting": "Rule Status Condition Setting",
		"rule": "Rule",
		"status": "Status",
		"tip": {
			"rule": "Select a pre-set rule.",
			"status": "Set the execution status of this rule to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/cschedule.htm": {
		"scheduleConditionSetting": "Schedule Condition Setting",
		"schedule": "Schedule",
		"status": "Status",
		"tip": {
			"schedule": "Select a pre-set schedule.",
			"status": "Set the schedule status to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/csdcard.htm": {
		"sdCardStatusConditionSetting": "SD Card Status Condition Setting",
		"status": "Status",
		"tip": {
			"status": "Set the SD card status to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/ctimer.htm": {
		"timerConditionSetting": "Timer Condition Setting",
		"timer": "Timer",
		"status": "Status",
		"tip": {
			"timer": "Select a pre-set timer.",
			"status": "Set the timer status to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/cazurestatus.htm": {
		"azureConnectionStatusConditionSetting": "Microsoft Azure Connection Status Condition Setting",
		"status": "Status",
		"tip": {
			"status": "Set up the connection status of Microsoft Azure to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/cbluemixstatus.htm": {
		"bluemixConnectionStatusConditionSetting": "IBM Bluemix Connection Status Condition Setting",
		"status": "Status",
		"tip": {
			"status": "Set up the connection status of IBM Bluemix to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/cbroker.htm": {
		"mqttConnectionStatusConditionSetting": "MQTT Broker Connection Status Condition Setting",
		"status": "Status",
		"tip": {
			"broker": "Select a pre-set broker.",
			"status": "Set up the connection status of this broker to be a Condition."
		}
	},
	"html/desktop/home/rules/rule/cazuresubscribe.htm": {
		"azureSubscribeMessageConditionSetting": "Microsoft Azure Subscribe Message Condition Setting",
		"name": "Name",
		"variableName": "Variable Name",
		"operator": "Operator",
		"value": "Value",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cbluemixsubscribe.htm": {
		"bluemixSubscribeMessageConditionSetting": "IBM Bluemix Subscribe Message Condition Setting",
		"name": "Name",
		"commandName": "Command Name",
		"variableName": "Variable Name",
		"operator": "Operator",
		"value": "Value",
		"no": "No."
	},
	"html/desktop/home/rules/rule/ctopic.htm": {
		"mqttSubscribeTopicConditionSetting": "MQTT Subscribe Topic Condition Setting",
		"operator": "Operator",
		"value": "Value",
		"no": "No."
	},
	"html/desktop/home/rules/rule/cftp.htm": {
		"ftpUploadStatusConditionSetting": "FTP Upload Status Condition Setting",
		"status": "Status",
		"uploadFailedContinuingXHours": "Upload Failed Continuing $input Hour(s)"
	},
	"html/desktop/home/rules/rule/csignal.htm": {
		"signalStrengthConditionSetting": "Mobile Network Signal Strength Condition Setting",
		"unit": "Unit",
		"percent": "Percent",
		"operator": "Operator",
		"value": "Value",
		"bit": "Bit"
	},
	"html/desktop/home/rules/rule/aao.htm": {
		"aoActionSetting": "AO Action Setting",
		"moduleAndChannel": "Module & Channel",
		"operator": "Operator",
		"value": "Value",
		"channel": "Channel",
		"no": "No."
	},
	"html/desktop/home/rules/rule/aro.htm": {
		"holdingRegisterActionSetting": "Holding Register Action Setting",
		"moduleAndAddress": "Module & Address",
		"operator": "Operator",
		"value": "Value",
		"address": "Address",
		"no": "No."
	},
	"html/desktop/home/rules/rule/ado.htm": {
		"doActionSetting": "DO Action Setting",
		"moduleAndChannel": "Module & Channel",
		"interface": "I/O Interface",
		"module": "Module",
		"channel": "Channel",
		"status": "Status",
		"pulseOutput": "Pulse Output",
		"tip": {
			"moduleAndChannel": "Select the module and channel.",
			"status": "Set the status of this channel."
		}
	},
	"html/desktop/home/rules/rule/adic.htm": {
		"diCounterActionSetting": "DI Counter Action Setting",
		"moduleAndChannel": "Module & Channel",
		"interface": "I/O Interface",
		"module": "Module",
		"channel": "Channel",
		"action": "Action",
		"tip": {
			"moduleAndChannel": "Select the module and channel.",
			"action": "Reset the counter value of the selected DI channel."
		}
	},
	"html/desktop/home/rules/rule/aco.htm": {
		"coilOutputActionSetting": "Coil Output Action Setting",
		"moduleAndAddress": "Module & Address",
		"interface": "I/O Interface",
		"module": "Module",
		"channel": "Channel",
		"status": "Status",
		"tip": {
			"moduleAndAddress": "Select the module and address.",
			"status": "Set the status of this Coil Output."
		}
	},
	"html/desktop/home/rules/rule/aemail.htm": {
		"emailActionSetting": "Email Action Setting",
		"email": "Email",
		"action": "Action",
		"emailInformation": "Email Information",
		"receiverEmail": "Receiver Email Address",
		"subject": "Subject",
		"content": "Content",
		"tip": {
			"email": "Select a pre-set Email.",
			"action": "Send the selected Email."
		}
	},
	"html/desktop/home/rules/rule/acgi.htm": {
		"cgiCommandActionSetting": "CGI Command Action Setting",
		"cgiCommand": "CGI Command",
		"server": "Server",
		"command": "Command",
		"action": "Action",
		"tip": {
			"cgiCommand": "Select a pre-set CGI command.",
			"action": "Send the selected CGI Command."
		}
	},
	"html/desktop/home/rules/rule/atimer.htm": {
		"timerActionSetting": "Timer Action Setting",
		"timer": "Timer",
		"action": "Action",
		"resetDescription": "The Reset action will reset the Timer and stop running the Timer.",
		"startDescription": "The Start action will start to run the Timer or restart when the Timer is running.",
		"pauseDescription": "The Pause action will pause the running Timer.",
		"resumeDescription": "The Resume action will resume the stopped Timer.",
		"tip": {
			"timer": "Select a pre-set timer.",
			"action": "Change the status of this timer."
		}
	},
	"html/desktop/home/rules/rule/aschedule.htm": {
		"scheduleActionSetting": "Schedule Action Setting",
		"schedule": "Schedule",
		"action": "Action",
		"tip": {
			"schedule": "Select a pre-set schedule.",
			"action": "Change the status of this schedule."
		}
	},
	"html/desktop/home/rules/rule/arule.htm": {
		"ruleStatusActionSetting": "Rule Status Action Setting",
		"rule": "Rule",
		"action": "Action",
		"tip": {
			"rule": "Select a pre-set rule.",
			"action": "Change the execution status of this rule."
		}
	},
	"html/desktop/home/rules/rule/aregister.htm": {
		"registerActionSetting": "Internal Register Action Setting",
		"no": "No.",
		"operator": "Operator",
		"value": "Value"
	},
	"html/desktop/home/rules/rule/alogger.htm": {
		"dataLoggerActionSetting": "Data Logger Action Setting",
		"action": "Action",
		"tip": {
			"action": "Modify the status of the data logger. You can perform a One-Time Log."
		}
	},
	"html/desktop/home/rules/rule/asms.htm": {
		"smsAlarmActionSetting": "SMS Alarm Action Setting",
		"smsAlarm": "SMS Alarm",
		"action": "Action",
		"send": "Send",
		"smsAlarmInformation": "SMS Alarm Information",
		"phoneNumbers": "Phone Numbers",
		"message": "Message",
		"tip": {
			"smsAlarm": "Select a pre-set SMS alarm.",
			"action": "Send the selected SMS alarm."
		}
	},
	"html/desktop/home/rules/rule/asnmp.htm": {
		"snmpTrapActionSetting": "SNMP Trap Action Setting",
		"trap": "Trap",
		"action": "Action",
		"send": "Send",
		"snmpTrapInformation": "SNMP Trap Information",
		"message": "Variable Bindings",
		"tip": {
			"trap": "Select a pre-set SNMP Trap.",
			"action": "Send the selected SNMP Trap.",
			"message": "The variable that is binded in the SNMP Trap to be sent."
		}
	},
	"html/desktop/home/rules/rule/aazurestatus.htm": {
		"azureFunctionStatusActionSetting": "Microsoft Azure Function Status Action Setting",
		"status": "Status",
		"tip": {
			"status": "Change the function status of Microsoft Azure."
		}
	},
	"html/desktop/home/rules/rule/abluemixstatus.htm": {
		"bluemixFunctionStatusActionSetting": "IBM Bluemix Function Status Action Setting",
		"status": "Status",
		"tip": {
			"status": "Change the function status of IBM Bluemix."
		}
	},
	"html/desktop/home/rules/rule/abroker.htm": {
		"mqttBrokerFunctionStatusActionSetting": "MQTT Broker Function Status Action Setting",
		"status": "Status",
		"tip": {
			"broker": "Select a pre-set broker.",
			"status": "Change the function status of this broker."
		}
	},
	"html/desktop/home/rules/rule/aazurepublish.htm": {
		"azurePublishMessageActionSetting": "Microsoft Azure Publish Message Action Setting",
		"message": "Message",
		"action": "Action",
		"publish": "Publish",
		"azurePublishMessageInformation": "Microsoft Azure Publish Message Information",
		"content": "Content",
		"tip": {
			"message": "Select a pre-set message.",
			"action": "Send the selected message.",
			"content": "The content of message to be sent"
		}
	},
	"html/desktop/home/rules/rule/abluemixpublish.htm": {
		"bluemixPublishMessageActionSetting": "IBM Bluemix Publish Message Action Setting",
		"message": "Message",
		"action": "Action",
		"publish": "Publish",
		"bluemixPublishMessageInformation": "IBM Bluemix Publish Message Information",
		"content": "Content",
		"tip": {
			"message": "Select a pre-set message.",
			"action": "Send the selected message.",
			"content": "The content of message to be sent"
		}
	},
	"html/desktop/home/rules/rule/amessage.htm": {
		"mqttPublishMessageActionSetting": "MQTT Publish Message Action Setting",
		"message": "Message",
		"action": "Action",
		"publish": "Publish",
		"mqttPublishMessageInformation": "MQTT Publish Message Information",
		"content": "Content",
		"tip": {
			"message": "Select a pre-set message.",
			"action": "Send the selected message.",
			"topic": "The Topic of the selected message",
			"content": "The content of message to be sent"
		}
	},
	"html/desktop/home/rules/rule/alinenotify.htm": {
		"lineNotifyActionSetting": "LINE Notify Action Setting",
		"message": "Message",
		"action": "Action",
		"messageInformation": "Message Information",
		"chatRoom": "Chat Room",
		"content": "Content",
		"tip": {
			"message": "Select a pre-set message.",
			"action": "Send the selected message."
		}
	},
	"html/desktop/home/status.htm": {
		"none": "None"
	},
	"html/desktop/home/status/menu.htm": {
		"internalRegister": "Internal Register",
		"customizeStatus": "Channel Status",
		"connecting": "Connecting",
		"offline": "Offline",
		"online": "Online",
		"other": "Other",
		"eventLogger": "Event Logger",
		"fileList": "檔案清單"
	},
	"html/desktop/home/status/default.htm": {
		"internalRegister": "Internal Register",
		"no": "No.",
		"channel": "Ch.",
		"address": "Addr.",
		"counter": "Counter:",
		"none": "None",
		"diCounterX": "DI Counter $channel",
		"internalRegisterX": "Internal Register $no"
	},
	"html/desktop/home/status/event.htm": {
		"eventLogger": "Event Logger",
		"time": "Time",
		"type": "Type",
		"message": "Message",
		"noEventLog": "No event logs."
	},
	"html/desktop/home/status/file.htm": {
		"fileList": "檔案清單",
		"list": "清單",
		"thumbnail": "縮圖",
		"reload": "重新整理",
		"fileName": "檔名",
		"fileSize": "檔案大小",
		"time": "時間",
		"noFile": "無檔案",
		"loading": "載入中..."
	}
});