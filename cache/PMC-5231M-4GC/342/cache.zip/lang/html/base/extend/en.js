$.extend(true, Lang, {
	"global": {
		"ctX": "CT$no",
		"submeterX": "Submeter$no",
		"phaseX": "Phase $no",
		"totalOrAverage": "Total / Average",
		"basicValue": "Basic Values",
		"statisticsValue": "Statistical Values",
		"ioInformation": "I/O Information",
		"otherInformation": "Other Information",
	}
});